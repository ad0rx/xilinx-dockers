"""Module for handling AIM MIL devices

This module contains classes and funcions
for detection, initialization and
usage of AIM MIL devices
"""
import stat

__author__ = 'Martin Haag'

import aim_mil.library
import ctypes
import array
from ctypes import *
from aim_mil.mil_bindings import *
from aim_mil.error import *
import aim_mil.bc
import aim_mil.hs_bc
import aim_mil.rt
import aim_mil.bm
import time

import bisect
from itertools import groupby
from operator import itemgetter

class IdManager():
    def __init__(self, count):
        self._count = count
        self._ids   = list(range(count))

    def debug(self):
        for k, g in groupby(enumerate(self._ids), lambda ix : ix[0] - ix[1]):
            print( list(map(itemgetter(1), g)))

    def find_id_range(self, count):
        for k, g in groupby(enumerate(self._ids), lambda ix : ix[0] - ix[1]):
            sub_keys = list(map(itemgetter(1), g))
            if len(sub_keys)>count:
                return sub_keys[0]

    def alloc(self, count):
        first_id       = self.find_id_range(count)
        first_id_index = self._ids.index(first_id)
        del self._ids[first_id_index:first_id_index+count]
        return first_id

    def free(self, id, count ):
        free_ids = list(range(id, id+count))
        for id in free_ids:
            bisect.insort_left(self._ids, id)

class Host(object):
    """
    This class represents a host that provides
    AIM MIL devices for the user.
    A host can either be the local computer or a
    remote computer that can be accessed via AIM Network server
    """

    def __init__(self, url='local'):
        """
        Creates a host instance.
        The API library of the local system is loaded and a connection
        to the specified host system either local or remote is established.
        After connection is successfully established, the host system is searched for
        AIM MIL devices
        :param url: URL of the host system to connect to
        :return: returns an instance of class Host
        """
        self._api = aim_mil.library.Api.instance()
        self._num_devices = ctypes.c_short(0)
        self._url = url.encode(encoding="ascii")
        self._devices = []

        if url == 'local':
            self._num_devices = ctypes.c_short(self._api.lib.ApiInit())
            #print("device.py found {} devices".format(self._num_devices))
            self._remote = False
        else:
            res = self._api.lib.ApiConnectToServer(self._url, ctypes.byref(self._num_devices))
            if res != API_OK:
                raise Exception("Error: ApiConnectToServer: %s" % self.api.error(res))
            self._remote = True

        # disable error message box
        self._api.lib.ApiSetDllDbgLevel(DBG_ERROR | DBG_PARAMCHK)

        for device_id in range(0, self._num_devices.value):
                    self._devices.append(Device(self, device_id))

    def __del__(self):
        if self._remote:
            self._api.lib.ApiDisconnectFromServer(self._url)
        else:
            self._api.lib.ApiExit()


    @property
    def num_devices(self):
        """
        :return: Returns number of AIM MIL devices on the host
        :rtype : int
        """
        return self._num_devices.value

    @property
    def devices(self):
        """
        Get AIM MIL devices of the host
        :return: returns a list of class Device instances of the host
        """
        return self._devices[0:len(self._devices)]

    @property
    def url(self):
        """
        Get URL of host
        :return: returns URL string of host
        """
        return self._url

    @property
    def api(self):
        """
        Get API object of host
        :return: returns class Api instance the host uses for controlling devices
        """
        return self._api


class DeviceMemory(object):
    def __init__(self, device, stream ):
        self._device = device
        self._stream = stream

    def write_uint32(self, type, offset, value ):
        return self.__write_value(type, offset, value, 4, 1)

    def write_uint32_block(self, type, offset, value, count ):
        return self.__write_value(type, offset, value, 4, count)

    def write_uint16(self, type, offset, value ):
        return self.__write_value(type, offset, value, 2, 1)

    def write_uint16_block(self, type, offset, value, count ):
        return self.__write_value(type, offset, value, 2, count)

    def write_uint8(self, type, offset, value ):
        return self.__write_value(type, offset, value, 1, 1)

    def write_uint8_block(self, type, offset, value, count ):
        return self.__write_value(type, offset, value, 1, count)


    def read_uint32(self, type, offset ):
        return self.__read_value(type, offset, 4, 1)

    def read_uint32_block(self, type, offset, count ):
        return self.__read_value(type, offset, 4, count)

    def read_uint16(self, type, offset ):
        return self.__read_value(type, offset, 2, 1)

    def read_uint16_block(self, type, offset, count ):
        return self.__read_value(type, offset, 2, count)

    def read_uint8(self, type, offset ):
        return self.__read_value(type, offset, 1, 1)

    def read_uint8_block(self, type, offset, count ):
        return self.__read_value(type, offset, 1, count)


    def __write_value(self, type, offset, value, width, count):
        written       = AiUInt32(0)

        if width == 4:
            data_write  = (AiUInt32 * count)()
        elif width == 2:
            data_write  = (AiUInt16 * count)()
        elif width == 1:
            data_write  = (AiUInt8 * count)()
        else:
            raise Exception("Invalid type")

        if count == 1:
            data_write[0] = value
        else:
            for i in range(count):
                data_write[i] = value[i]

        if( count == 1 ):
            ret = self._device.host.api.lib.ApiWriteMemData( self._stream.handle, type, offset, width, ctypes.byref(data_write) )

            if ret != API_OK:
                raise AimMilError(ret, "Error: ApiWriteMemData: %s." % self._stream.api.error(ret))
        else:
            ret = self._device.host.api.lib.ApiWriteBlockMemData( self._stream.handle,
                                                       type,
                                                       offset,
                                                       width,
                                                       ctypes.byref(data_write),
                                                       count,
                                                       ctypes.byref(written) )

            if ret != API_OK:
                raise AimMilError(ret, "Error: ApiWriteBlockMemData: %s." % self._stream.api.error(ret))

        return

    def __read_value(self, type, offset, width, count):
        read       = AiUInt32(0)

        if width == 4:
            data_read  = (AiUInt32 * count)()
        elif width == 2:
            data_read  = (AiUInt16 * count)()
        elif width == 1:
            data_read  = (AiUInt8 * count)()
        else:
            raise Exception("Invalid type")

        if( count == 1 ):
            ret = self._device.host.api.lib.ApiReadMemData( self._stream.handle, type, offset, width, ctypes.byref(data_read) )

            if ret != API_OK:
                raise AimMilError(ret, "Error: ApiReadBlockMemData: %s." % self._stream.api.error(ret))
        else:
            ret = self._device.host.api.lib.ApiReadBlockMemData( self._stream.handle,
                                                       type,
                                                       offset,
                                                       width,
                                                       ctypes.byref(data_read),
                                                       count,
                                                       ctypes.byref(read) )

            if ret != API_OK:
                raise AimMilError(ret, "Error: ApiReadBlockMemData: %s." % self._stream.api.error(ret))

        return data_read


class Device(object):
    """
    This class represents an AIM MIL device
    """

    def __init__(self, host, module_id):
        """
        Constructor for an AIM MIL device.
        :param host: The host the device is situated on
        :param module_id: the ID of the device
        :return: returns an instance of class Device
        """
        self._host = host
        self._id = module_id
        self._streams = []
        self._serial = -1
        self._boardname = ''
        self._free_sim_buffers = set()
        self._version_info = None

    @property
    def id(self):
        """
        Get device ID
        :return: returns the device ID as int
        """
        return self._id

    @property
    def serial(self):
        """
        Get device serial number
        :return: returns the device serial number as int
        """
        return self._serial

    def init(self,amplitude=128):
        """
        Initializes the device.
        This function must be called first before actually using the device.
        It will query the device for its properties like serial number and name
        """
      
        self._boardname        = "UNKNOWN"
        self._init_info        = TY_API_INI_INFO()
        self._driver_info      = TY_API_DRIVER_INFO()
        self._version_info     = TY_API_VERSION_INFO()
        self._serial           = 0
        self._free_sim_buffers = set(range(1, 512))
        self._free_hs_sim_buffers = set(range(1, 512))

        # -- we have at least one stream, open it to check how many streams the device has ---
        first_stream = Stream(self, 1)
        first_stream.open()

        # -- Initialize device global values ---
        print("In device.init()")
        self.init_board(first_stream._handle)
        self.init_driver_info(first_stream._handle)
        self.init_name(first_stream._handle)
        self.init_boardinfo(first_stream._handle)
        self.init_versions(first_stream._handle)
        self.init_amplitude(first_stream._handle,amplitude)

        # -- Close first stream ---
        first_stream.close()

        # -- Append streams ---
        self._streams.append(Stream(self, 1))
        for i in range(2,self._init_info.chns+1):
          self._streams.append(Stream(self, self._init_info.chns))  #LISA -- Isn't this AIM code wrong?  Shouldn't i be mentioned here?
        #if self._init_info.chns > 1:
            #self._streams.append(Stream(self, self._init_info.chns))
    
    def init_board(self, handle):
        res = self._host.api.lib.ApiCmdIni(handle, API_INIT_MODE_READ, ctypes.byref(self._init_info))

        if res != API_OK:
            raise Exception("Error: ApiCmdIni: %s." % self.host.api.error(res))

    def init_amplitude(self, handle,amplitude):
        print("SETTING THE AMPLITUDE FOR AIM TO {}".format(amplitude))
        res = self._host.api.lib.ApiCmdCalXmtCon(handle, 0, API_CAL_XMT_FULL_RANGE_PRI, amplitude)

        if res != API_OK:
            raise Exception("Error: ApiCmdCalXmtCon: %s." % self.host.api.error(res))

         
         
    def init_driver_info(self, handle):
        res = self._host.api.lib.ApiGetDriverInfo(handle, ctypes.byref(self._driver_info))

        if res != API_OK:
            raise Exception("Error: ApiGetDriverInfo: %s." % self.host.api.error(res))


    def init_name(self, handle):
        self.host.api.lib.ApiGetBoardName.restype = ctypes.c_char_p
        self._boardname = self.host.api.lib.ApiGetBoardName(handle)

    def init_boardinfo(self, handle):

        board_info = (AiUInt32 * TY_BOARD_INFO_MAX)()

        self.host.api.lib.ApiCmdSysGetBoardInfo.restype = AiReturn
        res = self.host.api.lib.ApiCmdSysGetBoardInfo(handle, 0, TY_BOARD_INFO_MAX, ctypes.byref(board_info), None)

        if res != API_OK:
            raise Exception("Error: ApiCmdSysGetBoardInfo: %s." % self.host.api.error(res))


        self._serial = board_info[TY_BOARD_INFO_SERIAL]
        self._num_channels = board_info[TY_BOARD_INFO_CHANNEL_COUNT]
        self._num_discretes = board_info[TY_BOARD_INFO_DISCRETE_CNT]
        print("The ability to set amplitudes is {}".format(board_info[TY_BOARD_INFO_CHANGE_AMPL]))
        

    def init_versions(self, handle):
        compatibility = AiUInt8(0)

        res = self.host.api.lib.ApiReadBSPVersionEx(handle, ctypes.byref(self._version_info), ctypes.byref(compatibility))

        if res != API_OK:
            raise Exception("Error: ApiReadBSPVersionEx: %s." % self.host.api.error(res))

        self._serial = self._version_info.ul_BoardSerialNo

    def get_mem_partition(self):
        mem_partition = TY_API_GET_MEM_INFO()

        res = self.host.api.lib.ApiCmdSysGetMemPartition(self.streams[0].handle, 0, byref(mem_partition))

        if res != API_OK:
            raise Exception("Error: ApiCmdSysGetMemPartition: %s." % self.host.api.error(res))

        return mem_partition

    def set_mem_partition(self, mem_partition ):
        status   = AiUInt32()
        mem_used = (AiUInt32 * 2)()

        res = self.host.api.lib.ApiCmdSysSetMemPartition(self.streams[0].handle, 0, byref(mem_partition), byref(status), byref(mem_used))

        if res != API_OK:
            raise Exception("Error: ApiCmdSysSetMemPartition: %s." % self.host.api.error(res))

        if status.value != API_MEM_PART_OK:
            raise Exception("Error: ApiCmdSysSetMemPartition: status = %d." % (status.value))

    def convert_get_to_set_mempartition(self, get_mem_partition):
        set_mem_partition = TY_API_SET_MEM_INFO()

        ctypes.memmove( byref(set_mem_partition.ax_BiuCnt),  byref(get_mem_partition.ax_BiuCnt),  sizeof(get_mem_partition.ax_BiuCnt ) )
        ctypes.memmove( byref(set_mem_partition.ax_BiuSize), byref(get_mem_partition.ax_BiuSize), sizeof(get_mem_partition.ax_BiuSize) )

        set_mem_partition.aul_SimBufSize[0] = get_mem_partition.x_Sim[0].ul_BufSize
        if self.streams[0].is_hs:
            # On HS boards the second PBI value is used as HS simbuf size
            # @AIMFIXME: This will not work with EFA-2 combined boards
            set_mem_partition.aul_SimBufSize[1] = get_mem_partition.x_Sim[0].ul_HsBufSize
        else:
            set_mem_partition.aul_SimBufSize[1] = get_mem_partition.x_Sim[1].ul_BufSize

        return set_mem_partition

    def utility(self, command, values ):
        # We support only commands 0,1,4,5,6,7,8 because command 2,3 have different return values
        in_count    = AiUInt8(len(values) + 1)
        out_count   = AiUInt8(1)

        in_values   = (AiUInt32 * in_count.value )()
        out_values  = (AiUInt32 * out_count.value)()

        in_values[0] = command

        for count, value in enumerate(values):
            in_values[count+1] = value

        res = self.host.api.lib.ApiCmdUtility(self.streams[0].handle, in_count, byref(out_count), byref(in_values), byref(out_values))

        if res != API_OK:
            raise Exception("Error: ApiCmdUtility: %s." % self.host.api.error(res))

        if out_count.value != 1:
            raise Exception("Error: ApiCmdUtility: invalid out_count %d." % (out_count.value))

        return out_values[0]

    def switch(self, type, key=None):
        ctype      = AiUInt8(type)
        creserved  = AiUInt8(0)
        ckey       = (AiUInt32 * 4 )()

        if key == None:
            for i in range(4):
                ckey[i] = 0
        else:
            for i, value in enumerate(key):
                ckey[i] = value

        res = self.host.api.lib.Api3910CmdEfSwitchEfaEfex(self.streams[0].handle, ctype, byref(ckey), byref(creserved))

        if res != API_OK:
            raise Exception("Error: Api3910CmdEfSwitchEfaEfex: %s." % self.host.api.error(res))

    @property
    def host(self):
        """
        Get host the device situated on
        :return: returns the class Host instance the device belongs to
        """
        return self._host

    @property
    def streams(self):
        """
        Get the streams of the device
        :return: returns a list of class Stream instances
        """
        return self._streams[0:len(self._streams)]

    @property
    def streams_on_pbi(self):
        """
        Get the count of available streams of the device pbi
        :return: returns a tuple with the count for pbi1 and pbi2
        """
        bt_pbi1 = (self._init_info.board_type)     & 0xFFFF
        bt_pbi2 = (self._init_info.board_type>>16) & 0xFFFF

        count_list = []
        for bt_pbi in [bt_pbi1, bt_pbi2]:
            count = 0
            for i in range(2):
                bt = ( (bt_pbi >> (i*8) ) & 0x000000F0)

                if bt == 0x10:
                    count += 1
                elif bt == 0x30:
                    continue
                elif bt == 0x70:
                    continue
                elif bt == 0xA0:
                    count += 2

            count_list.append(count)

        return count_list


    @property
    def boardname(self):
        """
        Get name of board
        :return: returns the board name as string
        """
        return self._boardname

    @property
    def versions(self):
        """
        Get version overview of the board
        :return: returns instance of class TY_API_VERSION_INFO
        """
        return self._version_info

    @property
    def novram_offset_board_type(self):
        platform = self._init_info.board_config & 0xFF
        group    = self._driver_info.uc_DeviceGroup

        if platform == AI_PLATFORM_PC_CARD:
            # No rule without exception => PC card is in group AMC but has offset like AyX
            return 0x2C
        elif group in (AI_DEVICE_AYI, AI_DEVICE_AYX, AI_DEVICE_USB):
            return 0x2C
        elif group in (AI_DEVICE_AMC, AI_DEVICE_AMC_ASP, AI_DEVICE_AYE, AI_DEVICE_AYE_ASP, AI_DEVICE_AYS_ASP, AI_DEVICE_AYS, AI_DEVICE_ZYNQMP_ASP ):
            return 0x10

        raise Exception("Error: offset not found")

    @property
    def novram_offset_board_config(self):
        platform = self._init_info.board_config & 0xFF
        group    = self._driver_info.uc_DeviceGroup

        if platform == AI_PLATFORM_PC_CARD:
            # No rule without exception => PC card is in group AMC but has offset like AyX
            return 0x28
        elif group in (AI_DEVICE_AYI, AI_DEVICE_AYX, AI_DEVICE_USB):
            return 0x28
        elif group in (AI_DEVICE_AMC, AI_DEVICE_AMC_ASP, AI_DEVICE_AYE, AI_DEVICE_AYE_ASP, AI_DEVICE_AYS_ASP, AI_DEVICE_AYS, AI_DEVICE_ZYNQMP_ASP ):
            return 0x08

        raise Exception("Error: offset not found")




    def alloc_buffer(self):
        """
        Allocate a buffer of the device.
        The buffer will have size for 32 MIL data words (=64 Byte)
        :return: returns ID of allocated buffer
        """
        return self._free_sim_buffers.pop()

    def free_buffer(self, buffer_id):
        """
        Free a buffer
        :param buffer_id: ID of the buffer to free
        """
        self._free_sim_buffers.add(buffer_id)

    def alloc_hs_buffer(self):
        """
        Allocate a buffer of the device.
        The buffer will have size for 32 MIL data words (=64 Byte)
        :return: returns ID of allocated buffer
        """
        return self._free_hs_sim_buffers.pop()

    def free_hs_buffer(self, buffer_id):
        """
        Free a buffer
        :param buffer_id: ID of the buffer to free
        """
        self._free_hs_sim_buffers.add(buffer_id)

    def capabilities(self, start=0, count=TY_BOARD_INFO_MAX ):
        read = AiUInt32()
        raw_data = array.array('I', [0] * count)

        ret = self._streams[0].api.lib.ApiCmdSysGetBoardInfo(self._streams[0].handle, start, count, ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(AiUInt32)), ctypes.byref(read))

        if ret != API_OK:
            raise AimMilError(ret, "Error: ApiCmdSysGetBoardInfo: %s." %  self._streams[0].api.error(ret))

        if count != read.value:
            raise AimMilValueMissmatch( count, read.value, "Error: ApiCmdSysGetBoardInfo: Not enough data read %d != %d" % (count,read.value) )

        return raw_data.tolist()

    def set_time(self, day, hour, minute, second ):
        irig_time = TY_API_IRIG_TIME()
        irig_time.day = day
        irig_time.hour = hour
        irig_time.minute = minute
        irig_time.second = second

        ret = self.host.api.lib.ApiCmdSetIrigTime(self.streams[0].handle, ctypes.byref(irig_time))

        if ret != API_OK:
            raise AimMilError(ret, "Error: ApiCmdSetIrigTime: %s." %  self._streams[0].api.error(ret))

        time.sleep(3)

    def is_full_function(self):
        return self.capabilities()[TY_BOARD_INFO_APPLICATION_TYPE] == 0

    def is_simulator_only(self):
        return ((self.capabilities()[TY_BOARD_INFO_APPLICATION_TYPE] & 1) == 1 )

    def is_single_function(self):
        return ((self.capabilities()[TY_BOARD_INFO_APPLICATION_TYPE] & 2) == 2 )

    def is_embedded(self):
        return ((self.capabilities()[TY_BOARD_INFO_APPLICATION_TYPE] & 4) == 4 )

    def is_no_replay_no_error_injection(self):
        return ((self.capabilities()[TY_BOARD_INFO_APPLICATION_TYPE] & 8) == 8 )

    def is_full_function_embedded(self):
        return (((self.capabilities()[TY_BOARD_INFO_APPLICATION_TYPE] & 4) == 4) and not self.is_simulator_only() and not self.is_single_function() )

    def is_simulator_only_embedded(self):
        return (((self.capabilities()[TY_BOARD_INFO_APPLICATION_TYPE] & 4) == 4) and self.is_simulator_only() )

    def is_single_function_embedded(self):
        return (((self.capabilities()[TY_BOARD_INFO_APPLICATION_TYPE] & 4) == 4) and self.is_single_function() )

    def is_error_injection_supported(self):
        return ( not self.is_embedded() and not self.is_no_replay_no_error_injection())

class Stream(object):
    """
    This class represents one specific stream of an
    AIM MIL device
    """

    def __init__(self, device, stream_id):
        """
        Constructor for class Stream
        The corresponding stream will be re-set when this constructor is executed
        :param device: the class Device instance the stream belongs to
        :param stream_id: the ID of the stream
        :return: instance of class Stream
        """
        self._device = device
        self._id = stream_id
        self._handle = AiUInt32(-1)
        self._api = device.host.api
        self._free_xfer_ids = set()
        self._transfers = []
        self._acyc_transfers = []
        self._framing = None
        self._acyc_framing = None
        self._remote_terminals = []
        self._monitor_queue = None
        self._monitor_recording = None
        self._monitor_hs_recording = None
        self._is_hs  = False
        self._is_multichannel = False
        self._ls_biu = None
        self._hs_biu = None
        self._pbi    = None

    def open(self):
        """
        Opens the stream.
        This function has to be called first before the stream can be used
        """
        if self._handle.value == AiUInt32(-1).value:
            open_parameters = ty_api_open()
            open_parameters.ul_Module = self._device.id
            open_parameters.ul_Stream = self._id
            open_parameters.ac_SrvName = self._device.host.url

            res = self._api.lib.ApiOpenEx(ctypes.byref(open_parameters), ctypes.byref(self._handle))

            if res != 0:
                raise Exception("Error: ApiOpenEx: %s." % self._api.error(res))

            self.open_initialize_biu_info()

    def is_biu_multichannel(self, logical_biu):
        current_logical_biu = 1
        for i in range(8):
            bt = ( (self._device._init_info.board_type >> (i*8) ) & 0x000000F0)

            if bt == 0x10:
                current_logical_biu += 1
            elif bt == 0x30:
                current_logical_biu += 1
            elif bt == 0x70:
                current_logical_biu += 1
            elif bt == 0xA0:
                current_logical_biu += 2

            if current_logical_biu > logical_biu:
                if bt == 0xA0:
                    return True
                else:
                    return False
        raise Exception("Invalid biu (%d %d %d %x) "  % (logical_biu, current_logical_biu, i, bt))


    def open_initialize_biu_info(self):
        self._pbi = 1 if self._id >  self._device.streams_on_pbi[0] else 0

        if self._device._init_info.prot == API_PROTOCOL_1553:
            self._ls_biu = self._id
            self._hs_biu = None
            self._is_hs  = False
            self._is_multichannel = self.is_biu_multichannel(self._ls_biu)


        if self._device._init_info.prot in (API_PROTOCOL_3910, API_PROTOCOL_EFEX):
            if self._id == 1:
                self._ls_biu = 1
                self._hs_biu = 2
                self._is_hs  = True
                self._is_multichannel = False
            else:
                self._ls_biu = 3
                self._hs_biu = 4
                self._is_hs  = True
                self._is_multichannel = False

        if self._device._init_info.prot in (API_PROTOCOL_1553_3910, API_PROTOCOL_1553_EFEX):
            if self._id < self._device._init_info.chns:
                self._ls_biu = self._id
                self._hs_biu = None
                self._is_hs  = False
                self._is_multichannel = self.is_biu_multichannel(self._ls_biu)
            else:
                self._ls_biu = self._id
                self._hs_biu = self._id + 1
                self._is_hs  = True
                self._is_multichannel = False


    def reset(self):
        """
        Reset the stream.
        """
        reset_info = TY_API_RESET_INFO()

        res = self._api.lib.ApiCmdReset(self._handle, 0, 0, ctypes.byref(reset_info))

        if res != 0:
            raise Exception("Error: ApiCmdReset: %s." % self._api.error(res))
          
    def set_response_timeout(self, responsetimeout=14):  
      res = self._api.lib.ApiCmdDefRespTout(self._handle, 0, ctypes.byref(AiFloat(responsetimeout)))
          
      if res != API_OK:
        print("\n\n%%%%%Setting the responsetimeout failed")
        raise Exception("Error: ApiCmdDefRespTout: %s." % self._api.error(res))
      else :
        print("Successfully set the response timeout to {}".format(responsetimeout))
          
          

    def close(self):
        """
        Closes the stream
        The stream cannot be used any more after this function is called
        """
        if self._handle.value != AiUInt32(-1).value:
            res = self._api.lib.ApiClose(self._handle)

            if res != 0:
                raise Exception("Error: ApiClose: %s." % self._api.error(res))

            self._handle.value = -1

 
    def enable_calibration_signal(self, bus=API_CAL_BUS_PRIMARY):
        res = self.api.lib.ApiCmdCalSigCon(self.handle, 0, bus, API_ENA)
        if res != API_OK:
            raise Exception("Error: ApiCmdCalSigCon (enable): %s." % self.api.error(res))

    def disable_calibration_signal(self, bus=API_CAL_BUS_PRIMARY):
        res = self.api.lib.ApiCmdCalSigCon(self.handle, 0, bus, API_DIS)
        if res != API_OK:
            raise Exception("Error: ApiCmdCalSigCon (disable): %s." % self.api.error(res))

    @property
    def device(self):
        """
        Get device the stream belongs to
        :return: instance of class Device
        """
        return self._device

    @property
    def handle(self):
        """
        Get handle of the stream
        :return: instance of AiUInt32
        """
        return self._handle

    @property
    def is_hs(self):
        return self._is_hs

    @property
    def ls_biu(self):
        return self._ls_biu

    @property
    def hs_biu(self):
        return self._hs_biu

    @property
    def is_multichannel(self):
        return self._is_multichannel

    @property
    def api(self):
        """
        Get API object the stream is associated with
        :return: instance of class Api
        """
        return self._api

    
    @property
    def id(self):
        """
        Get ID of stream.
        :return: ID of the stream as int
        """
        return self._id

    def selftest(self):
        """
        Performs a self test of the stream.
        :return: dictionary with result and status bytes of ApiCmdBite API function
        """
        bite_status = (AiUInt8 * 2)()

        ret = self._api.lib.ApiCmdBite(self.handle, 0, API_BITE_ALL, ctypes.byref(bite_status))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBite: %s." % self._api.error(ret))

        result = ((bite_status[0] or bite_status[1]) and 'Failed') or 'Passed'
        return {'Result': result, 'Status Byte 1': bite_status[0], 'Status Byte 2': bite_status[1]}

    def set_coupling(self, coupling):
        """
        Sets the coupling of the stream on primary and secondary bus.
        :param coupling: Coupling mode as defined for ApiCmdCalCplCon API function
        :return:
        """
        ret = self._api.lib.ApiCmdCalCplCon(self._handle, 0, API_CAL_BUS_PRIMARY, coupling)

        if ret != API_OK:
            raise Exception("Error: ApiCmdCalCplCon on first bus: %s." % self._api.error(ret))

        ret = self._api.lib.ApiCmdCalCplCon(self._handle, 0, API_CAL_BUS_SECONDARY, coupling)

        if ret != API_OK:
            raise Exception("Error: ApiCmdCalCplCon on second bus: %s." % self._api.error(ret))

    def init_bc(self,wantbbus=False,redundant_bus=False):
        """
        Initializes the Bus controller of the stream.
        All transfers of the stream and the framing are released
        """
        for transfer in self._transfers:
            transfer.release()
        for transfer in self._acyc_transfers:
            transfer.release()
        del self._transfers[:]
        del self._acyc_transfers[:]
        del self._framing
        self._framing = None
        self._acyc_framing = None
        
        if wantbbus:
          mGlobalStartBus = API_BC_XFER_BUS_SECONDARY
        else:
          mGlobalStartBus = API_BC_XFER_BUS_PRIMARY
      
        if redundant_bus:
          mRetryOption=API_RETRY_1ALT
        else:
          mRetryOption=API_DIS
      

        ret = self._api.lib.ApiCmdBCIni(self._handle, 0, mRetryOption, API_DIS,
                                        API_TBM_GLOBAL, mGlobalStartBus)

        if ret != API_OK:
            raise Exception("Error: ApiCmdBCIni: %s." % self._api.error(ret))

        self._free_xfer_ids = set(range(1, 512))

    def add_cyclic_transfers(self, transfer_list ):
        self._transfers.extend(transfer_list)

    def add_acyclic_transfers(self, transfer_list ):
        self._acyc_transfers.extend(transfer_list)

    def setup_hs_bc_rt_xfer(self, block_count, rt, cyclic=True, qsize=API_QUEUE_SIZE_1):
        """
        Sets up a HS BC to RT transfer on the stream.
        :param word_count: Number of the data words that are sent
        :param rt: tuple of rt address and rt mid
        :return: instance of class BcRtTransfer
        """
        transfer = aim_mil.hs_bc.HsBcRtTransfer(self, block_count, rt, qsize)
        if cyclic:
            self._transfers.append(transfer)
        else:
            self._acyc_transfers.append(transfer)

        return transfer

    def alloc_transfer_id(self):
        """
        Allocates a transfer ID on the stream
        :return: returns transfer ID as int
        """
        return self._free_xfer_ids.pop()

    def free_transfer_id(self, transfer_id):
        """
        Frees transfer ID
        :param transfer_id: transfer ID to free
        :return: return
        """
        self._free_xfer_ids.add(transfer_id)

    def setup_default_framing(self):
        """
        Sets up default framing for the stream.
        Packs each transfer of the stream into a separate minor frame
        """
        self._framing = aim_mil.bc.SimpleFraming(self, self._transfers)

    def setup_instruction_framing(self):
        """
        Sets up instruction list based for the stream.
        """
        self._framing = aim_mil.bc.InstructionFraming(self, [self._transfers])

    def setup_acyclic_framing(self):
        """
        Sets up default framing for the stream.
        Packs each transfer of the stream into a separate minor frame
        """
        self._acyc_framing = aim_mil.bc.AcyclicFraming(self, self._acyc_transfers)

    def start_bc(self, cycles=0, frame_time=10.0):
        """
        Starts Bus Controller of the stream
        :param cycles:  number of cycles the framing shall be sent
        :param frame_time: minor frame time in milliseconds
        """

        print ("\n\n@@@ In Stream.start_bc, setting frame_time = {}\n\n".format(frame_time))
        self._framing.send(cycles,frame_time)

    def start_bc_acyclic(self, low_prio=False):
        if low_prio:
            self._acyc_framing.send_at_end_of_frame()
        else:
            self._acyc_framing.send()

    def stop_bc(self):
        """
        Stops the Bus Controller of the stream
        """
        ret = self._api.lib.ApiCmdBCHalt(self._handle, 0)

        if ret != API_OK:
            raise Exception("Error: ApiCmdBCHalt: %s." % self._api.error(ret))

    @property
    def bc_status(self):
        """
        Get current status of stream's bus controller
        :return: returns dictionary with status, message and error count entries
        """
        status = TY_API_BC_STATUS_DSP()
        ret = self._api.lib.ApiCmdBCStatusRead(self._handle, 0, ctypes.byref(status))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBCStatusRead: %s." % self._api.error(ret))

        stat = dict([('status', status.status), ('messages', status.glb_msg_cnt), 
                     ('errors', status.glb_err_cnt), ('hxfer', status.hxfer)])
        #print("bc stat = {}".format(stat))
        return stat

    @property
    def bc_is_active(self):
        """
        Get current active status of stream's bus controller
        :return: returns true if the BC is not halted
        """
        return self.bc_status['status'] == API_BC_STATUS_BUSY

    @property
    def hs_bc_status(self):
        """
        Get current status of stream's hs bus controller
        :return: returns dictionary with status, message and error count entries
        """
        status = TY_API_HS_BC_STATUS()
        ret = self._api.lib.Api3910CmdHsBCStatusRead(self._handle, ctypes.byref(status))

        if ret != API_OK:
            raise Exception("Error: Api3910CmdHsBCStatusRead: %s." % self._api.error(ret))

        return dict([('messages', status.ul_GlbMsgCnt), ('errors', status.ul_GlbErrCnt)])

    def init_rts(self):
        """
        Initialize remote terminals of stream
        All remote terminals are disabled when this function is called
        """
        for rt in self._remote_terminals:
            rt.release()
        del self._remote_terminals[:]

    def setup_receive_rt(self, rt_address, mode=None, response_time = 8.0, statusbits=0):
        """
        Sets up a specific receive RT in simulation mode
        :param rt_address: tuple of rt address and sub-address
        :return: instance of class RTSubAddress
        """
        #print("In device.py, setup_receive_rt, input rt_address = {} self._remote_terminals = {}".
              #format(rt_address, self._remote_terminals))        
        n = [x for x in self._remote_terminals if x.address == rt_address[0]]

        if not len(n):
            #print("@@@NEW RT:: Setting up simulation rt for {}".format(rt_address[0]))
            rt = aim_mil.rt.SimulationRT(self, rt_address[0],response_time)
            self._remote_terminals.append(rt)
        else:
            rt = n[0]
            #print("@@@PREVIOUSLY SEEN RT: {}".format(rt_address[0]))

        subaddrOrMode =  rt_address[1]
        #print("subaddr is = rt_address[1] = {}".format(rt_address[1]))
            
        if rt_address[1] == 0 or rt_address[1] == 31:
            #These are mode code subaddresses
            subaddr_type = API_RT_TYPE_RECEIVE_MODECODE
            subaddrOrMode = mode
        else:
            subaddr_type = API_RT_TYPE_RECEIVE_SA

        #print("subaddr_type = {}".format(subaddr_type))
        return rt.setup_subaddr(subaddrOrMode, subaddr_type,statusbits)

    def setup_transmit_rt(self, rt_address, mode=None, response_time = 8.0,statusbits=0):
        """
        Sets up a specific transmit RT in simulation mode
        :param rt_address: tuple of rt address and sub-address
        :return: instance of class RTSubAddress
        """
        #print("In device.py, setup_transmit_rt, input rt_address = {} self._remote_terminals = {}".
              #format(rt_address, self._remote_terminals))
        n = [x for x in self._remote_terminals if x.address == rt_address[0]]

        if not len(n):
            #print("@@@NEW RT:: Setting up simulation rt for {}".format(rt_address[0]))
            rt = aim_mil.rt.SimulationRT(self, rt_address[0], response_time)
            self._remote_terminals.append(rt)
        else:
            rt = n[0]
            #print("@@@PREVIOUSLY SEEN RT: {}".format(rt_address[0]))
            
        subaddrOrMode =  rt_address[1]
        #print("subaddr is = rt_address[1] = {}".format(rt_address[1]))

        if rt_address[1] == 0 or rt_address[1] == 31:
            #These are mode code subaddresses
            subaddr_type = API_RT_TYPE_TRANSMIT_MODECODE
            subaddrOrMode = mode
        else:
            subaddr_type = API_RT_TYPE_TRANSMIT_SA        
        
        #print("subaddr_type = {}".format(subaddr_type))
        return rt.setup_subaddr(subaddrOrMode, subaddr_type,statusbits)

    def start_rts(self):
        """
        Starts all RTs of the stream
        """
        ret = self._api.lib.ApiCmdRTStart(self._handle, 0)

        if ret != API_OK:
            raise AimMilError(ret, "Error: ApiCmdRTStart: %s." % self._api.error(ret))

    def stop_rts(self):
        """
        Stops all RTs of the stream
        """
        ret = self._api.lib.ApiCmdRTHalt(self._handle, 0)

        if ret != API_OK:
            raise Exception("Error: ApiCmdRTHalt: %s." % self._api.error(ret))


    @property
    def rt_status(self):
        """
        Get current status of stream's RT simulation
        :return: returns dictionary with status, message and error count entries
        """
        status = TY_API_RT_STATUS_DSP()
        ret = self._api.lib.ApiCmdRTStatusRead(self._handle, 0, ctypes.byref(status))

        if ret != API_OK:
            raise Exception("Error: ApiCmdRTStatusRead: %s." % self._api.error(ret))

        return dict([('status', status.status), ('messages', status.glb_msg_cnt), ('errors', status.glb_err_cnt)])


    def get_individual_rt_statuses(self):
        #print("Get the status for each rt associated with this stream, {}. self._remote_terminals = {}".format(self.id, self._remote_terminals))
        for rt in self._remote_terminals:
            print("RT{}: MESSAGES={}\tERRORS={}".format(rt.address ,rt.status['message_count'],rt.status['error_count']))
        

    def start_monitoring(self):
        """
        Starts a queue based monitoring on the stream
        :return: instance of class MonitorQueue
        """
        self._monitor_queue = aim_mil.bm.MonitorQueue(self)

        self._monitor_queue.start()
        return self._monitor_queue

    def start_recording(self,file):
        """
        Starts a LS bus monitor recording
        :return: instance of class MonitorRecording
        """
        if self._monitor_recording is None:
            self._monitor_recording = aim_mil.bm.MonitorRecording(self,file)

        self._monitor_recording.start()
        return self._monitor_recording

    def stop_recording(self):
        if not self._monitor_recording is None:
            self._monitor_recording.close()
            self._monitor_recording = None


    def start_hs_recording(self,file):
        """
        Starts a HS bus monitor recording
        :return: instance of class MonitorRecording
        """
        if self._monitor_hs_recording is None:
            self._monitor_hs_recording = aim_mil.bm.MonitorRecording(self,file,True)

        self._monitor_hs_recording.start()
        return self._monitor_hs_recording

    def stop_hs_recording(self):
        if not self._monitor_hs_recording is None:
            self._monitor_hs_recording.close()
            self._monitor_hs_recording = None
