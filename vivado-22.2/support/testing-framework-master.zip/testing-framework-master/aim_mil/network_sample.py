__author__ = 'Markus Melcher'


import socket
import aim_mil.device
from aim_mil.apibindings import *
import time
import struct
import threading

def send_packet(send_socket, packet):
    send_socket.sendall(packet)


class ServerThread(threading.Thread):

    def __init__(self, server_socket):
        threading.Thread.__init__(self)
        self._server_socket = server_socket

    def run(self):
        connection = self._server_socket.accept()
        self._client_con = connection[0]


        print("Established connection with " + repr(connection[1]))

        num_msgs = 0
        while True:
            msg_header = self.receive_header()
            if msg_header == '':
                break

            rt_addr, sa_mc, sa_type, word_cnt = struct.unpack('!4B', msg_header)

            msg = self.receive_data(word_cnt)
            if msg == '':
                break

            num_msgs += 1
            data = struct.unpack('!%dH' % word_cnt, msg)

            print("Received message for RT %d-%d with data:" % (rt_addr, sa_mc) + repr(data))

        print("A total of %d messages was received" % num_msgs)
        self._client_con.close()
        self._server_socket.close()


    def receive_header(self):
        chunks = []
        bytes_recd = 0
        while bytes_recd < 4:
            chunk = self._client_con.recv(min(4 - bytes_recd, 4096))
            if chunk == '':
                return chunk
            chunks.append(chunk)
            bytes_recd += len(chunk)
        return ''.join(chunks)

    def receive_data(self, word_count):
        chunks = []
        bytes_recd = 0
        while bytes_recd < word_count * 2:
            chunk = self._client_con.recv(min(word_count * 2 - bytes_recd, 4096))
            if chunk == '':
                return chunk
            chunks.append(chunk)
            bytes_recd = bytes_recd + len(chunk)
        return ''.join(chunks)



if __name__ == '__main__':

    server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    server_sock.bind(("127.0.0.1", 0))

    server_sock.listen(5)

    server_thread = ServerThread(server_sock)
    server_thread.start()

    client_sock = socket.create_connection(server_sock.getsockname())

    host = aim_mil.device.Host('local')

    if not len(host.devices):
        raise Exception('No devices available')

    device = host.devices[0]
    device.init()

    stream = device.streams[0]
    stream.open()

    stream.init_bc()
    stream.init_rts()
    monitor = stream.start_monitoring()

    transfer = aim_mil.bc.BcRtTransfer(stream, 8,(1,2))
    transfer.data = [1, 2, 3, 4, 5, 256, 1024, 4096]

    stream.add_cyclic_transfers([transfer])
    stream.setup_default_framing()

    rt = stream.setup_receive_rt((1, 2))

    print("Starting simulation on stream %d..." % stream.id)
    stream.start_rts()
    stream.start_bc(10000, 0.1)

    status = {'status': API_BC_STATUS_BUSY}
    while status['status'] != API_BC_STATUS_HALTED:
        status = stream.bc_status
        monitor_msgs = monitor.read_empty(1000)

        for message in monitor_msgs:
            packet = struct.pack('!4B%dH' % message['word_cnt'], message['rt_addr'], message['sa_mc'],
                                 message['sa_type'], message['word_cnt'], *(word for word in message['buffer']))

            send_packet(client_sock, packet)

    print("Stopping simulation")

    stream.stop_bc()
    stream.stop_rts()
    monitor.stop()

    print("BC Status: Messages: %d Errors: %d" % (status['messages'], status['errors']))

    monitor_msgs = monitor.read_empty()

    for message in monitor_msgs:
        packet = struct.pack('!4B%dH' % message['word_cnt'], message['rt_addr'], message['sa_mc'],
                             message['sa_type'], message['word_cnt'], *(word for word in message['buffer']))

        send_packet(client_sock, packet)

    client_sock.close()
    server_thread.join()



