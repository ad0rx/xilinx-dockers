import numpy as np
import pandas as pd


class BmDataFrame:
    def __init__(self):
        self._table = None

    def fromfile(self, file ):
        """
        Load data from file
        """
        data   = np.fromfile(file, dtype=np.uint32)
        self.fromArray(data)

    def fromArray(self, data, offset=0 ):
        """
        Load data from numpy array
        """
        self._table           =  pd.DataFrame( data=data, columns=['RAW'] )
        self._table['HEX']    = self._table.apply(lambda x: hex(x['RAW']),axis=1)
        self._table['STRING'] = self._table.apply(lambda x: self.entry_to_string(x['RAW']),axis=1)

        self._table['OFFSET'] = np.arange(offset, offset + self._table.shape[0]*4, 4 )
        self._table.set_index('OFFSET', inplace=True)

    def dump(self):
        print( self._table['STRING'] )

    def command_word_to_string(self, cw):
        rt      = ( (cw>>11) & 0x1F )
        tx      = ( (cw>>10) & 0x1  )
        sa_mc   = ( (cw>>5 ) & 0x1F )
        wc      = ( (cw    ) & 0x1F )

        return ("C%02d_%c_%02d_%02d" % (rt, 'R' if tx == 0 else 'T',sa_mc,wc))

    def status_word_to_string(self, sw):
        rt      = ( (sw>>11) & 0x1F )

        status = "S%02d" % rt

        if( (sw & 0x7FF ) == 0 ): status += "_CS"
        if( (sw & 1<<0  ) != 0 ): status += "_TF"
        if( (sw & 1<<1  ) != 0 ): status += "_DBCA"
        if( (sw & 1<<2  ) != 0 ): status += "_SSF"
        if( (sw & 1<<3  ) != 0 ): status += "_BUSY"
        if( (sw & 1<<4  ) != 0 ): status += "_BCR"
        if( (sw & 1<<5  ) != 0 ): status += "_RES1"
        if( (sw & 1<<6  ) != 0 ): status += "_RES2"
        if( (sw & 1<<7  ) != 0 ): status += "_RES3"
        if( (sw & 1<<8  ) != 0 ): status += "_SRQ"
        if( (sw & 1<<9  ) != 0 ): status += "_INST"
        if( (sw & 1<<10 ) != 0 ): status += "_ME"

        return status

    def error_word_to_string(self, payload):
        error = 'Error: '
        if( (payload & 1<<15 ) != 0 ): error += "E, "
        if( (payload & 1<<14 ) != 0 ): error += "_AlternateBus, "
        if( (payload & 1<<13 ) != 0 ): error += "_WordCountLow, "
        if( (payload & 1<<12 ) != 0 ): error += "_WordCountHigh, "
        if( (payload & 1<<11 ) != 0 ): error += "_SW, "
        if( (payload & 1<<10 ) != 0 ): error += "_Address, "
        if( (payload & 1<<9  ) != 0 ): error += "_EarlyResp, "
        if( (payload & 1<<8  ) != 0 ): error += "_IllegalCW, "
        if( (payload & 1<<7  ) != 0 ): error += "_BothBusses, "
        if( (payload & 1<<6  ) != 0 ): error += "_Gap, "
        if( (payload & 1<<5  ) != 0 ): error += "_InvSync, "
        if( (payload & 1<<4  ) != 0 ): error += "_Parity, "
        if( (payload & 1<<3  ) != 0 ): error += "_BitCountLow, "
        if( (payload & 1<<2  ) != 0 ): error += "_BitCountHigh, "
        if( (payload & 1<<1  ) != 0 ): error += "_Mancheser, "
        if( (payload & 1<<0  ) != 0 ): error += "_NoResp, "

        return error



    def entry_to_string(self, entry):
        type    = (entry >> 28       ) # Bits 28 .. 31
        payload = (entry & 0x3ffffff ) # Bits  0 .. 26

        if type == 0x1: # Error Word
            return "ERROR:   0x%04X (%s)" % (payload, self.error_word_to_string(payload))
        elif type == 0x2: # Time Tag Low
            return "TTLOW:   0x%08x" % (payload)
        elif type == 0x3: # Time Tag High
            return "TTHIGH:  0x%08x" % (payload)
        elif type == 0x8: # CW Primary
            return "CW1_PRI: 0x%04X (%s)" % (payload, self.command_word_to_string(payload))
        elif type == 0x9: # CW2 Primary
            return "CW2_PRI: 0x%04X (%s)" % (payload, self.command_word_to_string(payload))
        elif type == 0xa: # Data Word Primary
            return "DW_PRI:  0x%04X (%d us)" % (payload & 0xFFFF, (payload>>16 & 0x1FF))
        elif type == 0xb: # Status Word Primary
            return "SW_PRI:  0x%04X (%s)" % (payload & 0xFFFF, self.status_word_to_string(payload))
        elif type == 0xc: # CW Secondary
            return "CW1_SEC: 0x%04X (%s)" % (payload, self.command_word_to_string(payload))
        elif type == 0xd: # CW2 Secondary
            return "CW2_SEC: 0x%04X (%s)" % (payload, self.command_word_to_string(payload))
        elif type == 0xe: # Data Word Secondary
            return "DW_SEC:  0x%04X (%d us)" % (payload & 0xFFFF, (payload>>16 & 0x1FF))
        elif type == 0xf: # Status Word Secondary
            return "SW_SEC:  0x%04X (%s)" % (payload & 0xFFFF, self.status_word_to_string(payload))
        else:
            return "INVALID: 0x%08X" % (entry)










class BmDataFrameParser:
    def __init__(self):
        self._table = None

    def fromfile(self, file ):
        """
        Load data from file
        """
        data   = np.fromfile(file, dtype=np.uint32)
        return self.fromArray(data)

    def fromArray(self, data ):
        """
        Load data from numpy array
        """

        # Search all TTHigh entries
        tth_offsets = [i for i in range(data.shape[0]) if (data[i]>>28 == 0x3) ]

        # extract message arrays
        count = len(tth_offsets)

        msg_list = count * [BmDataFrame]

        for i in range(count):
            if i < count-1:
                message_range = (tth_offsets[i], tth_offsets[i+1]-1)
            else:
                message_range = (tth_offsets[i], data.shape[0])

            df = BmDataFrame()
            df.fromArray(data[message_range[0]:message_range[1]+1], offset=message_range[0]*4)
            msg_list[i] = df

        return msg_list

