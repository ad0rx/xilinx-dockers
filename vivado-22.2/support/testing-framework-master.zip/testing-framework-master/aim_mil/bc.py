"""Module for Bus Controller functionality

This module provides functionality for
controlling the Bus Controller functionality
on AIM MIL devices
"""

__author__ = 'Markus Melcher'


from aim_mil.mil_bindings import *
import ctypes
import array
import abc
from aim_mil.error import AimMilError


class Transfer(object, metaclass=abc.ABCMeta):
    """
    This class is abstract and provides common
    properties of different transfer types
    """

    @abc.abstractmethod
    def __init__(self, stream, word_count, queue_size=API_QUEUE_SIZE_1, chn=API_BC_XFER_BUS_PRIMARY):
        """
        Constructor of class.
        Performs core initialization for different transfer types
        :param stream: the stream the transfer belongs to
        :param word_count: number of data words that are sent with the transfer
        """
        self._stream = stream
        self._queue_size = queue_size
        self._chn = chn

        if word_count == 0:
            self._word_count = 32
        else:
            self._word_count = word_count

        self._id = stream.alloc_transfer_id()
        self._buffer_id = stream.device.alloc_buffer()

    @property
    def id(self):
        """
        Get ID of transfer
        :return: the ID of the transfer as int
        """
        return self._id

    @property
    def hid(self):
        """
        Get ID of transfer
        :return: the ID of the transfer as int
        """
        return self._buffer_id
        
    @property
    def data(self):
        """
        Get data of transfer
        Reads current active data buffer of transfer
        :return: returns list of data buffer values as int
        """
        raw_data = array.array('H', [0] * self._word_count)
        rid = AiUInt16()
        raddr = AiUInt32()
        ret = self._stream.api.lib.ApiCmdBufRead(self._stream.handle, 0, API_BUF_BC_MSG, self._buffer_id, 0,
                                                 raw_data.buffer_info()[1], ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(AiUInt16)),
                                                 ctypes.byref(rid), ctypes.byref(raddr))
        if ret != API_OK:
            raise Exception("Error: ApiCmdBufRead: %s." % self._stream.api.error(ret))

        return raw_data.tolist()

    @data.setter
    def data(self, new_data):
        """
        Sets data of transfer
        Current data buffer of transfer is filled with given data
        :param new_data: list of data values as int
        :return:
        """
        rid = AiUInt16()
        raddr = AiUInt32()

        if len(new_data) > self._word_count:
            raise Exception("Error data exceeds word count of transfer")

        raw_data = array.array('H', new_data)
        ret = self._stream.api.lib.ApiCmdBufDef(self._stream.handle, 0, API_BUF_BC_MSG,
                                                self._buffer_id, 0, len(new_data), ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(AiUInt16)),
                                                ctypes.byref(rid), ctypes.byref(raddr))
        if ret != API_OK:
            raise Exception("Error: ApiCmdBufDef: %s." % self._stream.api.error(ret))

    def setup(self, transfer):
        """
        Installs a transfer on hardware
        :param transfer: instance of TY_API_BC_XFER
        """
        assert isinstance(transfer, TY_API_BC_XFER)

        address = AiUInt32()
        ret = self._stream.api.lib.ApiCmdBCXferDef(self._stream.handle, 0, ctypes.byref(transfer),
                                                   ctypes.byref(address))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBCXferDef: %s." % self._stream.api.error(ret))

        buffer_info = TY_API_BC_BH_INFO()

        ret = self._stream.api.lib.ApiCmdBCBHDef(self._stream.handle, 0, self._buffer_id, self._buffer_id, 0, 0,
                                                 self._queue_size, API_BQM_CYCLIC, API_BSM_TX_KEEP_SAME,
                                                 API_SQM_AS_QSIZE, 0, 0, ctypes.byref(buffer_info))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBCBHDef: %s." % self._stream.api.error(ret))

    def release(self):
        """
        Releases a transfer
        The transfer ID and buffer ID of the transfer are freed
        """
        self._stream.free_transfer_id(self._id)
        self._stream.device.free_buffer(self._buffer_id)

    def read(self):
        """
        Read the transfer status
        """
        transfer_info = TY_API_BC_XFER_DSP()

        ret = self._stream.api.lib.ApiCmdBCXferRead(self._stream.handle, 0, self.id, 0x7, ctypes.byref(transfer_info))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBCXferRead: id=%d %s." % (self.id, self._stream.api.error(ret)))

        return dict([('bid', transfer_info.bid),
                     ('msg_cnt', transfer_info.msg_cnt),
                     ('err_cnt', transfer_info.err_cnt),
                     ('st1', transfer_info.st1),
                     ('st2', transfer_info.st2),
                     ('brw_buf_stat', (transfer_info.brw>>12)&0x2 ),
                     ])


class BcRtTransfer(Transfer):
    """
    Implementation of abstract class Transfer
    that implements a BC to RT transfer
    """
    def __init__(self, stream, word_count, rt, queue_size=API_QUEUE_SIZE_1, chn=API_BC_XFER_BUS_PRIMARY,tic=API_BC_TIC_NO_INT,
                 gaptime=2,gapmode=API_BC_GAP_MODE_DELAY):
        """
        Constructor.
        Sets up transfer and installs it on hardware
        :param stream: stream the transfer belongs to
        :param word_count: number of data words that are sent during the transfer
        :param rt: tuple of rt address and sub-address of the receiver RT
        :return: instance of class BcRtTransfer
        """
        super(BcRtTransfer, self).__init__(stream, word_count,queue_size,chn)

        self._type = API_BC_TYPE_BCRT
        transfer = TY_API_BC_XFER()
        transfer.xid = self._id
        transfer.hid = self._buffer_id
        transfer.chn = self._chn
        transfer.tic = tic
        transfer.gap_mode = gapmode
        transfer.gap = gaptime
       

        if self._word_count == 32:
            transfer.wcnt = 0
        else:
            transfer.wcnt = self._word_count

        transfer.type = self._type
        transfer.rcv_rt = rt[0]
        transfer.rcv_sa = rt[1]

        super(BcRtTransfer, self).setup(transfer)


class RtBcTransfer(Transfer):

    """
    Implementation of abstract class Transfer
    that implements a RT to BC transfer
    """
    def __init__(self, stream, word_count, rt, queue_size=API_QUEUE_SIZE_1, chn=API_BC_XFER_BUS_PRIMARY,tic=API_BC_TIC_NO_INT,
                 gaptime=2,gapmode=API_BC_GAP_MODE_DELAY):
        """
        Constructor.
        Sets up transfer and installs it on hardware
        :param stream: stream the transfer belongs to
        :param word_count: number of data words that are sent during the transfer
        :param rt: tuple of rt address and sub-address of the transmitter RT
        :return: instance of class RtBcTransfer
        """
        super(RtBcTransfer, self).__init__(stream, word_count,queue_size,chn)

        self._type = API_BC_TYPE_RTBC
        transfer = TY_API_BC_XFER()
        transfer.xid = self._id
        transfer.hid = self._buffer_id
        transfer.tic = tic
        transfer.gap_mode = gapmode
        transfer.gap = gaptime       
        
        if self._word_count == 32:
            transfer.wcnt = 0
        else:
            transfer.wcnt = self._word_count

        transfer.type = self._type
        transfer.xmt_rt = rt[0]
        transfer.xmt_sa = rt[1]

        super(RtBcTransfer, self).setup(transfer)


class RtRtTransfer(Transfer):

    """
    Implementation of abstract class Transfer
    that implements a RT to RT transfer
    """
    def __init__(self, stream, word_count, transmit_rt, receive_rt, queue_size=API_QUEUE_SIZE_1, chn=API_BC_XFER_BUS_PRIMARY,tic=API_BC_TIC_NO_INT,
                 gaptime=2,gapmode=API_BC_GAP_MODE_DELAY):
        """
        Constructor.
        Sets up transfer and installs it on hardware
        :param stream: stream the transfer belongs to
        :param word_count: number of data words that are sent during the transfer
        :param transmit_rt: tuple of rt address and sub-address of the transmitter RT
        :param receive_rt: tuple of rt address and sub-address of the receiver RT
        :return: instance of class RtRtTransfer
        """
        super(RtRtTransfer, self).__init__(stream, word_count, queue_size,chn)

        self._type = API_BC_TYPE_RTRT
        transfer = TY_API_BC_XFER()
        transfer.xid = self._id
        transfer.hid = self._buffer_id
        transfer.tic = tic
        transfer.gap_mode = gapmode
        transfer.gap = gaptime


        if self._word_count == 32:
            transfer.wcnt = 0
        else:
            transfer.wcnt = self._word_count

        transfer.type = self._type
        transfer.xmt_rt = transmit_rt[0]
        transfer.xmt_sa = transmit_rt[1]
        transfer.rcv_rt = receive_rt[0]
        transfer.rcv_sa = receive_rt[1]

        super(RtRtTransfer, self).setup(transfer)


class BcSetup(object):

    """
    This class will install a simple framing from a
    given list of transfers.
    Each transfer is packed into a dedicated minor frame
    """

    def __init__(self, stream, svrq=API_DIS, retry=API_DIS, transfer_bus_mode=API_TBM_GLOBAL, global_start_bus=API_BC_XFER_BUS_PRIMARY):
        """
        Initializes the BC / Optional
        """
        self._stream = stream

        ret = stream.api.lib.ApiCmdBCIni(stream.handle, 0, retry, svrq, transfer_bus_mode, global_start_bus)

        if ret != API_OK:
            raise AimMilError(ret, "Error: ApiCmdBCIni: %s." % stream.api.error(ret))



class SimpleFraming(object):

    """
    This class will install a simple framing from a
    given list of transfers.
    Each transfer is packed into a dedicated minor frame
    """

    def __init__(self, stream, transfers):
        """
        Initializes a simple framing and installs it
        on hardware
        :param stream: the stream the framing will be installed
        :param transfers: list of transfers the framing will be set up of
        :return: instance of class SimpleFraming
        """
        self._frames = []
        self._stream = stream

        if len(transfers) > 0 :
          frame = TY_API_BC_FRAME()
          frame.id = 1
          frame.cnt = len(transfers)
          for count, transfer in enumerate(transfers):
            #frame = TY_API_BC_FRAME()
            #frame.id = count + 1
            #frame.cnt = 1
            frame.instr[count] = API_BC_INSTR_TRANSFER
            frame.xid[count] = transfer.id

          ret = stream.api.lib.ApiCmdBCFrameDef(stream.handle, 0, ctypes.byref(frame))

          if ret != API_OK:
            raise Exception("Error: ApiCmdBCFrameDef: %s." % stream.api.error(ret))

          self._frames.append(frame)
        else:
            # Create dummy frame with wait instruction to be able to send acyclics.
            frame = TY_API_BC_FRAME()
            frame.id = 1
            frame.cnt = 1
            frame.instr[0] = API_BC_INSTR_WAIT
            frame.xid[0] = 10 # Wait time

            ret = stream.api.lib.ApiCmdBCFrameDef(stream.handle, 0, ctypes.byref(frame))

            if ret != API_OK:
                raise Exception("Error: ApiCmdBCFrameDef: %s." % stream.api.error(ret))

            self._frames.append(frame)



        major_frame = TY_API_BC_MFRAME()
        major_frame.cnt = len(self._frames)

        for num, frame in enumerate(self._frames):
            major_frame.fid[num] = frame.id

        ret = stream.api.lib.ApiCmdBCMFrameDef(stream.handle, 0, ctypes.byref(major_frame))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBCMFrameDef: %s." % stream.api.lib.error(ret))

    def send(self, cycles=0, frame_time=10.0):
        major_frame_addr = AiUInt32()
        minor_frame_addr = (AiUInt32 * MAX_API_BC_MFRAME)()

        ret = self._stream.api.lib.ApiCmdBCStart(self._stream.handle, 0,
                                                 API_BC_START_IMMEDIATELY,
                                                 cycles,
                                                 AiFloat(frame_time),
                                                 0,
                                                 ctypes.byref(major_frame_addr),
                                                 ctypes.byref(minor_frame_addr))

        if ret != API_OK:
            raise AimMilError(ret, "Error: ApiCmdBCStart: %s." % self._stream.api.error(ret))

    @property
    def frames(self):
        """
        Get frames of the framing
        :return: list of TY_API_BC_FRAME instances
        """
        return self._frames[0:len(self._frames)]

class InstructionFraming(object):

    """
    This class will install a instruction list based framing from a
    given list of minor frames with a list of transfers.
    """

    def __init__(self, stream, framing):
        """
        Initializes the framing and installs it on hardware
        :param stream: the stream the framing will be installed
        :param transfers: list of list [frame1[transfer1, transfer2], frame2[transfer3], ... ]
        :return: instance of class SimpleFraming
        """
        self._stream = stream
        self._table_size = 800
        self._frame_labels = []
        self._start_label  = 0xEEEE
        self._end_label    = 0xFFFF
        self._instruction_table = None
        self._fw_instruction_table = None
        self._instruction_count = int(0)

        self.init_framing()
        self.create_framing(framing)
        self.install_framing()

    def init_framing(self):
        ulErrorPos = AiUInt32()
        ucStatus   = AiUInt8()

        if( self._fw_instruction_table == None ):
            self._fw_instruction_table = (AiUInt32           * self._table_size)()
            self._instruction_table    = (TY_API_BC_FW_INSTR * self._table_size)()

        # Initialize instruction list
        ret = self._stream.api.lib.ApiCmdBCInstrTblIni(self._stream.handle, 0)

        if ret != API_OK:
            raise Exception("Error: ApiCmdBCInstrTblIni: %s." % self._stream.api.lib.error(ret))

        # Clear instruction list
        ret = self._stream.api.lib.ApiCmdBCInstrTblGen(self._stream.handle,
                                                       0,
                                                       0, # clear
                                                       self._table_size,
                                                       0, 0,
                                                       ctypes.byref(self._instruction_table),
                                                       ctypes.byref(self._fw_instruction_table),
                                                       ctypes.byref(ulErrorPos),
                                                       ctypes.byref(ucStatus))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBCInstrTblGen: %s." % self._stream.api.lib.error(ret))


    def create_framing(self, framing):
        i = int(0)

        # Jump to start
        self._instruction_table[i].label = i
        self._instruction_table[i].op    = API_BC_FWI_JUMP
        self._instruction_table[i].par1  = self._start_label
        i = i+1

        # Create frames
        for minor_frame in framing:
            for transfer in minor_frame:
                # Add transfers for minor frame
                self._frame_labels.append(i)
                self._instruction_table[i].label = i
                self._instruction_table[i].op    = API_BC_FWI_XFER
                self._instruction_table[i].par1  = transfer.id
                i = i+1
            # Add wait for minor frame time instruction
            self._instruction_table[i].label = i
            self._instruction_table[i].op    = API_BC_FWI_WMFT
            i = i+1
            # Add return instruction
            self._instruction_table[i].label = i
            self._instruction_table[i].op    = API_BC_FWI_RET
            i = i+1

        # Add frame calls
        for index, minor_frame in enumerate(self._frame_labels):
            # Add call to label
            if index == 0:
                self._instruction_table[i].label = self._start_label
            else:
                self._instruction_table[i].label = i
            self._instruction_table[i].op    = API_BC_FWI_CALL
            self._instruction_table[i].par1  = minor_frame
            i = i+1


        # Add minor frame count handling
        self._instruction_table[i].label = i
        self._instruction_table[i].op    = API_BC_FWI_DJZ
        self._instruction_table[i].par1  = self._end_label
        i = i+1

        self._instruction_table[i].label = i
        self._instruction_table[i].op    = API_BC_FWI_JUMP
        self._instruction_table[i].par1  = self._start_label
        i = i+1

        self._instruction_table[i].label = self._end_label
        self._instruction_table[i].op    = API_BC_FWI_HALT
        i = i+1

        self._instruction_count = i

    def install_framing(self):
        ulAddress  = AiUInt32()
        ulLine     = AiUInt32()
        ulErrorPos = AiUInt32()
        ucStatus   = AiUInt8()

        # Write instruction list
        ret = self._stream.api.lib.ApiCmdBCInstrTblGen(self._stream.handle,
                                                       0,
                                                       3, # convert + write
                                                       self._table_size,
                                                       self._instruction_count,
                                                       0,
                                                       ctypes.byref(self._instruction_table),
                                                       ctypes.byref(self._fw_instruction_table),
                                                       ctypes.byref(ulErrorPos),
                                                       ctypes.byref(ucStatus))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBCInstrTblGen: %s." % self._stream.api.lib.error(ret))


    def send(self, cycles=0, frame_time=10.0):
        major_frame_addr = AiUInt32()
        minor_frame_addr = (AiUInt32 * MAX_API_BC_MFRAME)()
        ret = self._stream.api.lib.ApiCmdBCStart(self._stream.handle, 0,
                                                 API_BC_START_INSTR_TABLE,
                                                 cycles,
                                                 AiFloat(frame_time),
                                                 0,
                                                 ctypes.byref(major_frame_addr),
                                                 ctypes.byref(minor_frame_addr))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBCStart: %s." % self._stream.api.error(ret))

    @property
    def frames(self):
        """
        Get frames of the framing
        :return: list of TY_API_BC_FRAME instances
        """
        return self._frame_labels

    @property
    def start_offset(self):
        """
        Get frames of the framing
        :return: list of TY_API_BC_FRAME instances
        """
        return self._start_offset

class AcyclicFraming(object):

    """
    This class will install a acyclic framing from a
    given list of transfers.
    """

    def __init__(self, stream, transfers):
        """
        Initializes a simple framing and installs it
        on hardware
        :param stream: the stream the framing will be installed
        :param transfers: list of transfers the framing will be set up of
        :return: instance of class AcyclicFraming
        """
        self._stream = stream

        frame = TY_API_BC_ACYC()
        frame.id = 1

        for count, transfer in enumerate(transfers):
            frame.cnt = count+1
            frame.instr[count] = API_BC_INSTR_TRANSFER
            frame.xid[count]   = transfer.id

            ret = self._stream.api.lib.ApiCmdBCAcycPrep(self._stream.handle, 0, ctypes.byref(frame))

            if ret != API_OK:
                raise Exception("Error: ApiCmdBCAcycPrep: %s." % self._stream.api.error(ret))


    def send(self):
        """
        Sent the acyclic frame
        """
        ret = self._stream.api.lib.ApiCmdBCAcycSend(self._stream.handle, 0, 0, 0, 0 )

        if ret != API_OK:
            raise Exception("Error: ApiCmdBCAcycSend: %s." % self._stream.api.error(ret))

    def send_at_end_of_frame(self):
        """
        Sent the acyclic frame
        """
        ret = self._stream.api.lib.ApiCmdBCAcycSend(self._stream.handle, 0, API_BC_ACYC_SEND_AT_END_OF_FRAME, 0, 0 )

        if ret != API_OK:
            raise AimMilError(ret, "Error: ApiCmdBCAcycSend/API_BC_ACYC_SEND_AT_END_OF_FRAME: %s." % self._stream.api.error(ret))

