""" Check Python version and import the right module """

__author__ = 'Martin Haag'

import sys

if sys.version_info > (3,):
    from aim_mil.mil_bindings3 import *
else:
    from aim_mil.mil_bindings2 import *
