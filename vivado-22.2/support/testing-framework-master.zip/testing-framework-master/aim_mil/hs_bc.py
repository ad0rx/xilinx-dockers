"""Module for Bus Controller functionality

This module provides functionality for
controlling the Bus Controller functionality
on AIM MIL devices
"""

__author__ = 'Martin Haag'

from aim_mil.mil_bindings import *
import ctypes
import array
import abc


class HsTransfer(object, metaclass=abc.ABCMeta):
    """
    This class is abstract and provides common
    properties of different transfer types
    """

    @abc.abstractmethod
    def __init__(self, stream, block_count, qsize):
        """
        Constructor of class.
        Performs core initialization for different transfer types
        :param stream: the stream the transfer belongs to
        :param block_count: number of data words that are sent with the transfer
        """
        self._stream = stream
        self._block_count = block_count
        self._id = stream.alloc_transfer_id()
        self._buffer_id = stream.device.alloc_buffer()
        self._qsize = qsize
        self._qindex = 1

    @property
    def id(self):
        """
        Get ID of transfer
        :return: the ID of the transfer as int
        """
        return self._id

    @property
    def data(self):
        """
        Get data of transfer
        Reads current active data buffer of transfer
        :return: returns list of data buffer values as int
        """
        raw_data = array.array('H', [0] * self._block_count * 32)
        rid = AiUInt16()
        rsize = AiUInt16()
        bnr = AiUInt16()
        raddr = AiUInt32()

        ret = self._stream.api.lib.Api3910CmdHsBufRead(self._stream.handle, API_BUF_BC_MSG,
                                                       self._buffer_id, 
                                                       self._qindex,
                                                       ctypes.byref(rid), ctypes.byref(rsize),
                                                       ctypes.byref(bnr), ctypes.byref(raddr),
                                                       raw_data.buffer_info()[0])

        if ret != API_OK:
            raise Exception("Error: ApiCmdBufRead: %s." % self._stream.api.error(ret))

        return raw_data.tolist()

    @data.setter
    def data(self, new_data):
        """
        Sets data of transfer
        Current data buffer of transfer is filled with given data
        :param new_data: list of data values as int
        :return:
        """
        raw_data = array.array('H', new_data)

        ret = self._stream.api.lib.Api3910CmdHsBufDef(self._stream.handle, API_BUF_BC_MSG,
                                                      self._buffer_id, 
                                                      self._qindex,
                                                      len(new_data) + 3, 3,
                                                      len(new_data),
                                                      ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(AiUInt16)),
                                                      None, None,
                                                      None)

        if ret != API_OK:
            raise Exception("Error: Api3910CmdHsBufDef: %s." % self._stream.api.error(ret))

    @property
    def fcpa_da(self):
        return [0xC000|31, 0x8101, 0]

    @fcpa_da.setter
    def fcpa_da(self, header ):
        """
        Sets fcpa da fields

        auwData[0] = 0xC000|31;
        auwData[1] = 0x8101;
        auwData[2] = 0;

        :return:
        """

        if len(header) != 3:
            raise Exception("Error header requires three values (fc,pa,da)")

        raw_data = array.array('H', header)

        for i in range(1, (1<<self._qsize)+1 ):
            # Set in all queue elements
            ret = self._stream.api.lib.Api3910CmdHsBufDef(self._stream.handle, API_BUF_BC_MSG,
                                                      self._buffer_id, i,
                                                      len(header), 0,
                                                      len(header),
                                                      ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(AiUInt16)),
                                                      None, 
                                                      None,
                                                      None)

        if ret != API_OK:
            raise Exception("Error: Api3910CmdHsBufDef: %s." % self._stream.api.error(ret))

    def setup(self, transfer):
        """
        Installs a transfer on hardware
        :param transfer: instance of TY_API_BC_XFER
        """
        assert isinstance(transfer, TY_API_HS_BC_XFER)

        ret = self._stream.api.lib.Api3910CmdHsBCBHDef(self._stream.handle,
                                                       self._buffer_id, 0, 0, 0,
                                                       self._qsize,
                                                       API_BQM_CYCLIC, 0,
                                                       API_SQM_AS_QSIZE, 0, 0, 0)

        if ret != API_OK:
            raise Exception("Error: Api3910CmdHsBCBHDef: %s." % self._stream.api.error(ret))

        self.fcpa_da = [0xC000|31, 0x8101, 0]

        address = AiUInt32()
        ret = self._stream.api.lib.Api3910CmdHsBCXferDef(self._stream.handle, ctypes.byref(transfer))

        if ret != API_OK:
            raise Exception("Error: Api3910CmdHsBCXferDef: %s." % self._stream.api.error(ret))



    def release(self):
        """
        Releases a transfer
        The transfer ID and buffer ID of the transfer are freed
        """
        self._stream.free_transfer_id(self._id)
        self._stream.device.free_buffer(self._buffer_id)


class HsBcRtTransfer(HsTransfer):
    """
    Implementation of abstract class HsTransfer
    that implements a HS BC to RT transfer
    """

    def __init__(self, stream, block_count, rt, qsize=API_QUEUE_SIZE_1):
        """
        Constructor.
        Sets up transfer and installs it on hardware
        :param stream: stream the transfer belongs to
        :param block_count: number of data blocks that are sent during the transfer
        :param rt: tuple of rt address and sub-address of the receiver RT
        :return: instance of class HsBcRtTransfer
        """
        super(HsBcRtTransfer, self).__init__(stream, block_count, qsize)

        if rt[0] == 31:
            self._type = API_HS_BC_TYPE_BCBR
        else:
            self._type = API_HS_BC_TYPE_BCRT

        transfer = TY_API_HS_BC_XFER()
        transfer.x_Common.uw_XferId = self._id
        transfer.x_Common.uw_HeaderId = self._buffer_id

        if self._block_count < 128:
            transfer.x_Common.uc_MsgSize = self._block_count
        else:
            transfer.x_Common.uc_MsgSize = 0

        transfer.x_Hs.ul_HsXmt = 0
        transfer.x_Hs.ul_HsXmt |= (104 << 0)  # Transmitter Initialise Time (26us)
        transfer.x_Hs.ul_HsXmt |= (40 << 16)  # Preambles

        transfer.x_Common.uc_XferType = self._type
        transfer.x_Common.uw_Rt = rt[0] <<8 # rcv
        transfer.x_Common.uw_Mid = rt[1]<<8  # rcv

        # (Transmitter Initialise Time) + (Transfered Bits / 20Mbit * 1000000 ) + gap
        transfer.x_Common.x_FirstXfer.ul_Gap   = int(26 + ((16*self._block_count*32)/20) + 50)
        transfer.x_Common.x_SecondXfer.ul_Gap  = 0

        super(HsBcRtTransfer, self).setup(transfer)
