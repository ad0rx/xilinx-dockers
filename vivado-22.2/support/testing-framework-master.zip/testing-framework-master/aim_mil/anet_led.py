"""Module for ANET LED handling

    This module contains classes for controlling
    the LEDs on AIM ANET devices
"""

__author__ = 'Markus Melcher'

import os
import abc


class AnetLed(object):

    """
    This class represents a specific LED on ANET devices
    """

    def __init__(self, color):
        """
        Constructor.
        Creates AnetLed class instance for a given color
        :param color: the color of the LED the class is used for
        :return: instance of class AnetLed
        """
        self._color = color.lower()
        self._sys_file_path = "/sys/class/leds/sys-state::%s" % self._color

        if not os.path.isdir(self._sys_file_path):
            raise Exception('LED with color %s is not available' % color)

    @property
    def color(self):
        """
        Get color of LED
        :return: color as string
        """
        return self._color

    def __open(self, led_file):
        """
        Private function for opening sysfs LED files
        :param led_file: the LED control file to open
        :return: file descriptor of LED control file
        :rtype: int
        """
        return os.open('%s/%s' % (self._sys_file_path, led_file), os.O_RDWR)

    def __write_setting(self, setting_file, setting):
        """
        Private function for writing a setting to a specific LED control file
        :param setting_file: the LED control file that will receive the setting
        :param setting: the setting as string
        """
        fd = self.__open(setting_file)
        os.write(fd, setting)
        os.close(fd)

    def switch_on(self, brightness=255):
        """
        Switches on the LED with a given brightness
        :param brightness: brightness to set from 0 to 255
        """
        self.__write_setting('brightness', str(brightness))

    def switch_off(self):
        """
        Switches off the LED
        """
        self.__write_setting('brightness', str(0))
        self.__write_setting('trigger', 'none')

    def blink(self, period_ms=5000):
        """
        Activate blinking of the LED
        :param period_ms: Period in milliseconds from on-to-on
        """
        self.__write_setting('trigger', 'timer')
        self.switch_on()
        self.__write_setting('delay_on', str(period_ms / 2))
        self.__write_setting('delay_off', str(period_ms / 2))


class AnetLedFactory(object, metaclass=abc.ABCMeta):
    """
    Abstract class used for probing the available LEDs
    on ANET devices
    """

    @abc.abstractmethod
    def __init__(self):
        pass

    @staticmethod
    def probe_leds():
        """
        Probes all available LEDs on ANET devices
        :return: dictionary with the color as key and a class AnetLed instance as value for each probed LED
        """
        leds = {}
        for led_dir in os.listdir('/sys/class/leds'):
            if os.path.isdir('/sys/class/leds/%s' % led_dir) and led_dir.startswith('sys-state::'):
                color = led_dir.split('::')[1]
                leds[color] = AnetLed(color)

        return leds
