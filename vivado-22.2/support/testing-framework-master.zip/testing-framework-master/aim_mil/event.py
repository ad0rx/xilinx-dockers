from aim_mil.mil_bindings import *
from aim_mil.error import *



class AimDeviceEventHandler:
    def __init__(self, stream):
        self._stream      = stream
        self._event_count = 0
        self._event_list  = []
        self._callback    = TY_INT_FUNC_PTR(self.__callback_handler)

    def set_callback_handler(self, callback_handler):
        self._callback    = TY_INT_FUNC_PTR(callback_handler)

    def __callback_handler(self, handle, biu, int_type, loglist_addr):
        
        print("EVENT.PY: INTERRUPT: event count = {}".format(self._event_count))
        if(handle != self._stream.handle.value):
            raise Exception("Interrupt with invalid handle")

        if int_type == API_INT_BC:
            print("event.py:Got BC interrupt")
            #print("Got BC interrupt")
        elif int_type == API_INT_BM:
            print("event.py:Got BM interrupt")
        elif int_type == API_INT_RT:
            print("event.py:Got RT interrupt")
            #pass            

        # process event
        self._event_count += 1
        
        self._event_list.append( TY_API_INTR_LOGLIST_ENTRY.from_buffer_copy(loglist_addr.contents) )

        print(" __callback_handler: The event list is {}".format(self._event_list))
        

    @property
    def events(self):
        return self._event_count

    def install(self, interrupt_type):
        print("%%%Doing the installation of AimDeviceEventHandlers for interrupt type {}".
						format(interrupt_type))
        ret = self._stream.api._lib.ApiInstIntHandler(self._stream.handle, API_INT_LS, interrupt_type, self._callback)

        if ret != API_OK:
            raise AimMilError(ret, 'ApiInstIntHandler failed with %s' % self._stream.api.error(ret) )

    def remove(self, interrupt_type):
        ret = self._stream.api.lib.ApiDelIntHandler( self._stream.handle, API_INT_LS, interrupt_type)

        if ret != API_OK:
            raise AimMilError(ret, 'ApiDelIntHandler failed with %s' % self._stream.api.error(ret) )

