from ctypes import *

STRING = c_char_p


API_BC_MODE_CONFIGURED_DYTAGS = 3 # Variable c_int '3'
MAX_BC_MODE_CTRL = API_BC_MODE_CONFIGURED_DYTAGS # alias
API_EF_SWITCH_TO_EFEX_TEMPORARY = 4 # Variable c_int '4'
MAX_EF_SWITCHTYPE = API_EF_SWITCH_TO_EFEX_TEMPORARY # alias
def GET_STREAM_ID(ulModHandle): return ((ulModHandle & API_STREAM_MASK) >> API_STREAM_POS) # macro
AI_DEVICE_AYS = 12
AI_DEVICE_ZYNQMP_ASP = 11
AI_DEVICE_AYS_ASP_MA = 10
AI_DEVICE_USB = 8
AI_DEVICE_AYE = 5
AI_DEVICE_AMC = 3
AI_DEVICE_AYI = 1
API_BM_PULSE_STROBE_ON_TRG = 1 # Variable c_int '1'
MAX_TCB_SOT = API_BM_PULSE_STROBE_ON_TRG # alias
AI_TARGET_VER = 4
def __STRING(x): return #x # macro
API_BM_INVERT_RESULT = 1 # Variable c_int '1'
MAX_TCB_INV = API_BM_INVERT_RESULT # alias
API_BC_ACYC_SEND_AT_END_OF_FRAME = 2 # Variable c_int '2'
MAX_ACYC_MODE = API_BC_ACYC_SEND_AT_END_OF_FRAME # alias
# BSWAP32_MAC = _BSWAP32 # alias
API_SCOPE_TRG_STROBE_DISCRETE = 2
API_SCOPE_TRG_STROBE_BC = 1
API_SCOPE_TRG_STROBE_MON = 0
API_RT_MODE = 2 # Variable c_int '2'
MAX_SYSTAG_MODE = API_RT_MODE # alias
API_SYSTAG_FCT_CHECKSUM = 8 # Variable c_int '8'
MAX_SYSTAG_FCT = API_SYSTAG_FCT_CHECKSUM # alias
API_RETRY_2SAME_1ALT = 3 # Variable c_int '3'
MAX_RETRY = API_RETRY_2SAME_1ALT # alias
API_SCOPE_SRC_SECONDARY = 1 # Variable c_int '1'
MAX_SCOPE_TRG_SRC = API_SCOPE_SRC_SECONDARY # alias
API_SCOPE_MODE_BIU = 7 # Variable c_int '7'
MAX_SCOPE_TRG_MODE = API_SCOPE_MODE_BIU # alias
API_RT_TYPE_TRANSMIT_MODECODE = 3 # Variable c_int '3'
MAX_RT_SA_TYPE = API_RT_TYPE_TRANSMIT_MODECODE # alias
API_RESET_USE_COUNTER_MODE_2 = 64 # Variable c_int '64'
MAX_RESET_CONTROL = API_RESET_USE_COUNTER_MODE_2 # alias
API_TRG_BM_HS = 20 # Variable c_int '20'
MAX_PXICON_TRGSOURCE = API_TRG_BM_HS # alias
MAX_PXICON_TRGDEST = API_TRG_BM_HS # alias
API_DEVICE_MODE_SIM = 1
API_TYPE_SIM_ONLY = API_DEVICE_MODE_SIM # alias
def NUM_SCOPE_SAMPLES(data_size): return (((data_size) / 4) * 3) # macro
APIEF_BC_XFER_TYPE_MCBR = 30 # Variable c_int '30'
MAX_HS_XFER_TYPE = APIEF_BC_XFER_TYPE_MCBR # alias
API_BC_HLT_HALT_ON_ANY_INT = 4 # Variable c_int '4'
MAX_HS_XFER_HALT = API_BC_HLT_HALT_ON_ANY_INT # alias
API_BC_INSTR_STROBE = 4 # Variable c_int '4'
MAX_INSTR_NR = API_BC_INSTR_STROBE # alias
API_UPDATE_FAILED = 3
API_UPDATE_IDLE = 0
API_RT_MODE_CONFIGURED_DYTAGS = 3 # Variable c_int '3'
MIN_RT_MODE_CTRL = API_RT_MODE_CONFIGURED_DYTAGS # alias
API_UPDATE_DEV_CON_FAILURE = -1
# MAX_TIMER = API_TIMER_4 # alias
def __GLIBC_PREREQ(maj,min): return ((__GLIBC__ << 16) + __GLIBC_MINOR__ >= ((maj) << 16) + (min)) # macro
API_HS_BM_TRG_AND = 2 # Variable c_int '2'
MAX_HS_TRG_SEL = API_HS_BM_TRG_AND # alias
API_BC_SRVW_MULTIPLE = 3 # Variable c_int '3'
MAX_HS_SW_EXCEPTION = API_BC_SRVW_MULTIPLE # alias
API_BC_XFER_BUS_SECONDARY = 1 # Variable c_int '1'
MAX_LS_BUS = API_BC_XFER_BUS_SECONDARY # alias
API_BM_STROBE_ON_STOP_EVENT = 3 # Variable c_int '3'
MAX_HS_STROBE_MODE = API_BM_STROBE_ON_STOP_EVENT # alias
API_HS_RT_EFA_PROTOCOL = 1 # Variable c_int '1'
MAX_HS_RT_PROTOCOL = API_HS_RT_EFA_PROTOCOL # alias
def __CONCAT(x,y): return x ## y # macro
API_HS_RT_MODE_CONFIGURED_DYTAGS = 3 # Variable c_int '3'
MAX_HS_RT_MODE_CTRL = API_HS_RT_MODE_CONFIGURED_DYTAGS # alias
API_HS_RT_MODE_MAILBOX = 1 # Variable c_int '1'
MAX_HS_RT_MODE = API_HS_RT_MODE_MAILBOX # alias
API_HS_RT_TYPE_MODECODE = 2 # Variable c_int '2'
MAX_HS_MSGIDTYPE = API_HS_RT_TYPE_MODECODE # alias
API_HS_RT_ENABLE_INT_ERR = 2 # Variable c_int '2'
MAX_HS_MID_INT = API_HS_RT_ENABLE_INT_ERR # alias
API_BC_TIC_INT_ON_XFER_ERR = 2 # Variable c_int '2'
MAX_HS_IR = API_BC_TIC_INT_ON_XFER_ERR # alias
API_BM_MODE_STOP_EVENT_INT = 3 # Variable c_int '3'
MAX_HS_INT_MODE = API_BM_MODE_STOP_EVENT_INT # alias
API_BC_GAP_MODE_FAST = 2 # Variable c_int '2'
MAX_HS_GAPMODE = API_BC_GAP_MODE_FAST # alias
API_HS_FMOD_CONT_PREAM_DDL = 3 # Variable c_int '3'
MAX_HS_FMOD_CONT = API_HS_FMOD_CONT_PREAM_DDL # alias
API_EF_ERR_TYPE_ILLEGAL_WORDCOUNT = 13 # Variable c_int '13'
MAX_HS_ERR_TYPE = API_EF_ERR_TYPE_ILLEGAL_WORDCOUNT # alias
API_DYTAG_FUNCTION_MODIFY = 1 # Variable c_int '1'
MAX_HS_DYTAG_WORD_MODE = API_DYTAG_FUNCTION_MODIFY # alias
API_CAL_CPL_EXT_WRAP_AROUND_LOOP = 5 # Variable c_int '5'
MAX_HS_CPL_MODE = API_CAL_CPL_EXT_WRAP_AROUND_LOOP # alias
API_HS_CHANNEL_B = 1 # Variable c_int '1'
MAX_HS_BUS = API_HS_CHANNEL_B # alias
API_HS_BM_ENTRY_LS_CA_WORD = 3 # Variable c_int '3'
MAX_HS_BM_ENTRY_TYPE = API_HS_BM_ENTRY_LS_CA_WORD # alias
API_HS_BC_MODE_CONFIGURED_DYTAGS = 3 # Variable c_int '3'
MAX_HS_BC_MODE_CTRL = API_HS_BC_MODE_CONFIGURED_DYTAGS # alias
API_MODE_BMINI_CLEAR_BUFFER = 16 # Variable c_int '16'
MAX_EXECSYS_MODE = API_MODE_BMINI_CLEAR_BUFFER # alias
API_ERR_TYPE_BUS_SWITCH = 15 # Variable c_int '15'
MAX_ERR_TYPE = API_ERR_TYPE_BUS_SWITCH # alias
API_EF_RTMODE_EFEX = 2 # Variable c_int '2'
MAX_EF_RTMODE = API_EF_RTMODE_EFEX # alias
API_EF_TRIG_S = 1 # Variable c_int '1'
MAX_EF_BM_STRIG_TYPE = API_EF_TRIG_S # alias
API_EF_TRIG_EFA_CMD = 1 # Variable c_int '1'
MAX_EF_BM_CWTRIG_TYPE = API_EF_TRIG_EFA_CMD # alias
API_DYTAG_EFA_MODE = 1 # Variable c_int '1'
MAX_DYTAG_MODE = API_DYTAG_EFA_MODE # alias
API_DYTAG_FCT_SAWTOOTH_8_HIGH = 3 # Variable c_int '3'
MAX_DYTAG_FCT = API_DYTAG_FCT_SAWTOOTH_8_HIGH # alias
API_DATA_QUEUE_GEN_ASP = 9 # Variable c_int '9'
MAX_DATA_QUEUE_ID = API_DATA_QUEUE_GEN_ASP # alias
API_DATA_QUEUE_CTRL_MODE_FLUSH = 3 # Variable c_int '3'
MAX_DATA_QUEUE_CONTROL_MODE = API_DATA_QUEUE_CTRL_MODE_FLUSH # alias
API_CAL_CPL_WRAP_AROUND_LOOP = 4 # Variable c_int '4'
MAX_CPL_MODE = API_CAL_CPL_WRAP_AROUND_LOOP # alias
API_BSM_RX_KEEP_CURRENT = 1 # Variable c_int '1'
MAX_BSM = API_BSM_RX_KEEP_CURRENT # alias
API_BQM_HOST_CONTROLLED = 2 # Variable c_int '2'
MAX_BQM = API_BQM_HOST_CONTROLLED # alias
API_BM_WRITE_ETI = 4 # Variable c_int '4'
MAX_BM_TIW_CON = API_BM_WRITE_ETI # alias
API_BM_SIGN_NEG = 1 # Variable c_int '1'
MAX_BM_STACK_ENTRY_SIGN = API_BM_SIGN_NEG # alias
API_BM_READ_ABS = 3 # Variable c_int '3'
MAX_BM_STACK_ENTRY_READMODE = API_BM_READ_ABS # alias
MAX_BM_SMODE = API_BM_STROBE_ON_STOP_EVENT # alias
API_BM_FLT_MODE_DEPENDENT = 1 # Variable c_int '1'
MAX_BM_MSGFLT_MODE = API_BM_FLT_MODE_DEPENDENT # alias
# def __ASMNAME2(prefix,cname): return __STRING (prefix) cname # macro
API_INIT_MODE_READ = 1 # Variable c_int '1'
MAX_INIT_MODE = API_INIT_MODE_READ # alias
def API_BC_FW_MAKE_INSTR(b1,b2): return ((AiUInt32)(((AiUInt32)(b1) << 26) + ((AiUInt32)(b2) & 0x03FFFFFF))) # macro
def AI_MMAP_OFFSET(m): return (m<<24) # macro
def UINTMAX_C(c): return c ## UL # macro
def __attribute_format_strfmon__(a,b): return __attribute__ ((__format__ (__strfmon__, a, b))) # macro
AI_TCP_VER = 9
def CREATE_MODULE_HANDLE_FROM_LOCAL(local_handle,srv): return ((srv << API_SERVER_POS) | local_handle) # macro
AI_MEMTYPE_RX_MEM = 6
AI_MAIN_LCA_VER = 6
# def __REDIRECT_NTHNL(name,proto,alias): return name proto __THROWNL __asm__ (__ASMNAME (#alias)) # macro
def API_DEVICE_MODE_IS_SINGLEFUNCTION(m): return (((m) & API_DEVICE_MODE_SF) == API_DEVICE_MODE_SF) # macro
# def __REDIRECT_NTH(name,proto,alias): return name proto __THROW __asm__ (__ASMNAME (#alias)) # macro
def __REDIRECT_LDBL(name,proto,alias): return __REDIRECT (name, proto, alias) # macro
def __PMT(args): return args # macro
# def __LDBL_REDIR_NTH(name,proto): return name proto __THROW # macro
def __P(args): return args # macro
# __WCHAR_MAX = __WCHAR_MAX__ # alias
# __WCHAR_MIN = __WCHAR_MIN__ # alias
API_DEVICE_MODE_NOREPLAY_NOERROR = 8
API_DEVICE_MODE_EMBEDDED = 4
def __GNUC_PREREQ(maj,min): return ((__GNUC__ << 16) + __GNUC_MINOR__ >= ((maj) << 16) + (min)) # macro
API_DEVICE_MODE_FULL = 0
# NULL = __null # alias
# WCHAR_MIN = __WCHAR_MIN # alias
MIN_HS_RT_MODE_CTRL = API_HS_RT_MODE_CONFIGURED_DYTAGS # alias
def UINT32_C(c): return c ## U # macro
MIN_HS_BC_MODE_CTRL = API_HS_BC_MODE_CONFIGURED_DYTAGS # alias
def UINT16_C(c): return c # macro
API_BIU_1 = 1 # Variable c_int '1'
MIN_BIU = API_BIU_1 # alias
API_BC_MODE_INSERT_MC17_SYNC_CNT = 1 # Variable c_int '1'
MIN_BC_MODE_CTRL = API_BC_MODE_INSERT_MC17_SYNC_CNT # alias
API_STREAM_1 = 1 # Variable c_int '1'
MIN_API_STREAM = API_STREAM_1 # alias
API_TRACK_CLR_UDF = 1 # Variable c_int '1'
MAX_TRACK_READ_MODE = API_TRACK_CLR_UDF # alias
SCOPE_BUFFER_SECONDARY = 1
SCOPE_BUFFER_PRIMARY = 0
API_IRIG_EXTERN = 1
def API_DEVICE_MODE_IS_SIMULATOR(m): return (((m) & API_DEVICE_MODE_SIM) == API_DEVICE_MODE_SIM) # macro
def API_DEVICE_MODE_IS_NOREPLAY_NOERROR(m): return (((m) & API_DEVICE_MODE_NOREPLAY_NOERROR) == API_DEVICE_MODE_NOREPLAY_NOERROR) # macro
# MAX_TIMER_MODE = API_STOP_TIMER # alias
def GET_SERVER_ID(ulModHandle): return ((ulModHandle & API_SERVER_MASK) >> API_SERVER_POS) # macro
def GET_MODULE_ID(ulModHandle): return (ulModHandle & API_MODULE_MASK) # macro
# def __LDBL_REDIR1(name,proto,alias): return name proto # macro
def API_DEVICE_MODE_IS_EMBEDDED(m): return (((m) & API_DEVICE_MODE_EMBEDDED) == API_DEVICE_MODE_EMBEDDED) # macro
API_IRIG_INTERN = 0
def __glibc_unlikely(cond): return __builtin_expect ((cond), 0) # macro
def __bos0(ptr): return __builtin_object_size (ptr, 0) # macro
# def MIL_COM_INIT(p_Struct,_ulStream,_ucBiu,_ulCommand,_ulInSize,_ulOutSize): return { (p_Struct)->ulMagic = MIL_COM_MAGIC; if( _ulStream != 0 ) (p_Struct)->ulStream = _ulStream; else (p_Struct)->ulStream = _ucBiu; (p_Struct)->ulCommand = _ulCommand; (p_Struct)->ulSize = _ulInSize; (p_Struct)->ulExpectedAckSize = _ulOutSize; (p_Struct)->ulSwapControl = 0; (p_Struct)->ulReserved_3 = 0; (p_Struct)->ulReserved_4 = 0; } # macro
def __bos(ptr): return __builtin_object_size (ptr, __USE_FORTIFY_LEVEL > 1) # macro
AI_MEMTYPE_REF_MEM = 8
AI_MEMTYPE_TX_MEM = 7
# def __attribute_alloc_size__(params): return __attribute__ ((__alloc_size__ params)) # macro
def __REDIRECT_NTH_LDBL(name,proto,alias): return __REDIRECT_NTH (name, proto, alias) # macro
# def __REDIRECT(name,proto,alias): return name proto __asm__ (__ASMNAME (#alias)) # macro
def AI_UNUSED(x): return (void)(x) # macro
# def __NTH(fct): return __LEAF_ATTR fct throw () # macro
# def __LDBL_REDIR1_NTH(name,proto,alias): return name proto __THROW # macro
# def __LDBL_REDIR(name,proto): return name proto # macro
def __ASMNAME(cname): return __ASMNAME2 (__USER_LABEL_PREFIX__, cname) # macro
def UINT8_C(c): return c # macro
def UINT64_C(c): return c ## UL # macro
API_BM_ASSERT_TRG_INT = 1 # Variable c_int '1'
MAX_TCB_TRI = API_BM_ASSERT_TRG_INT # alias
# def SCOPE_SAMPLE_BY_SAMPLE_ID(pBuffer,sample_id): return (((((AiUInt32*) pBuffer)[sample_id / 3]) >> (((sample_id % 3) * 10) + 2)) & 0x3FF) # macro
def NUM_SCOPE_SAMPLE_PACKETS(data_size): return ((data_size) / 4) # macro
def LOWORD(l): return ((WORD)(l)) # macro
def IS_REMOTE(ulModHandle): return ((ulModHandle & API_SERVER_MASK) != 0) # macro
def INTMAX_C(c): return c ## L # macro
def INT8_C(c): return c # macro
def INT64_C(c): return c ## L # macro
def INT16_C(c): return c # macro
# def INLINE(Type): return __inline__ Type # macro
def HOST_TO_BE32(x): return _BSWAP32(x) # macro
def HIWORD(l): return ((WORD)(((DWORD)(l) >> 16) & 0xFFFF)) # macro
def GET_LOCAL_MODULE_HANDLE_KEEP_HS_FLAG(ulModHandle): return (ulModHandle & ~(API_SERVER_MASK)) # macro
def IS_HS_ACCESS(ulModHandle): return ((ulModHandle & API_HS_ACCESS) != 0) # macro
SCOPE_STATUS_WAIT_FOR_TRIGGER = 0
API_BM_MSG_FLT_FORMAT_5 = 5 # Variable c_int '5'
MAX_BM_MSGFLT_FORMAT = API_BM_MSG_FLT_FORMAT_5 # alias
API_BM_ENTRY_TIMETAG_HIGH = 3 # Variable c_int '3'
MAX_BM_ENTRY_TYPE = API_BM_ENTRY_TIMETAG_HIGH # alias
API_BIU_4 = 4 # Variable c_int '4'
MAX_BIU = API_BIU_4 # alias
API_BITE_TIMING = 13 # Variable c_int '13'
MAX_BITE_CONTROL = API_BITE_TIMING # alias
def offsetof(TYPE,MEMBER): return __builtin_offsetof (TYPE, MEMBER) # macro
MAX_API_DLL_INST = 32 # Variable c_int '32'
MAX_API_SERVER_PER_SYSTEM = MAX_API_DLL_INST # alias
API_TYPE_SIM_MON = API_DEVICE_MODE_FULL # alias
API_DEVICE_MODE_NA = 255
API_TYPE_NOT_PRESENT = API_DEVICE_MODE_NA # alias
API_DEVICE_MODE_SF = 2
API_TYPE_MON_ONLY = API_DEVICE_MODE_SF # alias
API_BC_MODE = 1 # Variable c_int '1'
API_TRACK_TYPE_BC = API_BC_MODE # alias
API_ERR = 1 # Variable c_int '1'
API_NET_IO_ERR = API_ERR # alias
AI_MEMTYPE_SHARED = 1
API_MEMTYPE_SHARED = AI_MEMTYPE_SHARED # alias
AI_MEMTYPE_GLOBAL_DIRECT = 4
API_MEMTYPE_GLOBAL_DIRECT = AI_MEMTYPE_GLOBAL_DIRECT # alias
__AI_MAX_VERSIONS = 23
AI_MAX_VERSIONS = __AI_MAX_VERSIONS # alias
# def SCOPE_SAMPLE_PACKET_BY_SAMPLE_ID(pBuffer,sample_id): return (*(((TY_API_SCOPE_SAMPLE_PACKET*) pBuffer) + (sample_id / 3))) # macro
# AI_LIB_FUNC = AI_CFUNC # alias
# AI_INLINE = __inline__ # alias
SCOPE_STATUS_TRIGGERED = 1
def __warnattr(msg): return __attribute__((__warning__ (msg))) # macro
# def __nonnull(params): return __attribute__ ((__nonnull__ params)) # macro
AI_DEVICE_AYS_ASP = 9
AI_DEVICE_AYXGNET = 7
AI_DEVICE_AYE_ASP = 6
def __va_arg_pack_len(): return __builtin_va_arg_pack_len () # macro
AI_DEVICE_AMC_ASP = 4
API_CAL_TRANS_500K = 1 # Variable c_int '1'
MAX_TRANS_MODE = API_CAL_TRANS_500K # alias
AI_DEVICE_AYX = 2
AI_DEVICE_UNKNOWN = 0
def __attribute_format_arg__(x): return __attribute__ ((__format_arg__ (x))) # macro
# def AI_DEPRECATED(func): return func __attribute__ ((deprecated)) # macro
# def CREATE_MODULE_HANDLE(dev,stream,srv): return ((((stream==0xFFFFFFFF)?0:stream) << API_STREAM_POS) | (srv << API_SERVER_POS) | dev) # macro
def BSWAP32(X): return (X) # macro
def BSWAP16(X): return (X) # macro
def BE32_TO_HOST(x): return _BSWAP32(x) # macro
# __wur = __attribute_warn_unused_result__ # alias
# WCHAR_MAX = __WCHAR_MAX # alias
API_SYSTAG_STEP_1S_COMP = 1 # Variable c_int '1'
MIN_SYSTAG_STEP_FCT7 = API_SYSTAG_STEP_1S_COMP # alias
API_HS_BC_TYPE_BCRT = 8 # Variable c_int '8'
MIN_HS_XFER_TYPE = API_HS_BC_TYPE_BCRT # alias
API_EF_SWITCH_TO_EFA = 1 # Variable c_int '1'
MIN_EF_SWITCHTYPE = API_EF_SWITCH_TO_EFA # alias
API_SQM_AS_QSIZE = 2 # Variable c_int '2'
MAX_API_SQM_MODE = API_SQM_AS_QSIZE # alias
MAX_BM_IMODE = API_BM_MODE_STOP_EVENT_INT # alias
# def __warndecl(name,msg): return extern void name (void) __attribute__((__warning__ (msg))) # macro
SCOPE_STATUS_OVERFLOW = 3
SCOPE_STATUS_STOPPED = 2
API_BC_START_INSTR_TABLE_DBA = 9 # Variable c_int '9'
MAX_BC_START_MODE = API_BC_START_INSTR_TABLE_DBA # alias
API_STREAM_8 = 8 # Variable c_int '8'
MAX_API_STREAM = API_STREAM_8 # alias
def GET_LOCAL_MODULE_HANDLE(ulModHandle): return (ulModHandle & ~(API_SERVER_MASK | API_HS_ACCESS)) # macro
# BSWAP16_MAC = _BSWAP16 # alias
API_TRACK_TYPE_RT = API_RT_MODE # alias
# def SCOPE_SAMPLE_PACKET_BY_PACKET_ID(pBuffer,packet_id): return (*(((TY_API_SCOPE_SAMPLE_PACKET*) pBuffer) + (packet_id))) # macro
AI_SUBDLL1_VER = 20
API_BM_TRG_HS_EVENT = 4 # Variable c_int '4'
MAX_TCB_TT = API_BM_TRG_HS_EVENT # alias
AI_MEMTYPE_LOCAL = 2
API_MEMTYPE_LOCAL = AI_MEMTYPE_LOCAL # alias
API_TBM_GLOBAL = 1 # Variable c_int '1'
MAX_TBM = API_TBM_GLOBAL # alias
AI_MEMTYPE_IO = 3
API_MEMTYPE_IO = AI_MEMTYPE_IO # alias
API_SYSTAG_STEP_2S_COMP = 2 # Variable c_int '2'
MAX_SYSTAG_STEP_FCT7 = API_SYSTAG_STEP_2S_COMP # alias
API_SYSTAG_STEP_KEEP_LAST = 1 # Variable c_int '1'
MAX_SYSTAG_STEP_FCT6 = API_SYSTAG_STEP_KEEP_LAST # alias
AI_MEMTYPE_GLOBAL_EXTENSION = 5
API_MEMTYPE_GLOBAL_EXTENSION = AI_MEMTYPE_GLOBAL_EXTENSION # alias
MAX_SYSTAG_STEP_FCT5 = API_SYSTAG_STEP_KEEP_LAST # alias
API_SYSTAG_RESUME = 1 # Variable c_int '1'
MAX_SYSTAG_CON = API_SYSTAG_RESUME # alias
API_RT_SWM_NXW_AND = 3 # Variable c_int '3'
MAX_SW_MASK_CONTROL = API_RT_SWM_NXW_AND # alias
API_SREC_START_ONCE = 3 # Variable c_int '3'
MAX_SREC_MODE = API_SREC_START_ONCE # alias
API_SCOPE_OPR_CHANNEL_B100 = 5 # Variable c_int '5'
MAX_SCOPE_OPR_MODE = API_SCOPE_OPR_CHANNEL_B100 # alias
API_SCOPE_COUPLING_EXTERN_3V = 7 # Variable c_int '7'
MAX_SCOPE_COUPLING_MODE = API_SCOPE_COUPLING_EXTERN_3V # alias
AI_IO_LCA_VER_BIU4 = 19
API_SCOPE_START_SINGLE = 2 # Variable c_int '2'
MAX_SCOPE_CAP_MODE = API_SCOPE_START_SINGLE # alias
API_RT_ENABLE_SA_INT_ERR = 3 # Variable c_int '3'
MAX_SA_CON = API_RT_ENABLE_SA_INT_ERR # alias
API_RT_RSP_SEC_BUS = 2 # Variable c_int '2'
MAX_RT_RESPONSE = API_RT_RSP_SEC_BUS # alias
API_RT_MODE_OPERATION_CTRL = 6 # Variable c_int '6'
MAX_RT_MODE_CTRL = API_RT_MODE_OPERATION_CTRL # alias
API_QUEUE_SIZE_256 = 8 # Variable c_int '8'
MAX_QUEUE_SIZE = API_QUEUE_SIZE_256 # alias
AI_MEMTYPE_GLOBAL = 0
API_MEMTYPE_GLOBAL = AI_MEMTYPE_GLOBAL # alias
API_PXI_SET_TTSRC_INTERNAL = 3 # Variable c_int '3'
MAX_PXICON_MODE = API_PXI_SET_TTSRC_INTERNAL # alias
API_MODE_SINGLE_RT = 1 # Variable c_int '1'
MAX_PROTOCOL_MODE = API_MODE_SINGLE_RT # alias
API_PROTOCOL_EFEX = 3 # Variable c_int '3'
MAX_PROTOCOL = API_PROTOCOL_EFEX # alias
API_BUF_RT_MSG = 2 # Variable c_int '2'
MAX_MSG_BUF = API_BUF_RT_MSG # alias
APIEF_BC_HS_XFER = 20 # Variable c_int '20'
APIEF_BC_XFER_TYPE_XXRTRT = APIEF_BC_HS_XFER # alias
API_BC_TIC_INT_ON_STAT_EXCEPT = 3 # Variable c_int '3'
MAX_LS_IR = API_BC_TIC_INT_ON_STAT_EXCEPT # alias
API_HS_WCM_STATUS_QUEUE = 1 # Variable c_int '1'
MAX_HS_WCM = API_HS_WCM_STATUS_QUEUE # alias
API_UPDATE_FINISHED = 4
API_UPDATE_IN_PROGRESS = 2
API_UPDATE_START_REQUESTED = 1
AI_SUBDLL3_VER = 22
AI_SUBDLL2_VER = 21
AI_IO_LCA_VER_BIU3 = 18
AI_IO_LCA_VER_BIU2 = 17
AI_FIRMWARE_VER_BIU3 = 15
AI_FIRMWARE_VER_BIU2 = 14
AI_FPGA_VER = 13
AI_TARGET_OS_VER = 12
AI_MONITOR_VER = 11
AI_BOOTSTRAP_VER = 10
API_BM_WRITE_HTM = 4 # Variable c_int '4'
MAX_BM_FTW_CON = API_BM_WRITE_HTM # alias
AI_PCI_LCA_VER = 8
AI_IO_LCA_VER_BIU1 = 7
AI_FIRMWARE_VER_BIU1 = 5
AI_REMOTE_DLL_VER = 3
AI_DLL_VER = 2
AI_ANS_VER = 1
AI_FIRMWARE_VER_BIU4 = 16
AI_SYS_DRV_VER = 0
def __va_arg_pack(): return __builtin_va_arg_pack () # macro
API_BM_CAPMODE_FILTER = 3 # Variable c_int '3'
MAX_BM_CAPMODE = API_BM_CAPMODE_FILTER # alias
def INT32_C(c): return c # macro
def __glibc_likely(cond): return __builtin_expect ((cond), 1) # macro
# def __errordecl(name,msg): return extern void name (void) __attribute__((__error__ (msg))) # macro
API_CAL_BUS_SECONDARY = 2 # Variable c_int '2'
MAX_BUS = API_CAL_BUS_SECONDARY # alias
class ty_api_lib_info(Structure):
    pass
uint32_t = c_uint32
AiUInt32 = uint32_t
ty_api_lib_info._fields_ = [
    ('ul_AttachedApps', AiUInt32),
]
TY_API_LIB_INFO = ty_api_lib_info
class ty_api_intr_regs(Structure):
    pass
ty_api_intr_regs._fields_ = [
    ('lla', AiUInt32),
    ('llb', AiUInt32),
    ('llc', AiUInt32),
    ('lld', AiUInt32),
]
TY_API_INTR_REGS = ty_api_intr_regs * 256
class ty_api_intr_loglist_llc_union(Union):
    pass
class ty_api_intr_loglist_llc_t(Structure):
    pass
ty_api_intr_loglist_llc_t._fields_ = [
    ('ul_Info', AiUInt32, 24),
    ('uc_IntType', AiUInt32, 8),
]
class ty_api_intr_loglist_llc_b(Structure):
    pass
ty_api_intr_loglist_llc_b._fields_ = [
    ('ul_Info', AiUInt32, 24),
    ('uc_Biu1', AiUInt32, 1),
    ('uc_Biu2', AiUInt32, 1),
    ('uc_Dma', AiUInt32, 1),
    ('uc_Target', AiUInt32, 1),
    ('uc_Cmd', AiUInt32, 1),
    ('uc_Biu3', AiUInt32, 1),
    ('uc_Biu4', AiUInt32, 1),
    ('res', AiUInt32, 1),
]
ty_api_intr_loglist_llc_union._fields_ = [
    ('ul_All', AiUInt32),
    ('t', ty_api_intr_loglist_llc_t),
    ('b', ty_api_intr_loglist_llc_b),
]
TY_API_INTR_LOGLIST_LLC = ty_api_intr_loglist_llc_union
class ty_api_intr_loglist_lld_union(Union):
    pass
class ty_api_intr_loglist_lld_union_t(Structure):
    pass
ty_api_intr_loglist_lld_union_t._fields_ = [
    ('ul_Index', AiUInt32, 16),
    ('uc_Res', AiUInt32, 8),
    ('uc_IntSrc', AiUInt32, 8),
]
ty_api_intr_loglist_lld_union._fields_ = [
    ('ul_All', AiUInt32),
    ('t', ty_api_intr_loglist_lld_union_t),
]
TY_API_INTR_LOGLIST_LLD = ty_api_intr_loglist_lld_union
class ty_api_intr_loglist_entry(Structure):
    pass
ty_api_intr_loglist_entry._fields_ = [
    ('ul_Lla', AiUInt32),
    ('ul_Llb', AiUInt32),
    ('x_Llc', TY_API_INTR_LOGLIST_LLC),
    ('x_Lld', TY_API_INTR_LOGLIST_LLD),
]
TY_API_INTR_LOGLIST_ENTRY = ty_api_intr_loglist_entry
class ty_api_intr_event_list(Structure):
    pass
ty_api_intr_event_list._fields_ = [
    ('put_cnt', AiUInt32),
    ('get_cnt', AiUInt32),
    ('entry', TY_API_INTR_LOGLIST_ENTRY * 256),
]
TY_API_INTR_EVENT_LIST = ty_api_intr_event_list
VOID_FUNC_1553 = CFUNCTYPE(None)
uint8_t = c_uint8
AiUInt8 = uint8_t
INTERRUPT_FUNC = CFUNCTYPE(None, AiUInt32, AiUInt8, AiUInt8, POINTER(TY_API_INTR_LOGLIST_ENTRY))
TY_INT_FUNC_PTR = CFUNCTYPE(None, AiUInt32, AiUInt8, AiUInt8, POINTER(TY_API_INTR_LOGLIST_ENTRY))
TY_PNP_CALLBACK_FUNC_PTR = CFUNCTYPE(None, AiUInt32, AiUInt32)
class ty_api_hs_gpio_res_inf(Structure):
    pass
uint16_t = c_uint16
AiUInt16 = uint16_t
ty_api_hs_gpio_res_inf._fields_ = [
    ('uc_DeviceId', AiUInt8),
    ('uc_DeviceType', AiUInt8),
    ('uw_Padding1', AiUInt16),
]
TY_API_HS_GPIO_RES_INF = ty_api_hs_gpio_res_inf
class ty_api_hs_reset_info(Structure):
    pass
ty_api_hs_reset_info._fields_ = [
    ('uc_LsMBufs', AiUInt8),
    ('uc_LsSBufs', AiUInt8),
    ('uc_HsMBufs', AiUInt8),
    ('uc_HsSBufs', AiUInt8),
    ('ul_LsMonAddr', AiUInt32),
    ('ul_LsSimAddr', AiUInt32),
    ('ul_HsMonAddr', AiUInt32),
    ('ul_HsSimAddr', AiUInt32),
]
TY_API_HS_RESET_INFO = ty_api_hs_reset_info
class ty_api_hs_systag(Structure):
    pass
ty_api_hs_systag._fields_ = [
    ('uw_XidRtMid', AiUInt16),
    ('uw_Fct', AiUInt16),
    ('uw_Min', AiUInt16),
    ('uw_Max', AiUInt16),
    ('uw_Step', AiUInt16),
    ('uw_WPos', AiUInt16),
    ('uw_BPos', AiUInt16),
]
TY_API_HS_SYSTAG = ty_api_hs_systag
class ty_api_hs_bh_modify(Structure):
    pass
ty_api_hs_bh_modify._fields_ = [
    ('ul_BHAddr', AiUInt32),
    ('ul_DataBufferStoreMode', AiUInt32),
    ('ul_WordCountMode', AiUInt32),
    ('ul_BufferSize', AiUInt32),
    ('ul_BufferQueueMode', AiUInt32),
    ('ul_BufferQueueSize', AiUInt32),
    ('ul_StatusQueueSize', AiUInt32),
    ('ul_EventQueueSize', AiUInt32),
    ('ul_CurrentBufferIndex', AiUInt32),
]
TY_API_HS_BH_MODIFY = ty_api_hs_bh_modify
class ty_api_hs_track_def_in(Structure):
    pass
int32_t = c_int32
AiInt32 = int32_t
ty_api_hs_track_def_in._fields_ = [
    ('ul_TrackId', AiUInt32),
    ('ul_BT', AiUInt32),
    ('ul_XidRtMid', AiUInt32),
    ('ul_Mode', AiUInt32),
    ('ul_TrackStartPos', AiUInt32),
    ('ul_TrackBPos', AiUInt32),
    ('ul_TrackBLen', AiUInt32),
    ('ul_TrackLen', AiUInt32),
    ('ul_MultiplexedTrackNb', AiUInt32),
    ('ul_ContinousTrackNb', AiUInt32),
    ('l_Offset', AiInt32),
]
TY_API_HS_TRACK_DEF_IN = ty_api_hs_track_def_in
class ty_api_hs_track_def_out(Structure):
    pass
ty_api_hs_track_def_out._fields_ = [
    ('ul_TrackBufferStartAddr', AiUInt32),
]
TY_API_HS_TRACK_DEF_OUT = ty_api_hs_track_def_out
class ty_api_hs_track_read_in(Structure):
    pass
ty_api_hs_track_read_in._fields_ = [
    ('ul_TrackId', AiUInt32),
    ('ul_MultiplexedTrackIndex', AiUInt32),
    ('ul_ReadMode', AiUInt32),
]
TY_API_HS_TRACK_READ_IN = ty_api_hs_track_read_in
class ty_api_hs_track_read_out(Structure):
    pass
ty_api_hs_track_read_out._fields_ = [
    ('ul_DataValid', AiUInt32),
    ('ul_LastTT', AiUInt32),
    ('puw_TrackDataWords', POINTER(AiUInt16)),
]
TY_API_HS_TRACK_READ_OUT = ty_api_hs_track_read_out
class ty_api_hs_track_scan_in(Structure):
    pass
ty_api_hs_track_scan_in._fields_ = [
    ('ul_TrackId', AiUInt32),
    ('ul_ChunkNb', AiUInt32),
    ('ul_ChunkSize', AiUInt32),
]
TY_API_HS_TRACK_SCAN_IN = ty_api_hs_track_scan_in
class ty_api_hs_track_scan_out(Structure):
    pass
ty_api_hs_track_scan_out._fields_ = [
    ('ul_NumberOfReturnedStates', AiUInt32),
    ('ul_MoreData', AiUInt32),
    ('pul_ReturnedStates', POINTER(AiUInt32)),
]
TY_API_HS_TRACK_SCAN_OUT = ty_api_hs_track_scan_out
class ty_api_hs_track_prealloc_in(Structure):
    pass
ty_api_hs_track_prealloc_in._fields_ = [
    ('ul_TrackId', AiUInt32),
    ('ul_PreAllocNb', AiUInt32),
    ('pul_MuxStates', POINTER(AiUInt32)),
]
TY_API_HS_TRACK_PREALLOC_IN = ty_api_hs_track_prealloc_in
class ty_api_hs_track_prealloc_out(Structure):
    pass
ty_api_hs_track_prealloc_out._fields_ = [
    ('pul_TrackBufferStartAddr', POINTER(AiUInt32)),
]
TY_API_HS_TRACK_PREALLOC_OUT = ty_api_hs_track_prealloc_out
class ty_api_hs_bc_bh_info(Structure):
    pass
ty_api_hs_bc_bh_info._fields_ = [
    ('uw_SqId', AiUInt16),
    ('uw_EqId', AiUInt16),
    ('uw_NBufs', AiUInt16),
    ('uw_Padding1', AiUInt16),
    ('ul_Mem', AiUInt32),
    ('ul_HIdAddr', AiUInt32),
    ('ul_BqAddr', AiUInt32),
    ('ul_SqAddr', AiUInt32),
    ('ul_EqAddr', AiUInt32),
    ('ul_HeaderId2', AiUInt32),
    ('ul_LsHIdAddr1', AiUInt32),
    ('ul_LsBqAddr1', AiUInt32),
    ('ul_LsSqAddr1', AiUInt32),
    ('ul_LsEqAddr1', AiUInt32),
    ('ul_LsHIdAddr2', AiUInt32),
    ('ul_LsBqAddr2', AiUInt32),
    ('ul_LsSqAddr2', AiUInt32),
    ('ul_LsEqAddr2', AiUInt32),
]
TY_API_HS_BC_BH_INFO = ty_api_hs_bc_bh_info
class ty_api_hs_bc_err(Structure):
    pass
ty_api_hs_bc_err._fields_ = [
    ('uc_Type', AiUInt8),
    ('uc_Padding1', AiUInt8),
    ('uw_Padding2', AiUInt16),
    ('ul_ErrSpec', AiUInt32),
]
TY_API_HS_BC_ERR = ty_api_hs_bc_err
class ty_api_hsls_bc_xfer(Structure):
    pass
ty_api_hsls_bc_xfer._fields_ = [
    ('ul_Gap', AiUInt32),
    ('ul_Swxm', AiUInt32),
]
TY_API_HSLS_BC_XFER = ty_api_hsls_bc_xfer
class ty_api_hs_bc_xfer(Structure):
    pass
class ty_api_hs_bc_xfer_x_common(Structure):
    pass
ty_api_hs_bc_xfer_x_common._fields_ = [
    ('uw_XferId', AiUInt16),
    ('uw_HeaderId', AiUInt16),
    ('uc_XferType', AiUInt8),
    ('uc_XferHalt', AiUInt8),
    ('uc_MsgSize', AiUInt8),
    ('uc_Padding1', AiUInt8),
    ('uw_Rt', AiUInt16),
    ('uw_Mid', AiUInt16),
    ('uc_StatusWordException', AiUInt8),
    ('uc_RetryControl', AiUInt8),
    ('uw_Padding2', AiUInt16),
    ('x_FirstXfer', TY_API_HSLS_BC_XFER),
    ('x_SecondXfer', TY_API_HSLS_BC_XFER),
]
class ty_api_hs_bc_xfer_x_ls(Structure):
    pass
class ty_api_bc_err(Structure):
    pass
ty_api_bc_err._fields_ = [
    ('type', AiUInt8),
    ('sync', AiUInt8),
    ('contig', AiUInt8),
    ('padding1', AiUInt8),
    ('err_spec', AiUInt32),
]
TY_API_BC_ERR = ty_api_bc_err
ty_api_hs_bc_xfer_x_ls._fields_ = [
    ('ul_LsChnIr', AiUInt32),
    ('x_LsErr', TY_API_BC_ERR),
]
class ty_api_hs_bc_xfer_x_hs(Structure):
    pass
ty_api_hs_bc_xfer_x_hs._fields_ = [
    ('ul_HsChnIr', AiUInt32),
    ('ul_HsXmt', AiUInt32),
    ('x_HsErr', TY_API_HS_BC_ERR),
]
ty_api_hs_bc_xfer._fields_ = [
    ('x_Common', ty_api_hs_bc_xfer_x_common),
    ('x_Ls', ty_api_hs_bc_xfer_x_ls),
    ('x_Hs', ty_api_hs_bc_xfer_x_hs),
]
TY_API_HS_BC_XFER = ty_api_hs_bc_xfer
class ty_api_hs_bc_xfer_info(Structure):
    pass
ty_api_hs_bc_xfer_info._fields_ = [
    ('ul_LsXferDescAddr1', AiUInt32),
    ('ul_LsXferDescAddr2', AiUInt32),
    ('ul_HsXferDescAddr', AiUInt32),
]
TY_API_HS_BC_XFER_INFO = ty_api_hs_bc_xfer_info
class ty_api_hs_bc_dytag(Structure):
    pass
ty_api_hs_bc_dytag._fields_ = [
    ('uc_DytagWordMode', AiUInt8),
    ('uc_Mode', AiUInt8),
    ('uw_FctWord', AiUInt16),
    ('uw_WPos', AiUInt16),
]
TY_API_HS_BC_DYTAG = ty_api_hs_bc_dytag
class ty_api_hs_bc_xfer_status_xfer(Structure):
    pass
ty_api_hs_bc_xfer_status_xfer._fields_ = [
    ('uw_CmdWord', AiUInt16),
    ('uw_StatusWord', AiUInt16),
    ('uw_XferRepWord', AiUInt16),
    ('uw_ActionWord', AiUInt16),
    ('ul_TimeTag', AiUInt32),
    ('ul_XferCnt', AiUInt32),
    ('ul_ErrCnt', AiUInt32),
    ('ul_LastVectorWord', AiUInt32),
    ('ul_ServiceRequestCnt', AiUInt32),
]
TY_API_HS_BC_XFER_STATUS_XFER = ty_api_hs_bc_xfer_status_xfer
class ty_api_hs_bc_xfer_status(Structure):
    pass
ty_api_hs_bc_xfer_status._fields_ = [
    ('x_First', TY_API_HS_BC_XFER_STATUS_XFER),
    ('x_Second', TY_API_HS_BC_XFER_STATUS_XFER),
    ('uw_SqDa', AiUInt16),
    ('uw_SqFrmCtrlWord', AiUInt16),
    ('uw_SqWCntWord', AiUInt16),
    ('uw_SqMsgTagWord', AiUInt16),
    ('uw_SqEntryCtrlWord', AiUInt16),
    ('uw_Padding1', AiUInt16),
    ('ul_SqActBufPtr', AiUInt32),
    ('ul_SqTimeTag', AiUInt32),
]
TY_API_HS_BC_XFER_STATUS = ty_api_hs_bc_xfer_status
class ty_api_hs_bc_xfer_status_queue(Structure):
    pass
ty_api_hs_bc_xfer_status_queue._fields_ = [
    ('ul_SqCtrlWord', AiUInt32),
    ('ul_SqCmdActWord', AiUInt32),
    ('ul_SqActBufPtr', AiUInt32),
    ('ul_SqFCPADAWord', AiUInt32),
    ('ul_SqWCntMsgTagWord', AiUInt32),
    ('ul_SqTimeTag', AiUInt32),
]
TY_API_HS_BC_XFER_STATUS_QUEUE = ty_api_hs_bc_xfer_status_queue
class ty_api_hs_bc_xfer_status_info(Structure):
    pass
ty_api_hs_bc_xfer_status_info._fields_ = [
    ('ul_ActBufferId', AiUInt32),
    ('ul_XferCnt', AiUInt32),
    ('ul_ErrCnt', AiUInt32),
]
TY_API_HS_BC_XFER_STATUS_INFO = ty_api_hs_bc_xfer_status_info
class ty_api_hs_bc_xfer_status_ex(Structure):
    pass
class ty_api_bc_xfer_status_info(Structure):
    pass
ty_api_bc_xfer_status_info._fields_ = [
    ('ul_ActBufferId', AiUInt32),
    ('ul_ActionWord', AiUInt32),
    ('ul_XferCnt', AiUInt32),
    ('ul_ErrCnt', AiUInt32),
    ('ul_LastVectorWord', AiUInt32),
    ('ul_ServiceRequestCnt', AiUInt32),
]
TY_API_BC_XFER_STATUS_INFO = ty_api_bc_xfer_status_info
class ty_api_bc_xfer_status_queue(Structure):
    pass
ty_api_bc_xfer_status_queue._fields_ = [
    ('ul_SqCtrlWord', AiUInt32),
    ('ul_SqStatusWords', AiUInt32),
    ('ul_SqActBufPtr', AiUInt32),
    ('ul_SqTimeTag', AiUInt32),
]
TY_API_BC_XFER_STATUS_QUEUE = ty_api_bc_xfer_status_queue
class ty_api_bc_xfer_event_queue(Structure):
    pass
ty_api_bc_xfer_event_queue._fields_ = [
    ('ul_EqEntryWord1', AiUInt32),
    ('ul_EqEntryWord2', AiUInt32),
    ('ul_EqEntryWord3', AiUInt32),
    ('ul_EqEntryWord4', AiUInt32),
]
TY_API_BC_XFER_EVENT_QUEUE = ty_api_bc_xfer_event_queue
ty_api_hs_bc_xfer_status_ex._fields_ = [
    ('ul_BufferQueueSize', AiUInt32),
    ('x_LsXfer1Info', TY_API_BC_XFER_STATUS_INFO),
    ('x_LsXfer2Info', TY_API_BC_XFER_STATUS_INFO),
    ('x_HsXferInfo', TY_API_HS_BC_XFER_STATUS_INFO),
    ('x_LsXfer1SQueue', TY_API_BC_XFER_STATUS_QUEUE * 256),
    ('x_LsXfer2SQueue', TY_API_BC_XFER_STATUS_QUEUE * 256),
    ('x_HsXferSQueue', TY_API_HS_BC_XFER_STATUS_QUEUE * 256),
    ('x_LsXfer1EQueue', TY_API_BC_XFER_EVENT_QUEUE * 1),
    ('x_LsXfer2EQueue', TY_API_BC_XFER_EVENT_QUEUE * 1),
    ('x_HsXferEQueue', TY_API_BC_XFER_EVENT_QUEUE * 1),
]
TY_API_HS_BC_XFER_STATUS_EX = ty_api_hs_bc_xfer_status_ex
class ty_api_hs_bc_xfer_read_in(Structure):
    pass
ty_api_hs_bc_xfer_read_in._fields_ = [
    ('ul_XferId', AiUInt32),
    ('ul_Clear', AiUInt32),
    ('ul_Mode', AiUInt32),
]
TY_API_HS_BC_XFER_READ_IN = ty_api_hs_bc_xfer_read_in
class ty_api_hs_bc_status(Structure):
    pass
ty_api_hs_bc_status._fields_ = [
    ('ul_GlbMsgCnt', AiUInt32),
    ('ul_GlbErrCnt', AiUInt32),
    ('ul_Reserved1', AiUInt32),
    ('ul_Reserved2', AiUInt32),
    ('ul_Reserved3', AiUInt32),
    ('ul_Reserved4', AiUInt32),
]
TY_API_HS_BC_STATUS = ty_api_hs_bc_status
class ty_api_hs_bc_mode_ctrl(Structure):
    pass
ty_api_hs_bc_mode_ctrl._fields_ = [
    ('ul_BcMode', AiUInt32),
    ('ul_Ctrl', AiUInt32),
    ('ul_Param1', AiUInt32),
    ('ul_Param2', AiUInt32),
    ('ul_Param3', AiUInt32),
]
TY_API_HS_BC_MODE_CTRL = ty_api_hs_bc_mode_ctrl
class ty_api_hs_rt_err(Structure):
    pass
ty_api_hs_rt_err._fields_ = [
    ('uc_Type', AiUInt8),
    ('uc_Padding1', AiUInt8),
    ('uw_Padding2', AiUInt16),
    ('ul_ErrSpec', AiUInt32),
]
TY_API_HS_RT_ERR = ty_api_hs_rt_err
class ty_api_hs_rt_bh_info(Structure):
    pass
ty_api_hs_rt_bh_info._fields_ = [
    ('uw_SqId', AiUInt16),
    ('uw_EqId', AiUInt16),
    ('uw_NBufs', AiUInt16),
    ('uw_Padding1', AiUInt16),
    ('ul_BhAddr', AiUInt32),
    ('ul_BqAddr', AiUInt32),
    ('ul_SqAddr', AiUInt32),
    ('ul_EqAddr', AiUInt32),
]
TY_API_HS_RT_BH_INFO = ty_api_hs_rt_bh_info
class ty_api_hs_rt_dytag(Structure):
    pass
ty_api_hs_rt_dytag._fields_ = [
    ('uc_DytagWordMode', AiUInt8),
    ('uc_Mode', AiUInt8),
    ('uw_FctWord', AiUInt16),
    ('uw_WPos', AiUInt16),
]
TY_API_HS_RT_DYTAG = ty_api_hs_rt_dytag
class ty_api_hs_rt_status_dsp(Structure):
    pass
ty_api_hs_rt_status_dsp._fields_ = [
    ('uw_HsStatusWord', AiUInt16),
    ('uw_HsActionWord', AiUInt16),
    ('ul_HsMsgCnt', AiUInt32),
    ('ul_HsErrCnt', AiUInt32),
]
TY_API_HS_RT_STATUS_DSP = ty_api_hs_rt_status_dsp
class ty_api_hs_rt_mid_status(Structure):
    pass
ty_api_hs_rt_mid_status._fields_ = [
    ('uw_HsStatusRepWord', AiUInt16),
    ('uw_HsSqDa', AiUInt16),
    ('uw_HsSqFrmCtrlWord', AiUInt16),
    ('uw_HsSqWCntWord', AiUInt16),
    ('uw_HsSqMsgTag', AiUInt16),
    ('uw_HsActionWord', AiUInt16),
    ('ul_HsCurBufPtr', AiUInt32),
    ('ul_HsCurTimeTag', AiUInt32),
]
TY_API_HS_RT_MID_STATUS = ty_api_hs_rt_mid_status
class ty_api_hs_rt_mid_status_queue(Structure):
    pass
ty_api_hs_rt_mid_status_queue._fields_ = [
    ('ul_SqCtrlWord', AiUInt32),
    ('ul_SqCmdActWord', AiUInt32),
    ('ul_SqActBufPtr', AiUInt32),
    ('ul_SqFCPADAWord', AiUInt32),
    ('ul_SqWCntMsgTagWord', AiUInt32),
    ('ul_SqTimeTag', AiUInt32),
]
TY_API_HS_RT_MID_STATUS_QUEUE = ty_api_hs_rt_mid_status_queue
class ty_api_hs_rt_mid_status_info(Structure):
    pass
ty_api_hs_rt_mid_status_info._fields_ = [
    ('ul_ActBufferId', AiUInt32),
    ('ul_XferCnt', AiUInt32),
    ('ul_ErrCnt', AiUInt32),
]
TY_API_HS_RT_MID_STATUS_INFO = ty_api_hs_rt_mid_status_info
class ty_api_hs_rt_mid_status_ex(Structure):
    pass
class ty_api_rt_sa_status_info(Structure):
    pass
ty_api_rt_sa_status_info._fields_ = [
    ('ul_ActBufferId', AiUInt32),
    ('ul_ActionWord', AiUInt32),
    ('ul_XferCnt', AiUInt32),
    ('ul_ErrCnt', AiUInt32),
]
TY_API_RT_SA_STATUS_INFO = ty_api_rt_sa_status_info
class ty_api_rt_sa_status_queue(Structure):
    pass
ty_api_rt_sa_status_queue._fields_ = [
    ('ul_SqCtrlWord', AiUInt32),
    ('ul_SqStatusWords', AiUInt32),
    ('ul_SqActBufPtr', AiUInt32),
    ('ul_SqTimeTag', AiUInt32),
]
TY_API_RT_SA_STATUS_QUEUE = ty_api_rt_sa_status_queue
class ty_api_rt_sa_event_queue(Structure):
    pass
ty_api_rt_sa_event_queue._fields_ = [
    ('ul_EqEntryWord1', AiUInt32),
    ('ul_EqEntryWord2', AiUInt32),
    ('ul_EqEntryWord3', AiUInt32),
    ('ul_EqEntryWord4', AiUInt32),
]
TY_API_RT_SA_EVENT_QUEUE = ty_api_rt_sa_event_queue
ty_api_hs_rt_mid_status_ex._fields_ = [
    ('ul_BufferQueueSize', AiUInt32),
    ('x_LsXferInfo', TY_API_RT_SA_STATUS_INFO),
    ('x_HsXferInfo', TY_API_HS_RT_MID_STATUS_INFO),
    ('x_LsXferSQueue', TY_API_RT_SA_STATUS_QUEUE * 256),
    ('x_HsXferSQueue', TY_API_HS_RT_MID_STATUS_QUEUE * 256),
    ('x_LsXferEQueue', TY_API_RT_SA_EVENT_QUEUE * 1),
    ('x_HsXferEQueue', TY_API_RT_SA_EVENT_QUEUE * 1),
]
TY_API_HS_RT_MID_STATUS_EX = ty_api_hs_rt_mid_status_ex
class ty_api_hs_rt_mid_read_in(Structure):
    pass
ty_api_hs_rt_mid_read_in._fields_ = [
    ('ul_RtAddr', AiUInt32),
    ('ul_MsgId', AiUInt32),
    ('ul_MsgIdType', AiUInt32),
    ('ul_ClrBufStat', AiUInt32),
    ('ul_Mode', AiUInt32),
]
TY_API_HS_RT_MID_READ_IN = ty_api_hs_rt_mid_read_in
class ty_api_hs_rt_mode_ctrl(Structure):
    pass
ty_api_hs_rt_mode_ctrl._fields_ = [
    ('ul_BcMode', AiUInt32),
    ('ul_Ctrl', AiUInt32),
    ('ul_Param1', AiUInt32),
    ('ul_Param2', AiUInt32),
    ('ul_Param3', AiUInt32),
]
TY_API_HS_RT_MODE_CTRL = ty_api_hs_rt_mode_ctrl
class ty_api_hs_rep_status(Structure):
    pass
ty_api_hs_rep_status._fields_ = [
    ('uc_Status', AiUInt8),
    ('uc_Padding1', AiUInt8),
    ('uw_Padding2', AiUInt16),
    ('ul_RpiCnt', AiUInt32),
    ('ul_SAddr', AiUInt32),
    ('ul_Size', AiUInt32),
    ('ul_MsgCnt', AiUInt32),
]
TY_API_HS_REP_STATUS = ty_api_hs_rep_status
class ty_api_hs_bm_msg_flt(Structure):
    pass
ty_api_hs_bm_msg_flt._fields_ = [
    ('ul_MceRxMid1', AiUInt32),
    ('ul_MceRxMid2', AiUInt32),
    ('ul_MceRxMid3', AiUInt32),
    ('ul_MceRxMid4', AiUInt32),
    ('ul_MceRxMid5', AiUInt32),
    ('ul_MceRxMid6', AiUInt32),
    ('ul_MceRxMid7', AiUInt32),
    ('ul_MceRxMid8', AiUInt32),
    ('ul_MceTxMid1', AiUInt32),
    ('ul_MceTxMid2', AiUInt32),
    ('ul_MceTxMid3', AiUInt32),
    ('ul_MceTxMid4', AiUInt32),
    ('ul_MceTxMid5', AiUInt32),
    ('ul_MceTxMid6', AiUInt32),
    ('ul_MceTxMid7', AiUInt32),
    ('ul_MceTxMid8', AiUInt32),
]
TY_API_HS_BM_MSG_FLT = ty_api_hs_bm_msg_flt
class ty_api_hs_bm_status(Structure):
    pass
ty_api_hs_bm_status._fields_ = [
    ('uc_Men', AiUInt8),
    ('uc_Padding1', AiUInt8),
    ('uw_Padding2', AiUInt16),
    ('ul_Msw', AiUInt32),
    ('ul_GlbMsgCnt', AiUInt32),
    ('ul_GlbErrCnt', AiUInt32),
    ('ul_GlbWordCntB', AiUInt32),
    ('ul_GlbWordCntA', AiUInt32),
    ('ul_GlbMsgCntB', AiUInt32),
    ('ul_GlbMsgCntA', AiUInt32),
    ('ul_GlbErrCntB', AiUInt32),
    ('ul_GlbErrCntA', AiUInt32),
    ('ul_BusLoadB', AiUInt32),
    ('ul_BusLoadA', AiUInt32),
    ('ul_BusLoadBAvg', AiUInt32),
    ('ul_BusLoadAAvg', AiUInt32),
]
TY_API_HS_BM_STATUS = ty_api_hs_bm_status
class ty_api_hs_bm_trg_cond(Structure):
    pass
ty_api_hs_bm_trg_cond._fields_ = [
    ('ul_ErrTrgWord', AiUInt32),
    ('ul_MonDataWord', AiUInt32),
    ('ul_MonCwActWord', AiUInt32),
    ('ul_MonCwActMask', AiUInt32),
    ('ul_MonFcPaWord', AiUInt32),
    ('ul_MonFcPaMask', AiUInt32),
]
TY_API_HS_BM_TRG_COND = ty_api_hs_bm_trg_cond
class ty_api_hs_bm_act(Structure):
    pass
ty_api_hs_bm_act._fields_ = [
    ('uc_Fnd', AiUInt8),
    ('uc_Rt', AiUInt8),
    ('uc_Mid', AiUInt8),
    ('uc_Type', AiUInt8),
    ('ul_MsgCnt', AiUInt32),
    ('ul_ErrCnt', AiUInt32),
    ('ul_ErrTypeWord', AiUInt32),
]
TY_API_HS_BM_ACT = ty_api_hs_bm_act
class ty_api_hs_bm_rt_act(Structure):
    pass
ty_api_hs_bm_rt_act._fields_ = [
    ('ul_MsgCnt', AiUInt32),
    ('ul_ErrCnt', AiUInt32),
    ('ul_ErrTypeWord', AiUInt32),
]
TY_API_HS_BM_RT_ACT = ty_api_hs_bm_rt_act
class ty_api_hs_bm_stackp_dsp(Structure):
    pass
ty_api_hs_bm_stackp_dsp._fields_ = [
    ('uc_Status', AiUInt8),
    ('uc_Padding1', AiUInt8),
    ('uw_StpCtpCnt', AiUInt16),
    ('uw_CtpEtpCnt', AiUInt16),
    ('uw_EntryCnt', AiUInt16),
    ('ul_Stp', AiUInt32),
    ('ul_Ctp', AiUInt32),
    ('ul_Etp', AiUInt32),
]
TY_API_HS_BM_STACKP_DSP = ty_api_hs_bm_stackp_dsp
class ty_api_hs_bm_stack_entry(Structure):
    pass
ty_api_hs_bm_stack_entry._fields_ = [
    ('uw_TxInitTime', AiUInt16),
    ('uw_HsBufTagWord', AiUInt16),
    ('ul_HsTimetagHigh', AiUInt32),
    ('ul_HsTimetagLow', AiUInt32),
    ('uw_LsCmdWord', AiUInt16),
    ('uw_LsActWord', AiUInt16),
    ('ul_LsCtrlWord', AiUInt32),
    ('uw_LsCmdWord2', AiUInt16),
    ('uw_LsActWord2', AiUInt16),
    ('ul_LsCtrlWord2', AiUInt32),
    ('ul_FcPaDa', AiUInt32),
    ('uw_WCntWord', AiUInt16),
    ('uw_EntryAmount', AiUInt16),
    ('auw_Data', AiUInt16 * 4096),
    ('ul_Reserved1', AiUInt32),
    ('ul_Reserved2', AiUInt32),
    ('ul_Reserved3', AiUInt32),
    ('ul_Reserved4', AiUInt32),
    ('uw_Reserved5', AiUInt16),
    ('uw_Fcs', AiUInt16),
]
TY_API_HS_BM_STACK_ENTRY = ty_api_hs_bm_stack_entry
class ty_api_hs_bm_fw_mon_buffer_entry(Structure):
    pass
ty_api_hs_bm_fw_mon_buffer_entry._fields_ = [
    ('ul_BufHeadPointer', AiUInt32),
    ('ul_NextBufPointer', AiUInt32),
    ('uw_HsBufTagWord', AiUInt16),
    ('uw_TxInitTime', AiUInt16),
    ('ul_HsTimetagHigh', AiUInt32),
    ('ul_HsTimetagLow', AiUInt32),
    ('uw_LsActWord', AiUInt16),
    ('uw_LsCmdWord', AiUInt16),
    ('ul_LsCtrlWord', AiUInt32),
    ('uw_LsActWord2', AiUInt16),
    ('uw_LsCmdWord2', AiUInt16),
    ('ul_LsCtrlWord2', AiUInt32),
    ('aul_reserved', AiUInt32 * 4),
    ('uw_Fcs', AiUInt16),
    ('uw_reserved', AiUInt16),
    ('uw_Da', AiUInt16),
    ('uw_FcPa', AiUInt16),
    ('uw_EntryAmount', AiUInt16),
    ('uw_WCntWord', AiUInt16),
    ('auw_Data', AiUInt16 * 4096),
]
TY_API_HS_BM_FW_MON_BUFFER_ENTRY = ty_api_hs_bm_fw_mon_buffer_entry
class ty_api_hs_bm_stack_fnd(Structure):
    pass
ty_api_hs_bm_stack_fnd._fields_ = [
    ('uc_EntryFnd', AiUInt8),
    ('uc_Eos', AiUInt8),
    ('uw_EntryNr', AiUInt16),
    ('uw_WordNr', AiUInt16),
]
TY_API_HS_BM_STACK_FND = ty_api_hs_bm_stack_fnd
class ty_api_hs_bm_rec(Structure):
    pass
ty_api_hs_bm_rec._fields_ = [
    ('uc_Status', AiUInt8),
    ('uc_Padding1', AiUInt8),
    ('uw_Padding2', AiUInt16),
    ('ul_HfiCnt', AiUInt32),
    ('ul_SAddr', AiUInt32),
    ('ul_Size', AiUInt32),
]
TY_API_HS_BM_REC = ty_api_hs_bm_rec
class ty_api_ef_bm_stack_entry(Structure):
    pass
ty_api_ef_bm_stack_entry._fields_ = [
    ('ul_BufHeadPtr', AiUInt32),
    ('ul_NextBufPtr', AiUInt32),
    ('ul_HsBufTagWord', AiUInt32),
    ('ul_HsTimetagHigh', AiUInt32),
    ('ul_HsTimetagLow', AiUInt32),
    ('uw_FrameDAW', AiUInt16),
    ('uw_FramePAW', AiUInt16),
    ('uw_FrameTagWord', AiUInt16),
    ('uw_FrameWordCnt', AiUInt16),
    ('uw_ModeDataWord2', AiUInt16),
    ('uw_Res1', AiUInt16),
    ('uw_SFrameADWWord', AiUInt16),
    ('uw_SFramePAWord', AiUInt16),
    ('uw_SFrameTagWord', AiUInt16),
    ('uw_Res2', AiUInt16),
    ('uw_SDFrameTagWord', AiUInt16),
    ('uw_SDFrameXmtWordCnt', AiUInt16),
    ('uw_LsActWord', AiUInt16),
    ('uw_LsCmdWord', AiUInt16),
    ('uw_LsActWord2', AiUInt16),
    ('uw_LsCmdWord2', AiUInt16),
    ('ul_Res5', AiUInt32),
    ('uw_SDFrameDSIWord', AiUInt16),
    ('uw_SDFrameFCPA', AiUInt16),
    ('uw_EntryAmount', AiUInt16),
    ('uw_SDFrameRcvWordCnt', AiUInt16),
    ('auw_Data', AiUInt16 * 4096),
]
TY_API_EF_BM_STACK_ENTRY = ty_api_ef_bm_stack_entry
class ty_api_ef_bc_xfer(Structure):
    pass
class ty_api_ef_bc_xfer_x_common(Structure):
    pass
ty_api_ef_bc_xfer_x_common._fields_ = [
    ('uw_XferId', AiUInt16),
    ('uw_HeaderId', AiUInt16),
    ('uc_XferType', AiUInt8),
    ('uc_XferHalt', AiUInt8),
    ('uc_MsgSize', AiUInt8),
    ('uc_Padding1', AiUInt8),
    ('uw_Rt', AiUInt16),
    ('uw_Mid', AiUInt16),
    ('uc_StatusWordException', AiUInt8),
    ('uc_RetryControl', AiUInt8),
    ('uw_Padding2', AiUInt16),
    ('uw_WCount', AiUInt16),
    ('uw_EfexMCWordOne', AiUInt16),
    ('uw_EfexMCWordTwo', AiUInt16),
    ('x_FirstXfer', TY_API_HSLS_BC_XFER),
    ('x_SecondXfer', TY_API_HSLS_BC_XFER),
]
class ty_api_ef_bc_xfer_x_ls(Structure):
    pass
ty_api_ef_bc_xfer_x_ls._fields_ = [
    ('ul_LsChnIr', AiUInt32),
    ('x_LsErr', TY_API_BC_ERR),
]
class ty_api_ef_bc_xfer_x_hs(Structure):
    pass
ty_api_ef_bc_xfer_x_hs._fields_ = [
    ('ul_HsChnIr', AiUInt32),
    ('ul_HsXmt', AiUInt32),
    ('x_HsErr', TY_API_HS_BC_ERR),
]
ty_api_ef_bc_xfer._fields_ = [
    ('x_Common', ty_api_ef_bc_xfer_x_common),
    ('x_Ls', ty_api_ef_bc_xfer_x_ls),
    ('x_Hs', ty_api_ef_bc_xfer_x_hs),
]
TY_API_EF_BC_XFER = ty_api_ef_bc_xfer
class ty_api_ef_rt_descriptor(Structure):
    pass
ty_api_ef_rt_descriptor._fields_ = [
    ('ul_RtTransDescControl', AiUInt32),
    ('ul_RtTransStatus', AiUInt32),
    ('ul_RtTransCount', AiUInt32),
    ('ul_RtTransErrCount', AiUInt32),
    ('uw_NextStatus', AiUInt16),
    ('uw_LastStatus', AiUInt16),
    ('uw_NextADW', AiUInt16),
    ('uw_LastADW', AiUInt16),
    ('uw_CCMCDestAdd', AiUInt16),
    ('uw_CCMCFrameCont', AiUInt16),
    ('uw_CCMCMessTag', AiUInt16),
    ('uw_CCMCWCount', AiUInt16),
    ('uw_MCDataW2', AiUInt16),
    ('uw_MCDataW1', AiUInt16),
    ('ul_Res1', AiUInt32),
]
TY_API_EF_RT_DESCRIPTOR = ty_api_ef_rt_descriptor
class ty_api_ef_bc_xfer_stat(Structure):
    pass
ty_api_ef_bc_xfer_stat._fields_ = [
    ('ul_TransDescControl', AiUInt32),
    ('ul_TransStatus', AiUInt32),
    ('ul_ErrSpec', AiUInt32),
    ('ul_TransCount', AiUInt32),
    ('ul_TransErrCount', AiUInt32),
    ('uw_CCDestAddress', AiUInt16),
    ('uw_CCFrameControl', AiUInt16),
    ('uw_CCWCountMCModeCom', AiUInt16),
    ('uw_MCModeCom', AiUInt16),
    ('uw_SFrameMessTag', AiUInt16),
    ('uw_Reserved', AiUInt16),
    ('uw_SFrameADW', AiUInt16),
    ('uw_SFrameControl', AiUInt16),
    ('uw_SDFrameMessTag', AiUInt16),
    ('uw_SDFrameWCount', AiUInt16),
    ('uw_SDFrameDestAddr', AiUInt16),
    ('uw_SDFrameControl', AiUInt16),
    ('ul_TimeTag', AiUInt32),
    ('uw_SFrameSatusWExcMask', AiUInt16),
    ('uw_SDFrameSatusWExcMask', AiUInt16),
    ('uw_BCTransWaitT', AiUInt16),
    ('uw_Reserved1', AiUInt16),
    ('uw_Reserved2', AiUInt16),
    ('uw_Reserved3', AiUInt16),
]
TY_API_EF_BC_XFER_STATUS = ty_api_ef_bc_xfer_stat
class ty_api_ef_resp_sim_sdframe(Structure):
    pass
ty_api_ef_resp_sim_sdframe._fields_ = [
    ('ul_Bus', AiUInt32),
    ('ul_ErrorWordPos', AiUInt32),
    ('ul_ErrorType', AiUInt32),
    ('ul_BitCntOrPos', AiUInt32),
    ('ul_ResponseTime', AiUInt32),
    ('ul_FCPA', AiUInt32),
    ('ul_DestAddr', AiUInt32),
    ('ul_WordCount', AiUInt32),
]
TY_API_EF_BC_RESP_SIM_SDFRAME = ty_api_ef_resp_sim_sdframe
class ty_api_ef_resp_sim_sframe(Structure):
    pass
ty_api_ef_resp_sim_sframe._fields_ = [
    ('ul_Bus', AiUInt32),
    ('ul_ErrorWordPos', AiUInt32),
    ('ul_ErrorType', AiUInt32),
    ('ul_BitCntOrPos', AiUInt32),
    ('ul_ResponseTime', AiUInt32),
    ('ul_FCPA', AiUInt32),
    ('ul_ADW', AiUInt32),
]
TY_API_EF_BC_RESP_SIM_SFRAME = ty_api_ef_resp_sim_sframe
class ty_api_ef_bc_resp_sim(Structure):
    pass
ty_api_ef_bc_resp_sim._fields_ = [
    ('ul_XferId', AiUInt32),
    ('ul_HeaderId', AiUInt32),
    ('x_SDFrame', TY_API_EF_BC_RESP_SIM_SDFRAME),
    ('x_SFrame', TY_API_EF_BC_RESP_SIM_SFRAME),
]
TY_API_EF_BC_RESP_SIM = ty_api_ef_bc_resp_sim
class ty_api_ef_bc_resp_sim_mode(Structure):
    pass
ty_api_ef_bc_resp_sim_mode._fields_ = [
    ('ul_XferId', AiUInt32),
    ('ul_ResponseMode', AiUInt32),
    ('ul_FastMode', AiUInt32),
    ('ul_ForceResponseOnError', AiUInt32),
]
TY_API_EF_BC_RESP_SIM_MODE = ty_api_ef_bc_resp_sim_mode
class ty_api_ef_bc_internal_frame(Structure):
    pass
ty_api_ef_bc_internal_frame._fields_ = [
    ('ul_FCPA', AiUInt32),
    ('ul_DestAddr', AiUInt32),
    ('ul_WordCount', AiUInt32),
    ('ul_ModeCodeWords', AiUInt32),
]
TY_API_EF_BC_INTERNAL_FRAME = ty_api_ef_bc_internal_frame
class ty_api_ef_bc_internal(Structure):
    pass
ty_api_ef_bc_internal._fields_ = [
    ('ul_XferId', AiUInt32),
    ('ul_HeaderId', AiUInt32),
    ('x_BCInternalValidation', TY_API_EF_BC_INTERNAL_FRAME),
]
TY_API_EF_BC_INTERNAL = ty_api_ef_bc_internal
class ty_api_ef_bc_internal_mode(Structure):
    pass
ty_api_ef_bc_internal_mode._fields_ = [
    ('ul_XferId', AiUInt32),
    ('ul_ForceLocalResponseOnError', AiUInt32),
    ('ul_SuppressLocalCCError', AiUInt32),
    ('ul_UseBCInternalValidation', AiUInt32),
]
TY_API_EF_BC_INTERNAL_MODE = ty_api_ef_bc_internal_mode
class ty_api_ef_bc_sync_time_def(Structure):
    pass
ty_api_ef_bc_sync_time_def._fields_ = [
    ('ul_SyncTimeOffset', AiUInt32),
]
TY_API_EF_BC_SYNC_TIME_DEF = ty_api_ef_bc_sync_time_def
class ty_api_ef_bc_sync_time_get(Structure):
    pass
ty_api_ef_bc_sync_time_get._fields_ = [
    ('ul_SyncTimeOffset', AiUInt32),
    ('ul_LastRcvSyncTime', AiUInt32),
    ('ul_LastSyncTime', AiUInt32),
]
TY_API_EF_BC_SYNC_TIME_GET = ty_api_ef_bc_sync_time_get
class ty_api_ef_rt_mc_def(Structure):
    pass
ty_api_ef_rt_mc_def._fields_ = [
    ('ul_RtAddr', AiUInt32),
    ('ul_ModeCode', AiUInt32),
    ('ul_ModeCodeTx', AiUInt32),
    ('ul_ModeCodeBr', AiUInt32),
    ('ul_ModeCodeRx', AiUInt32),
    ('ul_StdIllegalHandling', AiUInt32),
]
TY_API_EF_RT_MC_DEF = ty_api_ef_rt_mc_def
class ty_api_hs_rx_select(Structure):
    pass
ty_api_hs_rx_select._fields_ = [
    ('ul_RxBusSelect', AiUInt32),
]
TY_API_HS_RX_SELECT = ty_api_hs_rx_select
class ty_api_ef_rx_select(Structure):
    pass
ty_api_ef_rx_select._fields_ = [
    ('ul_RxBusSelect', AiUInt32),
    ('ul_FFlt', AiUInt32),
]
TY_API_EF_RX_SELECT = ty_api_ef_rx_select
class ty_api_ef_bm_trg_cond(Structure):
    pass
ty_api_ef_bm_trg_cond._fields_ = [
    ('ul_ErrTrgWord', AiUInt32),
    ('ul_MonDataWord', AiUInt32),
    ('ul_MonCmdWord', AiUInt32),
    ('ul_MonCmdMask', AiUInt32),
    ('ul_MonHdrWord', AiUInt32),
    ('ul_MonHdrMask', AiUInt32),
]
TY_API_EF_BM_TRG_COND = ty_api_ef_bm_trg_cond
class api_file_upload_in(Structure):
    pass
AiChar = c_char
api_file_upload_in._fields_ = [
    ('pc_DestFilePath', STRING),
    ('pc_SourceFileName', STRING),
    ('ul_Flags', AiUInt32),
]
TY_API_FILE_UPLOAD_IN = api_file_upload_in

# values for enumeration 'api_e_update_status'
api_e_update_status = c_int # enum
TY_API_E_UPDATE_STATUS = api_e_update_status
class api_packet_update_status_out(Structure):
    pass
api_packet_update_status_out._fields_ = [
    ('e_Status', TY_API_E_UPDATE_STATUS),
    ('ul_ComponentsDone', AiUInt32),
    ('ul_TotalComponents', AiUInt32),
]
TY_API_PACKET_UPDATE_STATUS_OUT = api_packet_update_status_out
class ty_api_open(Structure):
    pass
ty_api_open._fields_ = [
    ('ul_Module', AiUInt32),
    ('ul_Stream', AiUInt32),
    ('ac_SrvName', AiChar * 28),
]
TY_API_OPEN = ty_api_open
class ty_api_board_capabilities(Structure):
    pass
class ty_coupling_capabilities_union(Union):
    pass
class ty_coupling_capabilities_b(Structure):
    pass
ty_coupling_capabilities_b._fields_ = [
    ('ul_Res', AiUInt32, 26),
    ('b_DigitalWrap', AiUInt32, 1),
    ('b_Packed', AiUInt32, 1),
    ('b_Network', AiUInt32, 1),
    ('b_Transformer', AiUInt32, 1),
    ('b_Direct', AiUInt32, 1),
    ('b_Isolated', AiUInt32, 1),
]
ty_coupling_capabilities_union._fields_ = [
    ('ul_All', AiUInt32),
    ('b', ty_coupling_capabilities_b),
]
TY_COUPLING_CAPABILITIES = ty_coupling_capabilities_union
class ty_irig_capabilities_union(Union):
    pass
class ty_irig_capabilities_b(Structure):
    pass
ty_irig_capabilities_b._fields_ = [
    ('ul_Res', AiUInt32, 29),
    ('b_Sinusoidal', AiUInt32, 1),
    ('b_FreeWheeling', AiUInt32, 1),
    ('b_IrigSwitch', AiUInt32, 1),
]
ty_irig_capabilities_union._fields_ = [
    ('ul_All', AiUInt32),
    ('b', ty_irig_capabilities_b),
]
TY_IRIG_CAPABILITIES = ty_irig_capabilities_union
ty_api_board_capabilities._fields_ = [
    ('ul_CanChangeAmplitude', AiUInt32),
    ('x_CouplingCapabilities', TY_COUPLING_CAPABILITIES),
    ('x_IrigCapabilities', TY_IRIG_CAPABILITIES),
]
TY_API_BOARD_CAPABILITIES = ty_api_board_capabilities
class ty_api_board_info(Structure):
    pass
ty_api_board_info._fields_ = [
    ('ul_DeviceType', AiUInt32),
    ('ul_NumberOfChannels', AiUInt32),
    ('ul_NumberOfBiu', AiUInt32),
    ('ul_NovRamBoardType', AiUInt32),
    ('ul_NovRamBoardConfig', AiUInt32),
    ('ul_SerialNumber', AiUInt32),
    ('ul_PartNumber', AiUInt32),
    ('ul_GlobalRamSize', AiUInt32),
    ('ul_SharedRamSize', AiUInt32),
    ('ul_GlobalRamStartOffset', AiUInt32 * 4),
    ('x_BoardCapabilities', TY_API_BOARD_CAPABILITIES),
    ('ul_Reserved', AiUInt32),
]
TY_API_BOARD_INFO = ty_api_board_info
class api_device_config(Structure):
    pass
api_device_config._fields_ = [
    ('uc_DmaEnabled', AiUInt8),
    ('uc_DataQueueMemoryType', AiUInt8),
    ('uc_DataQueueMode', AiUInt8),
    ('uc_ReservedB4', AiUInt8),
    ('uw_ReservedW1', AiUInt16),
    ('uw_ReservedW2', AiUInt16),
    ('ul_DmaMinimumSize', AiUInt32),
    ('ul_IntRequestCount', AiUInt32),
    ('ul_DriverFlags', AiUInt32),
    ('ul_ReservedLW4', AiUInt32),
    ('ul_ReservedLW5', AiUInt32),
    ('ul_ReservedLW6', AiUInt32),
    ('ul_ReservedLW7', AiUInt32),
    ('ul_ReservedLW8', AiUInt32),
]
TY_API_DEVICE_CONFIG = api_device_config
class ty_api_gen_io_dev_ven(Structure):
    pass
ty_api_gen_io_dev_ven._fields_ = [
    ('ul_DeviceVendor', AiUInt32),
    ('ul_SubSystemSubVendor', AiUInt32),
]
TY_API_GEN_IO_DEV_VEN = ty_api_gen_io_dev_ven
class ty_api_gen_io_dev_ven_list(Structure):
    pass
ty_api_gen_io_dev_ven_list._fields_ = [
    ('ul_Cnt', AiUInt32),
    ('px_DevVen', POINTER(TY_API_GEN_IO_DEV_VEN)),
]
TY_API_GEN_IO_DEV_VEN_LIST = ty_api_gen_io_dev_ven_list
class ty_api_gen_io_board_type(Structure):
    pass
ty_api_gen_io_board_type._fields_ = [
    ('ul_BoardType', AiUInt32),
    ('ul_Type', AiUInt32),
]
TY_API_GEN_IO_BOARD_TYPE = ty_api_gen_io_board_type
class ty_api_gen_io_board_type_list(Structure):
    pass
ty_api_gen_io_board_type_list._fields_ = [
    ('ul_Cnt', AiUInt32),
    ('px_BoardTypes', POINTER(TY_API_GEN_IO_BOARD_TYPE)),
]
TY_API_GEN_IO_BOARD_TYPE_LIST = ty_api_gen_io_board_type_list
class ty_api_gen_io_get_boards_in(Structure):
    pass
ty_api_gen_io_get_boards_in._fields_ = [
    ('px_DevVenList', POINTER(TY_API_GEN_IO_DEV_VEN_LIST)),
    ('px_BoardTypesList', POINTER(TY_API_GEN_IO_BOARD_TYPE_LIST)),
]
TY_API_GEN_IO_GET_BOARDS_IN = ty_api_gen_io_get_boards_in
class ty_api_gen_io_board(Structure):
    pass
ty_api_gen_io_board._fields_ = [
    ('ul_Board', AiUInt32),
    ('ul_Type', AiUInt32),
    ('ul_StartAddress', AiUInt32),
]
TY_API_GEN_IO_BOARD = ty_api_gen_io_board
class ty_api_gen_io_get_board_out(Structure):
    pass
ty_api_gen_io_get_board_out._fields_ = [
    ('ul_Cnt', AiUInt32),
    ('px_Board', POINTER(TY_API_GEN_IO_BOARD)),
]
TY_API_GEN_IO_GET_BOARDS_OUT = ty_api_gen_io_get_board_out
class ty_api_bc_bh_info(Structure):
    pass
ty_api_bc_bh_info._fields_ = [
    ('bid', AiUInt16),
    ('sid', AiUInt16),
    ('eid', AiUInt16),
    ('nbufs', AiUInt16),
    ('hid_addr', AiUInt32),
    ('bq_addr', AiUInt32),
    ('sq_addr', AiUInt32),
    ('eq_addr', AiUInt32),
]
TY_API_BC_BH_INFO = ty_api_bc_bh_info
class ty_api_bc_xfer(Structure):
    pass
ty_api_bc_xfer._fields_ = [
    ('xid', AiUInt16),
    ('hid', AiUInt16),
    ('type', AiUInt8),
    ('chn', AiUInt8),
    ('xmt_rt', AiUInt8),
    ('rcv_rt', AiUInt8),
    ('xmt_sa', AiUInt8),
    ('rcv_sa', AiUInt8),
    ('wcnt', AiUInt8),
    ('tic', AiUInt8),
    ('hlt', AiUInt8),
    ('rte', AiUInt8),
    ('res', AiUInt8),
    ('sxh', AiUInt8),
    ('rsp', AiUInt8),
    ('gap_mode', AiUInt8),
    ('swxm', AiUInt16),
    ('err', ty_api_bc_err),
    ('gap', AiUInt16),
]
TY_API_BC_XFER = ty_api_bc_xfer
class ty_api_bc_dytag(Structure):
    pass
ty_api_bc_dytag._fields_ = [
    ('tag_fct', AiUInt16),
    ('min', AiUInt16),
    ('max', AiUInt16),
    ('step', AiUInt16),
    ('wpos', AiUInt16),
]
TY_API_BC_DYTAG = ty_api_bc_dytag
class ty_api_bc_frame(Structure):
    pass
ty_api_bc_frame._fields_ = [
    ('id', AiUInt8),
    ('cnt', AiUInt8),
    ('instr', AiUInt16 * 128),
    ('xid', AiUInt16 * 128),
]
TY_API_BC_FRAME = ty_api_bc_frame
class ty_api_bc_mframe(Structure):
    pass
ty_api_bc_mframe._fields_ = [
    ('cnt', AiUInt8),
    ('fid', AiUInt8 * 64),
]
TY_API_BC_MFRAME = ty_api_bc_mframe
class ty_api_bc_mframe_ex(Structure):
    pass
ty_api_bc_mframe_ex._fields_ = [
    ('cnt', AiUInt16),
    ('padding1', AiUInt16),
    ('fid', AiUInt8 * 512),
]
TY_API_BC_MFRAME_EX = ty_api_bc_mframe_ex
class ty_api_bc_acyc(Structure):
    pass
ty_api_bc_acyc._fields_ = [
    ('cnt', AiUInt8),
    ('padding1', AiUInt8),
    ('instr', AiUInt16 * 127),
    ('xid', AiUInt16 * 127),
]
TY_API_BC_ACYC = ty_api_bc_acyc
class ty_api_bc_status_dsp(Structure):
    pass
ty_api_bc_status_dsp._fields_ = [
    ('status', AiUInt8),
    ('padding1', AiUInt8),
    ('hxfer', AiUInt16),
    ('glb_msg_cnt', AiUInt32),
    ('glb_err_cnt', AiUInt32),
    ('hip', AiUInt32),
    ('mfc', AiUInt32),
]
TY_API_BC_STATUS_DSP = ty_api_bc_status_dsp
class ty_api_bc_xfer_dsp(Structure):
    pass
ty_api_bc_xfer_dsp._fields_ = [
    ('cw1', AiUInt16),
    ('st1', AiUInt16),
    ('cw2', AiUInt16),
    ('st2', AiUInt16),
    ('bid', AiUInt16),
    ('brw', AiUInt16),
    ('bufp', AiUInt32),
    ('ttag', AiUInt32),
    ('msg_cnt', AiUInt32),
    ('err_cnt', AiUInt32),
    ('lvw', AiUInt32),
    ('srvreq_cnt', AiUInt32),
]
TY_API_BC_XFER_DSP = ty_api_bc_xfer_dsp
class ty_api_bc_xfer_status_ex(Structure):
    pass
ty_api_bc_xfer_status_ex._fields_ = [
    ('x_XferSQueue', TY_API_BC_XFER_STATUS_QUEUE * 256),
    ('x_XferEQueue', TY_API_BC_XFER_EVENT_QUEUE * 1),
    ('x_XferInfo', TY_API_BC_XFER_STATUS_INFO),
    ('ul_BufferQueueSize', AiUInt32),
]
TY_API_BC_XFER_STATUS_EX = ty_api_bc_xfer_status_ex
class ty_api_bc_xfer_read_in(Structure):
    pass
ty_api_bc_xfer_read_in._fields_ = [
    ('ul_XferId', AiUInt32),
    ('ul_Clear', AiUInt32),
    ('ul_Biu', AiUInt32),
]
TY_API_BC_XFER_READ_IN = ty_api_bc_xfer_read_in
class ty_api_bc_srvw(Structure):
    pass
ty_api_bc_srvw._fields_ = [
    ('uw_XferId', AiUInt16),
    ('uw_LastVecWord', AiUInt16),
    ('ul_SrvReqCnt', AiUInt32),
]
TY_API_BC_SRVW = ty_api_bc_srvw
class ty_api_bc_srvw_con(Structure):
    pass
ty_api_bc_srvw_con._fields_ = [
    ('uc_SubAddress', AiUInt8),
    ('uc_Padding1', AiUInt8),
    ('uw_Padding2', AiUInt16),
    ('ul_Reserved1', AiUInt32),
    ('ul_Reserved2', AiUInt32),
    ('ul_Reserved3', AiUInt32),
]
TY_API_BC_SRVW_CON = ty_api_bc_srvw_con
class ty_api_bc_fw_instr(Structure):
    pass
ty_api_bc_fw_instr._fields_ = [
    ('label', AiUInt16),
    ('op', AiUInt8),
    ('res', AiUInt8),
    ('par1', AiUInt32),
    ('par2', AiUInt32),
    ('laddr', AiUInt32),
]
TY_API_BC_FW_INSTR = ty_api_bc_fw_instr
class ty_api_bc_fw_rsrc_desc(Structure):
    pass
ty_api_bc_fw_rsrc_desc._fields_ = [
    ('max_cnt', AiUInt32),
    ('start_addr', AiUInt32),
]
TY_API_BC_FW_RSRC_DESC = ty_api_bc_fw_rsrc_desc
class ty_api_bc_fw_rsrc(Structure):
    pass
ty_api_bc_fw_rsrc._fields_ = [
    ('xfer', TY_API_BC_FW_RSRC_DESC),
    ('modif', TY_API_BC_FW_RSRC_DESC),
    ('instr', TY_API_BC_FW_RSRC_DESC),
]
TY_API_BC_FW_RSRC = ty_api_bc_fw_rsrc
class ty_api_bc_mode_ctrl(Structure):
    pass
ty_api_bc_mode_ctrl._fields_ = [
    ('ul_BcMode', AiUInt32),
    ('ul_Ctrl', AiUInt32),
    ('ul_Param1', AiUInt32),
    ('ul_Param2', AiUInt32),
    ('ul_Param3', AiUInt32),
]
TY_API_BC_MODE_CTRL = ty_api_bc_mode_ctrl
class ty_api_bm_cap_setup(Structure):
    pass
ty_api_bm_cap_setup._fields_ = [
    ('cap_mode', AiUInt8),
    ('padding1', AiUInt8),
    ('padding2', AiUInt16),
    ('cap_tat', AiUInt32),
    ('cap_mcc', AiUInt16),
    ('cap_fsize', AiUInt16),
]
TY_API_BM_CAP_SETUP = ty_api_bm_cap_setup
class ty_api_bm_status_dsp(Structure):
    pass
ty_api_bm_status_dsp._fields_ = [
    ('men', AiUInt8),
    ('msw', AiUInt8),
    ('msp', AiUInt8),
    ('padding1', AiUInt8),
    ('glb_msg_cnt', AiUInt32),
    ('glb_err_cnt', AiUInt32),
    ('glb_word_cnt_sec', AiUInt32),
    ('glb_word_cnt_pri', AiUInt32),
    ('glb_msg_cnt_sec', AiUInt32),
    ('glb_msg_cnt_pri', AiUInt32),
    ('glb_err_cnt_sec', AiUInt32),
    ('glb_err_cnt_pri', AiUInt32),
    ('bus_load_sec', AiUInt32),
    ('bus_load_pri', AiUInt32),
    ('bus_load_sec_avg', AiUInt32),
    ('bus_load_pri_avg', AiUInt32),
]
TY_API_BM_STATUS_DSP = ty_api_bm_status_dsp
class ty_api_bm_act_dsp(Structure):
    pass
ty_api_bm_act_dsp._fields_ = [
    ('fnd', AiUInt8),
    ('rt', AiUInt8),
    ('tr', AiUInt8),
    ('sa', AiUInt8),
    ('cc', AiUInt32),
    ('ec', AiUInt32),
    ('et', AiUInt32),
]
TY_API_BM_ACT_DSP = ty_api_bm_act_dsp
class ty_api_bm_stackp_dsp(Structure):
    pass
ty_api_bm_stackp_dsp._fields_ = [
    ('status', AiUInt8),
    ('padding1', AiUInt8),
    ('padding2', AiUInt16),
    ('stp', AiUInt32),
    ('ctp', AiUInt32),
    ('etp', AiUInt32),
]
TY_API_BM_STACKP_DSP = ty_api_bm_stackp_dsp
class ty_api_bm_stack_dsp(Structure):
    pass
ty_api_bm_stack_dsp._fields_ = [
    ('entry', AiUInt32),
]
TY_API_BM_STACK_DSP = ty_api_bm_stack_dsp
class ty_api_bm_stack_fnd(Structure):
    pass
ty_api_bm_stack_fnd._fields_ = [
    ('efnd', AiUInt8),
    ('padding1', AiUInt8),
    ('padding2', AiUInt16),
    ('eptr', AiUInt32),
    ('entry', AiUInt32),
]
TY_API_BM_STACK_FND = ty_api_bm_stack_fnd
class ty_api_bm_rec(Structure):
    pass
ty_api_bm_rec._fields_ = [
    ('status', AiUInt8),
    ('padding1', AiUInt8),
    ('padding2', AiUInt16),
    ('hfi_cnt', AiUInt32),
    ('saddr', AiUInt32),
    ('size', AiUInt32),
]
TY_API_BM_REC = ty_api_bm_rec
class ty_api_bm_tcb(Structure):
    pass
ty_api_bm_tcb._fields_ = [
    ('tt', AiUInt8),
    ('sot', AiUInt8),
    ('tri', AiUInt8),
    ('inv', AiUInt8),
    ('tres', AiUInt8),
    ('tset', AiUInt8),
    ('tsp', AiUInt8),
    ('next', AiUInt8),
    ('eom', AiUInt8),
    ('padding1', AiUInt8),
    ('tdw', AiUInt16),
    ('tmw', AiUInt16),
    ('tuli', AiUInt16),
    ('tlli', AiUInt16),
]
TY_API_BM_TCB = ty_api_bm_tcb
class ty_api_bm_rt_act(Structure):
    pass
ty_api_bm_rt_act._fields_ = [
    ('mc', AiUInt32),
    ('ec', AiUInt32),
    ('et', AiUInt32),
]
TY_API_BM_RT_ACT = ty_api_bm_rt_act
class ty_api_bm_ini_msg_flt_rec(Structure):
    pass
ty_api_bm_ini_msg_flt_rec._fields_ = [
    ('cw', AiUInt16),
    ('pos1', AiUInt8),
    ('pos2', AiUInt8),
]
TY_API_BM_INI_MSG_FLT_REC = ty_api_bm_ini_msg_flt_rec
class ty_api_bm_dytag_mon_def(Structure):
    pass
ty_api_bm_dytag_mon_def._fields_ = [
    ('uc_Id', AiUInt8),
    ('uc_Con', AiUInt8),
    ('uc_RtAddr', AiUInt8),
    ('uc_SubAddrMsgId', AiUInt8),
    ('uc_SubAddrMsgIdType', AiUInt8),
    ('uc_Padding1', AiUInt8),
    ('uw_DytagType', AiUInt16),
    ('uw_DytagWPos', AiUInt16),
    ('uw_DytagBPos', AiUInt16),
    ('uw_DytagBLen', AiUInt16),
    ('uw_DytagStep', AiUInt16),
]
TY_API_BM_DYTAG_MON_DEF = ty_api_bm_dytag_mon_def
class ty_api_bm_dytag_mon_read_ctrl(Structure):
    pass
ty_api_bm_dytag_mon_read_ctrl._fields_ = [
    ('uc_Id', AiUInt8),
]
TY_API_BM_DYTAG_MON_READ_CTRL = ty_api_bm_dytag_mon_read_ctrl
class ty_api_bm_dytag_mon_act(Structure):
    pass
ty_api_bm_dytag_mon_act._fields_ = [
    ('ul_Stale', AiUInt32),
    ('ul_Bad', AiUInt32),
    ('ul_Good', AiUInt32),
]
TY_API_BM_DYTAG_MON_ACT = ty_api_bm_dytag_mon_act
class ty_api_bh_modify(Structure):
    pass
ty_api_bh_modify._fields_ = [
    ('ul_BHAddr', AiUInt32),
    ('ul_DataBufferStoreMode', AiUInt32),
    ('ul_BufferSizeMode', AiUInt32),
    ('ul_BufferSize', AiUInt32),
    ('ul_BufferQueueMode', AiUInt32),
    ('ul_BufferQueueSize', AiUInt32),
    ('ul_StatusQueueSize', AiUInt32),
    ('ul_EventQueueSize', AiUInt32),
    ('ul_CurrentBufferIndex', AiUInt32),
]
TY_API_BH_MODIFY = ty_api_bh_modify
class ty_api_c1760_con(Structure):
    pass
ty_api_c1760_con._fields_ = [
    ('mode', AiUInt8),
    ('c01', AiUInt8),
    ('buf_id', AiUInt16),
    ('c02', AiUInt8 * 16),
]
TY_API_C1760_CON = ty_api_c1760_con
class ty_api_data_queue_status(Structure):
    pass
uint64_t = c_uint64
AiUInt64 = uint64_t
ty_api_data_queue_status._fields_ = [
    ('status', AiUInt32),
    ('bytes_transfered', AiUInt32),
    ('bytes_in_queue', AiUInt32),
    ('total_bytes_transfered', AiUInt64),
]
TY_API_DATA_QUEUE_STATUS = ty_api_data_queue_status
class ty_api_queue_table(Structure):
    pass
ty_api_queue_table._fields_ = [
    ('uc_QueueFlag', AiUInt8),
    ('ul_QueueStart', AiUInt32),
    ('x_QueueStatus', TY_API_DATA_QUEUE_STATUS),
]
TY_API_QUEUE_TABLE = ty_api_queue_table
class ty_api_data_queue_read(Structure):
    pass
ty_api_data_queue_read._fields_ = [
    ('id', AiUInt32),
    ('buffer', c_void_p),
    ('bytes_to_read', AiUInt32),
]
TY_API_DATA_QUEUE_READ = ty_api_data_queue_read
class ty_api_data_queue_write(Structure):
    pass
ty_api_data_queue_write._fields_ = [
    ('uc_Id', AiUInt8),
    ('uc_Padding1', AiUInt8),
    ('uw_Padding2', AiUInt16),
    ('pv_MemBuf', c_void_p),
    ('ul_BytesToWrite', AiUInt32),
    ('x_Info', TY_API_DATA_QUEUE_STATUS),
]
TY_API_DATA_QUEUE_WRITE = ty_api_data_queue_write
class ty_api_queue_buf(Structure):
    pass
ty_api_queue_buf._fields_ = [
    ('rt_addr', AiUInt8),
    ('sa_mc', AiUInt8),
    ('sa_type', AiUInt8),
    ('rt_addr2', AiUInt8),
    ('sa_mc2', AiUInt8),
    ('sa_type2', AiUInt8),
    ('word_cnt', AiUInt8),
    ('rbf_trw', AiUInt8),
    ('msg_trw', AiUInt16),
    ('status_word1', AiUInt16),
    ('status_word2', AiUInt16),
    ('buffer', AiUInt16 * 32),
    ('ttag', AiUInt32),
]
TY_API_QUEUE_BUF = ty_api_queue_buf
class ty_api_rep_status(Structure):
    pass
ty_api_rep_status._fields_ = [
    ('status', AiUInt8),
    ('padding1', AiUInt8),
    ('padding2', AiUInt16),
    ('rpi_cnt', AiUInt32),
    ('saddr', AiUInt32),
    ('size', AiUInt32),
    ('entry_cnt', AiUInt32),
]
TY_API_REP_STATUS = ty_api_rep_status
class ty_api_rt_bh_info(Structure):
    pass
ty_api_rt_bh_info._fields_ = [
    ('bid', AiUInt16),
    ('sid', AiUInt16),
    ('eid', AiUInt16),
    ('nbufs', AiUInt16),
    ('hid_addr', AiUInt32),
    ('bq_addr', AiUInt32),
    ('sq_addr', AiUInt32),
    ('eq_addr', AiUInt32),
]
TY_API_RT_BH_INFO = ty_api_rt_bh_info
class ty_api_rt_err(Structure):
    pass
ty_api_rt_err._fields_ = [
    ('type', AiUInt8),
    ('sync', AiUInt8),
    ('contig', AiUInt8),
    ('padding1', AiUInt8),
    ('err_spec', AiUInt32),
]
TY_API_RT_ERR = ty_api_rt_err
class ty_api_rt_dytag(Structure):
    pass
ty_api_rt_dytag._fields_ = [
    ('tag_fct', AiUInt16),
    ('min', AiUInt16),
    ('max', AiUInt16),
    ('step', AiUInt16),
    ('wpos', AiUInt16),
]
TY_API_RT_DYTAG = ty_api_rt_dytag
class ty_api_rt_status_dsp(Structure):
    pass
ty_api_rt_status_dsp._fields_ = [
    ('status', AiUInt8),
    ('padding1', AiUInt8),
    ('padding2', AiUInt16),
    ('glb_msg_cnt', AiUInt32),
    ('glb_err_cnt', AiUInt32),
]
TY_API_RT_STATUS_DSP = ty_api_rt_status_dsp
class ty_api_rt_msg_dsp(Structure):
    pass
ty_api_rt_msg_dsp._fields_ = [
    ('nxw', AiUInt16),
    ('lsw', AiUInt16),
    ('lcw', AiUInt16),
    ('padding1', AiUInt16),
    ('msg_cnt', AiUInt32),
    ('err_cnt', AiUInt32),
]
TY_API_RT_MSG_DSP = ty_api_rt_msg_dsp
class ty_api_rt_sa_msg_dsp(Structure):
    pass
ty_api_rt_sa_msg_dsp._fields_ = [
    ('bid', AiUInt16),
    ('trw', AiUInt16),
    ('lcw', AiUInt16),
    ('lsw', AiUInt16),
    ('bufp', AiUInt32),
    ('ttag', AiUInt32),
]
TY_API_RT_SA_MSG_DSP = ty_api_rt_sa_msg_dsp
class ty_api_rt_sa_status_ex(Structure):
    pass
ty_api_rt_sa_status_ex._fields_ = [
    ('x_XferSQueue', TY_API_RT_SA_STATUS_QUEUE * 256),
    ('x_XferEQueue', TY_API_RT_SA_EVENT_QUEUE * 1),
    ('x_XferInfo', TY_API_RT_SA_STATUS_INFO),
    ('ul_BufferQueueSize', AiUInt32),
]
TY_API_RT_SA_STATUS_EX = ty_api_rt_sa_status_ex
class ty_api_rt_sa_msg_read_in(Structure):
    pass
ty_api_rt_sa_msg_read_in._fields_ = [
    ('ul_RtAddr', AiUInt32),
    ('ul_SA', AiUInt32),
    ('ul_SaType', AiUInt32),
    ('ul_Biu', AiUInt32),
]
TY_API_RT_SA_MSG_READ_IN = ty_api_rt_sa_msg_read_in
class ty_api_rt_msg_all_dsp_rt(Structure):
    pass
ty_api_rt_msg_all_dsp_rt._fields_ = [
    ('rt_msg', AiUInt32),
    ('rt_err', AiUInt32),
]
TY_API_RT_MSG_ALL_DSP_RT = ty_api_rt_msg_all_dsp_rt
class ty_api_rt_msg_all_dsp(Structure):
    pass
ty_api_rt_msg_all_dsp._fields_ = [
    ('rt', TY_API_RT_MSG_ALL_DSP_RT * 32),
]
TY_API_RT_MSG_ALL_DSP = ty_api_rt_msg_all_dsp
class ty_api_rt_sa(Structure):
    pass
ty_api_rt_sa._fields_ = [
    ('buffer', AiUInt16 * 32),
    ('mode', AiUInt8),
    ('rt', AiUInt8),
    ('rt_con', AiUInt8),
    ('sa_mc', AiUInt8),
    ('sa_type', AiUInt8),
    ('sa_con', AiUInt8),
    ('resp_time', AiUInt8),
    ('smod', AiUInt8),
    ('nxw', AiUInt16),
    ('swm', AiUInt16),
    ('hid', AiUInt16),
    ('bid', AiUInt16),
]
TY_API_RT_SA = ty_api_rt_sa
class ty_api_rt_mode_ctrl(Structure):
    pass
ty_api_rt_mode_ctrl._fields_ = [
    ('ul_RtMode', AiUInt32),
    ('ul_Ctrl', AiUInt32),
    ('ul_Param1', AiUInt32),
    ('ul_Param2', AiUInt32),
    ('ul_Param3', AiUInt32),
]
TY_API_RT_MODE_CTRL = ty_api_rt_mode_ctrl
class rt_info_tag(Structure):
    pass
rt_info_tag._fields_ = [
    ('uc_Mode', AiUInt8),
    ('ul_RxSA', AiUInt32),
    ('ul_TxSA', AiUInt32),
    ('ul_RxMC', AiUInt32),
    ('ul_TxMC', AiUInt32),
    ('ul_HSRxMID', AiUInt32 * 8),
    ('ul_HSTxMID', AiUInt32 * 8),
    ('ul_HSMC', AiUInt32),
]
TY_RT_INFO = rt_info_tag
TY_API_SCOPE_WAIT_STATE = AiUInt32
class API_SCOPE_SAMPLE_PACKET(Union):
    pass
class N23API_SCOPE_SAMPLE_PACKET3DOT_2E(Structure):
    pass
N23API_SCOPE_SAMPLE_PACKET3DOT_2E._fields_ = [
    ('res', AiUInt32, 2),
    ('sample0', AiUInt32, 10),
    ('sample1', AiUInt32, 10),
    ('sample2', AiUInt32, 10),
]
API_SCOPE_SAMPLE_PACKET._fields_ = [
    ('raw', AiUInt32),
    ('samples', N23API_SCOPE_SAMPLE_PACKET3DOT_2E),
]
TY_API_SCOPE_SAMPLE_PACKET = API_SCOPE_SAMPLE_PACKET
class ty_api_scope_calibration_info(Structure):
    pass
ty_api_scope_calibration_info._fields_ = [
    ('lOffsetA', AiUInt32),
    ('lOffsetB', AiUInt32),
    ('lOffsetA100', AiUInt32),
    ('lOffsetB100', AiUInt32),
    ('lOffsetA100Sec', AiUInt32),
    ('lOffsetB100Sec', AiUInt32),
]
TY_API_SCOPE_CALIBRATION_INFO = ty_api_scope_calibration_info
class API_SCOPE_BUFFER(Structure):
    pass
TY_API_SCOPE_BUFFER_HANDLER = CFUNCTYPE(None, AiUInt32, POINTER(API_SCOPE_BUFFER))
TY_API_SCOPE_BUFFER_FLAGS = AiUInt32

# values for enumeration 'API_SCOPE_BUFFER_TYPE'
API_SCOPE_BUFFER_TYPE = c_int # enum
TY_API_SCOPE_BUFFER_TYPE = API_SCOPE_BUFFER_TYPE
API_SCOPE_BUFFER._fields_ = [
    ('ulID', AiUInt32),
    ('eBufferType', TY_API_SCOPE_BUFFER_TYPE),
    ('pvBuffer', c_void_p),
    ('ulBufferSize', AiUInt32),
    ('ulFlags', TY_API_SCOPE_BUFFER_FLAGS),
    ('ulDataSize', AiUInt32),
    ('ulTriggerId', AiUInt32),
    ('BufferHandler', TY_API_SCOPE_BUFFER_HANDLER),
    ('pvUserData', c_void_p),
]
TY_API_SCOPE_BUFFER = API_SCOPE_BUFFER
class ty_api_ini_info(Structure):
    pass
ty_api_ini_info._fields_ = [
    ('bt', AiUInt8 * 4),
    ('chns', AiUInt8),
    ('prot', AiUInt8),
    ('emod', AiUInt8),
    ('irg', AiUInt8),
    ('res1', AiUInt8),
    ('padd1', AiUInt8),
    ('padd2', AiUInt16),
    ('pbi_id_biu1', AiUInt16),
    ('asp_mon_id', AiUInt16),
    ('asp_bite_id', AiUInt16),
    ('pbi_id_biu2', AiUInt16),
    ('board_config', AiUInt32),
    ('glb_mem_size', AiUInt32),
    ('glb_mem_addr', AiUInt32),
    ('loc_dram_size', AiUInt32),
    ('loc_dram_addr', AiUInt32),
    ('shared_dram_size', AiUInt32),
    ('shared_dram_addr', AiUInt32),
    ('flash_ram_size', AiUInt32),
    ('flash_ram_addr', AiUInt32),
    ('pci', AiUInt32 * 16),
    ('board_type', AiUInt32),
    ('board_sub_type', AiUInt32),
    ('hardware_variant', AiUInt32),
]
TY_API_INI_INFO = ty_api_ini_info
class ty_api_reset_info(Structure):
    pass
ty_api_reset_info._fields_ = [
    ('mbufs', AiUInt8),
    ('sbufs', AiUInt8),
    ('padding1', AiUInt16),
    ('mon_addr', AiUInt32),
    ('sim_addr', AiUInt32),
]
TY_API_RESET_INFO = ty_api_reset_info

# values for enumeration 'api_irig_source'
api_irig_source = c_int # enum
TY_API_IRIG_SOURCE = api_irig_source
class ty_api_irig_time(Structure):
    pass
ty_api_irig_time._fields_ = [
    ('day', AiUInt32),
    ('hour', AiUInt32),
    ('minute', AiUInt32),
    ('second', AiUInt32),
    ('microsecond', AiUInt32),
]
TY_API_IRIG_TIME = ty_api_irig_time
class ty_api_pxi_con(Structure):
    pass
ty_api_pxi_con._fields_ = [
    ('ul_Mode', AiUInt32),
    ('ul_TrgSource', AiUInt32),
    ('ul_TrgDest', AiUInt32),
    ('ul_TTClear', AiUInt32),
]
TY_API_PXI_CON = ty_api_pxi_con
class ty_api_sync_cnt_set(Structure):
    pass
ty_api_sync_cnt_set._fields_ = [
    ('ul_SyncCntVal', AiUInt32),
]
TY_API_SYNC_CNT_SET = ty_api_sync_cnt_set
class ty_api_sync_cnt_get(Structure):
    pass
ty_api_sync_cnt_get._fields_ = [
    ('ul_SyncCntVal', AiUInt32),
    ('ul_SyncCntInit', AiUInt32),
    ('ul_SyncCntInitLow', AiUInt32),
    ('ul_SyncCntInitHigh', AiUInt32),
]
TY_API_SYNC_CNT_GET = ty_api_sync_cnt_get
class ty_api_systag(Structure):
    pass
ty_api_systag._fields_ = [
    ('xid_rtsa', AiUInt16),
    ('fct', AiUInt16),
    ('min', AiUInt16),
    ('max', AiUInt16),
    ('step', AiUInt16),
    ('wpos', AiUInt16),
    ('bpos', AiUInt16),
]
TY_API_SYSTAG = ty_api_systag
class ty_api_discr_info(Structure):
    pass
ty_api_discr_info._fields_ = [
    ('channels', AiUInt32),
    ('canIn', AiUInt32),
    ('canOut', AiUInt32),
]
TY_API_DISCR_INFO = ty_api_discr_info
class ty_api_track_def_in(Structure):
    pass
ty_api_track_def_in._fields_ = [
    ('ul_TrackId', AiUInt32),
    ('ul_BT', AiUInt32),
    ('ul_XidRtSa', AiUInt32),
    ('ul_Mode', AiUInt32),
    ('ul_TrackStartPos', AiUInt32),
    ('ul_TrackBPos', AiUInt32),
    ('ul_TrackBLen', AiUInt32),
    ('ul_TrackLen', AiUInt32),
    ('ul_MultiplexedTrackNb', AiUInt32),
    ('ul_ContinousTrackNb', AiUInt32),
    ('l_Offset', AiInt32),
]
TY_API_TRACK_DEF_IN = ty_api_track_def_in
class ty_api_track_def_out(Structure):
    pass
ty_api_track_def_out._fields_ = [
    ('ul_TrackBufferStartAddr', AiUInt32),
]
TY_API_TRACK_DEF_OUT = ty_api_track_def_out
class ty_api_track_read_in(Structure):
    pass
ty_api_track_read_in._fields_ = [
    ('ul_TrackId', AiUInt32),
    ('ul_MultiplexedTrackIndex', AiUInt32),
    ('ul_ReadMode', AiUInt32),
]
TY_API_TRACK_READ_IN = ty_api_track_read_in
class ty_api_track_read_out(Structure):
    pass
ty_api_track_read_out._fields_ = [
    ('ul_DataValid', AiUInt32),
    ('ul_LastTT', AiUInt32),
    ('puw_TrackDataWords', POINTER(AiUInt16)),
]
TY_API_TRACK_READ_OUT = ty_api_track_read_out
class ty_api_track_scan_in(Structure):
    pass
ty_api_track_scan_in._fields_ = [
    ('ul_TrackId', AiUInt32),
    ('ul_ChunkNb', AiUInt32),
    ('ul_ChunkSize', AiUInt32),
]
TY_API_TRACK_SCAN_IN = ty_api_track_scan_in
class ty_api_track_scan_out(Structure):
    pass
ty_api_track_scan_out._fields_ = [
    ('ul_NumberOfReturnedStates', AiUInt32),
    ('ul_MoreData', AiUInt32),
    ('pul_ReturnedStates', POINTER(AiUInt32)),
]
TY_API_TRACK_SCAN_OUT = ty_api_track_scan_out
class ty_api_track_prealloc_in(Structure):
    pass
ty_api_track_prealloc_in._fields_ = [
    ('ul_TrackId', AiUInt32),
    ('ul_PreAllocNb', AiUInt32),
    ('pul_MuxStates', POINTER(AiUInt32)),
]
TY_API_TRACK_PREALLOC_IN = ty_api_track_prealloc_in
class ty_api_track_prealloc_out(Structure):
    pass
ty_api_track_prealloc_out._fields_ = [
    ('pul_TrackBufferStartAddr', POINTER(AiUInt32)),
]
TY_API_TRACK_PREALLOC_OUT = ty_api_track_prealloc_out
class ty_tagserverinfo(Structure):
    pass
class ty_ver_info(Structure):
    pass
ty_ver_info._fields_ = [
    ('ul_VersionType', AiUInt32),
    ('ac_Description', AiChar * 256),
    ('ul_MajorVer', AiUInt32),
    ('ul_MinorVer', AiUInt32),
    ('ul_PatchVersion', AiUInt32),
    ('ul_BuildNr', AiUInt32),
    ('ac_FullVersion', AiChar * 256),
]
TY_VER_INFO = ty_ver_info
ty_tagserverinfo._fields_ = [
    ('server_version', TY_VER_INFO),
    ('protocol_major', AiUInt32),
    ('protocol_minor', AiUInt32),
    ('application_name', AiChar * 128),
    ('description', AiChar * 128),
    ('host_name', AiChar * 128),
    ('os_info', AiChar * 128),
]
TY_API_SERVERINFO = ty_tagserverinfo
class TY_API_DISCOVER_RESPONSE(Structure):
    pass
TY_API_DISCOVER_RESPONSE._pack_ = 1
TY_API_DISCOVER_RESPONSE._fields_ = [
    ('magic', AiUInt32),
    ('protocol', AiUInt32),
    ('port', AiUInt32),
    ('board_count', AiUInt32),
    ('protocol_major', AiUInt32),
    ('protocol_minor', AiUInt32),
    ('host_name', c_char * 128),
]
TY_API_DISCOVER_CALLBACK_FUNC_PTR = CFUNCTYPE(None, STRING, POINTER(TY_API_DISCOVER_RESPONSE))
class TY_API_DISCOVER_CALLBACK(Structure):
    pass
TY_API_DISCOVER_CALLBACK._pack_ = 1
TY_API_DISCOVER_CALLBACK._fields_ = [
    ('port', AiUInt32),
    ('callback', TY_API_DISCOVER_CALLBACK_FUNC_PTR),
]
class ty_api_version(Structure):
    pass
ty_api_version._fields_ = [
    ('ul_MajorVer', AiUInt32),
    ('ul_MinorVer', AiUInt32),
    ('ul_BuildNo', AiUInt32),
    ('ul_MajorSpecialVer', AiUInt32),
    ('ul_MinorSpecialVer', AiUInt32),
]
TY_API_VERSION = ty_api_version
class ty_api_version_info(Structure):
    pass
ty_api_version_info._fields_ = [
    ('x_TcpVer', TY_API_VERSION),
    ('x_AslLcaVer', TY_API_VERSION),
    ('x_PciLcaVer', TY_API_VERSION),
    ('x_IoLcaBiu1Ver', TY_API_VERSION),
    ('x_CoreLcaBiu1Ver', TY_API_VERSION),
    ('x_IoLcaBiu2Ver', TY_API_VERSION),
    ('x_EndDecLcaBiu2Ver', TY_API_VERSION),
    ('x_IoLcaBiu3Ver', TY_API_VERSION),
    ('x_CoreLcaBiu3Ver', TY_API_VERSION),
    ('x_IoLcaBiu4Ver', TY_API_VERSION),
    ('x_EndDecLcaBiu4Ver', TY_API_VERSION),
    ('x_FirmwareBiu1Ver', TY_API_VERSION),
    ('x_FirmwareBiu2Ver', TY_API_VERSION),
    ('x_FirmwareBiu3Ver', TY_API_VERSION),
    ('x_FirmwareBiu4Ver', TY_API_VERSION),
    ('x_TargetSWVer', TY_API_VERSION),
    ('x_SysDrvVer', TY_API_VERSION),
    ('x_DllVer', TY_API_VERSION),
    ('x_MonitorVer', TY_API_VERSION),
    ('ul_BoardSerialNo', AiUInt32),
]
TY_API_VERSION_INFO = ty_api_version_info
BYTE = AiUInt8
WORD = AiUInt16
DWORD = AiUInt32
L_WORD = AiUInt32
LPVOID = c_void_p
LPDWORD = POINTER(AiUInt32)
LPOVERLAPPED = POINTER(AiUInt8)
HINSTANCE = c_void_p
class ty_ver_no(Structure):
    pass
ty_ver_no._fields_ = [
    ('ul_MajorVer', AiUInt32),
    ('ul_MinorVer', AiUInt32),
    ('ul_BuildNr', AiUInt32),
    ('ul_MajorSpecialVer', AiUInt32),
    ('ul_MinorSpecialVer', AiUInt32),
]
TY_VER_NO = ty_ver_no
class ty_version_out(Structure):
    pass
ty_version_out._fields_ = [
    ('ul_Count', AiUInt32),
    ('ul_MaxCount', AiUInt32),
]
TY_VERSION_OUT = ty_version_out

# values for enumeration 'TY_E_VERSION_ID'
TY_E_VERSION_ID = c_int # enum

# values for enumeration 'ty_e_mem_type'
ty_e_mem_type = c_int # enum
TY_E_MEM_TYPE = ty_e_mem_type
class ty_driver_info(Structure):
    pass
ty_driver_info._fields_ = [
    ('uc_DeviceGroup', AiUInt8),
    ('uc_ReservedB2', AiUInt8),
    ('uc_ReservedB3', AiUInt8),
    ('uc_ReservedB4', AiUInt8),
    ('uw_ReservedW1', AiUInt16),
    ('uw_ReservedW2', AiUInt16),
    ('ul_DriverFlags', AiUInt32),
    ('ul_SN', AiUInt32),
    ('ul_BoardConfig', AiUInt32),
    ('ul_BoardType', AiUInt32),
    ('ul_OpenConnections', AiUInt32),
    ('ul_ReservedLW6', AiUInt32),
    ('ul_ReservedLW7', AiUInt32),
    ('ul_ReservedLW8', AiUInt32),
]
TY_DRIVER_INFO = ty_driver_info

# values for enumeration '__ty_e_device_group'
__ty_e_device_group = c_int # enum
TY_E_DEVICE_GROUP = __ty_e_device_group
PTY_E_DEVICE_GROUP = POINTER(__ty_e_device_group)
int8_t = c_int8
AiInt8 = int8_t
int16_t = c_int16
AiInt16 = int16_t
int64_t = c_int64
AiInt64 = int64_t
AiUChar = c_ubyte
AiShort = c_short
AiUShort = c_ushort
AiInt = c_int
AiUInt = c_uint
AiLong = c_long
AiULong = c_ulong
AiDouble = c_double
AiFloat = c_float
size_t = c_ulong
AiSize = size_t
AiBoolean = c_ubyte
AiAddr = c_void_p
uintptr_t = c_ulong
AiUIntPtr = uintptr_t
ptrdiff_t = c_long
AiPtrDiff = ptrdiff_t
AiTrgVoidPtr = AiUInt32
AiTrgUI8Ptr = AiUInt32
AiBool32 = AiUInt32
AiReturn = AiInt32
AiHandle = c_void_p
class ai_int64_union(Union):
    pass
class ai_int64_union_ll(Structure):
    pass
ai_int64_union_ll._fields_ = [
    ('ul_LoPart', AiUInt32),
    ('l_HiPart', AiInt32),
]
ai_int64_union._fields_ = [
    ('ll_QuadPart', AiInt64),
    ('ll', ai_int64_union_ll),
]
Ai_Int64_Union = ai_int64_union
class ai_uint64_union(Union):
    pass
class ai_uint64_union_ull(Structure):
    pass
ai_uint64_union_ull._fields_ = [
    ('ul_LoPart', AiUInt32),
    ('ul_HiPart', AiUInt32),
]
ai_uint64_union._fields_ = [
    ('ull_QuadPart', AiUInt64),
    ('ull', ai_uint64_union_ull),
]
Ai_UInt64_Union = ai_uint64_union
TY_API_DRIVER_INFO = TY_DRIVER_INFO

# values for enumeration 'API_DEVICE_MODE'
API_DEVICE_MODE = c_int # enum
class ty_mil_com(Structure):
    pass
ty_mil_com._fields_ = [
    ('ulMagic', AiUInt32),
    ('ulStream', AiUInt32),
    ('ulCommand', AiUInt32),
    ('ulSize', AiUInt32),
    ('ulExpectedAckSize', AiUInt32),
    ('ulSwapControl', AiUInt32),
    ('ulReserved_3', AiUInt32),
    ('ulReserved_4', AiUInt32),
]
TY_MIL_COM = ty_mil_com
class ty_mil_com_ack(Structure):
    pass
ty_mil_com_ack._fields_ = [
    ('ulMagic', AiUInt32),
    ('ulCommand', AiUInt32),
    ('ulError', AiUInt32),
    ('ulSize', AiUInt32),
    ('ulSwapControl', AiUInt32),
    ('ulReserved_2', AiUInt32),
    ('ulReserved_3', AiUInt32),
    ('ulReserved_4', AiUInt32),
]
TY_MIL_COM_ACK = ty_mil_com_ack
class ty_mil_com_with_value(Structure):
    pass
ty_mil_com_with_value._fields_ = [
    ('cmd', TY_MIL_COM),
    ('value', AiUInt32),
]
TY_MIL_COM_WITH_VALUE = ty_mil_com_with_value
class ty_mil_com_ack_with_value(Structure):
    pass
ty_mil_com_ack_with_value._fields_ = [
    ('xAck', TY_MIL_COM_ACK),
    ('value', AiUInt32),
]
TY_MIL_COM_ACK_WITH_VALUE = ty_mil_com_ack_with_value
class ty_ir_capabilities_union(Union):
    pass
class ty_ir_capabilities_b(Structure):
    pass
ty_ir_capabilities_b._fields_ = [
    ('ul_Res', AiUInt32, 31),
    ('b_IrOnDiscretes', AiUInt32, 1),
]
ty_ir_capabilities_union._fields_ = [
    ('ul_All', AiUInt32),
    ('b', ty_ir_capabilities_b),
]
TY_IR_CAPABILITIES = ty_ir_capabilities_union
class ty_api_scope_setup(Structure):
    pass
ty_api_scope_setup._fields_ = [
    ('ul_CouplingPri', AiUInt32),
    ('ul_CouplingSec', AiUInt32),
    ('ul_SamplingRate', AiUInt32),
    ('ul_CaptureMode', AiUInt32),
    ('ul_OperationMode', AiUInt32),
    ('ul_SingleShotBuf', AiUInt32),
]
TY_API_SCOPE_SETUP = ty_api_scope_setup
class ty_api_scope_trg(Structure):
    pass
ty_api_scope_trg._fields_ = [
    ('ul_TrgMode', AiUInt32),
    ('ul_TrgSrc', AiUInt32),
    ('ul_TrgValue', AiUInt32),
    ('ul_TrgNbSamples', AiUInt32),
    ('ul_TrgFlags', AiUInt32),
    ('ul_TrgDelay', AiUInt32),
    ('ul_TrgTbt', AiUInt32),
]
TY_API_SCOPE_TRG = ty_api_scope_trg

# values for enumeration 'API_SCOPE_STATUS'
API_SCOPE_STATUS = c_int # enum
TY_API_SCOPE_STATUS = API_SCOPE_STATUS
class api_scope_trg_ex(Structure):
    pass
api_scope_trg_ex._fields_ = [
    ('ul_TrgMode', AiUInt32),
    ('ul_TrgSrc', AiUInt32),
    ('ul_TrgValue', AiUInt32),
    ('ul_TrgValue2', AiUInt32),
    ('ul_TrgNbSamples', AiUInt32),
    ('ul_TrgNbSamples2', AiUInt32),
    ('ul_TrgFlags', AiUInt32),
    ('ul_TrgDelay', AiUInt32),
    ('ul_TrgTbt', AiUInt32),
    ('ul_TrgDiscrete', AiUInt32),
]
TY_API_SCOPE_TRG_EX = api_scope_trg_ex

# values for enumeration 'api_scope_trigger_strobe_type'
api_scope_trigger_strobe_type = c_int # enum
TY_API_SCOPE_TRIGGER_STROBE_TYPE = api_scope_trigger_strobe_type
class api_scope_trg_strobe(Structure):
    pass
api_scope_trg_strobe._fields_ = [
    ('ul_TrgStrobeType', AiUInt32),
    ('ul_TrgStrobeDest', AiUInt32),
]
TY_API_SCOPE_TRG_STROBE = api_scope_trg_strobe
class api_scope_offsets(Structure):
    pass
api_scope_offsets._fields_ = [
    ('lOffsetA_3V_stub', AiInt32),
    ('lOffsetB_3V_stub', AiInt32),
    ('lOffsetA_30V_stub', AiInt32),
    ('lOffsetB_30V_stub', AiInt32),
    ('lOffsetA_3V_ext', AiInt32),
    ('lOffsetB_3V_ext', AiInt32),
    ('lOffsetA_30V_ext', AiInt32),
    ('lOffsetB_30V_ext', AiInt32),
]
TY_API_SCOPE_OFFSETS = api_scope_offsets
class ty_api_bc_error(Structure):
    pass
ty_api_bc_error._fields_ = [
    ('ul_Type', AiUInt32),
    ('ul_Sync', AiUInt32),
    ('ul_Contig', AiUInt32),
    ('ul_Padding1', AiUInt32),
    ('ul_ErrSpec', AiUInt32),
]
TY_API_BC_ERROR = ty_api_bc_error
class ty_api_hs_bc_error(Structure):
    pass
ty_api_hs_bc_error._fields_ = [
    ('ul_Type', AiUInt32),
    ('ul_Padding1', AiUInt32),
    ('ul_Padding2', AiUInt32),
    ('ul_ErrSpec', AiUInt32),
]
TY_API_HS_BC_ERROR = ty_api_hs_bc_error
class ty_api_gen_io_test_seq_array(Structure):
    pass
ty_api_gen_io_test_seq_array._fields_ = [
    ('mode', AiUInt32),
    ('cond', AiUInt32),
    ('res1', AiUInt32),
    ('res2', AiUInt32),
    ('tm_ms', AiUInt32 * 32),
    ('genio_type_op', AiUInt32 * 32),
    ('chn_val', AiUInt32 * 32),
]
TY_API_GENIO_TEST_SEQ_ARRAY = ty_api_gen_io_test_seq_array
class ty_api_gen_io_test_seq_tbl(Structure):
    pass
ty_api_gen_io_test_seq_tbl._fields_ = [
    ('ax_Seq', TY_API_GENIO_TEST_SEQ_ARRAY * 4),
]
TY_API_GENIO_TEST_SEQ_TBL = ty_api_gen_io_test_seq_tbl
class ty_api_ver_info_values(Structure):
    pass
ty_api_ver_info_values._fields_ = [
    ('ul_VersionType', AiUInt32),
    ('ul_MajorVer', AiUInt32),
    ('ul_MinorVer', AiUInt32),
    ('ul_PatchVersion', AiUInt32),
    ('ul_BuildNr', AiUInt32),
]
TY_API_VER_INFO_VALUES = ty_api_ver_info_values
class ty_api_ver_info_strings(Structure):
    pass
ty_api_ver_info_strings._fields_ = [
    ('ac_Description', AiChar * 256),
    ('ac_FullVersion', AiChar * 256),
]
TY_API_VER_INFO_STRINGS = ty_api_ver_info_strings
class ty_api_mem_biu_addr(Structure):
    pass
ty_api_mem_biu_addr._fields_ = [
    ('ul_Cb', AiUInt32),
    ('ul_IrLog', AiUInt32),
    ('ul_RtDesc', AiUInt32),
    ('ul_BmTcb', AiUInt32),
    ('ul_BmAct', AiUInt32),
    ('ul_RtSaDesc', AiUInt32),
    ('ul_RtBhArea', AiUInt32),
    ('ul_RtSqArea', AiUInt32),
    ('ul_RtEqArea', AiUInt32),
    ('ul_BcBhArea', AiUInt32),
    ('ul_BcSqArea', AiUInt32),
    ('ul_BcEqArea', AiUInt32),
    ('ul_BcXferDesc', AiUInt32),
    ('ul_BcHipInstr', AiUInt32),
    ('ul_BcLipInstr', AiUInt32),
    ('ul_BcAcycInstr', AiUInt32),
    ('ul_RepBuf', AiUInt32),
    ('ul_BmBuf', AiUInt32),
]
TY_API_MEM_BIU_ADDR = ty_api_mem_biu_addr
class ty_api_mem_sim_buf(Structure):
    pass
ty_api_mem_sim_buf._fields_ = [
    ('ul_BufBaseAddr', AiUInt32),
    ('ul_BufSize', AiUInt32),
    ('ul_BufCount', AiUInt32),
    ('ul_HsBufBaseAddr', AiUInt32),
    ('ul_HsBufSize', AiUInt32),
    ('ul_HsRes', AiUInt32),
]
TY_API_MEM_SIM_BUF = ty_api_mem_sim_buf
class ty_api_mem_biu_size(Structure):
    pass
ty_api_mem_biu_size._fields_ = [
    ('ul_BcHipInstr', AiUInt32),
    ('ul_BcLipInstr', AiUInt32),
    ('ul_BcAcycInstr', AiUInt32),
    ('ul_RepBuf', AiUInt32),
    ('ul_BmBuf', AiUInt32),
]
TY_API_MEM_BIU_SIZE = ty_api_mem_biu_size
class ty_api_mem_biu_count(Structure):
    pass
ty_api_mem_biu_count._fields_ = [
    ('ul_RtBhArea', AiUInt32),
    ('ul_RtSqArea', AiUInt32),
    ('ul_RtEqArea', AiUInt32),
    ('ul_BcBhArea', AiUInt32),
    ('ul_BcSqArea', AiUInt32),
    ('ul_BcEqArea', AiUInt32),
    ('ul_BcXferDesc', AiUInt32),
]
TY_API_MEM_BIU_COUNT = ty_api_mem_biu_count
class ty_api_mem_biu_info(Structure):
    pass
ty_api_mem_biu_info._fields_ = [
    ('ul_Protocol', AiUInt32),
    ('ul_StreamNb', AiUInt32),
    ('ul_MemoryBank', AiUInt32),
]
TY_API_MEM_BIU_INFO = ty_api_mem_biu_info
class ty_api_get_mem_layout(Structure):
    pass
ty_api_get_mem_layout._fields_ = [
    ('ax_BiuAddr', TY_API_MEM_BIU_ADDR * 8),
    ('x_Sim', TY_API_MEM_SIM_BUF * 2),
    ('ax_BiuSize', TY_API_MEM_BIU_SIZE * 8),
    ('ax_BiuCnt', TY_API_MEM_BIU_COUNT * 8),
    ('x_BiuInfo', TY_API_MEM_BIU_INFO * 8),
    ('aul_GlobalMemSize', AiUInt32 * 2),
]
TY_API_GET_MEM_INFO = ty_api_get_mem_layout
class ty_api_set_mem_layout(Structure):
    pass
ty_api_set_mem_layout._fields_ = [
    ('aul_SimBufSize', AiUInt32 * 2),
    ('ax_BiuSize', TY_API_MEM_BIU_SIZE * 8),
    ('ax_BiuCnt', TY_API_MEM_BIU_COUNT * 8),
]
TY_API_SET_MEM_INFO = ty_api_set_mem_layout
class ty_api_bc_modify_instruction(Structure):
    pass
ty_api_bc_modify_instruction._fields_ = [
    ('type', AiUInt32),
    ('compare_control', AiUInt32),
    ('write_type', AiUInt32),
    ('arithmetic_operation', AiUInt32),
    ('re_load', AiUInt32),
    ('operand', AiUInt32),
    ('compare_word_source_offset', AiUInt32),
    ('destination_offset', AiUInt32),
    ('mask_word', AiUInt32),
    ('compare_word', AiUInt32),
    ('destination_argument', AiUInt32),
]
TY_API_BC_MODIFY_INSTRUCTION = ty_api_bc_modify_instruction
class TY_MIL_ERR_TRANSLATE_TABLE(Structure):
    pass
TY_MIL_ERR_TRANSLATE_TABLE._fields_ = [
    ('ulNumber', AiUInt32),
    ('sZFileName', STRING),
]
API_ERR_HS_XFER_SW_EXCEPT_NOT_IN_RANGE = 778 # Variable c_int '778'
API_BUF_READ_FROM_CURRENT = 0 # Variable c_int '0'
TYPE_ACX_EFAXp_4_TWO_PBIS = 57 # Variable c_int '57'
API_HS_HSXMT_NOPRE_MASK = 16711680 # Variable c_int '16711680'
API_BC_HLT_HALT_ON_XFER_ERR = 1 # Variable c_int '1'
API_EF_TRIG_SD = 0 # Variable c_int '0'
API_TRG_BC_CHN3 = 10 # Variable c_int '10'
API_TRG_BC_CHN2 = 9 # Variable c_int '9'
API_BM_ET_HBIT_MASK = 4 # Variable c_int '4'
API_BM_SEARCH_WORDB_MASK = 512 # Variable c_int '512'
API_DIS_ON_ERROR = 2 # Variable c_int '2'
API_DATA_QUEUE_TSW_OFFSET_PUT = 4 # Variable c_int '4'
API_DATA_QUEUE_STATUS_REM_BUF_ERR = 8 # Variable c_int '8'
API_SCOPE_SIZE_SINGLE_CH_REC = 65536 # Variable c_int '65536'
API_ERR_BC_SIMULATION_ACTIVE = 4122 # Variable c_int '4122'
API_TRG_BC_CHN4 = 11 # Variable c_int '11'
API_BC_XFER_RTRT = 2 # Variable c_int '2'
API_TRG_BC_CHN1 = 8 # Variable c_int '8'
DBG_TRACE = 134217728 # Variable c_int '134217728'
API_RT_TYPE_TRANSMIT_SA = 1 # Variable c_int '1'
API_ERR_SUBPARAM1_NOT_IN_RANGE = 256 # Variable c_int '256'
API_SERVER_POS = 5 # Variable c_int '5'
API_ERR_PARA_TYPE_NOT_IN_RANGE = 128 # Variable c_int '128'
DBG_ERROR = 536870912 # Variable c_int '536870912'
API_ERR_1760_C01_NOT_IN_RANGE = 111 # Variable c_int '111'
API_PROTOCOL_1553_EFEX = 5 # Variable c_int '5'
API_HS_CTX_STATUS_DRDY = 128 # Variable c_int '128'
MAX_SCOPE_TRG_VALUE = 1023 # Variable c_int '1023'
TYPE_ACE3910 = 95 # Variable c_int '95'
MAX_SCOPE_TRG_DELAY = 262143 # Variable c_int '262143'
_DEFAULT_SOURCE = 1 # Variable c_int '1'
AI_PLATFORM_ASC = 168 # Variable c_int '168'
API_ERR_DQUEUE_ID_NOT_IN_RANGE = 113 # Variable c_int '113'
AI_PLATFORM_XMC = 176 # Variable c_int '176'
TYPE_ACI1553_1 = 3 # Variable c_int '3'
API_HS_ERR_TYPE_MANCHESTER_LOW = 6 # Variable c_int '6'
TYPE_ACI1553_2 = 4 # Variable c_int '4'
API_RESET_WITHOUT_SIMBUF_MON = 3 # Variable c_int '3'
API_BC_HLT_HALT_ON_STAT_EXCEPT = 2 # Variable c_int '2'
MAX_HS_ENTRY_NR = 8191 # Variable c_int '8191'
API_ERR_INVALID_DRIVER_HANDLE = 6 # Variable c_int '6'
MAX_SYSTAG_ID = 255 # Variable c_int '255'
API_ERR_SUBPARAM6_NOT_IN_RANGE = 261 # Variable c_int '261'
API_ERR_SUBPARAM4_IS_NULL = 387 # Variable c_int '387'
MAX_RT_DEFINED_WORD_CNT = 32 # Variable c_int '32'
API_SYSTAG_BITNB_MASK = 255 # Variable c_int '255'
TYPE_AVI3910Xp = 14 # Variable c_int '14'
TYPE_API3910Xp = 10 # Variable c_int '10'
API_BC_GAP_MODE_STANDARD = 1 # Variable c_int '1'
API_BITE_GLOBAL_RAM_BIU = 3 # Variable c_int '3'
API_HS_CTX_REG_OVRSHOOT = 19 # Variable c_int '19'
API_SYSTAG_BITPOS_POS = 8 # Variable c_int '8'
API_HS_BC_ERRSPEC_BPOS_POS = 8 # Variable c_int '8'
API_ERR_SCOPE_DMA_ENABLED = 4129 # Variable c_int '4129'
TY_BOARD_INFO_BOARD_TYPE = 3 # Variable c_int '3'
API_RT_SA_ERR_INT = 3 # Variable c_int '3'
API_DIS = 0 # Variable c_int '0'
API_BM_ENTRY_DW_PRIMARY = 10 # Variable c_int '10'
AI_PLATFORM_VMEX_B = 33 # Variable c_int '33'
DBG_OPEN = 4 # Variable c_int '4'
API_BSP_WRONG_TARGET_SW = 3 # Variable c_int '3'
TYPE_AVX_EFA_4_TWO_PBIS = 67 # Variable c_int '67'
API_BM_STROBE_ON_START_EVENT = 2 # Variable c_int '2'
API_PBI_APX = 9 # Variable c_int '9'
API_HS_BC_ECW_BUFINT_MASK = 96 # Variable c_int '96'
API_HS_RT_TYPE_RECEIVE_MID = 0 # Variable c_int '0'
MAX_HS_CONT_TRACK_NB = 128 # Variable c_int '128'
AI_PLATFORM_PCI_SHORT_ZYNQMP = 20 # Variable c_int '20'
AI_PLATFORM_XMC_ZYNQMP = 180
API_BC_TIC_NO_INT = 0 # Variable c_int '0'
API_EF_SWITCH_TO_EFEX = 2 # Variable c_int '2'
API_BM_ET_LBIT_MASK = 8 # Variable c_int '8'
API_ERR_PARAM4_NOT_IN_RANGE = 28 # Variable c_int '28'
API_HS_XMT_RT_POS = 0 # Variable c_int '0'
API_FIRMWARE_BIU1_VER_MASK = 65535 # Variable c_int '65535'
API_PXI_SET_TTSRC_EXTERNAL = 2 # Variable c_int '2'
AI_PLATFORM_VME_A = 34 # Variable c_int '34'
AI_PLATFORM_VME_B = 32 # Variable c_int '32'
API_ERR_CHN_NOT_IN_RANGE = 53 # Variable c_int '53'
API_HS_FMOD_CONT_PREAM = 1 # Variable c_int '1'
API_HS_BC_ERRSPEC_WPOS_MASK = 4294901760 # Variable c_uint '4294901760u'
API_BITE_ERR_MODE_ISOL_B_BM = 11 # Variable c_int '11'
API_BSIZEM_STATIC = 0 # Variable c_int '0'
API_BM_MENSW_START_MASK = 2 # Variable c_int '2'
TYPE_ACX_EFA_2_DS_TWO_PBIS = 54 # Variable c_int '54'
API_BITE_ERR_INTERRUPT = 10 # Variable c_int '10'
AI_PLATFORM_PMC_64 = 84 # Variable c_int '84'
API_BM_ET_ILLEGL_MASK = 256 # Variable c_int '256'
API_BM_TRG_DATA_VALUE = 3 # Variable c_int '3'
API_BC_MODIFY_TYPE_MODIFY = 0 # Variable c_int '0'
TYPE_APXX3910Xp = 91 # Variable c_int '91'
TYPE_APU1553_1 = 72 # Variable c_int '72'
TYPE_APU1553_2 = 73 # Variable c_int '73'
API_VER_MASK = 65535 # Variable c_int '65535'
API_BITE_ERR_HS_INT_PAT_AA = 18 # Variable c_int '18'
API_SYSTAG_XFERID_POS = 0 # Variable c_int '0'
__WORDSIZE = 64 # Variable c_int '64'
API_ERR_SUBPARAM2_NOT_IN_RANGE = 257 # Variable c_int '257'
MAX_XFER_ID = 8191 # Variable c_int '8191'
API_BC_FWI_MODIFY = 43 # Variable c_int '43'
API_HS_CHANNEL_A = 0 # Variable c_int '0'
_XOPEN_SOURCE = 700 # Variable c_int '700'
API_FLASH_ERR_PROG = 2 # Variable c_int '2'
TYPE_API1553_1 = 1 # Variable c_int '1'
API_PBI_ELECTRICAL = 0 # Variable c_int '0'
API_ERR_NO_SCOPE_EXECUTED = 401 # Variable c_int '401'
API_BITE_ERR_SHARED_RAM = 6 # Variable c_int '6'
API_ERR_UNKNOWN_COMMAND = 12 # Variable c_int '12'
API_BSP_COMPATIBLE = 0 # Variable c_int '0'
API_BITE_GLOBAL_RAM_BM = 5 # Variable c_int '5'
API_ERR_XMT_RT_NOT_IN_RANGE = 54 # Variable c_int '54'
API_ERR_XMT_SA_NOT_IN_RANGE = 56 # Variable c_int '56'
API_HS_HSXMT_NOPRE_POS = 16 # Variable c_int '16'
API_RT_SA_TYPE_RCV = 0 # Variable c_int '0'
API_ERR_SYSTAG_FCT_NOT_IN_RANGE = 101 # Variable c_int '101'
API_MEM_PART_PARAM_ERR = 2 # Variable c_int '2'
API_SYSTAG_STEP_CYCLIC = 0 # Variable c_int '0'
API_BITE_ERR_BC_TIMEOUT_ISOL_A_BM = 12 # Variable c_int '12'
MAX_HS_WPOS = 4095 # Variable c_int '4095'
API_BC_SWXM_SUB_MASK = 4 # Variable c_int '4'
API_BC_TIC_INT_ON_XFER_END = 1 # Variable c_int '1'
API_ERR_HS_XFER_XFERTYPE_NOT_IN_RANGE = 773 # Variable c_int '773'
API_BC_FWI_DJZ = 39 # Variable c_int '39'
API_BC_MODIFY_OPC_NONE = 0 # Variable c_int '0'
TRUE = 1 # Variable c_int '1'
API_ERR_SCOPE_ALREADY_RUNNING = 4128 # Variable c_int '4128'
__USE_POSIX2 = 1 # Variable c_int '1'
API_ERR_SUBPARAM8_IS_NULL = 391 # Variable c_int '391'
API_ERR_PARAM1_NOT_IN_RANGE = 25 # Variable c_int '25'
API_HS_RCV_MID_MASK = 65280 # Variable c_int '65280'
_AIM_LINUX = 1 # Variable c_int '1'
API_ERR_ACK2 = 3 # Variable c_int '3'
UINT64_MAX = 18446744073709551615 # Variable c_ulong '-1ul'
API_TRACK_XFERID_MASK = 65535 # Variable c_int '65535'
API_RT_SWM_NXW_OR = 2 # Variable c_int '2'
API_BITE_ERR_HS_TIMING_TX_TO = 3 # Variable c_int '3'
API_BITE_ERR_HS_RTBC_ISOL_AB = 21 # Variable c_int '21'
API_BITE_ERR_HS_RTBC_ISOL_AA = 20 # Variable c_int '20'
DBG_MINIMAL = 2147483648 # Variable c_uint '2147483648u'
API_ERR_TYPE_ALTERNATE_BUS = 11 # Variable c_int '11'
API_LLA_ANY_ERR_MASK = 33554432 # Variable c_int '33554432'
API_BC_MODIFY_TYPE_MOVE = 1 # Variable c_int '1'
API_ERR_NOVRAM_ERROR = 4134 # Variable c_int '4134'
API_SEND_SRVW_ON_SA0 = 0 # Variable c_int '0'
API_HS_BC_MSG_TAG_BCNT_MASK = 2048 # Variable c_int '2048'
API_BSP_WRONG_SYS_DRV = 11 # Variable c_int '11'
APIEF_BC_XFER_TYPE_XERTRT = 22 # Variable c_int '22'
API_BC_MODIFY_COMPC__EQ = 0 # Variable c_int '0'
TY_BOARD_INFO_CHANNEL_COUNT = 1 # Variable c_int '1'
API_BM_SEARCH_CMD_MASK = 8192 # Variable c_int '8192'
API_ERR_PARA_SAMID_NOT_IN_RANGE = 129 # Variable c_int '129'
API_BC_STATUS_HALTED = 1 # Variable c_int '1'
API_CHN_DUAL_EFEX = 2 # Variable c_int '2'
API_ERR_INVALID_HID = 4138 # Variable c_int '4138'
TY_GETMEM_RT_DESCR = 1 # Variable c_int '1'
SIZE_MAX = 18446744073709551615 # Variable c_ulong '-1ul'
SCOPE_WAIT_FINISHED = 1 # Variable c_int '1'
AI_PLATFORM_PCI_LONG = 16 # Variable c_int '16'
TYPE_APX3910 = 25 # Variable c_int '25'
API_SYSTAG_FCT_DATASET = 5 # Variable c_int '5'
API_SCOPE_MODE_BIU2_BM = 9 # Variable c_int '9'
API_ERR_PARAM4_IS_NULL = 22 # Variable c_int '22'
API_BC_START_EXT_TRIGGER = 2 # Variable c_int '2'
API_ERR_HS_XFER_SECOND_GAPMODE_NOT_IN_RANGE = 781 # Variable c_int '781'
API_ERR_DWC_NOT_AVAILABLE = 4153 # Variable c_int '4153'
API_ERR_SUBPARAM7_IS_NULL = 390 # Variable c_int '390'
API_SCOPE_MODE_BIU2_BC = 10 # Variable c_int '10'
SCOPE_BUFFER_FLAG_CANCELED = 2 # Variable c_int '2'
API_SCOPE_START_CONTINUOUS = 1 # Variable c_int '1'
MAX_TG_CMD_SIZE = 12288 # Variable c_int '12288'
TY_BOARD_INFO_HAS_EXTERNAL_TRIGGER = 23 # Variable c_int '23'
API_TRACK_XFERID_POS = 0 # Variable c_int '0'
API_BIU_7 = 7 # Variable c_int '7'
API_BITE_ERR_HS_INT_WALK_1 = 22 # Variable c_int '22'
API_BC_MODIFY_WRTYP_26BIT = 1 # Variable c_int '1'
AI_PLATFORM_PMC_BASED_EBD = 89 # Variable c_int '89'
API_HS_BC_ECW_BUFSTAT_MASK = 768 # Variable c_int '768'
API_SERVER_MASK = 224 # Variable c_int '224'
API_BIU_6 = 6 # Variable c_int '6'
API_HS_BC_TYPE_RTRT = 11 # Variable c_int '11'
API_ERR_HS_DYTAG_MODE_NOT_IN_RANGE = 769 # Variable c_int '769'
API_BC_ACYC_SEND_ON_TIMETAG = 1 # Variable c_int '1'
API_MODULE_11 = 10 # Variable c_int '10'
API_BITE_ERR_RTRT_ISOL_A_BM = 8 # Variable c_int '8'
API_HS_CTX_RISE_MAX = 17.5 # Variable c_double '1.75e+1'
API_BQM_CYCLIC = 0 # Variable c_int '0'
API_ERR_ACK = 2 # Variable c_int '2'
API_MODULE_15 = 14 # Variable c_int '14'
API_HS_BC_NO_INDEX_INT = 0 # Variable c_int '0'
FALSE = 0 # Variable c_int '0'
INT32_MAX = 2147483647 # Variable c_int '2147483647'
API_FILE_FLAG_OVERWRITE = 1 # Variable c_int '1'
INT_LEAST64_MIN = -9223372036854775808 # Variable c_long '-0x08000000000000000l'
TYPE_AMCX1553_1 = 79 # Variable c_int '79'
TYPE_AMCX1553_2 = 80 # Variable c_int '80'
TYPE_AMCX1553_4 = 81 # Variable c_int '81'
API_BC_MODIFY_COMPC__TRIGGER = 5 # Variable c_int '5'
MAX_TRACK_ID = 255 # Variable c_int '255'
API_DATA_QUEUE_TSW_OFFSET_STATUS = 0 # Variable c_int '0'
API_BM_MSG_ERR_HBIT = 3 # Variable c_int '3'
API_BM_TIMETAG_MIN_MASK = 63 # Variable c_int '63'
API_BSP_WRONG_BIU1_SW = 4 # Variable c_int '4'
API_BITE_ERR_SHARED_RAM_CMD = 7 # Variable c_int '7'
API_BM_MSG_ERR_EARLY_RESP = 10 # Variable c_int '10'
API_BM_TRG_RECEIVED_WORD = 2 # Variable c_int '2'
API_BM_MSG_TBUSY_MASK = 16 # Variable c_int '16'
API_CPL_ISO = 0 # Variable c_int '0'
API_BC_STATUS_BUSY = 2 # Variable c_int '2'
API_BITE_ERR_SHARED_RAM_ACK = 8 # Variable c_int '8'
API_HS_HSXMT_STARTDEL_POS = 0 # Variable c_int '0'
API_ERR_IOCTL_ERROR = 8 # Variable c_int '8'
API_ERR_TYPE_WORD_CNT_LOW = 8 # Variable c_int '8'
TY_BOARD_INFO_SIZE_SHARED = 8 # Variable c_int '8'
API_HS_RX_SEL_4_VALID_PRE = 2 # Variable c_int '2'
API_BM_MSG_FLT_FORMAT_4 = 4 # Variable c_int '4'
API_BM_MSG_FLT_FORMAT_3 = 3 # Variable c_int '3'
API_BM_MSG_FLT_FORMAT_2 = 2 # Variable c_int '2'
API_HS_RCV_RT_MASK = 65280 # Variable c_int '65280'
API_BITE_ERR_HS_INT_PAT_00 = 20 # Variable c_int '20'
API_DYTAG_FCT_POS_RAMP = 1 # Variable c_int '1'
API_ERR_DMA_TOO_MANY_BLOCKS = 4104 # Variable c_int '4104'
TYPE_AVX_EFAXp_1_TWO_PBIS = 60 # Variable c_int '60'
API_RT_MODE_LANE_CTRL = 4 # Variable c_int '4'
MAX_HS_GAP_TIME_MODE_2 = 63 # Variable c_int '63'
__GNU_LIBRARY__ = 6 # Variable c_int '6'
TY_BOARD_INFO_DISCRETE_CONFIG = 14 # Variable c_int '14'
API_BITE_ERR_HS_RTBC_ISOL_BB = 23 # Variable c_int '23'
API_BITE_ERR_HS_RTBC_ISOL_BA = 22 # Variable c_int '22'
API_ERR_IOFPGA_BOOT_FAILED = 4115 # Variable c_int '4115'
API_ERR_RTDYTAG_MIN_NOT_IN_RANGE = 93 # Variable c_int '93'
TYPE_APE1553_2 = 83 # Variable c_int '83'
API_BM_MSW_START_MASK = 1 # Variable c_int '1'
API_BC_FWI_JUMP = 34 # Variable c_int '34'
API_BITE_ERR_INT_ADDR = 16 # Variable c_int '16'
AI_PLATFORM_PCI_E_1L_ZYNQMP = 27 # Variable c_int '27'
API_BM_CAPMODE_RECORDING = 2 # Variable c_int '2'
MIN_HS_HEADER_ID = 1 # Variable c_int '1'
API_ERR_SUBPARAM5_NOT_IN_RANGE = 260 # Variable c_int '260'
UINTMAX_MAX = 18446744073709551615 # Variable c_ulong '-1ul'
API_RT_SA_USAGE_UPDATE = 2 # Variable c_int '2'
MIN_HEADER_ID = 1 # Variable c_int '1'
AI_PLATFORM_USB = 160 # Variable c_int '160'
API_BC_RSP_NO_SW1_EXPECTED = 1 # Variable c_int '1'
API_CAL_CPL_TRANSFORM = 1 # Variable c_int '1'
API_BITE_ERR_HS_INT_PAT_FF = 19 # Variable c_int '19'
MAX_API_SERVER_PER_SLOT = 8 # Variable c_int '8'
API_ERR_VALUE_NOT_IN_RANGE = 4127 # Variable c_int '4127'
API_PBI_DUAL_1553 = 2 # Variable c_int '2'
MAX_HS_MIDTYPE = 1 # Variable c_int '1'
AI_PLATFORM_PCIX_PCIE_BASED = 153 # Variable c_int '153'
API_SCOPE_QUEUE_SIZE_BRAM_2K = 128 # Variable c_int '128'
API_HS_MAX_DATA_WORDS = 4096 # Variable c_int '4096'
API_LLA_TRIG_MASK = 67108864 # Variable c_int '67108864'
API_ERR_ELEMENT_NOT_ENABLED = 4121 # Variable c_int '4121'
API_BM_ENTRY_TIMETAG_LOW = 2 # Variable c_int '2'
API_BC_FWI_STRB = 38 # Variable c_int '38'
API_BITE_SHARED_RAM_ACK = 8 # Variable c_int '8'
API_EF_RX_SEL_2_VALID_PRE = 4 # Variable c_int '4'
API_ERR_DMA_NOT_SUPPORTED = 404 # Variable c_int '404'
API_MODE_HS_ADDR = 8 # Variable c_int '8'
API_ERR_TCBNEXT_NOT_IN_RANGE = 86 # Variable c_int '86'
API_ERR_RTDYTAG_WPOS_NOT_IN_RANGE = 96 # Variable c_int '96'
API_BITE_ERR_INT_WALK_1 = 22 # Variable c_int '22'
API_BITE_ERR_INT_WALK_0 = 21 # Variable c_int '21'
MAX_FIFO_ID = 32 # Variable c_int '32'
API_ERR_HS_HSERR_ERRSPEC_BCBITS_NOT_IN_RANGE = 797 # Variable c_int '797'
API_FLASH_SECTOR_APX_EF_LCA = 52 # Variable c_int '52'
TYPE_ANET3910 = 87 # Variable c_int '87'
MAX_API_BC_XFRAME = 128 # Variable c_int '128'
__USE_XOPEN2K8 = 1 # Variable c_int '1'
API_BM_ENTRY_SW_SECONDARY = 15 # Variable c_int '15'
API_BM_MSG_ERR_SW_EXCEPT = 12 # Variable c_int '12'
API_BM_ENTRY_CW_PRIMARY = 8 # Variable c_int '8'
API_HS_BC_MSG_TAG_DEL_MASK = 4096 # Variable c_int '4096'
API_SCOPE_OFFSET_COMP_MEASURE = 1 # Variable c_int '1'
MIN_HS_TRACK_LEN = 1 # Variable c_int '1'
API_ERR_GAP_MODE_NOT_IN_RANGE = 63 # Variable c_int '63'
API_BC_INSTR_WAIT = 3 # Variable c_int '3'
API_ERR_PARA_MODE_NOT_IN_RANGE = 126 # Variable c_int '126'
API_BITE_SHARED_RAM_CMD = 7 # Variable c_int '7'
TYPE_ASE1553_1 = 103 # Variable c_int '103'
API_ERR_1760_MODE_NOT_IN_RANGE = 109 # Variable c_int '109'
USB_EEPROM = 0 # Variable c_int '0'
TYPE_APX3910Xp = 26 # Variable c_int '26'
API_ERR_PARA_RANGE_NOT_IN_RANGE = 131 # Variable c_int '131'
API_BRW_ERR_REPORT_MASK = 15 # Variable c_int '15'
API_BM_WRITE_TI0 = 1 # Variable c_int '1'
API_BM_WRITE_TI1 = 2 # Variable c_int '2'
API_ERR_DQUEUE_REM_MEMSIZE_NOT_IN_RANGE = 117 # Variable c_int '117'
MAX_GAP_TIME_MODE_2 = 63 # Variable c_int '63'
API_HS_FMOD_DDL = 2 # Variable c_int '2'
API_BUF_OVERRUN = 3 # Variable c_int '3'
API_CHN_DUAL_1553 = 2 # Variable c_int '2'
AI_PLATFORM_CPCIE_3U = 68 # Variable c_int '68'
AI_PLATFORM_PC104 = 128 # Variable c_int '128'
API_BITE_ERR_BC_BROAD_ELECT_A_BM = 3 # Variable c_int '3'
MIN_CONT_TRACK_NB = 1 # Variable c_int '1'
API_HS_GPIO_CMD_DEV_END = 255 # Variable c_int '255'
API_ERR_OVERFLOW = 406 # Variable c_int '406'
API_BITE_ERR_HS_INT_SIM_TX_CNT = 24 # Variable c_int '24'
API_BM_TRG_SPEC_CW_MASK = 1 # Variable c_int '1'
TY_BOARD_INFO_IS_MULTI_CHANNEL = 16 # Variable c_int '16'
MAX_WPOS = 31 # Variable c_int '31'
API_HS_RX_SEL_FIRST_EDGE = 0 # Variable c_int '0'
API_ERR_INVALID_TSW_VERSION = 400 # Variable c_int '400'
API_BC_EXEC_CYCLIC = 0 # Variable c_int '0'
API_BITE_ERR_INT_PAT_AA = 18 # Variable c_int '18'
API_BM_OVERFLOW = 1 # Variable c_int '1'
MAX_HS_BUFSIZE = 4131 # Variable c_int '4131'
MIN_XFER_ID = 1 # Variable c_int '1'
API_SCOPE_COUPLING_PRIMARY = 0 # Variable c_int '0'
API_BITE_DA_CONV_BUSA = 11 # Variable c_int '11'
API_BITE_ERR_HS_INT_WRONG_PBI = 23 # Variable c_int '23'
API_TRACK_RTADDR_MASK = 32512 # Variable c_int '32512'
API_BITE_ERR_TIMING_MFRM_10 = 2 # Variable c_int '2'
MAX_ERR_WPOS = 32 # Variable c_int '32'
MAX_MID_MCODE = 32 # Variable c_int '32'
AI_PLATFORM_XMC_EBD = 178 # Variable c_int '178'
API_DYTAG_FCT_MASK = 127 # Variable c_int '127'
API_BM_CAPMODE_ALL = 0 # Variable c_int '0'
API_SCOPE_MODE_GREATER_OR_LESS_THAN = 2 # Variable c_int '2'
API_SRV_OS_VER_WIN2000 = 4 # Variable c_int '4'
__USE_XOPEN2KXSI = 1 # Variable c_int '1'
API_ERR_PARAM9_NOT_IN_RANGE = 44 # Variable c_int '44'
API_BC_SWXM_BRCV_MASK = 16 # Variable c_int '16'
MAX_HS_XFER_ID = 4095 # Variable c_int '4095'
API_ERR_HLT_NOT_IN_RANGE = 60 # Variable c_int '60'
API_ERR_TCBSOT_NOT_IN_RANGE = 83 # Variable c_int '83'
API_ERR_WRONG_DRV_VERSION = 11 # Variable c_int '11'
TY_BOARD_INFO_HAS_ELECTRICAL_INTERFACE = 19 # Variable c_int '19'
API_ERR_NUMBUFFERSLEFT_INVALID = 403 # Variable c_int '403'
API_ERR_XID_NOT_IN_RANGE = 50 # Variable c_int '50'
API_BM_TIMETAG_DAYS_MASK = 1046528 # Variable c_int '1046528'
API_ERR_TYPE_MSG_LENGTH_LO_IGNORE = 19 # Variable c_int '19'
API_BC_SWXM_MERR_MASK = 1024 # Variable c_int '1024'
API_ERR_WRONG_TSW_VERSION = 10 # Variable c_int '10'
API_BITE_BOARD_ENABLE = 1 # Variable c_int '1'
API_BM_MSG_ERR_ISYNC = 6 # Variable c_int '6'
API_DATA_QUEUE_TSW_OFFSET_GET = 8 # Variable c_int '8'
API_RT_ALL = 0 # Variable c_int '0'
API_REP_HFI_INT = 1 # Variable c_int '1'
API_HS_BM_BCTYPE_BCRT = 1 # Variable c_int '1'
API_ERR_HS_LSIR_NOT_IN_RANGE = 784 # Variable c_int '784'
_ISOC99_SOURCE = 1 # Variable c_int '1'
API_BM_SEARCH_DATA_MASK = 4096 # Variable c_int '4096'
API_ERR_RT_SIMULATION_ACTIVE = 4123 # Variable c_int '4123'
API_ERR_INVALID_TIME = 4144 # Variable c_int '4144'
API_ERR_HS_XFER_XFERID_NOT_IN_RANGE = 771 # Variable c_int '771'
API_RT_TYPE_RECEIVE_MODECODE = 2 # Variable c_int '2'
MAX_SKIP_CNT = 127 # Variable c_int '127'
API_SREC_ERR_ADDR = 4 # Variable c_int '4'
API_RT_MC_TYPE_RCV = 2 # Variable c_int '2'
MAX_HS_HEADER_ID = 8191 # Variable c_int '8191'
API_BC_FWI_SKIP = 36 # Variable c_int '36'
API_UTIL_CMD_READ_NOVRAM = 1 # Variable c_int '1'
API_BITE_ERR_BCRT_ISOL_AB_BM = 7 # Variable c_int '7'
MAX_RESP_TIME = 63.75 # Variable c_double '6.375e+1'
API_ERR_SUBPARAM9_NOT_IN_RANGE = 264 # Variable c_int '264'
API_DATA_QUEUE_CTRL_MODE_START = 0 # Variable c_int '0'
API_ERR_IRIG_SEC_NOT_IN_RANGE = 99 # Variable c_int '99'
API_EF_BM_CMD_TRG_MASK = 1024 # Variable c_int '1024'
MIN_DATA_WORDPOS = 1 # Variable c_int '1'
TYPE_AVX1553_2_TWO_PBIS = 39 # Variable c_int '39'
API_SCOPE_OFFSET_COMP_RESET = 0 # Variable c_int '0'
API_RT_ENABLE_SA = 1 # Variable c_int '1'
API_BM_MSW_TRIG_MASK = 16 # Variable c_int '16'
API_RESET_ALL = 0 # Variable c_int '0'
TYPE_AXI3910 = 15 # Variable c_int '15'
API_BC_GAP_MODE_DELAY = 0 # Variable c_int '0'
API_HS_BM_ENTRY_ERROR_WORD = 1 # Variable c_int '1'
API_ENA = 1 # Variable c_int '1'
API_RCV_BUS_SECONDARY = 0 # Variable c_int '0'
AI_PLATFORM_PC_CARD = 112 # Variable c_int '112'
API_QUEUE_SIZE_16 = 4 # Variable c_int '4'
TYPE_ACX_EFA_4_TWO_PBIS = 56 # Variable c_int '56'
API_ERR_TYPE_BIT_CNT_HIGH = 9 # Variable c_int '9'
API_DATA_QUEUE_STATUS_CHN_OPERATING = 6291456 # Variable c_int '6291456'
API_BC_MODIFY_OPC_ADD_OPERAND = 1 # Variable c_int '1'
API_RT_REPORT_ERR_RSP_TIMEOUT = 2 # Variable c_int '2'
API_BSP_WRONG_SYS_W95_SW = 1 # Variable c_int '1'
MIN_BH_BUF_SIZE = 1 # Variable c_int '1'
API_DATA_QUEUE_ID_BM_REC_BIU2 = 1 # Variable c_int '1'
API_DATA_QUEUE_ID_BM_REC_BIU3 = 2 # Variable c_int '2'
API_DATA_QUEUE_ID_BM_REC_BIU1 = 0 # Variable c_int '0'
API_DATA_QUEUE_ID_BM_REC_BIU6 = 5 # Variable c_int '5'
API_DATA_QUEUE_ID_BM_REC_BIU7 = 6 # Variable c_int '6'
API_DATA_QUEUE_ID_BM_REC_BIU5 = 4 # Variable c_int '4'
API_DATA_QUEUE_ID_BM_REC_BIU8 = 7 # Variable c_int '7'
API_ERR_ERRSPEC_BCBITS_NOT_IN_RANGE = 67 # Variable c_int '67'
API_HS_BM_ENTRY_BUS_WORD = 0 # Variable c_int '0'
API_BC_MODIFY_COMPC__GT = 2 # Variable c_int '2'
API_RT_STATUS_HALTED = 1 # Variable c_int '1'
TYPE_ANET1553_1 = 85 # Variable c_int '85'
TYPE_ANET1553_2 = 86 # Variable c_int '86'
API_DYTAG_DIRECT_MODIFY = 0 # Variable c_int '0'
API_BC_MODIFY_COMPC__GE = 4 # Variable c_int '4'
API_BC_SRVW_SINGLE = 2 # Variable c_int '2'
API_BC_SWXM_INSTR_MASK = 512 # Variable c_int '512'
MIN_MULTI_TRACK_NB = 2 # Variable c_int '2'
API_HS_GAPMODE_MASK = 16711680 # Variable c_int '16711680'
API_ERR_SUBPARAM1_IS_NULL = 384 # Variable c_int '384'
ALL_RT_ADDR = 4294967295 # Variable c_uint '4294967295u'
MIN_HS_BUFSIZE = 3 # Variable c_int '3'
API_SCOPE_COUPLING_NETWORK = 6 # Variable c_int '6'
INT_LEAST32_MIN = -2147483648 # Variable c_int '-0x00000000080000000'
API_LLA_INT_TYPE_MASK = 3758096384 # Variable c_uint '3758096384u'
AI_PLATFORM_PCI_64_ASP = 96 # Variable c_int '96'
TYPE_APEX3910Xp = 93 # Variable c_int '93'
API_BM_ENTRY_CW2_SECONDARY = 13 # Variable c_int '13'
API_HS_CTX_PULSE_MIN = -12.5 # Variable c_double '-1.25e+1'
API_BM_WRITE_ALL = 0 # Variable c_int '0'
API_ERR_SUBPARAM4_NOT_IN_RANGE = 259 # Variable c_int '259'
API_PROTOCOL_1553_3910 = 4 # Variable c_int '4'
API_CAL_CPL_ISOLATED = 0 # Variable c_int '0'
API_PXI_CLR_TRG = 1 # Variable c_int '1'
API_HS_ERR_TYPE_BIT_CNT_LOW = 8 # Variable c_int '8'
SIG_ATOMIC_MAX = 2147483647 # Variable c_int '2147483647'
API_TRG_BM_CHN2 = 17 # Variable c_int '17'
API_CAL_BUS_PRIMARY = 1 # Variable c_int '1'
API_BM_ENTRY_CW2_PRIMARY = 9 # Variable c_int '9'
MIN_RESP_TIME = 4.0 # Variable c_double '4.0e+0'
API_EF_BM_HW_TRG_POS = 11 # Variable c_int '11'
API_ERR_SYSTAG_XIDRTMID_NOT_IN_RANGE = 100 # Variable c_int '100'
API_HS_ERR_TYPE_INV_BIT = 10 # Variable c_int '10'
API_CAL_XMT_FULL_RANGE_SEC = 2 # Variable c_int '2'
API_HS_BM_HW_TRG_POS = 2 # Variable c_int '2'
API_BITE_ERR_BC_BROAD_ISOL_B_BM = 6 # Variable c_int '6'
_LARGEFILE64_SOURCE = 1 # Variable c_int '1'
API_BM_MSG_ERR_PARITY = 5 # Variable c_int '5'
API_BITE_GLOBAL_RAM_BCRT = 4 # Variable c_int '4'
MIN_BC_START_MODE = 1 # Variable c_int '1'
API_ERR_DEV_IS_NOT_CTX = 24 # Variable c_int '24'
API_ERR_INVALID_RT = 4137 # Variable c_int '4137'
API_SCOPE_MODE_LESS_THAN = 1 # Variable c_int '1'
API_SYSTAG_RTADDR_POS = 8 # Variable c_int '8'
__USE_ISOC11 = 1 # Variable c_int '1'
MIN_API_BC_MFRAME = 1 # Variable c_int '1'
DBG_INT = 1 # Variable c_int '1'
API_BC_MODE_STOP_ON_MC0_DBCA_FLAG = 2 # Variable c_int '2'
AI_PLATFORM_VXI_C = 48 # Variable c_int '48'
API_ERR_PLATTFORM_NOT_SUPPORTED = 397 # Variable c_int '397'
MAX_HS_START_DELAY = 1023 # Variable c_int '1023'
API_RETRY_1SAME_1ALT = 2 # Variable c_int '2'
API_ERR_EF_WORDCOUNT_NOT_IN_RANGE = 798 # Variable c_int '798'
API_BITE_DA_CONV_BUSB = 12 # Variable c_int '12'
API_ERR_PRIMARY_COUPLING_NOT_INTERNAL = 4124 # Variable c_int '4124'
API_FLASH_ERR_ERASE = 1 # Variable c_int '1'
API_LLA_BFI_MASK = 33554432 # Variable c_int '33554432'
API_BITE_ERR_GLOBAL_RAM_BCRT = 4 # Variable c_int '4'
MAX_BH_BUF_SIZE = 31 # Variable c_int '31'
MAX_API_BC_MFRAME_EX = 512 # Variable c_int '512'
API_ERR_PARAM14_IS_NULL = 41 # Variable c_int '41'
MIN_HS_ERR_BCBITS = 1 # Variable c_int '1'
API_DATA_QUEUE_STATUS_ASP_OVERFLOW = 32768 # Variable c_int '32768'
MAX_DATA_BITLEN = 16 # Variable c_int '16'
API_ERR_SYSTAG_WPOS_NOT_IN_RANGE = 105 # Variable c_int '105'
API_ERR_SYSTAG_MAX_NOT_IN_RANGE = 103 # Variable c_int '103'
API_RT_DISABLE_OPERATION = 0 # Variable c_int '0'
API_HS_GPIO_CMD_DEV_START = 128 # Variable c_int '128'
API_ERR_RTDYTAG_STEP_NOT_IN_RANGE = 95 # Variable c_int '95'
API_ERR_CAPFSIZE_NOT_IN_RANGE = 81 # Variable c_int '81'
INT_LEAST8_MIN = -128 # Variable c_int '-0x00000000000000080'
API_DATA_VALID = 1 # Variable c_int '1'
API_DYTAG_FCT_SAWTOOTH_16 = 1 # Variable c_int '1'
API_ERR_POS2_NOT_IN_RANGE = 89 # Variable c_int '89'
API_ERR_PARAM7_NOT_IN_RANGE = 42 # Variable c_int '42'
__USE_LARGEFILE64 = 1 # Variable c_int '1'
API_ERR_TYPE_NOT_IN_RANGE = 52 # Variable c_int '52'
API_BM_ENTRY_ERROR_WORD = 1 # Variable c_int '1'
API_HS_BM_ERR_TRG_MASK = 192 # Variable c_int '192'
API_BSP_WRONG_BIU2_SW = 5 # Variable c_int '5'
API_FILE_FLAG_APPEND = 2 # Variable c_int '2'
API_BM_TRG_ERR_CONDITION = 0 # Variable c_int '0'
DBG_IO = 16 # Variable c_int '16'
API_RT_BUF = 2 # Variable c_int '2'
API_HS_BC_ERRSPEC_BCBITS_POS = 0 # Variable c_int '0'
API_RT_MODE_LSW_HANDLING = 5 # Variable c_int '5'
MIN_HS_BUFFER_ID = 1 # Variable c_int '1'
TYPE_AVX_EFA_2_TWO_PBIS = 63 # Variable c_int '63'
API_HS_CTX_FALL_MAX = 18.5 # Variable c_double '1.85e+1'
API_BC_START_SETUP = 5 # Variable c_int '5'
_LARGEFILE_SOURCE = 1 # Variable c_int '1'
MIN_TRACK_LEN = 1 # Variable c_int '1'
MAX_TRACK_CHUNKSIZE = 256 # Variable c_int '256'
API_ERR_SECONDARY_COUPLING_NOT_INTERNAL = 4125 # Variable c_int '4125'
TY_BOARD_INFO_PROTOCOL = 24 # Variable c_int '24'
API_MEM_PART_OK = 0 # Variable c_int '0'
API_ERR_HS_XFER_MSGSIZE_NOT_IN_RANGE = 775 # Variable c_int '775'
API_CHN_DUAL_3910 = 2 # Variable c_int '2'
API_RT_SA_TYPE_XMT = 1 # Variable c_int '1'
TYPE_AVX_EFA_1_DS_TWO_PBIS = 61 # Variable c_int '61'
MAX_BC_FRAME_TIME = 1048.576 # Variable c_double '1.0485760000000000218278728425502777099609375e+3'
API_DONT_MODIFY_STATUS_BITS = 0 # Variable c_int '0'
PTRDIFF_MAX = 9223372036854775807 # Variable c_long '9223372036854775807l'
API_SREC_DOWNLOAD = 1 # Variable c_int '1'
API_FLASH_SECTOR_LCA = 6 # Variable c_int '6'
API_ERR_PARAM6_IS_NULL = 33 # Variable c_int '33'
API_ERR_DQUEUE_CONTROL_MODE_NOT_IN_RANGE = 121 # Variable c_int '121'
APIEF_BC_XFER_TYPE_X_RTBRMIXED = 23 # Variable c_int '23'
API_BM_MENSW_MEN_MASK = 1 # Variable c_int '1'
API_ERR_HS_DYTAG_WPOS_NOT_IN_RANGE = 770 # Variable c_int '770'
API_RT_REPORT_NO_ERR = 0 # Variable c_int '0'
API_HS_BC_ASSERT_INDEX_INT = 1 # Variable c_int '1'
API_BITE_ERR_TIMING = 13 # Variable c_int '13'
__USE_BSD = 1 # Variable c_int '1'
API_ERR_PARA_ID_NOT_IN_RANGE = 125 # Variable c_int '125'
API_PBI_STANDARD = 0 # Variable c_int '0'
API_BITE_ERR_TIMING_IMG = 20 # Variable c_int '20'
API_SCOPE_MODE_GREATER_THAN_SAMPLES = 4 # Variable c_int '4'
API_BC_MODIFY_OPC_SUB_OPERAND = 2 # Variable c_int '2'
TYPE_ACX_EFAXp_1_DS_TWO_PBIS = 51 # Variable c_int '51'
API_BITE_ERR_HS_INT_MON_DATA = 30 # Variable c_int '30'
API_BITE_INTERRUPT = 10 # Variable c_int '10'
API_RT_SA_XFER_INT = 2 # Variable c_int '2'
UINT_FAST16_MAX = 18446744073709551615 # Variable c_ulong '-1ul'
TYPE_AVX3910Xp = 44 # Variable c_int '44'
API_BITE_ERR_HS_BC_BROAD_ISOL_AA = 1 # Variable c_int '1'
API_BITE_ERR_HS_BC_BROAD_ISOL_AB = 3 # Variable c_int '3'
AI_PLATFORM_XMC_AYS = 177 # Variable c_int '177'
MAX_HS_MSGSIZE = 127 # Variable c_int '127'
XFER_DESC_FIELD_CHN = 1 # Variable c_int '1'
API_ERR_WRONG_STREAM = 133 # Variable c_int '133'
API_FLASH_SECTOR_BIU2 = 16 # Variable c_int '16'
MAX_DYTAG_MON_ID = 64 # Variable c_int '64'
API_FLASH_SECTOR_BIU1 = 14 # Variable c_int '14'
API_BM_MSG_GERR_MASK = 32768 # Variable c_int '32768'
API_ERR_BCDYTAG_WPOS_NOT_IN_RANGE = 74 # Variable c_int '74'
API_BITE_ERR_TIMING_RT_RESPONSE = 10 # Variable c_int '10'
UINT8_MAX = 255 # Variable c_int '255'
API_ERR_GAP_NOT_IN_RANGE = 69 # Variable c_int '69'
API_EF_RTMODE_EFA = 1 # Variable c_int '1'
SCOPE_WAIT_OVERFLOW = 4 # Variable c_int '4'
TY_BOARD_INFO_CHANGE_AMPL = 10 # Variable c_int '10'
TYPE_AXI3910Xp = 16 # Variable c_int '16'
API_BC_XFER_BCRT = 0 # Variable c_int '0'
API_TRG_PXI5 = 5 # Variable c_int '5'
MIN_BUF_NB_IN_FIFO = 2 # Variable c_int '2'
API_BM_MSG_NO_ERR = 0 # Variable c_int '0'
AI_PLATFORM_PCIX_3_3V = 19 # Variable c_int '19'
TY_BOARD_INFO_IR = 15 # Variable c_int '15'
API_BC_START_EXTERNAL_PULSE = 4 # Variable c_int '4'
API_BITE_ERR_INTERN_SELFTEST = 2 # Variable c_int '2'
API_BM_MSG_PERR_MASK = 16384 # Variable c_int '16384'
INTMAX_MIN = -9223372036854775808 # Variable c_long '-0x08000000000000000l'
AI_PLATFORM_CPCIX_3U = 65 # Variable c_int '65'
API_ERR_PARAM12_NOT_IN_RANGE = 47 # Variable c_int '47'
API_TRACK_SA_MID_MASK = 255 # Variable c_int '255'
__USE_POSIX = 1 # Variable c_int '1'
AI_PLATFORM_CPCIE_3U_AYS = 70 # Variable c_int '70'
INTMAX_MAX = 9223372036854775807 # Variable c_long '9223372036854775807l'
API_RESET_ERROR_BITS = 2 # Variable c_int '2'
API_DATA_QUEUE_ID_BM_REC_BIU4 = 3 # Variable c_int '3'
API_BM_ET_MANCH_MASK = 2 # Variable c_int '2'
INT_FAST64_MAX = 9223372036854775807 # Variable c_long '9223372036854775807l'
API_HS_GPIO_TYPE_VOX3910CTX = 1 # Variable c_int '1'
API_ERR_SUBPARAM10_NOT_IN_RANGE = 265 # Variable c_int '265'
API_BC_SWXM_TERM_MASK = 1 # Variable c_int '1'
API_CHN_SINGLE_EFEX_QUAD_1553 = 5 # Variable c_int '5'
API_TRG_RT_CHN1 = 12 # Variable c_int '12'
TYPE_APEX3910 = 92 # Variable c_int '92'
MAX_BM_STACK_ENTRY_OFFSET = 262144 # Variable c_int '262144'
API_SYSTAG_FCT_STATES = 6 # Variable c_int '6'
API_BM_ENTRY_NOT_UPDATED = 0 # Variable c_int '0'
AI_PLATFORM_PMC_XMC_BASED = 88 # Variable c_int '88'
API_BITE_ERR_HS_INT_MON_DATA_REP = 33 # Variable c_int '33'
TYPE_API3910 = 9 # Variable c_int '9'
__WORDSIZE_TIME64_COMPAT32 = 1 # Variable c_int '1'
API_DATA_QUEUE_TSW_OFFSET_SIZE = 16 # Variable c_int '16'
API_BC_START_CONTINUE_ON_BC_HALT = 8 # Variable c_int '8'
API_HS_CTX_OVRSHOOT_MIN = 4.0 # Variable c_double '4.0e+0'
__USE_GNU = 1 # Variable c_int '1'
TY_BOARD_INFO_IRIG = 12 # Variable c_int '12'
TYPE_ACX3910_2 = 35 # Variable c_int '35'
TYPE_AP104_1553_2 = 70 # Variable c_int '70'
TYPE_AP104_1553_1 = 69 # Variable c_int '69'
API_BC_XFER_BUS_PRIMARY = 0 # Variable c_int '0'
TYPE_AP104_1553_4 = 71 # Variable c_int '71'
TYPE_ASC1553_1 = 89 # Variable c_int '89'
MAX_MULTI_TRACK_NB = 65536 # Variable c_int '65536'
AI_PLATFORM_PCIE_4L_PCIX_3_3V_BASED = 24 # Variable c_int '24'
__GLIBC__ = 2 # Variable c_int '2'
MIN_HS_XFER_ID = 1 # Variable c_int '1'
API_HS_BC_ECW_ERR_REPORT_MASK = 15 # Variable c_int '15'
INT8_MIN = -128 # Variable c_int '-0x00000000000000080'
API_BITE_ERR_HS_INT_WALK_0 = 21 # Variable c_int '21'
API_RT_RSP_BOTH_BUSSES = 0 # Variable c_int '0'
API_ERR_TCBTRI_NOT_IN_RANGE = 84 # Variable c_int '84'
API_SPECIAL_VER_MASK = 4294901760 # Variable c_uint '4294901760u'
API_ERR_PARAM12_IS_NULL = 39 # Variable c_int '39'
MAX_TCB_NEXT = 255 # Variable c_int '255'
API_HS_CTX_REG_MODE = 0 # Variable c_int '0'
API_CAL_TRANS_1M = 0 # Variable c_int '0'
API_ERR_RCV_RT_NOT_IN_RANGE = 55 # Variable c_int '55'
API_SCOPE_SIZE_DUAL_CH_REC = 32768 # Variable c_int '32768'
API_BITE_ERR_HS_BC_BROAD_ELECT_AA = 5 # Variable c_int '5'
API_ERR_BIU_OUT_OF_RANGE = 4100 # Variable c_int '4100'
API_ERR_TYPE_COMMAND_SYNC = 1 # Variable c_int '1'
API_QUEUE_SIZE_32 = 5 # Variable c_int '5'
API_HS_GPIO_DEVTYPE_RESERVED = 0 # Variable c_int '0'
API_FLASH_SECTOR_TARGET_SW = 18 # Variable c_int '18'
API_LLA_TCBI_MASK = 255 # Variable c_int '255'
API_REP_RLT_ALL = 1 # Variable c_int '1'
API_ERR_TCBTT_NOT_IN_RANGE = 82 # Variable c_int '82'
API_BM_ENTRY_BUS_WORD = 0 # Variable c_int '0'
API_HS_ERR_TYPE_START_DEL_PATTERN = 2 # Variable c_int '2'
MAX_BUFFER_ID = 65535 # Variable c_int '65535'
API_ERR_SUBPARAM2_IS_NULL = 385 # Variable c_int '385'
API_SEND_SRVW_ON_SA31 = 1 # Variable c_int '1'
API_HS_BC_ERRSPEC_WPOS_POS = 16 # Variable c_int '16'
API_RESET_ENABLE_1760 = 128 # Variable c_int '128'
API_BM_READ_STP = 0 # Variable c_int '0'
API_BM_TRG_SPEC_RXB_MASK = 16 # Variable c_int '16'
API_BSP_WRONG_LCA2_SW = 7 # Variable c_int '7'
API_ERR_PARA_RTXFER_NOT_IN_RANGE = 132 # Variable c_int '132'
API_LLA_RBI_MASK = 255 # Variable c_int '255'
API_LCA_BIU2_VER_MASK = 4294901760 # Variable c_uint '4294901760u'
API_BM_MSG_ERR_HCNT = 13 # Variable c_int '13'
INT_FAST8_MAX = 127 # Variable c_int '127'
API_SCOPE_COUPLING_SECONDARY = 0 # Variable c_int '0'
TYPE_AVX_EFAXp_2_TWO_PBIS = 64 # Variable c_int '64'
API_BITE_TRANSFER = 9 # Variable c_int '9'
API_ERR_HS_XFER_HEADER_NOT_IN_RANGE = 772 # Variable c_int '772'
INTPTR_MAX = 9223372036854775807 # Variable c_long '9223372036854775807l'
API_REP_ABS_TIME = 1 # Variable c_int '1'
API_ERR_NO_CTX_FOUND = 31 # Variable c_int '31'
API_RT_MODE_HALT = 1 # Variable c_int '1'
API_CAL_XMT_HIGHRES_RANGE = 3 # Variable c_int '3'
API_EF_ERR_TYPE_WORDCOUNT = 12 # Variable c_int '12'
WINT_MAX = 4294967295 # Variable c_uint '4294967295u'
API_EF_SWITCH_ERR = 0 # Variable c_int '0'
API_ERR_QUEUE_EMPTY = 107 # Variable c_int '107'
API_RETRY_1ALT = 1 # Variable c_int '1'
API_BM_MSG_ERR_LCNT = 14 # Variable c_int '14'
API_ERR_INVALID_DISCRETE = 4133 # Variable c_int '4133'
API_OFF = 0 # Variable c_int '0'
API_ERR_FOFE_OT_SHUTDOWN = 4135 # Variable c_int '4135'
TY_BOARD_INFO_IS_DBTE = 21 # Variable c_int '21'
API_OK = 0 # Variable c_int '0'
API_ON = 1 # Variable c_int '1'
API_BC_HLT_NO_HALT = 0 # Variable c_int '0'
API_BSP_NOT_COMPATIBLE = 255 # Variable c_int '255'
API_HS_BC_ERRSPEC_BCBITS_MASK = 255 # Variable c_int '255'
API_RT_ENABLE_DUAL_REDUNDANT = 3 # Variable c_int '3'
API_ERR_TYPE_MSG_LENGTH_HI_IGNORE = 18 # Variable c_int '18'
API_ERR_SUBPARAM6_IS_NULL = 389 # Variable c_int '389'
API_BM_STROBE_ON_HFI = 1 # Variable c_int '1'
API_SYSTAG_XFERID_MASK = 65535 # Variable c_int '65535'
API_FLASH_SECTOR_APX_TARGET_SW = 6 # Variable c_int '6'
API_BITE_ERR_HS_INT_SIM_RTBC = 29 # Variable c_int '29'
API_BM_TRG_SPEC_WPOS_MASK = 63 # Variable c_int '63'
API_ERR_PARA_WPOS_NOT_IN_RANGE = 130 # Variable c_int '130'
MAX_HS_BUFFER_ID = 65535 # Variable c_int '65535'
API_SCOPE_OPR_CHANNEL_DISABLED = 0 # Variable c_int '0'
API_MODE_DDL = 9 # Variable c_int '9'
DBG_MUTEX = 128 # Variable c_int '128'
INT64_MIN = -9223372036854775808 # Variable c_long '-0x08000000000000000l'
API_ERR_CAPMODE_NOT_IN_RANGE = 80 # Variable c_int '80'
API_ERR_FRAME_FID_NOT_IN_RANGE = 79 # Variable c_int '79'
API_RT_TYPE_RECEIVE_SA = 0 # Variable c_int '0'
API_ERR_DMA_INVALID_MEMORY = 4103 # Variable c_int '4103'
API_RESET_WITHOUT_SIMBUF = 2 # Variable c_int '2'
UINT_LEAST32_MAX = 4294967295 # Variable c_uint '4294967295u'
API_ERR_PARAM5_NOT_IN_RANGE = 29 # Variable c_int '29'
MAX_HS_STARTDEL = 1023 # Variable c_int '1023'
UINT32_MAX = 4294967295 # Variable c_uint '4294967295u'
API_HS_BM_ERR_TRG_POS = 6 # Variable c_int '6'
MAX_HS_MODECODE = 31 # Variable c_int '31'
TYPE_AVX_EFAXp_2_DS_TWO_PBIS = 66 # Variable c_int '66'
API_ERR_SYSTAG_MIN_NOT_IN_RANGE = 102 # Variable c_int '102'
__USE_XOPEN2K = 1 # Variable c_int '1'
API_RESET_SRVREQ_CNT = 4 # Variable c_int '4'
API_BC_ACYC_SEND_IMMEDIATELY = 0 # Variable c_int '0'
API_RT_SA_USAGE_INIT = 0 # Variable c_int '0'
API_HS_BM_AW_TRG_POS = 0 # Variable c_int '0'
AI_PLATFORM_ANET_AYS = 193 # Variable c_int '193'
MIN_SYSTAG_ID = 1 # Variable c_int '1'
API_HS_XMT_MID_MASK = 255 # Variable c_int '255'
API_BITE_ERR_DA_CONV_BUSB = 12 # Variable c_int '12'
API_BITE_ERR_DA_CONV_BUSA = 11 # Variable c_int '11'
API_BC_ERRSPEC_BPOS_MASK = 65280 # Variable c_int '65280'
MIN_FIFO_ID = 1 # Variable c_int '1'
API_HS_CTX_STATUS_FAIL = 64 # Variable c_int '64'
API_RESET_ERR_STAT_BITS = 3 # Variable c_int '3'
DBG_PARAMCHK = 256 # Variable c_int '256'
MAX_API_BC_MFRAME_ID = 64 # Variable c_int '64'
AI_PLATFORM_PMC_32 = 80 # Variable c_int '80'
API_ERR_TYPE_MANCHESTER_HIGH = 4 # Variable c_int '4'
API_ERR_WRONG_ACK_SIZE = 4099 # Variable c_int '4099'
DBG_READREC = 32 # Variable c_int '32'
API_LLA_PTRA_MASK = 4194304 # Variable c_int '4194304'
API_FIRMWARE_BIU2_VER_MASK = 4294901760 # Variable c_uint '4294901760u'
_STDINT_H = 1 # Variable c_int '1'
API_SCOPE_MODE_GREATER_THAN = 0 # Variable c_int '0'
API_HS_GPIO_CMD_SYS1_END = 7 # Variable c_int '7'
XFER_DESC_FIELD_CW1 = 2 # Variable c_int '2'
XFER_DESC_FIELD_CW2 = 3 # Variable c_int '3'
TYPE_APM1553_1 = 21 # Variable c_int '21'
API_HS_GPIO_CMD_SDREG = 64 # Variable c_int '64'
API_MODE_DSUB_CONNECT = 2 # Variable c_int '2'
MAX_ERR_BCBITS = 3 # Variable c_int '3'
MIN_DATA_WORDS = 1 # Variable c_int '1'
API_BSP_WRONG_LCA1_SW = 6 # Variable c_int '6'
API_CHN_SINGLE_3910_QUAD_1553 = 5 # Variable c_int '5'
API_BSP_WRONG_BIU3_SW = 9 # Variable c_int '9'
API_HS_RCV_MID_POS = 8 # Variable c_int '8'
API_HS_CTX_PULSE_MAX = 12.5 # Variable c_double '1.25e+1'
API_BITE_ERR_RTRT_ISOL_B_BM = 9 # Variable c_int '9'
API_IRIG_ON_BOARD = 0 # Variable c_int '0'
API_ERR_POS1_NOT_IN_RANGE = 88 # Variable c_int '88'
MAX_BM_ACT_ENTRY = 4095 # Variable c_int '4095'
API_RT_RSP_PRI_BUS = 1 # Variable c_int '1'
API_ERR_HS_HSERR_TYPE_NOT_IN_RANGE = 794 # Variable c_int '794'
API_BM_TIMETAG_MSEC_MASK = 1048575 # Variable c_int '1048575'
API_CHN_SINGLE_EFEX_SINGLE_1553 = 2 # Variable c_int '2'
API_HS_LSIR_POS = 0 # Variable c_int '0'
API_BM_ENTRY_FOUND = 1 # Variable c_int '1'
UINT_LEAST16_MAX = 65535 # Variable c_int '65535'
API_BC_FWI_EFEX_XFER = 17 # Variable c_int '17'
API_ERR_TIMEOUT = 405 # Variable c_int '405'
API_INT_HS = 2 # Variable c_int '2'
API_SREC_ERR_NO_STRING = 1 # Variable c_int '1'
INT_FAST32_MAX = 9223372036854775807 # Variable c_long '9223372036854775807l'
API_SREC_INIT = 0 # Variable c_int '0'
API_BC_SWXM_SREQ_MASK = 256 # Variable c_int '256'
API_BC_MODIFY_WRTYP_32BIT = 2 # Variable c_int '2'
AI_PLATFORM_PMC_32_QUAD = 81 # Variable c_int '81'
MAX_CONT_TRACK_NB = 32 # Variable c_int '32'
API_RT_MC_TYPE_XMT = 3 # Variable c_int '3'
API_HS_GPIO_CMD_RESET = 1 # Variable c_int '1'
API_ERR_PARAM7_IS_NULL = 34 # Variable c_int '34'
API_HS_BM_BCTYPE_RTRT = 3 # Variable c_int '3'
API_ERR_BCDYTAG_TAGFCT_NOT_IN_RANGE = 70 # Variable c_int '70'
MAX_TRACK_PREALLOC_STATES = 256 # Variable c_int '256'
API_ERR_PARAM2_NOT_IN_RANGE = 26 # Variable c_int '26'
API_PBI_ONBOARD_FOFE = 1 # Variable c_int '1'
API_RT_REPORT_ERR_FRAME_COD = 1 # Variable c_int '1'
API_ERR_HS_XFER_RT_NOT_IN_RANGE = 776 # Variable c_int '776'
TYPE_AMC1553_T = 20 # Variable c_int '20'
API_SRV_OS_VER_WINNT = 3 # Variable c_int '3'
API_BITE_ERR_GLOBAL_RAM_BIU = 3 # Variable c_int '3'
API_BM_ENTRY_BUSWORD_MASK = 65535 # Variable c_int '65535'
TYPE_AMC1553_1 = 17 # Variable c_int '17'
API_HS_GPIO_CMD_SDEV = 8 # Variable c_int '8'
TYPE_AMC1553_2 = 18 # Variable c_int '18'
TYPE_AMC1553_4 = 19 # Variable c_int '19'
API_DYTAG_FCT_SYNC_COUNTER = 6 # Variable c_int '6'
API_DYTAG_FCT_POS_TRIANGLE = 3 # Variable c_int '3'
API_ERR_ADDRESS_OUT_OF_RANGE = 4112 # Variable c_int '4112'
API_EF_SWITCH_TO_EFA_TEMPORARY = 3 # Variable c_int '3'
API_ERR_WRONG_DEVICE = 17 # Variable c_int '17'
API_HS_CTX_REG_BITE = 1 # Variable c_int '1'
MIN_API_BC_MFRAME_ID = 1 # Variable c_int '1'
API_ERR_PARAM8_NOT_IN_RANGE = 43 # Variable c_int '43'
API_BC_ERRSPEC_BCBITS_MASK = 255 # Variable c_int '255'
API_BITE_ERR_HS_BCRT_ISOL_AB = 11 # Variable c_int '11'
APIEF_BC_XFER_TYPE_EERTRT = 26 # Variable c_int '26'
MAX_DATA_BITPOS = 15 # Variable c_int '15'
API_BM_MSG_ERR_LBIT = 4 # Variable c_int '4'
API_ERR_SUBPARAM7_NOT_IN_RANGE = 262 # Variable c_int '262'
API_ERR_HS_XFER_FIRST_GAP_NOT_IN_RANGE = 780 # Variable c_int '780'
TY_BOARD_INFO_APPLICATION_TYPE = 25 # Variable c_int '25'
API_ERR_BCDYTAG_MAX_NOT_IN_RANGE = 72 # Variable c_int '72'
API_BIG_ENDIAN_MODE = 1 # Variable c_int '1'
API_HS_BC_MSG_TAG_FCHK_MASK = 8192 # Variable c_int '8192'
_SVID_SOURCE = 1 # Variable c_int '1'
API_BC_ERRSPEC_WPOS_MASK = 16711680 # Variable c_int '16711680'
MAX_BUF_NB_IN_FIFO = 128 # Variable c_int '128'
API_SCOPE_MODE_BIU_BM = 7 # Variable c_int '7'
API_SCOPE_MODE_BIU_BC = 8 # Variable c_int '8'
API_HS_BM_DW_TRG_MASK = 48 # Variable c_int '48'
API_EF_TRIG_EFEX_CMD = 0 # Variable c_int '0'
API_ERR_INVALID_ID = 4142 # Variable c_int '4142'
API_DATA_NOT_VALID = 0 # Variable c_int '0'
API_BC_FWI_CALL = 32 # Variable c_int '32'
TYPE_AXE1553_1 = 97 # Variable c_int '97'
TYPE_AXE1553_2 = 98 # Variable c_int '98'
TYPE_AXE1553_4 = 99 # Variable c_int '99'
API_BITE_ERR_TIMING_MFRM_50 = 1 # Variable c_int '1'
API_SCOPE_OPR_CHANNEL_A100 = 4 # Variable c_int '4'
API_BM_MSG_ERR_GAP = 7 # Variable c_int '7'
API_BITE_ERR_HS_INT_PAT_55 = 17 # Variable c_int '17'
API_TRACK_TYPE_MUX_TRACK = 3 # Variable c_int '3'
TYPE_ACE3910Xp = 96 # Variable c_int '96'
TYPE_ACX_EFA_2_TWO_PBIS = 52 # Variable c_int '52'
API_SQM_ONE_ENTRY_ONLY = 1 # Variable c_int '1'
DBG_INIT = 2 # Variable c_int '2'
API_MODULE_29 = 28 # Variable c_int '28'
API_MODULE_28 = 27 # Variable c_int '27'
API_RCV_BUS_PRIMARY = 1 # Variable c_int '1'
MIN_INSTR_NR = 1 # Variable c_int '1'
API_MODULE_21 = 20 # Variable c_int '20'
API_MODULE_20 = 19 # Variable c_int '19'
API_MODULE_23 = 22 # Variable c_int '22'
API_MODULE_22 = 21 # Variable c_int '21'
API_MODULE_25 = 24 # Variable c_int '24'
API_MODULE_24 = 23 # Variable c_int '23'
API_MODULE_27 = 26 # Variable c_int '26'
API_MODULE_26 = 25 # Variable c_int '25'
API_BSP_WRONG_BIU4_SW = 10 # Variable c_int '10'
DBG_WRITEREP = 64 # Variable c_int '64'
API_HS_HSIR_POS = 0 # Variable c_int '0'
API_ERR_HS_HSXMT_NOPRE_NOT_IN_RANGE = 792 # Variable c_int '792'
API_MILBUS_PROT_A = 0 # Variable c_int '0'
API_MILBUS_PROT_B = 1 # Variable c_int '1'
API_HS_BM_TRG_OR = 1 # Variable c_int '1'
API_RT_STATUS_BUSY = 2 # Variable c_int '2'
MAX_API_BC_MFRAME = 64 # Variable c_int '64'
TYPE_AXI1553_1 = 7 # Variable c_int '7'
API_BM_ENTRY_SW_PRIMARY = 11 # Variable c_int '11'
API_ERR_PARAM9_IS_NULL = 36 # Variable c_int '36'
API_ERR_PARAM1_IS_NULL = 19 # Variable c_int '19'
MAX_HS_BH_BUF_SIZE = 127 # Variable c_int '127'
API_HS_BM_TRG_NOT_OCCURED = 0 # Variable c_int '0'
API_CPL_DIR = 2 # Variable c_int '2'
API_ERR_INVALID_KEY = 4131 # Variable c_int '4131'
API_HS_CTX_REG_VERSION = 4 # Variable c_int '4'
API_SREC_ERR_WRONG_TYPE = 2 # Variable c_int '2'
API_INVALID_SLOT_NUMBER = 2 # Variable c_int '2'
MAX_API_BC_FW_XFER_DESC_SIZE = 8 # Variable c_int '8'
API_HS_XMT_RT_MASK = 255 # Variable c_int '255'
API_ERR_DQUEUE_REM_HANDLE_NOT_IN_RANGE = 119 # Variable c_int '119'
API_ERR_DQUEUE_ASP_SIZE_NOT_IN_RANGE = 120 # Variable c_int '120'
API_ERR_PARA_BUF_NOT_IN_RANGE = 127 # Variable c_int '127'
API_ERR_DMA_ALREADY_RUNNING = 4101 # Variable c_int '4101'
API_BM_ET_NRESP_MASK = 1 # Variable c_int '1'
API_BM_TRG_NOT_OCCURED = 0 # Variable c_int '0'
TYPE_ACX3910Xp_2 = 36 # Variable c_int '36'
API_SYSTAG_FCT_POS_RAMP = 1 # Variable c_int '1'
API_HS_WCM_ACTION_WORD = 0 # Variable c_int '0'
API_BITE_ERR_BC_BROAD_ELECT_B_BM = 4 # Variable c_int '4'
API_BC_SRVW_ENA = 1 # Variable c_int '1'
API_HS_GAP_MASK = 65535 # Variable c_int '65535'
API_BITE_ERR_HS_TIMING_CORR = 2 # Variable c_int '2'
API_BITE_ERR_TRANSFER = 9 # Variable c_int '9'
API_BM_FLT_MODE_INDEPENDENT = 0 # Variable c_int '0'
API_ERR_TYPE_PARITY = 3 # Variable c_int '3'
API_ERR_PARAM3_NOT_IN_RANGE = 27 # Variable c_int '27'
MAX_WCNT = 31 # Variable c_int '31'
API_ERR_INVALID_CON = 4136 # Variable c_int '4136'
AI_PLATFORM_VMEX_A = 35 # Variable c_int '35'
TYPE_API1553_2 = 2 # Variable c_int '2'
API_SERVER_NOT_REGISTERED = 1 # Variable c_int '1'
API_HS_CTX_REG_PULSE = 16 # Variable c_int '16'
API_HS_CTX_STATUS_FAIL_POS = 6 # Variable c_int '6'
INT_FAST16_MIN = -9223372036854775808 # Variable c_long '-0x08000000000000000l'
MAX_HS_MID = 255 # Variable c_int '255'
API_BM_CAPMODE_ONLY = 1 # Variable c_int '1'
API_ERR_DQUEUE_ASP_SIZE_TOO_BIG = 123 # Variable c_int '123'
INT_LEAST16_MAX = 32767 # Variable c_int '32767'
API_BITE_ERR_HS_RTRT_ISOL_AA = 30 # Variable c_int '30'
APIEF_BC_XFER_TYPE_X_RTBR = 21 # Variable c_int '21'
API_ERR_WRONG_CMD_SIZE = 4098 # Variable c_int '4098'
_POSIX_SOURCE = 1 # Variable c_int '1'
API_ERR_PARAM11_IS_NULL = 38 # Variable c_int '38'
API_HS_BUF_ALLOC_FAILED = 1 # Variable c_int '1'
MAX_API_INT_TYPE = 6 # Variable c_int '6'
API_BRW_RBUS_MASK = 16 # Variable c_int '16'
API_BM_SIGN_POS = 0 # Variable c_int '0'
API_CPL_NET = 3 # Variable c_int '3'
API_DATA_QUEUE_STATUS_CAPMODE = 8388608 # Variable c_int '8388608'
API_BC_REPORT_ERR_SW1_NOT_RCV = 2 # Variable c_int '2'
MAX_TRACK_LEN = 32 # Variable c_int '32'
API_PXI_SET_TRG = 0 # Variable c_int '0'
API_HS_CTX_STATUS_ICMD_POS = 5 # Variable c_int '5'
API_PROTOCOL_3910 = 2 # Variable c_int '2'
API_HS_CTX_REG_FALL = 18 # Variable c_int '18'
API_SYSTAG_SA_MID_POS = 0 # Variable c_int '0'
TYPE_APE1553_1 = 82 # Variable c_int '82'
API_BM_MSG_ERR_MANCH = 2 # Variable c_int '2'
API_BC_SWXM_BUSY_MASK = 8 # Variable c_int '8'
API_BC_TYPE_RTBC = 1 # Variable c_int '1'
API_PBI_PROGRAMMABLE = 1 # Variable c_int '1'
API_BSM_TX_GO_ON_NEXT = 1 # Variable c_int '1'
API_BITE_ERR_HS_BC_BROAD_ISOL_BA = 2 # Variable c_int '2'
API_BITE_ERR_HS_BC_BROAD_ISOL_BB = 4 # Variable c_int '4'
MIN_ERR_BPOS = 4 # Variable c_int '4'
API_BUF_EMPTY = 2 # Variable c_int '2'
APIEF_BC_XFER_TYPE_E_RTBRMIXED = 28 # Variable c_int '28'
API_HS_GPIO_CMD_ALL_ON = 3 # Variable c_int '3'
API_DATA_QUEUE_STATUS_LOC_BUF_ERR = 4 # Variable c_int '4'
API_ERR_INVALID_BUS = 4141 # Variable c_int '4141'
API_ERR_ERRSPEC_WPOS_NOT_IN_RANGE = 65 # Variable c_int '65'
API_ERR_INVALID_MODE = 4111 # Variable c_int '4111'
API_HS_MAX_GPIO_DEVICES = 8 # Variable c_int '8'
API_LLA_PSA_MASK = 4194304 # Variable c_int '4194304'
API_ERR_RSP_NOT_IN_RANGE = 62 # Variable c_int '62'
API_MODE_RESTART_TARGET_SW = 10 # Variable c_int '10'
API_SCOPE_RATE_EVERY = 0 # Variable c_int '0'
API_ERR_DMA_DEST_INVALID = 4105 # Variable c_int '4105'
API_CHN_QUAD_1553 = 4 # Variable c_int '4'
AI_PLATFORM_CPCIX_6U = 67 # Variable c_int '67'
TY_BOARD_INFO_MILSCOPE_TYPE = 20 # Variable c_int '20'
API_ERR_BIP2_START_FAILED = 4119 # Variable c_int '4119'
DBG_DISABLED = 0 # Variable c_int '0'
API_BC_REPORT_ERR_FRAME_COD = 1 # Variable c_int '1'
__USE_FORTIFY_LEVEL = 2 # Variable c_int '2'
APIEF_BC_XFER_TYPE_MCRT = 29 # Variable c_int '29'
MAX_CLR = 7 # Variable c_int '7'
AI_PLATFORM_VXI_D = 52 # Variable c_int '52'
AI_PLATFORM_VXI_B = 50 # Variable c_int '50'
API_BM_SEARCH_ENTRY_TYPE_MASK = 3 # Variable c_int '3'
INT32_MIN = -2147483648 # Variable c_int '-0x00000000080000000'
API_BM_SEARCH_WORDA_MASK = 256 # Variable c_int '256'
API_BC_ERRSPEC_BCBITS_POS = 0 # Variable c_int '0'
AI_PLATFORM_PMC_AYS = 83 # Variable c_int '83'
API_SREC_ERR_CHKS = 3 # Variable c_int '3'
API_ERR_DQUEUE_READ_NOT_BUFFERED = 122 # Variable c_int '122'
API_MODULE_32 = 31 # Variable c_int '31'
API_MODULE_30 = 29 # Variable c_int '29'
API_MODULE_31 = 30 # Variable c_int '30'
API_BITE_INTERN_SELFTEST = 2 # Variable c_int '2'
API_ERR_HS_LSERR_TYPE_NOT_IN_RANGE = 785 # Variable c_int '785'
TYPE_ACX_EFAXp_2_TWO_PBIS = 53 # Variable c_int '53'
API_HS_HSCHN_POS = 8 # Variable c_int '8'
API_REP_RLT_LOW_TT = 0 # Variable c_int '0'
MAX_RT_MODECODE = 31 # Variable c_int '31'
APIEF_BC_XFER_TYPE_E_RTBR = 27 # Variable c_int '27'
API_BITE_ERR_HS_INT_ADDR = 16 # Variable c_int '16'
API_ERR_RT_NOT_AVAILABLE = 4149 # Variable c_int '4149'
DBG_INFO = 268435456 # Variable c_int '268435456'
API_ERR_BIP1_BOOT_FAILED = 4116 # Variable c_int '4116'
DBG_SERVER = 1024 # Variable c_int '1024'
API_TRG_PXI4 = 4 # Variable c_int '4'
API_BITE_SHARED_RAM = 6 # Variable c_int '6'
API_TRG_PXI6 = 6 # Variable c_int '6'
API_TRG_PXI7 = 7 # Variable c_int '7'
API_TRG_PXI0 = 0 # Variable c_int '0'
API_TRG_PXI1 = 1 # Variable c_int '1'
API_TRG_PXI2 = 2 # Variable c_int '2'
API_TRG_PXI3 = 3 # Variable c_int '3'
API_BC_INSTR_TRANSFER = 1 # Variable c_int '1'
API_QUEUE_SIZE_128 = 7 # Variable c_int '7'
API_SYSTAG_FCT_POS_TRIANGLE = 3 # Variable c_int '3'
API_BITE_ERR_INT_PAT_55 = 17 # Variable c_int '17'
API_HS_HSCHN_MASK = 65280 # Variable c_int '65280'
API_RT_SA_DIS = 0 # Variable c_int '0'
API_ERR_PARAMETER_OUT_OF_RANGE = 4114 # Variable c_int '4114'
AI_PLATFORM_PMC_32_ASP = 82 # Variable c_int '82'
API_BITE_ERR_HS_INT_MON_ERR_CNT_REP = 32 # Variable c_int '32'
API_MODE_ALL_RT = 0 # Variable c_int '0'
API_ERR_HS_XFER_XFERHALT_NOT_IN_RANGE = 774 # Variable c_int '774'
API_HS_BM_DW_TRG_POS = 4 # Variable c_int '4'
API_BC_ERRSPEC_WPOS_POS = 16 # Variable c_int '16'
API_CAL_CPL_DIRECT = 2 # Variable c_int '2'
API_DYTAG_FCT_XMT_WORD = 5 # Variable c_int '5'
API_SYSTAG_RTADDR_MASK = 65280 # Variable c_int '65280'
TY_BOARD_INFO_CAN_HIGH_RES_ZERO_CROSSING = 18 # Variable c_int '18'
TY_BOARD_INFO_CHANGE_AMPL_HIGH_RES = 26 # Variable c_int '26'
API_BITE_ERR_PAGING = 1 # Variable c_int '1'
API_HS_BM_BCTYPE_RTBC = 2 # Variable c_int '2'
API_CHN_SINGLE_1553 = 1 # Variable c_int '1'
API_BM_WRITE_STC = 1 # Variable c_int '1'
API_LLC_TR = 1024 # Variable c_int '1024'
API_BM_WRITE_STM = 2 # Variable c_int '2'
API_DATA_QUEUE_STATUS_REM_OVERFLOW = 2 # Variable c_int '2'
API_TRG_RT_CHN2 = 13 # Variable c_int '13'
API_BM_ET_ISYNC_MASK = 32 # Variable c_int '32'
API_ERR_TYPE_WCLO_EXT = 17 # Variable c_int '17'
API_ERR_ERRTYPE_NOT_IN_RANGE = 64 # Variable c_int '64'
API_QUEUE_SIZE_1 = 0 # Variable c_int '0'
API_QUEUE_SIZE_2 = 1 # Variable c_int '1'
API_QUEUE_SIZE_4 = 2 # Variable c_int '2'
API_QUEUE_SIZE_8 = 3 # Variable c_int '3'
MIN_HS_CONT_TRACK_NB = 1 # Variable c_int '1'
API_ERR_HS_HSCHN_NOT_IN_RANGE = 790 # Variable c_int '790'
API_SYSTAG_STEP_CHECKSUM_1760 = 2 # Variable c_int '2'
API_ERR_HS_DYTAG_WMODE_NOT_IN_RANGE = 768 # Variable c_int '768'
MIN_BUFFER_ID = 0 # Variable c_int '0'
UINT_FAST8_MAX = 255 # Variable c_int '255'
API_HS_BM_TRG_EVENT_OCCURED = 1 # Variable c_int '1'
MAX_HS_ERR_BCBITS = 15 # Variable c_int '15'
API_BITE_ERR_HS_INT_SIM_ERR_CNT = 25 # Variable c_int '25'
API_BC_FWI_RET = 33 # Variable c_int '33'
API_BITE_ERR_ADDRESSING = 3 # Variable c_int '3'
MAX_HS_ERR_WPOS = 4099 # Variable c_int '4099'
API_BITE_ERR_DATA_PATTERN = 1 # Variable c_int '1'
__GLIBC_MINOR__ = 19 # Variable c_int '19'
API_ERR_BCDYTAG_MIN_NOT_IN_RANGE = 71 # Variable c_int '71'
API_BM_ET_TX_MASK = 128 # Variable c_int '128'
API_DYTAG_STD_MODE = 0 # Variable c_int '0'
API_BC_FWI_CMFT = 44 # Variable c_int '44'
API_BITE_ERR_BC_BROAD_ELECT_A = 1 # Variable c_int '1'
API_ERR_HS_XFER_FIRST_GAPMODE_NOT_IN_RANGE = 779 # Variable c_int '779'
API_ERR_BCDYTAG_STEP_NOT_IN_RANGE = 73 # Variable c_int '73'
API_ERR_MALLOC_FAILED = 395 # Variable c_int '395'
API_ERR_HS_XFER_SECOND_GAP_NOT_IN_RANGE = 782 # Variable c_int '782'
API_BC_FWI_XFER = 16 # Variable c_int '16'
API_HS_ERR_TYPE_BIT_CNT_HIGH = 7 # Variable c_int '7'
MAX_SCOPE_SAMPLING_RATE = 255 # Variable c_int '255'
API_BC_MODIFY_COMPC__LE = 3 # Variable c_int '3'
MAX_HS_MBUF = 32 # Variable c_int '32'
API_BM_MODE_HFI_INT = 1 # Variable c_int '1'
API_BC_MODIFY_COMPC__LT = 1 # Variable c_int '1'
MAX_DATASET_BUF_ID = 4095 # Variable c_int '4095'
API_HS_RT_ENABLE_INT_XFER = 1 # Variable c_int '1'
API_HS_GAPMODE_POS = 16 # Variable c_int '16'
API_RT_SA_ENA = 1 # Variable c_int '1'
TYPE_ACI3910 = 11 # Variable c_int '11'
API_BM_MSW_SYNC_MASK = 64 # Variable c_int '64'
API_BITE_ERR_BOARD_ENABLE = 1 # Variable c_int '1'
MIN_SKIP_CNT = 1 # Variable c_int '1'
API_RT_SWM_AND = 1 # Variable c_int '1'
API_HS_BM_HW_TRG_MASK = 12 # Variable c_int '12'
UINT_LEAST64_MAX = 18446744073709551615 # Variable c_ulong '-1ul'
UINT_FAST64_MAX = 18446744073709551615 # Variable c_ulong '-1ul'
API_BITE_ERR_INT_PAT_00 = 20 # Variable c_int '20'
API_ERR_REPLAY_NOT_AVAILABLE = 4151 # Variable c_int '4151'
API_DATA_QUEUE_TSW_OFFSET_START = 12 # Variable c_int '12'
API_BITE_ALL = 0 # Variable c_int '0'
AI_PLATFORM_MINI_PCIE_CARD = 118 # Variable c_int '118'
__USE_LARGEFILE = 1 # Variable c_int '1'
SCOPE_BUFFER_FLAG_TRIGGER = 4 # Variable c_int '4'
_FEATURES_H = 1 # Variable c_int '1'
API_BC_START_INSTR_TABLE = 7 # Variable c_int '7'
TY_BOARD_INFO_MAX = 27 # Variable c_int '27'
API_UTIL_CMD_READ_SW_VERSIONS = 2 # Variable c_int '2'
API_ERR_SERVER_INVALID_VERSION = 513 # Variable c_int '513'
TY_BOARD_INFO_BOARD_CONFIG = 4 # Variable c_int '4'
API_HS_XMT_MID_POS = 0 # Variable c_int '0'
API_BITE_ERR_HS_INT_SIM_BCRT = 28 # Variable c_int '28'
API_BITE_ERR_HS_INT_MON_ERR_CNT = 27 # Variable c_int '27'
TY_BOARD_INFO_OFFS_GLOBAL = 9 # Variable c_int '9'
API_BC_RSP_AUTOMATIC = 0 # Variable c_int '0'
API_HS_HSXMT_STARTDEL_MASK = 65535 # Variable c_int '65535'
API_BUF_NOT_USED = 0 # Variable c_int '0'
API_ERR_ERRSPEC_CONTIG_NOT_IN_RANGE = 68 # Variable c_int '68'
API_BITE_ERR_MODE_ISOL_A_BM = 10 # Variable c_int '10'
API_BM_TRG_SPEC_RXA_MASK = 32 # Variable c_int '32'
TY_BOARD_INFO_HAS_EXTERNAL_IRIG = 22 # Variable c_int '22'
DBG_ALL = 4294967295 # Variable c_uint '4294967295u'
TG_EXT_SET_REPLAY_ADDR = 5 # Variable c_int '5'
API_ERR_TCBINV_NOT_IN_RANGE = 85 # Variable c_int '85'
API_SREC_CHKS_OK = 0 # Variable c_int '0'
API_BC_FWI_WTRG = 37 # Variable c_int '37'
API_SCOPE_COUPLING_STUB_3V = 6 # Variable c_int '6'
API_MODE_RES_EXEC_SYS = 14 # Variable c_int '14'
API_MODE_SHOW_PARAM_TABLE = 15 # Variable c_int '15'
API_ERR_RCV_SA_NOT_IN_RANGE = 57 # Variable c_int '57'
API_RT_SWM_OR = 0 # Variable c_int '0'
API_ERR_PARAM10_NOT_IN_RANGE = 45 # Variable c_int '45'
API_LLC_MODECODE = 31 # Variable c_int '31'
API_MEM_PART_ERR = 1 # Variable c_int '1'
API_ERR_SERVER = 512 # Variable c_int '512'
API_BM_STOP_EVENT_OCCURED = 2 # Variable c_int '2'
API_BM_ET_IWGAP_MASK = 64 # Variable c_int '64'
AI_PLATFORM_PCIE_CARD = 117 # Variable c_int '117'
API_REP_HALTED = 0 # Variable c_int '0'
TYPE_APE1553_4 = 84 # Variable c_int '84'
API_MODULE_MASK = 31 # Variable c_int '31'
API_BUF_READ_FROM_LAST = 65535 # Variable c_int '65535'
API_BM_MSG_ERR_MODECODE = 9 # Variable c_int '9'
API_ERR_HS_HSERR_ERRSPEC_BPOS_NOT_IN_RANGE = 796 # Variable c_int '796'
TYPE_APX1553_4 = 24 # Variable c_int '24'
API_BSM_TX_KEEP_SAME = 0 # Variable c_int '0'
TYPE_APX1553_1 = 22 # Variable c_int '22'
TYPE_APX1553_2 = 23 # Variable c_int '23'
API_LLC_RT_SUB = 992 # Variable c_int '992'
TY_BOARD_INFO_PARTNO = 6 # Variable c_int '6'
AI_PLATFORM_CPCI_3U = 64 # Variable c_int '64'
API_ERR_FRAME_XID_NOT_IN_RANGE = 78 # Variable c_int '78'
API_ERR_CMD_NOT_SUPPORTED_BY_FW = 4145 # Variable c_int '4145'
API_HS_GPIO_CMD_SYS2_START = 16 # Variable c_int '16'
API_BM_READ_ETP = 2 # Variable c_int '2'
API_CHN_SINGLE_3910_DUAL_1553 = 3 # Variable c_int '3'
TY_BOARD_INFO_COUPLING = 11 # Variable c_int '11'
API_BC_REPORT_NO_ERR = 0 # Variable c_int '0'
MAX_IR_EVENT_BUF = 256 # Variable c_int '256'
TYPE_AMCE1553_4 = 102 # Variable c_int '102'
INT_LEAST64_MAX = 9223372036854775807 # Variable c_long '9223372036854775807l'
TYPE_AMCE1553_1 = 100 # Variable c_int '100'
TYPE_AMCE1553_2 = 101 # Variable c_int '101'
API_HS_ERR_TYPE_MANCHESTER_HIGH = 5 # Variable c_int '5'
API_BITE_ERR_TIMING_MFRM_1 = 3 # Variable c_int '3'
TYPE_AVX3910Xp_2 = 46 # Variable c_int '46'
API_TARGET_ERROR_OFFSET = 4096 # Variable c_int '4096'
API_CPL_WRAP = 4 # Variable c_int '4'
API_ERR_BC_NOT_AVAILABLE = 4148 # Variable c_int '4148'
MAX_HS_GAP_TIME_MODE_01 = 16383 # Variable c_int '16383'
API_DYTAG_FCT_NEG_TRIANGLE = 4 # Variable c_int '4'
AI_PLATFORM_ANET = 192 # Variable c_int '192'
API_PBI_APX_MILSCOPE = 0 # Variable c_int '0'
API_HS_CTX_RISE_MIN = 7.5 # Variable c_double '7.5e+0'
API_BSP_WRONG_SYS_W98_W2000_SW = 8 # Variable c_int '8'
API_ERR_ADDR_NOT_VALID = 91 # Variable c_int '91'
API_BSP_WRONG_SYS_WNT_SW = 2 # Variable c_int '2'
API_BM_MENSW_TRIG_MASK = 8 # Variable c_int '8'
API_BC_TYPE_RTRT = 2 # Variable c_int '2'
API_MODULE_3 = 2 # Variable c_int '2'
API_MODULE_1 = 0 # Variable c_int '0'
API_ERR_NAK = 4 # Variable c_int '4'
API_MODULE_7 = 6 # Variable c_int '6'
API_MODULE_4 = 3 # Variable c_int '3'
API_MODULE_5 = 4 # Variable c_int '4'
API_MODULE_8 = 7 # Variable c_int '7'
API_MODULE_9 = 8 # Variable c_int '8'
MAX_TCB_EOM = 255 # Variable c_int '255'
TYPE_AEC1553_1 = 74 # Variable c_int '74'
TYPE_AEC1553_2 = 75 # Variable c_int '75'
API_ERR_PARAM13_IS_NULL = 40 # Variable c_int '40'
API_ERR_DQUEUE_LOC_HANDLE_NOT_IN_RANGE = 118 # Variable c_int '118'
API_SYSTAG_FCT_NEG_TRIANGLE = 4 # Variable c_int '4'
AI_PLATFORM_PCIE = 152 # Variable c_int '152'
API_ERR_PARAM11_NOT_IN_RANGE = 46 # Variable c_int '46'
API_BM_SEARCH_CMD2_MASK = 1024 # Variable c_int '1024'
MAX_HEADER_ID = 8191 # Variable c_int '8191'
API_BM_ET_ALTER_MASK = 16384 # Variable c_int '16384'
AI_PLATFORM_PCIX = 144 # Variable c_int '144'
API_ERR_TYPE_HSSA = 14 # Variable c_int '14'
AI_PLATFORM_ANET_AYS_MA = 194 # Variable c_int '194'
TYPE_AVX1553_2 = 38 # Variable c_int '38'
TYPE_AVX1553_1 = 37 # Variable c_int '37'
TYPE_AVX1553_4 = 40 # Variable c_int '40'
API_HS_RT_EFEX_PROTOCOL = 0 # Variable c_int '0'
TYPE_AVX1553_8 = 42 # Variable c_int '42'
MIN_HS_ERR_BPOS = 0 # Variable c_int '0'
__USE_XOPEN2K8XSI = 1 # Variable c_int '1'
API_HS_RCV_RT_POS = 8 # Variable c_int '8'
_SYS_CDEFS_H = 1 # Variable c_int '1'
DBG_TRACE_PBAPRO = 67108864 # Variable c_int '67108864'
API_ERR_IOCTL_TIMEOUT = 7 # Variable c_int '7'
API_LLA_START_MASK = 16777216 # Variable c_int '16777216'
API_ERR_TYPE_PHYSICAL_ERROR_SUPPRESSION = 16 # Variable c_int '16'
TYPE_ACX_EFA_1_DS_TWO_PBIS = 50 # Variable c_int '50'
API_MODULE_10 = 9 # Variable c_int '9'
AI_PLATFORM_PMC_64_ASP = 86 # Variable c_int '86'
API_MODULE_12 = 11 # Variable c_int '11'
API_HS_BM_AW_TRG_MASK = 3 # Variable c_int '3'
API_MODULE_14 = 13 # Variable c_int '13'
API_PBI_SINGLE_1553 = 1 # Variable c_int '1'
API_MODULE_16 = 15 # Variable c_int '15'
API_MODULE_17 = 16 # Variable c_int '16'
API_MODULE_18 = 17 # Variable c_int '17'
API_MODULE_19 = 18 # Variable c_int '18'
API_ERR_FRAME_CNT_NOT_IN_RANGE = 76 # Variable c_int '76'
API_ERR_HOST_TO_TARGET = 5 # Variable c_int '5'
API_ERR_MEMORY_INVALID = 4106 # Variable c_int '4106'
MIN_ERR_BCBITS = 1 # Variable c_int '1'
API_TRACK_RTADDR_POS = 8 # Variable c_int '8'
API_IRIG_PRESENT = 1 # Variable c_int '1'
API_CAL_CPL_EXTERNAL = 3 # Variable c_int '3'
API_HS_BM_ENTRY_LS_CORRELATION = 2 # Variable c_int '2'
API_SCOPE_COUPLING_STUB = 5 # Variable c_int '5'
MAX_DATA_WORDS = 32 # Variable c_int '32'
API_DSUB_RS232 = 0 # Variable c_int '0'
API_ERR_AGAIN = 4147 # Variable c_int '4147'
API_BITE_ERR_GLOBAL_RAM_BM = 5 # Variable c_int '5'
API_INIT_MODE_ALL = 0 # Variable c_int '0'
TYPE_ASE1553_2 = 104 # Variable c_int '104'
TYPE_ASE1553_4 = 105 # Variable c_int '105'
API_ERR_SUBPARAM8_NOT_IN_RANGE = 263 # Variable c_int '263'
API_RESET_STATUS_BITS = 1 # Variable c_int '1'
API_PBI_APX_STANDARD = 1 # Variable c_int '1'
API_ERR_SUBPARAM3_NOT_IN_RANGE = 258 # Variable c_int '258'
API_LLC_RT_ADDR = 63488 # Variable c_int '63488'
API_HS_ERR_TYPE_GAP = 9 # Variable c_int '9'
API_MODULE_13 = 12 # Variable c_int '12'
API_BITE_ERR_BC_BROAD_ISOL_A_BM = 5 # Variable c_int '5'
MIN_CONTIG_GAPERROR = 1 # Variable c_int '1'
AI_DEVICE_GROUP_COUNT = 13 # Variable c_int '13'
TYPE_ACX3910Xp = 34 # Variable c_int '34'
API_ERR_WCNT_NOT_IN_RANGE = 58 # Variable c_int '58'
API_FLASH_SECTOR_EF_BIU1 = 15 # Variable c_int '15'
API_INT_REPLAY = 3 # Variable c_int '3'
API_FLASH_SECTOR_EF_BIU2 = 17 # Variable c_int '17'
API_ERR_TYPE_BIT_CNT_LOW = 10 # Variable c_int '10'
API_BM_ET_STAT_MASK = 2048 # Variable c_int '2048'
TYPE_AVX3910_2 = 45 # Variable c_int '45'
API_BM_ET_TADDR_MASK = 1024 # Variable c_int '1024'
API_LLA_STAT_MASK = 67108864 # Variable c_int '67108864'
TYPE_AVX_EFA_2_DS_TWO_PBIS = 65 # Variable c_int '65'
API_MAX_MEMORY_BARS = 2 # Variable c_int '2'
API_TRG_BM_CHN3 = 18 # Variable c_int '18'
TYPE_ACI3910Xp = 12 # Variable c_int '12'
API_TRG_BM_CHN1 = 16 # Variable c_int '16'
API_INT_LS = 1 # Variable c_int '1'
API_TRG_BM_CHN4 = 19 # Variable c_int '19'
API_BM_MSG_ERR_NO_RESP = 1 # Variable c_int '1'
API_QUEUE_SIZE_64 = 6 # Variable c_int '6'
_BITS_WCHAR_H = 1 # Variable c_int '1'
API_ERR_SYSTAG_STEP_NOT_IN_RANGE = 104 # Variable c_int '104'
API_ERR_HS_HSXMT_STARTDEL_NOT_IN_RANGE = 793 # Variable c_int '793'
MAX_TCB_INDEX = 255 # Variable c_int '255'
API_HS_CTX_FALL_MIN = 7.5 # Variable c_double '7.5e+0'
API_HS_CTX_REG_RISE = 17 # Variable c_int '17'
API_ERR_PARAM10_IS_NULL = 37 # Variable c_int '37'
API_HS_BC_MSG_TAG_BUS_MASK = 32768 # Variable c_int '32768'
TYPE_AVX1553_4_DS_TWO_PBIS = 58 # Variable c_int '58'
API_DYTAG_FCT_SAWTOOTH_8_LOW = 2 # Variable c_int '2'
API_SCOPE_MODE_LESS_THAN_SAMPLES = 5 # Variable c_int '5'
AI_PLATFORM_CPCIX_3U_AYS = 71 # Variable c_int '71'
API_ERR_OS_NOT_SUPPORTED = 396 # Variable c_int '396'
XFER_DESC_FIELD_TRTYPE = 4 # Variable c_int '4'
API_BC_SRVW_DIS = 0 # Variable c_int '0'
API_MILSCOPE_TYPE_AYX = 1 # Variable c_int '1'
API_RESET_WITHOUT_MONITOR = 1 # Variable c_int '1'
API_ERR_TYPE_ZERO_CROSS_POS = 13 # Variable c_int '13'
API_BM_WRITE_AEI = 3 # Variable c_int '3'
API_HS_GPIO_CMD_BITE = 2 # Variable c_int '2'
API_MILSCOPE_TYPE_AYE = 2 # Variable c_int '2'
MAX_DATA_WORDPOS = 32 # Variable c_int '32'
API_SCOPE_OPR_CHANNEL_B = 2 # Variable c_int '2'
API_SCOPE_OPR_CHANNEL_A = 1 # Variable c_int '1'
API_DATA_QUEUE_STATUS_RESUMED = 536870912 # Variable c_int '536870912'
API_DYTAG_FCT_DISABLE = 0 # Variable c_int '0'
API_MILSCOPE_TYPE_NONE = 0 # Variable c_int '0'
API_BM_TRG_SPEC_DW_MASK = 2 # Variable c_int '2'
TYPE_ACX_EFAXp_2_DS_TWO_PBIS = 55 # Variable c_int '55'
API_ERR_MYMON_ERROR = 4126 # Variable c_int '4126'
API_BITE_ERR_HS_TIMING = 103 # Variable c_int '103'
API_TRACK_DONT_CLR_UDF = 0 # Variable c_int '0'
API_INT_RT = 0 # Variable c_int '0'
API_BC_RSP_NO_SW2_EXPECTED = 2 # Variable c_int '2'
TYPE_AVI1553_2 = 6 # Variable c_int '6'
TYPE_AVI1553_1 = 5 # Variable c_int '5'
API_BC_SWXM_DBCA_MASK = 2 # Variable c_int '2'
API_BUF_WRITE_TO_CURRENT = 0 # Variable c_int '0'
API_HS_BC_MSG_TAG_ITIME_MASK = 1023 # Variable c_int '1023'
API_ERR_NO_SPACE_LEFT = 4107 # Variable c_int '4107'
UINT_LEAST8_MAX = 255 # Variable c_int '255'
API_BM_ET_LCNT_MASK = 8192 # Variable c_int '8192'
API_HS_RX_SEL_2_VALID_PRE = 1 # Variable c_int '1'
TYPE_ACX1553_4_TWO_PBIS = 31 # Variable c_int '31'
API_BM_MENSW_STOP_MASK = 4 # Variable c_int '4'
API_ERR_HS_HSIR_NOT_IN_RANGE = 791 # Variable c_int '791'
API_BC_START_IMMEDIATELY = 1 # Variable c_int '1'
API_BM_MSG_FLT_FORMAT_1 = 1 # Variable c_int '1'
API_BM_MSG_FLT_FORMAT_0 = 0 # Variable c_int '0'
API_BM_NO_OVERFLOW = 0 # Variable c_int '0'
API_ERR_LS_CMD_ON_HS_BIU = 4109 # Variable c_int '4109'
API_ERR_TYPE_WORD_CNT_HIGH = 7 # Variable c_int '7'
API_BM_MSG_ERR_ILLEGL = 15 # Variable c_int '15'
API_SYSTAG_STEP_CHECKSUM_PLUS = 0 # Variable c_int '0'
API_ERR_PARAM5_IS_NULL = 23 # Variable c_int '23'
API_DATA_QUEUE_STATUS_LOC_OVERFLOW = 1 # Variable c_int '1'
API_SCOPE_MODE_COMMAND_SYNC = 3 # Variable c_int '3'
API_ERR_HS_LSERR_ERRSPEC_BPOS_NOT_IN_RANGE = 788 # Variable c_int '788'
TYPE_ANET3910Xp = 88 # Variable c_int '88'
API_BITE_ERR_BUS = 4 # Variable c_int '4'
API_SCOPE_QUEUE_SIZE = 96 # Variable c_int '96'
SIG_ATOMIC_MIN = -2147483648 # Variable c_int '-0x00000000080000000'
API_HS_BM_LS_TRG_POS = 8 # Variable c_int '8'
API_BC_REPORT_ERR_SW2_NOT_RCV = 3 # Variable c_int '3'
TYPE_ACX1553_4 = 30 # Variable c_int '30'
_ATFILE_SOURCE = 1 # Variable c_int '1'
TYPE_ACX1553_1 = 27 # Variable c_int '27'
TYPE_ACX1553_2 = 28 # Variable c_int '28'
TYPE_ACX1553_8 = 32 # Variable c_int '32'
API_HS_ERR_TYPE_ALTERNATE_BUS = 11 # Variable c_int '11'
API_HS_GPIO_CMD_SYS1_START = 5 # Variable c_int '5'
API_HS_ERR_TYPE_END_DEL_NO_END = 4 # Variable c_int '4'
TYPE_AVX1553_4_TWO_PBIS = 41 # Variable c_int '41'
API_BC_ERRSPEC_BPOS_POS = 8 # Variable c_int '8'
API_SREC_START = 2 # Variable c_int '2'
API_ERR_HS_HSERR_ERRSPEC_WPOS_NOT_IN_RANGE = 795 # Variable c_int '795'
API_ERR_CON_NOT_ALLOWED = 408 # Variable c_int '408'
API_ERR_BUFFER_TOO_SMALL = 409 # Variable c_int '409'
API_HS_BUF_ALLOC_SUCCESSFUL = 0 # Variable c_int '0'
API_ERR_SUBPARAM10_IS_NULL = 393 # Variable c_int '393'
API_BM_TRG_SPEC_ST_MASK = 4 # Variable c_int '4'
API_SYSTAG_SUSPEND = 0 # Variable c_int '0'
API_HS_BC_MSG_TAG_MERR_MASK = 16384 # Variable c_int '16384'
TYPE_ACX1553_4_DS_TWO_PBIS = 47 # Variable c_int '47'
TYPE_ACX3910 = 33 # Variable c_int '33'
API_PROTOCOL_1553 = 1 # Variable c_int '1'
API_BM_ET_HCNT_MASK = 4096 # Variable c_int '4096'
API_SRV_OS_VER_WIN98 = 2 # Variable c_int '2'
API_FLASH_SECTOR_APX_BIU2 = 42 # Variable c_int '42'
API_FLASH_SECTOR_APX_BIU1 = 40 # Variable c_int '40'
INT_FAST64_MIN = -9223372036854775808 # Variable c_long '-0x08000000000000000l'
API_ERR_FUNCTION_NOT_SUPPORTED = 4120 # Variable c_int '4120'
API_ERR_ERRSPEC_BPOS_NOT_IN_RANGE = 66 # Variable c_int '66'
__USE_POSIX199309 = 1 # Variable c_int '1'
MAX_API_BC_XACYC = 127 # Variable c_int '127'
API_BITE_ERR_HS_INT_MON_TX_CNT_REP = 31 # Variable c_int '31'
MIN_DYTAG_MON_ID = 1 # Variable c_int '1'
API_HS_GPIO_CMD_ALL_OFF = 4 # Variable c_int '4'
API_ERR_DQUEUE_ASP_OPEN = 124 # Variable c_int '124'
API_SYSTAG_FCT_COMP = 7 # Variable c_int '7'
API_SCOPE_COUPLING_EXTERN = 4 # Variable c_int '4'
API_ERR_TYPE_MANCHESTER_LOW = 5 # Variable c_int '5'
API_ERR_DQUEUE_LOC_BUFTYPE_NOT_IN_RANGE = 114 # Variable c_int '114'
API_HS_CTX_OVRSHOOT_MAX = 26.0 # Variable c_double '2.6e+1'
API_SCOPE_OPR_CHANNEL_AB = 3 # Variable c_int '3'
API_RT_ENABLE_MONITORING = 2 # Variable c_int '2'
API_HS_RT_DISABLE_INT = 0 # Variable c_int '0'
INT8_MAX = 127 # Variable c_int '127'
TY_BOARD_INFO_IS_HS_REDUNDANT = 17 # Variable c_int '17'
API_BUF_FULL = 1 # Variable c_int '1'
API_RT_TYPE_ALL = 4 # Variable c_int '4'
API_BITE_ERR_HS_TIMING_INIT = 1 # Variable c_int '1'
MIN_HS_MSGSIZE = 1 # Variable c_int '1'
AI_VERSION_STRINGL = 256 # Variable c_int '256'
API_HS_BC_TYPE_BCBR = 10 # Variable c_int '10'
API_HS_BM_TRG_BF_OCCURED = 2 # Variable c_int '2'
API_BM_TTMODE_LOW_HIGH = 0 # Variable c_int '0'
INTPTR_MIN = -9223372036854775808 # Variable c_long '-0x08000000000000000l'
API_ERR_DQUEUE_REM_BUFTYPE_NOT_IN_RANGE = 115 # Variable c_int '115'
API_BM_ENTRY_CW_SECONDARY = 12 # Variable c_int '12'
API_BITE_PASSED = 0 # Variable c_int '0'
__USE_XOPEN_EXTENDED = 1 # Variable c_int '1'
API_BM_MODE_NO_INT = 0 # Variable c_int '0'
API_UTIL_CMD_EF_TIME_OUT_DEF = 5 # Variable c_int '5'
INT_LEAST32_MAX = 2147483647 # Variable c_int '2147483647'
API_BIU_5 = 5 # Variable c_int '5'
TYPE_APXX3910 = 90 # Variable c_int '90'
API_DATA_QUEUE_STATUS_ENABLED = 2147483648 # Variable c_uint '2147483648u'
API_BIU_3 = 3 # Variable c_int '3'
API_BIU_2 = 2 # Variable c_int '2'
API_BIU_8 = 8 # Variable c_int '8'
AI_PLATFORM_CPCIX_3U_PCIE_BASED = 69 # Variable c_int '69'
API_ERR_HS_LSERR_ERRSPEC_BCBITS_NOT_IN_RANGE = 789 # Variable c_int '789'
API_BC_START_RT_MODECODE = 3 # Variable c_int '3'
API_ERR_HS_LSERR_ERRSPEC_WPOS_NOT_IN_RANGE = 787 # Variable c_int '787'
API_ERR_BIU_NOT_ACTIVE = 4108 # Variable c_int '4108'
API_TOGGLE_BUS_KEEP = 2 # Variable c_int '2'
API_ERR_IRIG_MIN_NOT_IN_RANGE = 98 # Variable c_int '98'
MIN_HS_BH_BUF_SIZE = 0 # Variable c_int '0'
INT_FAST8_MIN = -128 # Variable c_int '-0x00000000000000080'
API_BITE_ERR_HS_INT_TT_FAST = 41 # Variable c_int '41'
XFER_DESC_FIELD_CW1_CW2 = 5 # Variable c_int '5'
API_ERR_SUBPARAM3_IS_NULL = 386 # Variable c_int '386'
WINT_MIN = 0 # Variable c_uint '0u'
__USE_ISOC95 = 1 # Variable c_int '1'
API_EF_BM_CMD_TRG_POS = 10 # Variable c_int '10'
__USE_ISOC99 = 1 # Variable c_int '1'
API_UTIL_CMD_WRITE_NOVRAM = 0 # Variable c_int '0'
API_HS_BC_TYPE_STATUS_ENTRY = 0 # Variable c_int '0'
API_BITE_ERR_BC_TIMEOUT_ISOL_B_BM = 13 # Variable c_int '13'
INT_LEAST8_MAX = 127 # Variable c_int '127'
API_ERR_INVALID_DEVICE_STATE = 4113 # Variable c_int '4113'
API_HS_BM_LS_TRG_MASK = 768 # Variable c_int '768'
MIN_BC_FRAME_TIME = 0.001 # Variable c_double '1.00000000000000002081668171172168513294309377670288085938e-3'
API_PBI_3910 = 4 # Variable c_int '4'
__USE_XOPEN = 1 # Variable c_int '1'
API_DATA_QUEUE_CTRL_MODE_STOP = 1 # Variable c_int '1'
DBG_DQUEUE = 2048 # Variable c_int '2048'
MAX_HS_TRACK_LEN = 4096 # Variable c_int '4096'
TYPE_AVI3910 = 13 # Variable c_int '13'
AI_PLATFORM_XMC_NOREPLAY_NOERROR = 179 # Variable c_int '179'
API_BM_BUSY = 2 # Variable c_int '2'
TYPE_ACX_EFA_1_TWO_PBIS = 48 # Variable c_int '48'
API_ERR_PARAM8_IS_NULL = 35 # Variable c_int '35'
INT16_MAX = 32767 # Variable c_int '32767'
__USE_ATFILE = 1 # Variable c_int '1'
API_ERR_QUEUE_OVERFLOW = 108 # Variable c_int '108'
API_BM_ENTRY_DW_SECONDARY = 14 # Variable c_int '14'
API_BM_MSW_STOP_MASK = 2 # Variable c_int '2'
API_BM_MSW_EVENT_MASK = 32 # Variable c_int '32'
API_MODE_SET_TRANSP_INTR = 13 # Variable c_int '13'
API_BC_FWI_DELAY = 42 # Variable c_int '42'
API_LLC_TRANS_ID = 16777215 # Variable c_int '16777215'
API_ERR_PARAM13_NOT_IN_RANGE = 48 # Variable c_int '48'
API_BM_MBUF_ENTRY_EC_MASK = 134217728 # Variable c_int '134217728'
API_SYSTAG_STEP_CHECKSUM_XOR = 1 # Variable c_int '1'
API_ERR_DEVICE_NOT_FOUND = 9 # Variable c_int '9'
API_CPL_TRF = 1 # Variable c_int '1'
API_DATA_QUEUE_ID_MIL_SCOPE = 8 # Variable c_int '8'
API_ERR_INVALID_RT_SA = 4139 # Variable c_int '4139'
API_HS_BUF_ENTRY_HEADER_SIZE = 64 # Variable c_int '64'
API_HS_BC_MSG_TAG_WCNT_MASK = 1024 # Variable c_int '1024'
API_ERR_CNT_IS_ZERO = 18 # Variable c_int '18'
API_CHN_SINGLE_EFEX = 1 # Variable c_int '1'
API_BM_MSG_ERR_BIT_SET = 11 # Variable c_int '11'
API_BC_TYPE_BCRT = 0 # Variable c_int '0'
API_HS_GPIO_RESET_INFO = 1 # Variable c_int '1'
MAX_HS_ERR_BPOS = 15 # Variable c_int '15'
API_ERR_CREATE_EVENT = 402 # Variable c_int '402'
API_PBI_SINGLE_1553_DBTE = 16 # Variable c_int '16'
TYPE_AVX_EFA_1_TWO_PBIS = 59 # Variable c_int '59'
_POSIX_C_SOURCE = 200809 # Variable c_long '200809l'
API_INT_BC = 1 # Variable c_int '1'
API_BITE_ERR_HS_TRANSFER = 102 # Variable c_int '102'
API_INT_BM = 2 # Variable c_int '2'
API_ERR_DQUEUE_LOC_MEMSIZE_NOT_IN_RANGE = 116 # Variable c_int '116'
__USE_SVID = 1 # Variable c_int '1'
API_HS_CAL_CHANNEL_A = 1 # Variable c_int '1'
API_HS_CAL_CHANNEL_B = 2 # Variable c_int '2'
AI_PLATFORM_PCI_E_1L = 26 # Variable c_int '26'
API_IRIG_NOT_PRESENT = 0 # Variable c_int '0'
MAX_SYSTAG_WPOS = 31 # Variable c_int '31'
MAX_HS_NOPRE = 255 # Variable c_int '255'
API_HSSA_DEF = 26 # Variable c_int '26'
API_ERR_BM_NOT_AVAILABLE = 4150 # Variable c_int '4150'
APIEF_BC_XFER_TYPE_EXRTBR = 25 # Variable c_int '25'
API_BITE_ERR_HS_INT_TT_TIMEOUT = 42 # Variable c_int '42'
MAX_CONTIG_GAPERROR = 15 # Variable c_int '15'
API_REP_NO_INT = 0 # Variable c_int '0'
API_BC_BUF = 1 # Variable c_int '1'
API_HS_RX_SEL_FW_DEFAULT = 6 # Variable c_int '6'
MAX_CONTIG_ZEROERROR = 1 # Variable c_int '1'
MAX_API_C1760_C02 = 16 # Variable c_int '16'
AI_PLATFORM_PCI_SHORT = 18 # Variable c_int '18'
TYPE_AME1553_1 = 94 # Variable c_int '94'
__USE_EXTERN_INLINES = 1 # Variable c_int '1'
PTRDIFF_MIN = -9223372036854775808 # Variable c_long '-0x08000000000000000l'
API_BC_MODIFY_TYPE_JUMP = 2 # Variable c_int '2'
API_ERR_WRONG_MODULE = 16 # Variable c_int '16'
API_HS_FMOD_NORM = 0 # Variable c_int '0'
API_HS_ERR_TYPE_START_DEL_INV = 1 # Variable c_int '1'
API_BC_TYPE_MASK_TRANSFER = 255 # Variable c_int '255'
API_ERR_BIP2_BOOT_FAILED = 4117 # Variable c_int '4117'
AI_PLATFORM_PCIE_PCIX_BASED = 145 # Variable c_int '145'
MIN_CONTIG_ZEROERROR = 0 # Variable c_int '0'
API_HS_RX_SEL_8_VALID_PRE = 3 # Variable c_int '3'
API_BM_ET_ERR_MASK = 32768 # Variable c_int '32768'
TYPE_AXI1553_2 = 8 # Variable c_int '8'
API_ERR_SUBPARAM9_IS_NULL = 392 # Variable c_int '392'
_XOPEN_SOURCE_EXTENDED = 1 # Variable c_int '1'
API_BITE_ERR_INT_MILBUS = 24 # Variable c_int '24'
API_ERR_INVALID_HANDLE = 399 # Variable c_int '399'
API_DYTAG_FCT_NEG_RAMP = 2 # Variable c_int '2'
API_BM_ET_PAR_MASK = 16 # Variable c_int '16'
API_BC_MODIFY_WRTYP_16BIT = 0 # Variable c_int '0'
API_HS_MIN_DATA_WORDS = 1 # Variable c_int '1'
MAX_HS_RX_INIT_TIMEOUT = 1023 # Variable c_int '1023'
API_ERR_TIC_NOT_IN_RANGE = 59 # Variable c_int '59'
API_ERR_TYPE_DATA_SYNC = 2 # Variable c_int '2'
TY_BOARD_INFO_SIZE_GLOBAL = 7 # Variable c_int '7'
MIN_DATA_BITLEN = 1 # Variable c_int '1'
API_ERR_RTDYTAG_MAX_NOT_IN_RANGE = 94 # Variable c_int '94'
API_SYSTAG_BITPOS_MASK = 65280 # Variable c_int '65280'
MAX_SCOPE_TRG_TBT = 262143 # Variable c_int '262143'
_BSD_SOURCE = 1 # Variable c_int '1'
API_ERR_RTDYTAG_TAGFCT_NOT_IN_RANGE = 92 # Variable c_int '92'
API_BC_HLT_HALT_ON_ERR_EXCEPT = 3 # Variable c_int '3'
API_SCOPE_MODE_DISCRETES = 11 # Variable c_int '11'
AI_DESCRIPTION_STRINGL = 256 # Variable c_int '256'
TYPE_AVX_EFAXp_4_TWO_PBIS = 68 # Variable c_int '68'
API_INT_TRG_TT = 5 # Variable c_int '5'
API_ERR_TYPE_NO_INJECTION = 0 # Variable c_int '0'
API_BITE_ERR_HS_BC_BROAD_ELECT_AA_BM = 6 # Variable c_int '6'
TY_BOARD_INFO_DEVICE_TYPE = 0 # Variable c_int '0'
API_BC_XFER_RTBC = 1 # Variable c_int '1'
API_ERR_NO_MODULE_EXTENSION = 394 # Variable c_int '394'
API_BM_ENTRY_GAP_MASK = 33488896 # Variable c_int '33488896'
API_BM_MBUF_ENTRY_TYPE_MASK = 4026531840 # Variable c_uint '4026531840u'
API_HS_LSIR_MASK = 255 # Variable c_int '255'
API_BITE_DISABLE_RESET = 128 # Variable c_int '128'
API_UTIL_CMD_SWITCH_EFA_EFEX = 4 # Variable c_int '4'
API_BM_HALTED = 1 # Variable c_int '1'
TY_BOARD_INFO_BIU_COUNT = 2 # Variable c_int '2'
API_HS_GPIO_CMD_SYS2_END = 63 # Variable c_int '63'
API_DSUB_TRG_IN = 1 # Variable c_int '1'
API_INT_BC_BRANCH = 4 # Variable c_int '4'
MAX_API_MODULE = 32 # Variable c_int '32'
API_REP_CET = 1 # Variable c_int '1'
API_BQM_STAY_LAST = 1 # Variable c_int '1'
API_REP_NO_ABS_TIME = 0 # Variable c_int '0'
API_HS_GPIO_RESET = 0 # Variable c_int '0'
TYPE_AVX3910 = 43 # Variable c_int '43'
API_CHN_SINGLE_3910_SINGLE_1553 = 2 # Variable c_int '2'
API_TRG_RT_CHN3 = 14 # Variable c_int '14'
API_TRG_RT_CHN4 = 15 # Variable c_int '15'
API_FLASH_OK = 0 # Variable c_int '0'
API_ERR_TYPE_GAP = 6 # Variable c_int '6'
API_ERR_PARAM2_IS_NULL = 20 # Variable c_int '20'
API_BM_WRITE_HTC = 3 # Variable c_int '3'
API_RT_ENABLE_SIMULATION = 1 # Variable c_int '1'
API_ERR_FAILED_TO_CREATE_MUTEX = 398 # Variable c_int '398'
API_CAL_XMT_FULL_RANGE_PRI = 1 # Variable c_int '1'
API_ERR_BIP1_START_FAILED = 4118 # Variable c_int '4118'
API_EF_BM_HW_TRG_MASK = 2048 # Variable c_int '2048'
API_FLASH_SECTOR_EF_LCA = 26 # Variable c_int '26'
API_EF_RTMODE_DUAL = 0 # Variable c_int '0'
API_ERR_SUBPARAM5_IS_NULL = 388 # Variable c_int '388'
SCOPE_WAIT_TIMEOUT = 2 # Variable c_int '2'
API_BSM_RX_DISCARD = 0 # Variable c_int '0'
API_BM_TIMETAG_SEC_MASK = 66060288 # Variable c_int '66060288'
API_ERR_IRIG_HOUR_NOT_IN_RANGE = 97 # Variable c_int '97'
USB_8051_RAM = 1 # Variable c_int '1'
API_HS_BC_TYPE_RTBR = 12 # Variable c_int '12'
API_ERR_SCOPE_DMA_STATUS_BUSY = 4130 # Variable c_int '4130'
API_ERR_HID_NOT_IN_RANGE = 51 # Variable c_int '51'
API_ERR_FRAME_INSTR_NOT_IN_RANGE = 77 # Variable c_int '77'
API_HS_GAP_POS = 0 # Variable c_int '0'
API_ENA_INIT = 3 # Variable c_int '3'
API_ERR_ACK_SIZE_UNDEFINED = 4146 # Variable c_int '4146'
UINTPTR_MAX = 18446744073709551615 # Variable c_ulong '-1ul'
API_ERR_MAXIMUM = 65535 # Variable c_int '65535'
API_RT_SING = 1 # Variable c_int '1'
API_ERR_WRONG_BIU = 32 # Variable c_int '32'
API_HS_ERR_TYPE_END_DEL_INV = 3 # Variable c_int '3'
INT16_MIN = -32768 # Variable c_int '-0x00000000000008000'
API_SYSTAG_BITNB_POS = 0 # Variable c_int '0'
API_LCA_BIU1_VER_MASK = 65535 # Variable c_int '65535'
API_FLASH_SECTOR_APX_LCA = 44 # Variable c_int '44'
API_BITE_ERR_HS_BCRT_ISOL_AA = 10 # Variable c_int '10'
__USE_MISC = 1 # Variable c_int '1'
API_ERR_PARAM6_NOT_IN_RANGE = 30 # Variable c_int '30'
API_BM_ET_GAP_MASK = 512 # Variable c_int '512'
API_ERR_HS_LSERR_CONTIG_NOT_IN_RANGE = 786 # Variable c_int '786'
MIN_API_BC_XFRAME = 1 # Variable c_int '1'
MAX_RT_SA = 30 # Variable c_int '30'
API_ERR_ERROR_INJECTION_NOT_AVAILABLE = 4152 # Variable c_int '4152'
API_ERR_SYSTAG_BPOS_NOT_IN_RANGE = 106 # Variable c_int '106'
API_BM_TRG_SPEC_CW2_MASK = 8 # Variable c_int '8'
UINT16_MAX = 65535 # Variable c_int '65535'
API_HS_LSCHN_MASK = 65280 # Variable c_int '65280'
UINT_FAST32_MAX = 18446744073709551615 # Variable c_ulong '-1ul'
API_REP_REC_AREA_OFFSET = 65536 # Variable c_int '65536'
API_SCOPE_SRC_PRIMARY = 0 # Variable c_int '0'
API_ERR_PARAM14_NOT_IN_RANGE = 49 # Variable c_int '49'
__USE_POSIX199506 = 1 # Variable c_int '1'
API_BC_FWI_HALT = 41 # Variable c_int '41'
API_RT_MODE_BUSY = 2 # Variable c_int '2'
API_RESET_ONLY_IF_NOT_ALREADY_RESETTED = 4 # Variable c_int '4'
API_SERVER_REGISTERED = 0 # Variable c_int '0'
AI_PLATFORM_CPCIE_3U_ZYNQMP = 72 # Variable c_int '72'
TY_BOARD_INFO_SERIAL = 5 # Variable c_int '5'
INT_FAST16_MAX = 9223372036854775807 # Variable c_long '9223372036854775807l'
API_ERR_POS1_GREATER_THAN_POS2 = 90 # Variable c_int '90'
API_CHN_SINGLE_EFEX_DUAL_1553 = 3 # Variable c_int '3'
INT_LEAST16_MIN = -32768 # Variable c_int '-0x00000000000008000'
API_BC_INSTR_SKIP = 2 # Variable c_int '2'
API_EF_SWITCH_OK = 1 # Variable c_int '1'
API_SCOPE_OFFSET_COMP_GET = 2 # Variable c_int '2'
API_BITE_ERR_WALKING_BIT = 2 # Variable c_int '2'
API_BITE_ERR_BC_BROAD_ELECT_B = 2 # Variable c_int '2'
API_ERR_TYPE_ZERO_CROSS_NEG = 12 # Variable c_int '12'
API_HS_BC_ECW_TYPE_MASK = 49152 # Variable c_int '49152'
SCOPE_BUFFER_FLAG_FILLED = 1 # Variable c_int '1'
API_HS_CTX_STATUS_DRDY_POS = 7 # Variable c_int '7'
AI_PLATFORM_MINI_PCIE_CARD_AP = 119 # Variable c_int '119'
API_RT_ENABLE_SA_INT_XFER = 2 # Variable c_int '2'
API_PBI_DUAL_1553_ONE_BIU = 10 # Variable c_int '10'
API_BITE_ERR_HS_INT_TT_SLOW = 40 # Variable c_int '40'
API_BC_FWI_RESMF = 45 # Variable c_int '45'
MAX_SCOPE_TRG_NB_SAMPLES = 255 # Variable c_int '255'
API_BM_READ_CTP = 1 # Variable c_int '1'
API_ERR_HS_CMD_ON_LS_BIU = 4110 # Variable c_int '4110'
API_ERR_CMD_NOT_FOUND = 4097 # Variable c_int '4097'
API_LLA_UPDATE_MASK = 268435456 # Variable c_int '268435456'
API_BM_SEARCH_STAT_MASK = 2048 # Variable c_int '2048'
MAX_BOARD_NAME_LENGTH = 32 # Variable c_int '32'
API_ERR_IRIG_DAY_NOT_IN_RANGE = 134 # Variable c_int '134'
API_ERR_DMA_WRITE_NOT_SUPPORTED = 4102 # Variable c_int '4102'
DBG_CLOSE = 8 # Variable c_int '8'
API_BM_START_EVENT_OCCURED = 1 # Variable c_int '1'
INT64_MAX = 9223372036854775807 # Variable c_long '9223372036854775807l'
API_LITTLE_ENDIAN_MODE = 0 # Variable c_int '0'
API_BC_START_FAST = 6 # Variable c_int '6'
API_BUF_BC_MSG = 1 # Variable c_int '1'
API_HS_LSCHN_POS = 8 # Variable c_int '8'
API_BSIZEM_DYNAMIC = 1 # Variable c_int '1'
API_CHN_SINGLE_3910 = 1 # Variable c_int '1'
TYPE_AVX_EFAXp_1_DS_TWO_PBIS = 62 # Variable c_int '62'
API_STREAM_2 = 2 # Variable c_int '2'
API_STREAM_3 = 3 # Variable c_int '3'
API_BM_MODE_START_EVENT_INT = 2 # Variable c_int '2'
API_STREAM_6 = 6 # Variable c_int '6'
API_STREAM_7 = 7 # Variable c_int '7'
API_STREAM_4 = 4 # Variable c_int '4'
API_STREAM_5 = 5 # Variable c_int '5'
API_RT_DISABLE_SA = 0 # Variable c_int '0'
API_BITE_ERR_INT_WRONG_PBI = 23 # Variable c_int '23'
_ISOC95_SOURCE = 1 # Variable c_int '1'
API_BM_TIMETAG_HOURS_MASK = 1984 # Variable c_int '1984'
MAX_API_BM_MSG_FLT_REC = 255 # Variable c_int '255'
API_MAX_PHYSICAL_BIU = 4 # Variable c_int '4'
DBG_ERRORMSG = 1073741824 # Variable c_int '1073741824'
API_ERR_HS_LSCHN_NOT_IN_RANGE = 783 # Variable c_int '783'
__SYSCALL_WORDSIZE = 64 # Variable c_int '64'
MAX_GENIO_TEST_SEQ_ARRAY_SIZE = 32 # Variable c_int '32'
API_HS_RX_SEL_EXT_LOGIC = 7 # Variable c_int '7'
API_SYSTAG_SA_MID_MASK = 255 # Variable c_int '255'
API_TBM_TRANSFER = 0 # Variable c_int '0'
API_LLA_STOP_MASK = 134217728 # Variable c_int '134217728'
TYPE_ACX_EFAXp_1_TWO_PBIS = 49 # Variable c_int '49'
API_HS_RX_SEL_LS_AW = 5 # Variable c_int '5'
API_HS_RT_MODE_SIMULATION = 0 # Variable c_int '0'
MAX_ERR_BPOS = 20 # Variable c_int '20'
TYPE_ACX1553_2_TWO_PBIS = 29 # Variable c_int '29'
API_ERR_SXH_NOT_IN_RANGE = 61 # Variable c_int '61'
TY_BOARD_INFO_DISCRETE_CNT = 13 # Variable c_int '13'
MAX_RT_ADDR = 31 # Variable c_int '31'
API_BM_NO_STROBE = 0 # Variable c_int '0'
AI_PLATFORM_PCIE_4L_AYS = 25 # Variable c_int '25'
_ISOC11_SOURCE = 1 # Variable c_int '1'
API_TOGGLE_BUS_ALT = 3 # Variable c_int '3'
__USE_UNIX98 = 1 # Variable c_int '1'
API_HS_BC_ERRSPEC_BPOS_MASK = 65280 # Variable c_int '65280'
API_HS_RT_TYPE_TRANSMIT_MID = 1 # Variable c_int '1'
API_SYSTAG_FCT_NEG_RAMP = 2 # Variable c_int '2'
MAX_SCOPE_TRG_HOLDOFF = 262143 # Variable c_int '262143'
TYPE_AXC1553_2 = 77 # Variable c_int '77'
TYPE_AXC1553_1 = 76 # Variable c_int '76'
TYPE_AXC1553_4 = 78 # Variable c_int '78'
MAX_GAP_TIME_MODE_01 = 32767 # Variable c_int '32767'
API_MODE_TIMETAG_SOURCE = 1 # Variable c_int '1'
API_BITE_ERR_HS_INTERN_SELFTEST = 101 # Variable c_int '101'
API_REP_BUSY = 1 # Variable c_int '1'
API_ERR_INVALID_RT_SA_TYPE = 4140 # Variable c_int '4140'
API_SYSTAG_FCT_DISABLE = 0 # Variable c_int '0'
API_HS_HSIR_MASK = 255 # Variable c_int '255'
API_ERR_BUFFER_NOT_ALLOCATED = 407 # Variable c_int '407'
API_BITE_ERR_INT_PAT_FF = 19 # Variable c_int '19'
API_HS_BC_TYPE_RTBC = 9 # Variable c_int '9'
API_ERR_1760_BUFID_NOT_IN_RANGE = 110 # Variable c_int '110'
API_ERR_FRAME_ID_NOT_IN_RANGE = 75 # Variable c_int '75'
API_MAX_LOGICAL_BIU = 8 # Variable c_int '8'
API_HS_BUF_ID_OUT_OF_RANGE = 2 # Variable c_int '2'
API_BRW_BUFSTAT_MASK = 12288 # Variable c_int '12288'
API_HS_CTX_STATUS_ICMD = 32 # Variable c_int '32'
INT_FAST32_MIN = -9223372036854775808 # Variable c_long '-0x08000000000000000l'
API_BITE_ERR_HS_INT_MON_TX_CNT = 26 # Variable c_int '26'
API_HS_ERR_TYPE_NO_INJECTION = 0 # Variable c_int '0'
API_ERR_TCBEOM_NOT_IN_RANGE = 87 # Variable c_int '87'
API_PROTOCOL_1553_B = 1 # Variable c_int '1'
AI_PLATFORM_CPCI_6U = 66 # Variable c_int '66'
API_PROTOCOL_1553_A = 0 # Variable c_int '0'
API_DATA_QUEUE_CTRL_MODE_RESUME = 2 # Variable c_int '2'
API_BC_FWI_WMFT = 40 # Variable c_int '40'
API_ERR_HS_XFER_MID_NOT_IN_RANGE = 777 # Variable c_int '777'
INT_REQUEST_COUNT_MAX = 1000 # Variable c_int '1000'
API_ERR_TARGET_RESPONSE_TIMEOUT = 4132 # Variable c_int '4132'
API_RT_SA_USAGE_BUF_INIT = 1 # Variable c_int '1'
API_ERR_INVALID_SIZE = 4143 # Variable c_int '4143'
API_BC_XFER_BUSB = 1 # Variable c_int '1'
API_BC_XFER_BUSA = 0 # Variable c_int '0'
API_BITE_ERR_HS_BCRT_ISOL_BB = 13 # Variable c_int '13'
API_BITE_ERR_HS_BCRT_ISOL_BA = 12 # Variable c_int '12'
API_BM_MSG_ERR_BOTH_CHN = 8 # Variable c_int '8'
MIN_HS_MID = 1 # Variable c_int '1'
API_BM_ENTRY_NOT_FOUND = 0 # Variable c_int '0'
API_MODULE_2 = 1 # Variable c_int '1'
API_ERR_PARAM3_IS_NULL = 21 # Variable c_int '21'
API_ERR_1760_C02_NOT_IN_RANGE = 112 # Variable c_int '112'
APIEF_BC_XFER_TYPE_EXRTRT = 24 # Variable c_int '24'
API_BM_TRG_EXTERNAL_EVENT = 1 # Variable c_int '1'
API_ERR_SERVER_CONNECT = 514 # Variable c_int '514'
API_MODULE_6 = 5 # Variable c_int '5'
API_TRACK_SA_MID_POS = 0 # Variable c_int '0'
int_least8_t = c_byte
int_least16_t = c_short
int_least32_t = c_int
int_least64_t = c_long
uint_least8_t = c_ubyte
uint_least16_t = c_ushort
uint_least32_t = c_uint
uint_least64_t = c_ulong
int_fast8_t = c_byte
int_fast16_t = c_long
int_fast32_t = c_long
int_fast64_t = c_long
uint_fast8_t = c_ubyte
uint_fast16_t = c_ulong
uint_fast32_t = c_ulong
uint_fast64_t = c_ulong
intptr_t = c_long
intmax_t = c_long
uintmax_t = c_ulong
__all__ = ['TY_API_RT_MSG_ALL_DSP_RT',
           'API_ERR_HS_XFER_SW_EXCEPT_NOT_IN_RANGE',
           'API_ERR_CNT_IS_ZERO', 'API_IRIG_EXTERN',
           'API_HS_HSXMT_NOPRE_MASK', 'API_EF_RTMODE_EFEX',
           'API_BC_HLT_HALT_ON_XFER_ERR', 'API_EF_TRIG_SD',
           'API_TRG_BC_CHN3', 'API_TRG_BC_CHN2',
           'API_BM_ET_HBIT_MASK', 'API_BM_SEARCH_WORDB_MASK',
           'TYPE_ACX_EFAXp_4_TWO_PBIS', 'API_DIS_ON_ERROR',
           'API_DATA_QUEUE_TSW_OFFSET_PUT',
           'API_DATA_QUEUE_STATUS_REM_BUF_ERR',
           'ty_api_hs_bc_xfer_x_common',
           'API_SCOPE_SIZE_SINGLE_CH_REC',
           'API_ERR_BC_SIMULATION_ACTIVE', 'API_BM_ENTRY_NOT_UPDATED',
           'ty_api_hs_bc_dytag', 'API_TRG_BC_CHN4',
           'API_BC_XFER_RTRT', 'PTY_E_DEVICE_GROUP',
           'API_TRG_BC_CHN1', 'MIN_API_STREAM', 'DBG_TRACE',
           'API_RT_TYPE_TRANSMIT_SA',
           'API_ERR_SUBPARAM1_NOT_IN_RANGE', 'TY_API_TRACK_SCAN_OUT',
           'API_SERVER_POS', 'API_ERR_PARA_TYPE_NOT_IN_RANGE',
           'TY_API_VER_INFO_VALUES', 'DBG_ERROR',
           'API_ERR_1760_C01_NOT_IN_RANGE', 'API_PROTOCOL_1553_EFEX',
           'uint_fast16_t', 'API_HS_CTX_STATUS_DRDY',
           'ty_api_hs_bm_stackp_dsp', 'MAX_SCOPE_TRG_VALUE',
           'TYPE_ACE3910', 'IS_REMOTE', 'API_CHN_SINGLE_EFEX',
           'ty_api_gen_io_dev_ven_list', 'TY_API_TRACK_READ_IN',
           '_DEFAULT_SOURCE', 'AI_PLATFORM_ASC',
           'ty_api_gen_io_dev_ven', 'API_ERR_DQUEUE_ID_NOT_IN_RANGE',
           'MAX_SCOPE_COUPLING_MODE', 'AI_PLATFORM_XMC',
           'TYPE_ACI1553_1', 'LOWORD', 'TYPE_ACI1553_2',
           'TY_API_SCOPE_TRG', 'ty_api_hs_bc_bh_info',
           'API_RESET_WITHOUT_SIMBUF_MON',
           'API_BC_HLT_HALT_ON_STAT_EXCEPT', 'MAX_EF_BM_STRIG_TYPE',
           'MAX_HS_ENTRY_NR', 'API_BC_FWI_JUMP',
           'TY_API_BC_XFER_STATUS_QUEUE', 'ty_api_bm_cap_setup',
           'ty_api_get_mem_layout', 'MAX_SYSTAG_ID',
           'TY_API_HS_RT_MID_STATUS_EX', 'ty_api_rt_sa',
           'API_ERR_SUBPARAM6_NOT_IN_RANGE', 'API_ON',
           'API_ERR_SUBPARAM4_IS_NULL', 'MAX_RT_DEFINED_WORD_CNT',
           'API_SYSTAG_BITNB_MASK', 'AiTrgVoidPtr', 'TYPE_AVI3910Xp',
           'TYPE_API3910Xp', 'API_BC_GAP_MODE_STANDARD',
           'API_BITE_GLOBAL_RAM_BIU', 'API_HS_CTX_REG_OVRSHOOT',
           'API_QUEUE_SIZE_128', 'API_TBM_GLOBAL',
           'API_SYSTAG_BITPOS_POS', 'API_HS_BC_ERRSPEC_BPOS_POS',
           'API_ERR_SCOPE_DMA_ENABLED', 'ty_api_hs_bm_stack_fnd',
           'API_BC_SWXM_MERR_MASK',
           'API_ERR_DQUEUE_LOC_HANDLE_NOT_IN_RANGE',
           'API_BITE_BOARD_ENABLE', 'AiTrgUI8Ptr',
           'API_DATA_QUEUE_TSW_OFFSET_SIZE', 'TYPE_API1553_2',
           'DBG_OPEN', 'API_BSP_WRONG_TARGET_SW',
           'TYPE_AVX_EFA_4_TWO_PBIS', 'API_BM_STROBE_ON_START_EVENT',
           'API_PBI_APX', 'TY_API_BC_MODIFY_INSTRUCTION',
           'API_ERR_PARAM8_NOT_IN_RANGE', 'API_HS_BC_ECW_BUFINT_MASK',
           'API_HS_RT_TYPE_RECEIVE_MID', 'MAX_HS_CONT_TRACK_NB',
           'ty_api_discr_info', 'ty_api_ef_resp_sim_sdframe',
           'TY_API_HS_BC_DYTAG', 'API_BC_TIC_NO_INT',
           'API_EF_SWITCH_TO_EFEX', 'MAX_HS_IR',
           'ty_api_track_def_out', 'API_BM_ET_LBIT_MASK',
           'TY_API_HS_BM_MSG_FLT', 'API_ERR_PARAM4_NOT_IN_RANGE',
           'API_BM_TRG_SPEC_CW_MASK', 'API_FIRMWARE_BIU1_VER_MASK',
           'API_PXI_SET_TTSRC_EXTERNAL', 'ty_api_hs_bc_err',
           'AI_PLATFORM_VME_A', 'AI_PLATFORM_VME_B',
           'API_ERR_CHN_NOT_IN_RANGE', 'TY_BOARD_INFO_IRIG',
           'API_HS_FMOD_CONT_PREAM', 'API_HS_BC_ERRSPEC_WPOS_MASK',
           'API_BITE_ERR_MODE_ISOL_B_BM', 'API_BSIZEM_STATIC',
           'API_BM_MENSW_START_MASK', 'TYPE_ACX_EFA_2_DS_TWO_PBIS',
           'API_BITE_ERR_INTERRUPT', 'AI_PLATFORM_PMC_64',
           'API_BM_ET_ILLEGL_MASK', 'API_BM_TRG_DATA_VALUE',
           'API_BC_MODIFY_TYPE_MODIFY', 'TY_API_BM_DYTAG_MON_ACT',
           'TYPE_APXX3910Xp', 'TYPE_APU1553_1', 'TYPE_APU1553_2',
           'MAX_INSTR_NR', 'API_VER_MASK',
           'API_BITE_ERR_HS_INT_PAT_AA', 'API_HS_CTX_STATUS_FAIL_POS',
           'AI_PLATFORM_ANET_AYS_MA', 'TY_E_MEM_TYPE',
           'API_ERR_SUBPARAM2_NOT_IN_RANGE', 'MAX_XFER_ID',
           'UINT32_C', 'API_BC_FWI_MODIFY', 'API_HS_CHANNEL_A',
           '_XOPEN_SOURCE', 'API_HS_CHANNEL_B', 'API_FLASH_ERR_PROG',
           'TY_API_HS_BM_TRG_COND', 'TYPE_ACX3910_2',
           'API_PBI_ELECTRICAL', 'ty_mil_com_ack',
           'API_BITE_ERR_SHARED_RAM', 'API_ERR_UNKNOWN_COMMAND',
           'MAX_RT_MODE_CTRL', 'API_BITE_GLOBAL_RAM_BM',
           'API_ERR_XMT_RT_NOT_IN_RANGE', 'TY_API_SCOPE_SETUP',
           'API_ERR_XMT_SA_NOT_IN_RANGE', 'API_HS_HSXMT_NOPRE_POS',
           'ty_api_hs_rt_dytag', 'TY_API_VER_INFO_STRINGS',
           'AI_MAX_VERSIONS', 'API_RT_SA_TYPE_RCV', 'MAX_TBM',
           'API_ERR_SYSTAG_FCT_NOT_IN_RANGE',
           'API_MEM_PART_PARAM_ERR', 'API_SYSTAG_STEP_CYCLIC',
           'API_BITE_ERR_BC_TIMEOUT_ISOL_A_BM', '_POSIX_C_SOURCE',
           'API_BC_SWXM_SUB_MASK', 'API_BC_TIC_INT_ON_XFER_END',
           '__glibc_likely', 'API_BC_MODIFY_OPC_NONE', 'TRUE',
           'API_ERR_SCOPE_ALREADY_RUNNING',
           'api_packet_update_status_out', '__USE_POSIX2',
           'API_ERR_SUBPARAM8_IS_NULL', 'API_ERR_PARAM1_NOT_IN_RANGE',
           'TY_API_SYSTAG', 'TY_API_MEM_BIU_ADDR',
           'API_HS_RCV_MID_MASK', 'TY_API_BC_ERROR', '_AIM_LINUX',
           'TYPE_ASC1553_1', 'TY_INT_FUNC_PTR',
           'ty_api_track_read_in', 'API_ERR_ACK2',
           'API_MEMTYPE_GLOBAL_EXTENSION', 'UINT64_MAX',
           'API_TRACK_XFERID_MASK', 'API_RT_SWM_NXW_OR',
           'API_BITE_ERR_HS_TIMING_TX_TO',
           'APIEF_BC_XFER_TYPE_X_RTBR', 'ty_ver_info',
           'API_BITE_ERR_HS_RTBC_ISOL_AB',
           'API_BITE_ERR_HS_RTBC_ISOL_AA', 'TY_API_MEM_BIU_COUNT',
           'DBG_MINIMAL', 'API_ERR_TYPE_ALTERNATE_BUS',
           'API_LLA_ANY_ERR_MASK', '_SYS_CDEFS_H',
           'API_BC_MODIFY_TYPE_MOVE', 'API_ERR_NOVRAM_ERROR',
           'API_SEND_SRVW_ON_SA0', 'ty_api_gen_io_board',
           'API_HS_BC_MSG_TAG_BCNT_MASK', 'API_BSM_RX_KEEP_CURRENT',
           'API_BSP_WRONG_SYS_DRV', 'API_ERR_IOCTL_TIMEOUT',
           'TY_API_HS_BC_XFER_STATUS_QUEUE',
           'AI_PLATFORM_PCIE_4L_PCIX_3_3V_BASED',
           'API_BC_MODIFY_COMPC__EQ', 'TY_BOARD_INFO_CHANNEL_COUNT',
           'MAX_SYSTAG_WPOS', 'uint_fast32_t',
           'API_BM_SEARCH_CMD_MASK', 'ty_api_version',
           'API_ERR_PARA_SAMID_NOT_IN_RANGE', 'API_BC_STATUS_HALTED',
           'API_ERR_TARGET_RESPONSE_TIMEOUT', 'TY_DRIVER_INFO',
           'MIN_HS_XFER_ID', 'AiUShort', 'API_ERR_INVALID_HID',
           'API_SCOPE_COUPLING_PRIMARY', 'SCOPE_WAIT_FINISHED',
           'MAX_SCOPE_TRG_DELAY', 'AI_PLATFORM_PCI_LONG',
           'TYPE_APX3910', 'API_SYSTAG_FCT_DATASET',
           'API_SCOPE_MODE_BIU2_BM', 'API_ERR_PARAM4_IS_NULL',
           'TY_API_MEM_SIM_BUF',
           'API_ERR_HS_XFER_SECOND_GAPMODE_NOT_IN_RANGE',
           'API_ERR_DWC_NOT_AVAILABLE', 'AiDouble',
           'API_SCOPE_MODE_BIU2_BC', 'SCOPE_BUFFER_FLAG_CANCELED',
           'API_SCOPE_START_CONTINUOUS', 'MAX_TG_CMD_SIZE',
           'TY_BOARD_INFO_HAS_EXTERNAL_TRIGGER',
           'API_TRACK_XFERID_POS', 'TY_API_BM_RT_ACT', 'MAX_SA_CON',
           'TY_API_HS_RT_ERR', 'AI_DEVICE_UNKNOWN',
           'ty_api_hs_bm_rt_act', 'AI_PLATFORM_PMC_BASED_EBD',
           'API_HS_BM_ENTRY_LS_CA_WORD', 'ty_api_bc_bh_info',
           'API_HS_BC_ECW_BUFSTAT_MASK',
           'API_BC_REPORT_ERR_SW1_NOT_RCV', 'API_HS_BC_TYPE_RTRT',
           'API_BM_FLT_MODE_DEPENDENT',
           'API_ERR_HS_DYTAG_MODE_NOT_IN_RANGE', 'AiUInt8',
           'AI_PLATFORM_PMC_64_ASP', 'API_BC_TIC_INT_ON_XFER_ERR',
           'API_BITE_ERR_RTRT_ISOL_A_BM', 'API_HS_CTX_RISE_MAX',
           'API_BQM_CYCLIC', 'ty_api_ver_info_strings',
           'API_PBI_SINGLE_1553', 'API_HS_BC_NO_INDEX_INT',
           'TY_API_BC_FRAME', 'FALSE', 'ty_api_hs_track_prealloc_in',
           'INT32_MAX', 'TY_API_VERSION', 'INT_LEAST64_MIN',
           'TYPE_AMCX1553_1', 'TYPE_AMCX1553_2', 'AiUChar',
           'API_BC_MODIFY_COMPC__TRIGGER', 'uint64_t', 'AiInt8',
           'MAX_TRACK_ID', 'API_DATA_QUEUE_TSW_OFFSET_STATUS',
           'ty_api_ef_bc_sync_time_def', 'API_BM_MSG_ERR_HBIT',
           'API_BM_TIMETAG_MIN_MASK', 'TY_API_HS_BC_XFER_STATUS',
           'API_BSP_WRONG_BIU1_SW', 'TY_API_SCOPE_TRG_STROBE',
           'API_HS_ERR_TYPE_MANCHESTER_LOW', 'MAX_PROTOCOL',
           'API_BM_MSG_ERR_EARLY_RESP', 'API_BM_TRG_RECEIVED_WORD',
           'API_BM_MSG_TBUSY_MASK', 'API_CPL_ISO',
           'API_BC_STATUS_BUSY', 'API_BITE_ERR_SHARED_RAM_ACK',
           'API_HS_HSXMT_STARTDEL_POS', 'SCOPE_STATUS_TRIGGERED',
           'API_ERR_IOCTL_ERROR', 'API_ERR_TYPE_WORD_CNT_LOW',
           'TY_BOARD_INFO_SIZE_SHARED', 'TY_API_HS_BM_STACK_ENTRY',
           'ty_api_bc_xfer_read_in', 'API_HS_RX_SEL_4_VALID_PRE',
           'API_BM_MSG_FLT_FORMAT_5', 'API_BM_MSG_FLT_FORMAT_4',
           'API_BM_MSG_FLT_FORMAT_3', 'API_BM_MSG_FLT_FORMAT_2',
           'API_HS_RCV_RT_MASK', 'API_SYSTAG_STEP_1S_COMP',
           'API_BITE_ERR_HS_INT_PAT_00', 'ty_mil_com_with_value',
           'API_DYTAG_FCT_POS_RAMP', 'API_ERR_DMA_TOO_MANY_BLOCKS',
           'TY_API_BC_FW_INSTR', 'TYPE_AVX_EFAXp_1_TWO_PBIS',
           'API_RT_MODE_LANE_CTRL', 'AI_MEMTYPE_LOCAL',
           'MAX_HS_GAP_TIME_MODE_2', '__GNU_LIBRARY__',
           'TY_BOARD_INFO_DISCRETE_CONFIG',
           'API_BITE_ERR_HS_RTBC_ISOL_BB',
           'API_BITE_ERR_HS_RTBC_ISOL_BA', 'INTMAX_C',
           'API_ERR_IOFPGA_BOOT_FAILED',
           'API_ERR_RTDYTAG_MIN_NOT_IN_RANGE', 'TYPE_AEC1553_2',
           'API_RT_RSP_BOTH_BUSSES', 'API_BM_MSG_ERR_MANCH',
           'API_BM_MSW_START_MASK', 'AI_SUBDLL1_VER',
           'TY_API_C1760_CON', 'AI_PLATFORM_PCI_E_1L_ZYNQMP',
           'API_BM_CAPMODE_RECORDING', 'API_BC_SWXM_BUSY_MASK',
           'ty_api_rt_sa_status_ex', 'MIN_HS_HEADER_ID',
           'API_ERR_SUBPARAM5_NOT_IN_RANGE', 'UINTMAX_MAX',
           'API_BC_START_INSTR_TABLE', 'API_RT_SA_USAGE_UPDATE',
           'API_TYPE_MON_ONLY', 'MIN_HEADER_ID',
           'API_ERR_BIU_OUT_OF_RANGE', 'TY_MIL_COM_ACK_WITH_VALUE',
           'MAX_BM_IMODE', 'API_PBI_PROGRAMMABLE',
           'API_BC_RSP_NO_SW1_EXPECTED', 'TY_API_HS_BM_STATUS',
           'API_CAL_CPL_TRANSFORM', 'MAX_HS_BC_MODE_CTRL',
           'MAX_RT_RESPONSE', 'API_BITE_ERR_HS_INT_PAT_FF',
           'MAX_API_SERVER_PER_SLOT', 'API_ERR_VALUE_NOT_IN_RANGE',
           'API_PBI_DUAL_1553', 'API_CAL_CPL_EXTERNAL',
           'AI_PLATFORM_PCIX_PCIE_BASED',
           'API_SCOPE_QUEUE_SIZE_BRAM_2K', 'TY_API_EF_RX_SELECT',
           'API_LLA_TRIG_MASK', 'TY_API_TRACK_DEF_IN',
           'API_ERR_ELEMENT_NOT_ENABLED', 'API_BM_ENTRY_TIMETAG_LOW',
           'BSWAP16', 'API_BC_FWI_STRB', 'API_BITE_SHARED_RAM_ACK',
           'API_EF_RX_SEL_2_VALID_PRE', 'TY_API_HSLS_BC_XFER',
           'API_ERR_DMA_NOT_SUPPORTED', 'API_MODE_HS_ADDR',
           'API_ERR_TCBNEXT_NOT_IN_RANGE',
           'API_ERR_RTDYTAG_WPOS_NOT_IN_RANGE',
           'TY_API_EF_BC_RESP_SIM_SDFRAME', 'API_BITE_ERR_INT_WALK_1',
           'API_BITE_ERR_INT_WALK_0', 'ty_api_bc_xfer_dsp',
           'MAX_FIFO_ID', 'TY_API_INTR_LOGLIST_ENTRY',
           'API_ERR_HS_HSERR_ERRSPEC_BCBITS_NOT_IN_RANGE',
           'AI_DEVICE_AYXGNET', 'API_FLASH_SECTOR_APX_EF_LCA',
           'API_LLA_TCBI_MASK', 'MAX_API_BC_XFRAME',
           'API_BM_WRITE_STM', 'MAX_EF_BM_CWTRIG_TYPE',
           'API_BM_ENTRY_SW_SECONDARY', 'API_BM_MSG_ERR_SW_EXCEPT',
           'API_BM_ENTRY_CW_PRIMARY', 'API_DYTAG_FUNCTION_MODIFY',
           'API_HS_BC_MSG_TAG_DEL_MASK', 'TY_API_HS_RT_MODE_CTRL',
           'API_SCOPE_OFFSET_COMP_MEASURE', 'MIN_HS_TRACK_LEN',
           'API_ERR_WRONG_DRV_VERSION', 'MAX_BIU',
           'API_ERR_GAP_MODE_NOT_IN_RANGE', 'API_BC_INSTR_WAIT',
           'AI_DEVICE_USB', 'MAX_HS_XFER_HALT',
           'API_HS_ERR_TYPE_START_DEL_INV', 'int32_t',
           'API_ERR_PARA_MODE_NOT_IN_RANGE',
           'API_BITE_SHARED_RAM_CMD', 'TY_API_EF_BC_XFER',
           'VOID_FUNC_1553', 'API_BM_STROBE_ON_STOP_EVENT',
           'TY_API_GEN_IO_BOARD_TYPE', 'TYPE_AVX1553_4_DS_TWO_PBIS',
           'API_INIT_MODE_ALL', 'ty_api_bm_stack_dsp',
           'API_SCOPE_SRC_SECONDARY',
           'API_ERR_1760_MODE_NOT_IN_RANGE', 'MIN_HS_ERR_BCBITS',
           'TYPE_APX3910Xp', 'TYPE_ASE1553_2',
           'API_ERR_PARA_RANGE_NOT_IN_RANGE',
           'API_BRW_ERR_REPORT_MASK', 'API_BM_WRITE_TI0',
           'API_BM_WRITE_TI1',
           'API_ERR_DQUEUE_REM_MEMSIZE_NOT_IN_RANGE',
           'MAX_GAP_TIME_MODE_2', 'API_HS_FMOD_DDL', 'MAX_BM_CAPMODE',
           'API_BUF_OVERRUN', 'API_ERR_INVALID_BUS',
           'API_CHN_DUAL_1553', 'BYTE', 'GET_MODULE_ID',
           'AI_PLATFORM_CPCIE_3U', 'AI_PLATFORM_PC104',
           'TY_API_HS_RT_BH_INFO', 'ty_api_rt_sa_event_queue',
           'API_BITE_ERR_BC_BROAD_ELECT_A_BM', 'MIN_CONT_TRACK_NB',
           'API_HS_GPIO_CMD_DEV_END', 'API_ERR_OVERFLOW',
           'API_BITE_ERR_HS_INT_SIM_TX_CNT', 'AiInt32',
           'TY_BOARD_INFO_IS_MULTI_CHANNEL', 'MAX_WPOS',
           'API_SCOPE_START_SINGLE', 'API_ERR_INVALID_TSW_VERSION',
           'API_BC_EXEC_CYCLIC', 'API_RETRY_2SAME_1ALT',
           'API_BITE_ERR_INT_PAT_AA', 'API_BM_OVERFLOW',
           'TY_API_EF_BC_SYNC_TIME_GET', 'uint_least16_t',
           'TY_API_HS_BM_STACKP_DSP', 'int_least32_t',
           'MIN_BC_MODE_CTRL', 'MAX_HS_BUFSIZE', 'AI_SUBDLL3_VER',
           'MIN_XFER_ID', 'API_BITE_DA_CONV_BUSB',
           'API_BITE_DA_CONV_BUSA', 'API_BITE_ERR_HS_INT_WRONG_PBI',
           'MAX_HS_XFER_TYPE', 'TY_API_DEVICE_CONFIG',
           'TY_API_HS_TRACK_SCAN_IN', 'API_TRACK_RTADDR_MASK',
           'TY_API_TRACK_READ_OUT', 'API_BITE_ERR_TIMING_MFRM_10',
           'MAX_ERR_WPOS', 'MAX_MID_MCODE', 'AI_PLATFORM_XMC_EBD',
           'API_DYTAG_FCT_MASK', 'API_BM_CAPMODE_ALL',
           'API_SCOPE_MODE_GREATER_OR_LESS_THAN',
           'API_SRV_OS_VER_WIN2000', 'ty_api_hs_bc_xfer_info',
           '__USE_XOPEN2KXSI', 'API_ERR_PARAM9_NOT_IN_RANGE',
           'API_TYPE_SIM_MON', 'API_DEVICE_MODE_IS_EMBEDDED',
           'API_BC_SWXM_BRCV_MASK', 'MAX_HS_XFER_ID',
           'API_ERR_HLT_NOT_IN_RANGE',
           'API_HS_ERR_TYPE_START_DEL_PATTERN',
           'API_ERR_TCBSOT_NOT_IN_RANGE', 'LPOVERLAPPED',
           '__USE_XOPEN2K8', 'GET_SERVER_ID',
           'TY_BOARD_INFO_HAS_ELECTRICAL_INTERFACE',
           'ty_api_ef_bc_xfer_x_ls', 'API_ERR_NUMBUFFERSLEFT_INVALID',
           'API_DYTAG_FCT_NEG_RAMP', 'ty_coupling_capabilities_b',
           'API_ERR_PARA_RTXFER_NOT_IN_RANGE',
           'API_ERR_TYPE_MSG_LENGTH_LO_IGNORE', 'API_RT_SA_ERR_INT',
           'API_HS_RX_SEL_FIRST_EDGE', 'ty_api_irig_time',
           'TY_API_EF_BC_RESP_SIM_SFRAME',
           'API_ERR_WRONG_TSW_VERSION', 'API_MEMTYPE_GLOBAL',
           'API_BM_ENTRY_DW_PRIMARY', 'API_BM_MSG_ERR_ISYNC',
           'API_DATA_QUEUE_TSW_OFFSET_GET', 'ty_api_bm_stackp_dsp',
           'API_RT_ALL', 'TY_API_BM_ACT_DSP', 'API_REP_HFI_INT',
           'API_HS_BM_BCTYPE_BCRT', 'API_ERR_HS_LSIR_NOT_IN_RANGE',
           '_ISOC99_SOURCE', 'MAX_HS_RX_INIT_TIMEOUT',
           'TY_API_SCOPE_BUFFER', 'API_ERR_RT_SIMULATION_ACTIVE',
           'API_ERR_INVALID_TIME',
           'API_ERR_HS_XFER_XFERID_NOT_IN_RANGE',
           'API_RT_TYPE_RECEIVE_MODECODE', 'MAX_SKIP_CNT',
           'API_SREC_ERR_ADDR', 'API_RT_MC_TYPE_RCV',
           'MAX_HS_HEADER_ID', 'API_UTIL_CMD_READ_NOVRAM',
           'APIEF_BC_XFER_TYPE_XXRTRT',
           'API_BITE_ERR_BCRT_ISOL_AB_BM', 'MAX_RESP_TIME',
           'API_ERR_SUBPARAM9_NOT_IN_RANGE',
           'API_DATA_QUEUE_CTRL_MODE_START',
           'API_ERR_IRIG_SEC_NOT_IN_RANGE',
           'ty_api_bc_xfer_status_queue', 'TY_API_INTR_LOGLIST_LLD',
           'API_EF_BM_CMD_TRG_MASK', 'TY_API_INTR_LOGLIST_LLC',
           'MIN_DATA_WORDPOS', 'API_SCOPE_OFFSET_COMP_RESET',
           'API_RT_ENABLE_SA', 'API_BM_MSW_TRIG_MASK',
           'API_RESET_ALL', 'INT_FAST8_MAX',
           'ty_api_bc_xfer_event_queue', 'API_BC_GAP_MODE_DELAY',
           'API_HS_BM_ENTRY_ERROR_WORD', 'API_ENA',
           'API_RCV_BUS_SECONDARY', 'AI_PLATFORM_PC_CARD',
           'API_QUEUE_SIZE_16', 'AI_FIRMWARE_VER_BIU4',
           'AI_FIRMWARE_VER_BIU3', 'AI_FIRMWARE_VER_BIU2',
           'TY_API_HS_TRACK_READ_OUT', 'TYPE_ACX_EFA_4_TWO_PBIS',
           'API_ERR_TYPE_BIT_CNT_HIGH', 'ty_api_rt_msg_dsp',
           'API_DATA_QUEUE_STATUS_CHN_OPERATING',
           'TY_API_HS_TRACK_PREALLOC_OUT', 'API_HS_GPIO_CMD_SDREG',
           'API_BC_MODIFY_OPC_ADD_OPERAND', 'ty_api_intr_event_list',
           'TY_API_DISCOVER_CALLBACK_FUNC_PTR', 'API_MEMTYPE_SHARED',
           'API_RT_REPORT_ERR_RSP_TIMEOUT', 'AI_MEMTYPE_IO',
           'MAX_BOARD_NAME_LENGTH', 'API_BSP_WRONG_SYS_W95_SW',
           'MIN_BH_BUF_SIZE', 'API_DATA_QUEUE_ID_BM_REC_BIU2',
           'API_DATA_QUEUE_ID_BM_REC_BIU3',
           'API_DATA_QUEUE_ID_BM_REC_BIU1',
           'API_DATA_QUEUE_ID_BM_REC_BIU6',
           'API_DATA_QUEUE_ID_BM_REC_BIU7',
           'API_BC_HLT_HALT_ON_ANY_INT',
           'API_DATA_QUEUE_ID_BM_REC_BIU5',
           'ty_api_hs_rt_mid_status_info', 'ty_api_bc_err',
           'API_ERR_ERRSPEC_BCBITS_NOT_IN_RANGE',
           'API_HS_BM_ENTRY_BUS_WORD', 'API_BC_MODIFY_COMPC__GT',
           'API_BM_ET_TADDR_MASK', 'TY_API_HS_TRACK_READ_IN',
           'TYPE_ANET1553_2', 'API_DYTAG_DIRECT_MODIFY',
           'ty_api_scope_calibration_info', 'API_BC_MODIFY_COMPC__GE',
           'API_BC_SRVW_SINGLE', 'API_BC_SWXM_INSTR_MASK',
           'MIN_MULTI_TRACK_NB', 'API_HS_GAPMODE_MASK',
           'API_ERR_SUBPARAM1_IS_NULL', 'ALL_RT_ADDR',
           'MIN_HS_BUFSIZE', 'API_SCOPE_COUPLING_NETWORK',
           'INT_LEAST32_MIN', 'ty_api_rt_msg_all_dsp',
           'API_LLA_INT_TYPE_MASK', 'ty_api_bc_mode_ctrl',
           'TY_API_DATA_QUEUE_READ', 'AI_PLATFORM_PCI_64_ASP',
           'TYPE_APEX3910Xp', 'API_BM_ENTRY_CW2_SECONDARY',
           'ty_api_track_prealloc_in', 'TY_API_HS_BC_XFER',
           'API_SYSTAG_BITPOS_MASK', 'API_BM_WRITE_ALL',
           'API_ERR_SUBPARAM4_NOT_IN_RANGE', 'TY_API_BM_STATUS_DSP',
           'API_PROTOCOL_1553_3910', 'API_CAL_CPL_ISOLATED',
           'API_PXI_CLR_TRG', 'API_HS_ERR_TYPE_BIT_CNT_LOW',
           'SIG_ATOMIC_MAX', 'API_TRG_BM_CHN3', 'TYPE_ACI3910Xp',
           'API_TRG_BM_CHN1', 'API_BM_ENTRY_CW2_PRIMARY',
           'ty_api_ef_bm_trg_cond', 'MIN_RESP_TIME',
           'API_EF_BM_HW_TRG_POS',
           'API_ERR_SYSTAG_XIDRTMID_NOT_IN_RANGE',
           'API_HS_ERR_TYPE_INV_BIT', 'API_CAL_XMT_FULL_RANGE_SEC',
           'ty_api_sync_cnt_get', 'TY_API_BC_SRVW',
           'API_HS_BM_HW_TRG_POS', 'API_EF_SWITCH_ERR',
           'API_TRG_BM_CHN4', 'API_BITE_ERR_BC_BROAD_ISOL_B_BM',
           '_LARGEFILE64_SOURCE', 'API_BM_MSG_ERR_PARITY',
           'API_BITE_GLOBAL_RAM_BCRT', 'MIN_BC_START_MODE',
           'API_ERR_DEV_IS_NOT_CTX', '__bos0', 'ty_api_ef_rx_select',
           'API_ERR_INVALID_RT', 'API_SCOPE_MODE_LESS_THAN',
           'API_SYSTAG_RTADDR_POS', '__USE_ISOC11',
           'MIN_API_BC_MFRAME', 'DBG_INT', 'API_RETRY_1ALT',
           'API_BC_MODE_STOP_ON_MC0_DBCA_FLAG', 'MAX_API_STREAM',
           'AI_PLATFORM_VXI_B', 'offsetof', 'API_BM_MSG_ERR_LCNT',
           'API_BM_SEARCH_ENTRY_TYPE_MASK', 'API_BM_MSG_ERR_NO_RESP',
           'API_ERR_PLATTFORM_NOT_SUPPORTED', 'MAX_HS_START_DELAY',
           'API_RETRY_1SAME_1ALT',
           'API_ERR_EF_WORDCOUNT_NOT_IN_RANGE',
           'API_BM_SEARCH_WORDA_MASK', 'API_FLASH_ERR_ERASE',
           'MAX_BM_STACK_ENTRY_SIGN', 'API_LLA_BFI_MASK',
           'API_BITE_ERR_GLOBAL_RAM_BCRT', 'MAX_BH_BUF_SIZE',
           'API_MEMTYPE_GLOBAL_DIRECT', 'MAX_API_BC_MFRAME_EX',
           'API_ERR_PARAM14_IS_NULL', 'ty_api_hs_rt_status_dsp',
           'API_CHN_SINGLE_3910_SINGLE_1553',
           'API_ERR_HS_HSXMT_STARTDEL_NOT_IN_RANGE',
           'ty_api_bc_xfer_status_info', 'MAX_DATA_BITLEN',
           'API_ERR_SYSTAG_WPOS_NOT_IN_RANGE', 'MAX_TRACK_READ_MODE',
           'TY_API_HS_RT_MID_READ_IN', 'API_RT_DISABLE_OPERATION',
           '__GLIBC_PREREQ', 'API_ERR_RTDYTAG_STEP_NOT_IN_RANGE',
           'API_DEVICE_MODE_EMBEDDED', 'API_HS_FMOD_CONT_PREAM_DDL',
           'TY_API_RT_SA_MSG_READ_IN', 'SCOPE_STATUS_OVERFLOW',
           'INT_LEAST8_MIN', 'AI_MMAP_OFFSET', 'API_DATA_VALID',
           'API_DYTAG_FCT_SAWTOOTH_16', 'ai_int64_union',
           'API_ERR_POS2_NOT_IN_RANGE', 'API_UPDATE_START_REQUESTED',
           'TY_API_GEN_IO_DEV_VEN', 'TY_API_HS_BC_STATUS',
           'API_BC_XFER_RTBC', 'API_ERR_TYPE_NOT_IN_RANGE',
           'API_BM_ENTRY_ERROR_WORD', 'API_HS_BM_ERR_TRG_MASK',
           'API_BSP_WRONG_BIU2_SW', 'MAX_HS_TRG_SEL', 'AI_TCP_VER',
           'TY_API_BC_XFER_DSP', '__attribute_format_strfmon__',
           'API_BM_TRG_ERR_CONDITION', 'DBG_IO', 'UINT16_C',
           'API_RT_BUF', 'api_e_update_status', 'TY_API_SYNC_CNT_GET',
           'TY_API_GEN_IO_GET_BOARDS_IN',
           'API_HS_BC_ERRSPEC_BCBITS_POS', 'API_RT_MODE_LSW_HANDLING',
           'API_HS_CTX_REG_RISE', 'ty_api_bc_frame',
           'API_CAL_TRANS_500K', 'TYPE_AVX_EFA_2_TWO_PBIS',
           'API_HS_CTX_FALL_MAX', 'API_BC_START_SETUP',
           'API_ERR_PARAM12_IS_NULL', '_LARGEFILE_SOURCE',
           'MIN_TRACK_LEN', 'MAX_TRACK_CHUNKSIZE', 'MAX_BITE_CONTROL',
           'API_ERR_SECONDARY_COUPLING_NOT_INTERNAL',
           'TY_BOARD_INFO_PROTOCOL', 'TYPE_APXX3910',
           'ty_api_ef_bc_internal_frame', 'API_MEM_PART_OK',
           'API_ERR_HS_XFER_MSGSIZE_NOT_IN_RANGE',
           'API_BITE_DISABLE_RESET', 'API_RT_SA_TYPE_XMT',
           'TYPE_AVX_EFA_1_DS_TWO_PBIS', 'uint_least32_t',
           'MAX_BC_FRAME_TIME', 'MAX_CONTIG_ZEROERROR',
           'API_DONT_MODIFY_STATUS_BITS', 'PTRDIFF_MAX',
           'API_SREC_DOWNLOAD', 'API_ERR_BUFFER_NOT_ALLOCATED',
           'API_FLASH_SECTOR_LCA', 'API_ERR_PARAM6_IS_NULL',
           'API_ERR_DQUEUE_CONTROL_MODE_NOT_IN_RANGE',
           'APIEF_BC_XFER_TYPE_X_RTBRMIXED', 'API_BM_MENSW_MEN_MASK',
           'ty_api_ini_info', 'API_ERR_HS_DYTAG_WPOS_NOT_IN_RANGE',
           'MAX_RT_MODECODE', 'TY_API_DISCOVER_CALLBACK',
           'API_RT_REPORT_NO_ERR', 'API_HS_BC_ASSERT_INDEX_INT',
           'API_BITE_ERR_TIMING', 'API_ERR_PARA_ID_NOT_IN_RANGE',
           'API_PBI_STANDARD', 'ty_api_hs_gpio_res_inf',
           'API_BITE_ERR_TIMING_IMG',
           'API_SCOPE_MODE_GREATER_THAN_SAMPLES',
           'API_BC_MODIFY_OPC_SUB_OPERAND',
           'TYPE_ACX_EFAXp_1_DS_TWO_PBIS',
           'API_BITE_ERR_HS_INT_MON_DATA', 'API_BITE_INTERRUPT',
           'API_SCOPE_BUFFER_TYPE', 'UINT_FAST16_MAX', 'MIN_HS_MID',
           'TYPE_AVX3910Xp', 'API_BITE_ERR_HS_BC_BROAD_ISOL_AA',
           'API_BITE_ERR_HS_BC_BROAD_ISOL_AB',
           'API_ERR_TYPE_MSG_LENGTH_HI_IGNORE', 'MAX_TRANS_MODE',
           'ty_api_bm_rt_act', 'MAX_HS_MSGSIZE', 'API_SCOPE_BUFFER',
           'XFER_DESC_FIELD_CHN', 'ty_api_queue_buf',
           'MAX_HS_GAPMODE', 'ty_api_bc_srvw',
           'TY_API_RT_SA_STATUS_QUEUE', 'API_ERR_WRONG_STREAM',
           'MAX_BC_START_MODE', 'API_FLASH_SECTOR_BIU2',
           'MAX_DYTAG_MON_ID', 'API_FLASH_SECTOR_BIU1',
           'API_BM_MSG_GERR_MASK',
           'API_ERR_BCDYTAG_WPOS_NOT_IN_RANGE',
           'API_BITE_ERR_TIMING_RT_RESPONSE', 'ty_api_bc_status_dsp',
           'UINT8_MAX', 'ty_api_hs_bc_xfer_x_hs',
           'API_ERR_GAP_NOT_IN_RANGE', 'MAX_PXICON_MODE',
           'API_EF_RTMODE_EFA', 'size_t', 'AiInt16',
           'SCOPE_WAIT_OVERFLOW', 'API_BC_MODE_CONFIGURED_DYTAGS',
           'TY_BOARD_INFO_CHANGE_AMPL', 'TYPE_AXI3910Xp',
           'API_UPDATE_IN_PROGRESS', 'API_BC_XFER_BCRT',
           'ty_api_mem_biu_count', 'MIN_BUF_NB_IN_FIFO',
           'API_BM_READ_ABS', 'TY_API_SYNC_CNT_SET', '__WORDSIZE',
           'ty_api_hs_bm_msg_flt', 'AI_PLATFORM_PCIX_3_3V',
           'API_SCOPE_TRG_STROBE_BC', 'TY_BOARD_INFO_IR',
           'API_BC_START_EXTERNAL_PULSE',
           'API_BITE_ERR_INTERN_SELFTEST', 'TY_API_BC_MFRAME_EX',
           'INTMAX_MIN', 'AI_PLATFORM_CPCIX_3U',
           'API_ERR_TYPE_ZERO_CROSS_POS',
           'API_ERR_PARAM12_NOT_IN_RANGE', 'API_TRACK_SA_MID_MASK',
           '__USE_POSIX', 'AI_PLATFORM_CPCIE_3U_AYS',
           'API_REP_NO_ABS_TIME', 'TY_API_HS_BC_BH_INFO',
           'API_DATA_QUEUE_ID_BM_REC_BIU4', 'API_BM_ET_MANCH_MASK',
           'INT_FAST64_MAX', 'ty_api_mem_biu_info',
           'API_HS_GPIO_TYPE_VOX3910CTX', 'MAX_EF_RTMODE',
           'API_HS_GPIO_CMD_ALL_OFF', 'API_HS_GPIO_RESET',
           'API_DATA_QUEUE_ID_BM_REC_BIU8', 'API_BC_SWXM_TERM_MASK',
           'API_CHN_SINGLE_EFEX_QUAD_1553', 'TYPE_AVX3910',
           'TYPE_APEX3910', 'TY_API_IRIG_TIME',
           'MAX_BM_STACK_ENTRY_OFFSET', 'API_SYSTAG_FCT_STATES',
           'TY_API_HS_GPIO_RES_INF', 'MAX_QUEUE_SIZE',
           'AI_PLATFORM_PMC_XMC_BASED', 'API_HS_HSCHN_MASK',
           'API_BITE_ERR_HS_INT_MON_DATA_REP', 'uint_least8_t',
           'API_ERR_CAPMODE_NOT_IN_RANGE', 'TYPE_ACX1553_4',
           '__WORDSIZE_TIME64_COMPAT32', 'ty_api_hs_bm_rec', '__P',
           'TY_API_BM_CAP_SETUP', 'API_RESET_STATUS_BITS',
           'API_BC_START_CONTINUE_ON_BC_HALT',
           'API_HS_CTX_OVRSHOOT_MIN', '__USE_GNU',
           'TY_API_SCOPE_STATUS', '__attribute_format_arg__',
           'API_ERR_NO_SCOPE_EXECUTED', 'MAX_TCB_INV', 'AiUIntPtr',
           'TYPE_AP104_1553_2', 'TY_API_EF_BC_INTERNAL',
           'TYPE_AP104_1553_1', 'API_BC_XFER_BUS_PRIMARY',
           'TYPE_AP104_1553_4', 'TYPE_ANET1553_1',
           'ty_api_hs_bm_trg_cond', 'MAX_MULTI_TRACK_NB',
           'APIEF_BC_XFER_TYPE_XERTRT', '__GLIBC__', 'ty_mil_com',
           'API_ERR_FAILED_TO_CREATE_MUTEX',
           'TY_API_GEN_IO_GET_BOARDS_OUT',
           'API_HS_BC_ECW_ERR_REPORT_MASK', 'ty_api_bm_rec',
           'INT8_MIN', 'API_ERR', 'API_BITE_ERR_HS_INT_WALK_0',
           'API_BITE_ERR_HS_INT_WALK_1', 'API_BSP_COMPATIBLE',
           'MAX_HS_RT_PROTOCOL', 'API_ERR_TCBTRI_NOT_IN_RANGE',
           'TY_API_BOARD_CAPABILITIES', 'TY_BOARD_INFO_BOARD_TYPE',
           'MAX_TCB_NEXT', 'API_SCOPE_OPR_CHANNEL_DISABLED',
           'API_HS_CTX_REG_MODE', 'API_CAL_TRANS_1M',
           'MAX_BM_TIW_CON', 'API_ERR_RCV_RT_NOT_IN_RANGE',
           'API_SCOPE_SIZE_DUAL_CH_REC', 'ty_api_mem_biu_addr',
           'API_TYPE_NOT_PRESENT', 'API_BITE_ERR_HS_TIMING',
           'API_INIT_MODE_READ', 'MAX_DATA_QUEUE_ID',
           'API_ERR_TYPE_COMMAND_SYNC', 'API_QUEUE_SIZE_32',
           'ty_api_ef_bc_xfer', 'ty_api_hs_bm_stack_entry',
           'API_HS_GPIO_DEVTYPE_RESERVED',
           'API_FLASH_SECTOR_TARGET_SW', 'TYPE_ANET3910',
           'API_REP_RLT_ALL', 'TY_API_HS_RT_DYTAG',
           'ty_api_hs_rt_mid_status_ex', 'INT64_C',
           'ty_api_bm_status_dsp', 'API_ERR_TCBTT_NOT_IN_RANGE',
           'API_BM_ENTRY_BUS_WORD', 'TY_API_HS_SYSTAG',
           'MAX_BUFFER_ID', 'API_MODE_ALL_RT', 'MAX_DYTAG_MODE',
           'API_PROTOCOL_1553_B', 'API_ERR_SUBPARAM2_IS_NULL',
           'TY_API_BC_FW_RSRC_DESC', 'API_SEND_SRVW_ON_SA31',
           'ty_api_ef_rt_mc_def', 'API_HS_BC_ERRSPEC_WPOS_POS',
           'API_ERR_HS_XFER_XFERHALT_NOT_IN_RANGE',
           'API_RESET_ENABLE_1760', 'API_BM_READ_STP',
           'MAX_HS_CPL_MODE', 'ty_api_rt_mode_ctrl',
           'API_BM_TRG_SPEC_RXB_MASK', 'API_BSP_WRONG_LCA2_SW',
           'API_BM_TIMETAG_DAYS_MASK', 'MAX_HS_RT_MODE_CTRL',
           'API_BC_ERRSPEC_WPOS_POS', 'AiChar', 'API_LLA_RBI_MASK',
           'API_LCA_BIU2_VER_MASK', 'API_TYPE_SIM_ONLY',
           'API_BM_MSG_ERR_HCNT', 'TYPE_AXI3910',
           'API_SCOPE_COUPLING_SECONDARY',
           'TYPE_AVX_EFAXp_2_TWO_PBIS', 'API_BITE_TRANSFER',
           'API_ERR_HS_XFER_HEADER_NOT_IN_RANGE', 'INTPTR_MAX',
           'API_REP_ABS_TIME', 'API_ERR_NO_CTX_FOUND',
           'API_RT_MODE_HALT', 'API_CAL_XMT_HIGHRES_RANGE',
           'API_EF_ERR_TYPE_WORDCOUNT', 'WINT_MAX',
           'ty_api_rt_bh_info', 'API_ERR_QUEUE_EMPTY',
           'ty_api_hs_bc_mode_ctrl', 'ty_api_hs_reset_info',
           'ty_api_scope_trg', 'API_ERR_SUBPARAM5_IS_NULL',
           'API_SYSTAG_RESUME', 'API_ERR_INVALID_DISCRETE',
           'ty_api_hs_bc_error', 'AI_MAIN_LCA_VER', 'API_OFF',
           'API_ERR_FOFE_OT_SHUTDOWN', 'TY_BOARD_INFO_IS_DBTE',
           'API_OK', 'ty_api_hs_rt_err', 'AiLong',
           'API_TRACK_CLR_UDF', 'API_HS_XMT_RT_POS',
           'API_DYTAG_FCT_POS_TRIANGLE', 'API_BC_HLT_NO_HALT',
           'MAX_HS_MODECODE', 'API_BSP_NOT_COMPATIBLE',
           'API_HS_BC_ERRSPEC_BCBITS_MASK',
           'API_BUF_WRITE_TO_CURRENT', 'intptr_t',
           'AI_PLATFORM_XMC_AYS', 'API_ERR_SUBPARAM6_IS_NULL',
           'API_BM_STROBE_ON_HFI', 'TY_API_HS_BM_REC',
           'API_SYSTAG_XFERID_MASK', 'API_FLASH_SECTOR_APX_TARGET_SW',
           'API_BC_FWI_DJZ', 'TY_API_RESET_INFO',
           'TY_BOARD_INFO_CHANGE_AMPL_HIGH_RES',
           'API_BM_INVERT_RESULT', 'API_BITE_ERR_HS_INT_SIM_RTBC',
           'API_UPDATE_DEV_CON_FAILURE',
           'API_ERR_PARA_WPOS_NOT_IN_RANGE', 'MAX_HS_BUFFER_ID',
           'API_ERR_SUBPARAM10_NOT_IN_RANGE', 'API_MODE_DDL',
           'DBG_MUTEX', 'INT64_MIN', 'ty_api_rt_err', 'TYPE_API3910',
           'API_ERR_FRAME_FID_NOT_IN_RANGE',
           'API_ERR_SYSTAG_MIN_NOT_IN_RANGE', 'ty_api_track_scan_out',
           'API_HS_RT_ENABLE_INT_ERR', 'API_RT_TYPE_RECEIVE_SA',
           'API_ERR_DMA_INVALID_MEMORY', 'API_RESET_WITHOUT_SIMBUF',
           'UINT_LEAST32_MAX', 'TY_API_BC_ERR',
           'TY_API_RT_MSG_ALL_DSP', 'API_ERR_PARAM5_NOT_IN_RANGE',
           'MAX_HS_STARTDEL', 'TY_API_SCOPE_WAIT_STATE',
           'TY_API_SCOPE_BUFFER_TYPE', 'UINT32_MAX',
           'MIN_HS_RT_MODE_CTRL', 'API_HS_BM_ERR_TRG_POS',
           'ty_api_rep_status', 'API_DYTAG_FCT_SAWTOOTH_8_HIGH',
           'TYPE_AVX_EFAXp_2_DS_TWO_PBIS', 'TY_API_DISCR_INFO',
           'SCOPE_STATUS_STOPPED', 'MAX_BM_ENTRY_TYPE',
           'AI_TARGET_VER', '__USE_XOPEN2K', 'API_MILSCOPE_TYPE_AYX',
           'TY_API_SCOPE_BUFFER_HANDLER', 'API_RESET_SRVREQ_CNT',
           'API_ERR_IRIG_HOUR_NOT_IN_RANGE', 'ty_api_sync_cnt_set',
           'API_RT_SA_USAGE_INIT', 'API_HS_BM_AW_TRG_POS',
           'AI_PLATFORM_ANET_AYS', 'rt_info_tag', 'TY_MIL_COM',
           'API_HS_XMT_MID_MASK', 'API_BITE_ERR_DA_CONV_BUSB',
           'API_BITE_ERR_DA_CONV_BUSA', 'API_BC_ERRSPEC_BPOS_MASK',
           'TYPE_AXC1553_4', 'AiFloat', 'MIN_EF_SWITCHTYPE', 'HIWORD',
           'TYPE_ACX_EFAXp_2_DS_TWO_PBIS', 'ty_ir_capabilities_b',
           'ty_api_gen_io_test_seq_tbl', 'API_HS_CTX_STATUS_FAIL',
           'INT16_C', 'DBG_PARAMCHK', 'MAX_API_BC_MFRAME_ID',
           'TYPE_ACX1553_4_TWO_PBIS', 'AI_FIRMWARE_VER_BIU1',
           'MIN_SYSTAG_ID', 'AI_PLATFORM_PMC_32',
           'API_ERR_TYPE_MANCHESTER_HIGH', 'API_ERR_WRONG_ACK_SIZE',
           'DBG_READREC', 'API_LLA_PTRA_MASK',
           'API_FIRMWARE_BIU2_VER_MASK', '_STDINT_H',
           'API_SCOPE_MODE_GREATER_THAN', 'API_BM_ENTRY_TIMETAG_HIGH',
           'API_HS_GPIO_CMD_SYS1_END', 'XFER_DESC_FIELD_CW1',
           'XFER_DESC_FIELD_CW2', 'TYPE_APM1553_1',
           'ty_api_hs_bc_xfer_status_ex', 'API_MODE_DSUB_CONNECT',
           'MAX_ERR_BCBITS', 'BE32_TO_HOST', 'MIN_DATA_WORDS',
           'API_BSP_WRONG_LCA1_SW', 'MAX_TCB_TRI',
           'API_CHN_SINGLE_3910_QUAD_1553', 'TY_API_QUEUE_BUF',
           'ty_api_hs_bm_status', 'API_BSP_WRONG_BIU3_SW',
           'API_HS_RCV_MID_POS', 'API_HS_CTX_PULSE_MAX',
           'API_HS_GAP_POS', 'api_scope_offsets', 'API_IRIG_ON_BOARD',
           'TY_API_RT_MSG_DSP', 'API_ERR_POS1_NOT_IN_RANGE',
           'ty_api_hs_track_prealloc_out', 'MAX_BM_ACT_ENTRY',
           'API_RT_RSP_PRI_BUS', 'AI_REMOTE_DLL_VER',
           'API_ERR_HS_HSERR_TYPE_NOT_IN_RANGE',
           'ty_api_ef_resp_sim_sframe', 'API_BM_TIMETAG_MSEC_MASK',
           'API_CHN_SINGLE_EFEX_SINGLE_1553', 'NUM_SCOPE_SAMPLES',
           'ty_api_track_prealloc_out', 'MIN_BIU',
           'ty_api_hs_bm_fw_mon_buffer_entry', 'TY_API_HS_RESET_INFO',
           'API_HS_LSIR_POS', 'API_DEVICE_MODE', 'API_BM_ENTRY_FOUND',
           'UINT_LEAST16_MAX', 'API_BC_FWI_EFEX_XFER',
           'API_ERR_TIMEOUT', 'API_INT_HS', 'API_QUEUE_SIZE_1',
           'API_HS_RT_EFA_PROTOCOL', 'INT_FAST32_MAX',
           'API_SREC_INIT', 'API_BC_SWXM_SREQ_MASK',
           'API_BC_MODIFY_WRTYP_32BIT', 'AI_PLATFORM_PMC_32_QUAD',
           'MAX_CONT_TRACK_NB', 'API_RT_MC_TYPE_XMT',
           'API_HS_GPIO_CMD_RESET', 'API_INT_LS', 'API_BC_MODE',
           'API_ERR_PARAM7_IS_NULL', 'TY_API_BC_XFER_READ_IN',
           'API_HS_BM_BCTYPE_RTRT', 'USB_8051_RAM',
           'API_RESET_ERR_STAT_BITS',
           'API_ERR_BCDYTAG_TAGFCT_NOT_IN_RANGE',
           'TY_MIL_ERR_TRANSLATE_TABLE', 'MAX_TRACK_PREALLOC_STATES',
           'ty_api_bm_stack_fnd', 'SIZE_MAX',
           'API_ERR_PARAM2_NOT_IN_RANGE', 'API_BIU_5',
           'MAX_INIT_MODE', 'API_PBI_ONBOARD_FOFE', 'ty_api_bc_acyc',
           'API_DATA_QUEUE_STATUS_ENABLED', 'MAX_ACYC_MODE',
           'ty_api_ef_bc_sync_time_get',
           'API_DATA_QUEUE_CTRL_MODE_FLUSH', 'AiAddr',
           'API_ERR_HS_XFER_RT_NOT_IN_RANGE', 'TYPE_AMC1553_T',
           'API_SRV_OS_VER_WINNT', 'INTERRUPT_FUNC',
           'API_HS_RT_MODE_MAILBOX', 'API_CAL_CPL_WRAP_AROUND_LOOP',
           'API_BM_ENTRY_BUSWORD_MASK', 'TYPE_AMC1553_1',
           'API_HS_GPIO_CMD_SDEV', 'TYPE_AMC1553_2',
           'ty_api_hs_rt_mid_status', 'TYPE_AMC1553_4',
           'API_DYTAG_FCT_SYNC_COUNTER', 'API_BITE_ERR_INT_ADDR',
           'MAX_HS_ERR_TYPE', 'API_ERR_ADDRESS_OUT_OF_RANGE',
           'API_EF_SWITCH_TO_EFA_TEMPORARY',
           'API_BITE_ERR_WALKING_BIT', 'API_ERR_WRONG_DEVICE',
           'API_ERR_ACK_SIZE_UNDEFINED', 'API_HS_CTX_REG_BITE',
           'MIN_API_BC_MFRAME_ID',
           'API_DEVICE_MODE_IS_SINGLEFUNCTION', 'ty_api_hs_bc_xfer',
           'API_BC_ERRSPEC_BCBITS_MASK',
           'ty_api_hs_bc_xfer_status_queue', 'uintmax_t',
           'API_FLASH_SECTOR_APX_LCA', 'TY_API_LIB_INFO',
           'API_BITE_ERR_HS_BCRT_ISOL_AA', 'API_EF_TRIG_EFA_CMD',
           'MAX_DATA_BITPOS', 'API_BM_MSG_ERR_LBIT',
           'API_UPDATE_IDLE', 'API_ERR_SUBPARAM7_NOT_IN_RANGE',
           'AI_SUBDLL2_VER', 'API_ERR_HS_XFER_FIRST_GAP_NOT_IN_RANGE',
           'TY_BOARD_INFO_APPLICATION_TYPE',
           'API_ERR_BCDYTAG_MAX_NOT_IN_RANGE',
           'API_DATA_QUEUE_GEN_ASP', 'API_BIG_ENDIAN_MODE',
           'API_HS_BC_MSG_TAG_FCHK_MASK', '_SVID_SOURCE',
           'API_BC_ERRSPEC_WPOS_MASK', 'MAX_BUF_NB_IN_FIFO',
           'TY_API_GENIO_TEST_SEQ_TBL', 'API_SCOPE_MODE_BIU_BM',
           'TY_API_FILE_UPLOAD_IN', 'API_SCOPE_MODE_BIU_BC',
           'TY_API_HS_RT_MID_STATUS',
           'ty_api_intr_loglist_lld_union_t',
           'ty_api_intr_loglist_llc_t',
           'API_BC_MODE_INSERT_MC17_SYNC_CNT',
           'API_HS_BM_DW_TRG_MASK', 'API_EF_TRIG_EFEX_CMD',
           'API_ERR_INVALID_ID', 'API_DATA_NOT_VALID',
           'TY_PNP_CALLBACK_FUNC_PTR', 'ty_api_intr_loglist_llc_b',
           'TYPE_AXE1553_1', 'TYPE_AXE1553_2', 'ty_api_bc_mframe_ex',
           'API_BITE_ERR_TIMING_MFRM_50',
           'API_ERR_HS_LSERR_ERRSPEC_BPOS_NOT_IN_RANGE',
           'API_SCOPE_OPR_CHANNEL_A100', 'API_BM_MSG_ERR_GAP',
           'API_BITE_ERR_HS_INT_PAT_55', 'API_TRACK_TYPE_MUX_TRACK',
           'TYPE_ACE3910Xp', 'API_BC_XFER_BUS_SECONDARY',
           'TYPE_ACX_EFA_2_TWO_PBIS', 'ty_api_hs_bc_xfer_status_info',
           'API_SQM_ONE_ENTRY_ONLY', 'DBG_INIT', 'HOST_TO_BE32',
           'API_MODULE_29', 'API_MODULE_28', 'AI_DEVICE_AYS_ASP_MA',
           'MIN_INSTR_NR', 'API_MODULE_21', 'API_MODULE_20',
           'API_MODULE_23', 'API_MODULE_22', 'API_MODULE_25',
           'API_MODULE_24', 'API_MODULE_27',
           'TY_API_HS_BC_XFER_STATUS_INFO', 'API_BSP_WRONG_BIU4_SW',
           'DBG_WRITEREP', 'API_HS_HSIR_POS', 'MAX_HS_STROBE_MODE',
           'API_ERR_HS_HSXMT_NOPRE_NOT_IN_RANGE', 'API_MILBUS_PROT_A',
           'ty_api_ef_bc_xfer_x_hs', 'API_MILBUS_PROT_B',
           'API_HS_BM_TRG_OR', 'API_RT_STATUS_BUSY', 'uintptr_t',
           'MAX_API_BC_MFRAME', 'AI_DEVICE_AYI', 'TYPE_AXI1553_1',
           'API_BM_ENTRY_SW_PRIMARY', 'AI_DEVICE_AYE', 'UINT64_C',
           'MAX_BM_FTW_CON', 'API_MODULE_6',
           'TY_API_HS_TRACK_SCAN_OUT', 'API_ERR_PARAM1_IS_NULL',
           'API_ERR_TYPE_BIT_CNT_LOW', 'AI_DEVICE_AYX',
           'ty_api_systag', 'MIN_API_BC_XFRAME', 'AI_DEVICE_AYS',
           'API_ERR_BIP1_START_FAILED', 'API_HS_BM_TRG_NOT_OCCURED',
           'ty_api_rt_status_dsp', 'TY_MIL_COM_ACK', 'API_CPL_DIR',
           'TY_API_BC_DYTAG', 'API_ERR_INVALID_KEY',
           'AI_PLATFORM_PCI_SHORT_ZYNQMP',
           'AI_PLATFORM_XMC_ZYNQMP',
           'API_SYSTAG_STEP_KEEP_LAST', 'API_SREC_ERR_WRONG_TYPE',
           'TY_E_DEVICE_GROUP', '__STRING', 'API_INVALID_SLOT_NUMBER',
           'MAX_API_BC_FW_XFER_DESC_SIZE', '__GNUC_PREREQ',
           'API_HS_XMT_RT_MASK',
           'API_ERR_DQUEUE_REM_HANDLE_NOT_IN_RANGE',
           'API_ERR_DQUEUE_ASP_SIZE_NOT_IN_RANGE',
           'API_ERR_PARA_BUF_NOT_IN_RANGE', 'MAX_HS_ERR_WPOS',
           'API_ERR_DMA_ALREADY_RUNNING', 'API_BM_ET_NRESP_MASK',
           'API_BM_TRG_NOT_OCCURED', 'TYPE_ACX3910Xp_2',
           '__va_arg_pack', 'API_HS_WCM_ACTION_WORD',
           'API_BITE_ERR_BC_BROAD_ELECT_B_BM',
           'SCOPE_STATUS_WAIT_FOR_TRIGGER', 'API_BC_SRVW_ENA',
           'API_HS_GAP_MASK', 'API_BITE_ERR_HS_TIMING_CORR',
           'MAX_CPL_MODE', 'API_RESET_USE_COUNTER_MODE_2',
           'ty_api_rt_sa_msg_read_in', 'API_MODE_SINGLE_RT',
           'API_BITE_ERR_TRANSFER', 'API_PROTOCOL_EFEX',
           'API_BM_FLT_MODE_INDEPENDENT', 'MAX_SCOPE_OPR_MODE',
           'ty_api_bm_act_dsp', 'API_ERR_TYPE_PARITY',
           'API_QUEUE_SIZE_256', 'int_fast32_t',
           'API_ERR_PARAM3_NOT_IN_RANGE',
           'API_SCOPE_OPR_CHANNEL_B100', 'TY_API_EF_BC_RESP_SIM',
           'MAX_WCNT', 'uint8_t', 'TY_API_GEN_IO_BOARD',
           'TYPE_API1553_1', 'AI_PLATFORM_VMEX_B',
           'ty_api_gen_io_test_seq_array', 'ty_api_rt_dytag',
           'MAX_HS_FMOD_CONT', 'API_SERVER_NOT_REGISTERED',
           'API_HS_CTX_REG_PULSE', 'API_SYSTAG_XFERID_POS',
           'INT_FAST16_MIN', 'MAX_HS_MID', 'API_BM_CAPMODE_ONLY',
           '_ISOC11_SOURCE', 'API_ERR_DQUEUE_ASP_SIZE_TOO_BIG',
           'INT_LEAST16_MAX', 'API_BITE_ERR_HS_RTRT_ISOL_AA',
           'API_SCOPE_SAMPLE_PACKET', 'TY_API_BC_BH_INFO',
           'TY_API_HS_BH_MODIFY', 'MAX_BC_MODE_CTRL',
           'API_ERR_WRONG_CMD_SIZE', '_POSIX_SOURCE',
           'TY_API_RT_STATUS_DSP', 'API_HS_BUF_ALLOC_FAILED',
           'MAX_API_INT_TYPE', 'API_BRW_RBUS_MASK', 'API_BM_SIGN_POS',
           'API_CPL_NET', 'API_DATA_QUEUE_STATUS_CAPMODE',
           'API_SERVER_MASK', 'MAX_TRACK_LEN', 'API_PXI_SET_TRG',
           'API_HS_CTX_STATUS_ICMD_POS', 'API_PROTOCOL_3910',
           'TY_API_HS_BM_STACK_FND', 'AiPtrDiff',
           'ty_api_intr_loglist_llc_union',
           'ty_api_bc_modify_instruction', 'API_SYSTAG_SA_MID_POS',
           'GET_STREAM_ID', 'TYPE_APE1553_1', 'TYPE_APE1553_2',
           'API_SREC_START_ONCE', 'API_BC_TYPE_RTBC',
           'AI_PLATFORM_USB', 'API_BSM_TX_GO_ON_NEXT',
           'API_BITE_ERR_HS_BC_BROAD_ISOL_BA',
           'API_BITE_ERR_HS_BC_BROAD_ISOL_BB', 'ty_api_bc_fw_instr',
           'MIN_ERR_BPOS', 'TY_API_RT_SA_EVENT_QUEUE',
           'APIEF_BC_XFER_TYPE_E_RTBRMIXED', 'TY_API_BM_STACK_DSP',
           'API_BM_ASSERT_TRG_INT', 'API_HS_GPIO_CMD_ALL_ON',
           'API_DATA_QUEUE_STATUS_LOC_BUF_ERR', 'MAX_PXICON_TRGDEST',
           'API_ERR_ERRSPEC_WPOS_NOT_IN_RANGE',
           'API_ERR_INVALID_MODE', 'TY_API_GEN_IO_BOARD_TYPE_LIST',
           'API_HS_MAX_GPIO_DEVICES', 'API_LLA_PSA_MASK',
           'MIN_HS_XFER_TYPE', 'API_ERR_RSP_NOT_IN_RANGE',
           'API_MODE_RESTART_TARGET_SW', 'API_SCOPE_RATE_EVERY',
           'API_BC_FWI_HALT', 'API_CHN_QUAD_1553', 'API_BM_SIGN_NEG',
           'TY_API_HS_BC_XFER_READ_IN', 'API_UPDATE_FINISHED',
           'MAX_PXICON_TRGSOURCE', 'API_HS_BM_TRG_AND',
           'TY_BOARD_INFO_MILSCOPE_TYPE', 'ty_tagserverinfo',
           'TY_API_BM_TCB', 'API_ERR_BIP2_START_FAILED',
           'DBG_DISABLED', 'API_BC_REPORT_ERR_FRAME_COD',
           'TY_API_BC_STATUS_DSP', '__USE_FORTIFY_LEVEL',
           'APIEF_BC_XFER_TYPE_MCRT', 'API_BC_START_EXT_TRIGGER',
           'MAX_CLR', 'AI_PLATFORM_VXI_D', 'MAX_SYSTAG_FCT',
           'AI_PLATFORM_VXI_C', 'INT32_MIN',
           'API_ERR_PRIMARY_COUPLING_NOT_INTERNAL',
           'API_BC_ERRSPEC_BCBITS_POS', 'AI_PLATFORM_PMC_AYS',
           'API_DEVICE_MODE_IS_SIMULATOR', 'API_SREC_ERR_CHKS',
           'API_ERR_DQUEUE_READ_NOT_BUFFERED', 'API_MODULE_32',
           'API_MODULE_30', 'API_MODULE_31', 'MAX_SCOPE_CAP_MODE',
           'API_ERR_SUBPARAM7_IS_NULL', 'API_BITE_INTERN_SELFTEST',
           'API_ERR_HS_LSERR_TYPE_NOT_IN_RANGE',
           'TYPE_ACX_EFAXp_2_TWO_PBIS', 'API_HS_HSCHN_POS',
           'API_EF_SWITCH_TO_EFEX_TEMPORARY', 'API_REP_RLT_LOW_TT',
           'API_DYTAG_EFA_MODE', 'APIEF_BC_XFER_TYPE_E_RTBR',
           'API_BITE_ERR_HS_INT_ADDR', 'API_ERR_RT_NOT_AVAILABLE',
           'DBG_INFO', 'API_ERR_BIP1_BOOT_FAILED', 'DBG_SERVER',
           'API_TRG_PXI4', 'API_TRG_PXI5', 'API_TRG_PXI6',
           'API_TRG_PXI7', 'API_TRG_PXI0', 'API_TRG_PXI1',
           'API_TRG_PXI2', 'API_TRG_PXI3', 'API_BC_INSTR_TRANSFER',
           'API_BM_MSG_PERR_MASK', 'API_SYSTAG_FCT_POS_TRIANGLE',
           'API_BITE_ERR_INT_PAT_55', 'API_RT_ENABLE_SA_INT_ERR',
           'API_DATA_QUEUE_STATUS_ASP_OVERFLOW', 'API_RT_SA_DIS',
           'API_ERR_PARAMETER_OUT_OF_RANGE', 'TY_API_HS_BM_RT_ACT',
           'AI_PLATFORM_PMC_32_ASP',
           'API_BITE_ERR_HS_INT_MON_ERR_CNT_REP',
           'API_HS_RT_ENABLE_INT_XFER',
           'ty_api_hs_bc_xfer_status_xfer',
           'AI_PLATFORM_CPCIX_3U_PCIE_BASED',
           'ty_irig_capabilities_union', 'API_HS_BM_DW_TRG_POS',
           'MAX_HS_MID_INT', 'AI_UNUSED', 'API_DYTAG_FCT_XMT_WORD',
           'API_ERR_SYSTAG_MAX_NOT_IN_RANGE', 'TY_API_BC_FW_RSRC',
           'API_SYSTAG_RTADDR_MASK',
           'TY_BOARD_INFO_CAN_HIGH_RES_ZERO_CROSSING', 'AI_DLL_VER',
           'TY_API_SCOPE_OFFSETS', 'MAX_BSM', 'API_BITE_ERR_PAGING',
           'API_HS_BM_BCTYPE_RTBC', 'API_CHN_SINGLE_1553',
           'API_BM_WRITE_STC', 'ty_api_gen_io_board_type',
           'API_LLC_TR', 'API_HS_GPIO_CMD_DEV_START',
           'API_DATA_QUEUE_STATUS_REM_OVERFLOW', '__AI_MAX_VERSIONS',
           'TYPE_ACI3910', 'API_TRG_RT_CHN2', 'uint_fast64_t',
           'API_BM_ET_ISYNC_MASK', 'API_ERR_TYPE_WCLO_EXT',
           'API_EF_ERR_TYPE_ILLEGAL_WORDCOUNT',
           'API_ERR_ERRTYPE_NOT_IN_RANGE', 'API_SREC_ERR_NO_STRING',
           'API_QUEUE_SIZE_2', 'API_QUEUE_SIZE_4', 'API_QUEUE_SIZE_8',
           'INT_FAST32_MIN', 'MIN_HS_CONT_TRACK_NB',
           'API_ERR_HS_HSCHN_NOT_IN_RANGE', 'MAX_BM_SMODE',
           'API_SCOPE_COUPLING_EXTERN',
           'API_SYSTAG_STEP_CHECKSUM_1760',
           'API_BC_MODIFY_WRTYP_26BIT', 'API_DEVICE_MODE_NA',
           'API_ERR_HS_DYTAG_WMODE_NOT_IN_RANGE',
           'ty_api_hs_rx_select', 'LPVOID', 'L_WORD', 'TY_RT_INFO',
           'MIN_BUFFER_ID', 'UINT_FAST8_MAX',
           'API_HS_BM_TRG_EVENT_OCCURED', 'MAX_HS_ERR_BCBITS',
           'API_BITE_ERR_HS_INT_SIM_ERR_CNT', 'API_BC_FWI_RET',
           'TY_API_BC_MFRAME', 'API_ERR_CAPFSIZE_NOT_IN_RANGE',
           'API_BITE_ERR_ADDRESSING', 'AI_PLATFORM_CPCIX_6U',
           'API_BITE_ERR_DATA_PATTERN', '__GLIBC_MINOR__',
           'API_ERR_BCDYTAG_MIN_NOT_IN_RANGE', 'API_BM_ET_TX_MASK',
           'API_DYTAG_STD_MODE', 'API_BC_FWI_CMFT',
           'API_BITE_ERR_BC_BROAD_ELECT_A',
           'API_ERR_HS_XFER_FIRST_GAPMODE_NOT_IN_RANGE',
           'AI_DEVICE_AYS_ASP', 'API_ERR_BCDYTAG_STEP_NOT_IN_RANGE',
           'API_ERR_MALLOC_FAILED',
           'API_ERR_HS_XFER_SECOND_GAP_NOT_IN_RANGE',
           'API_BC_FWI_XFER', 'API_HS_ERR_TYPE_BIT_CNT_HIGH',
           'ai_int64_union_ll', 'API_HS_WCM_STATUS_QUEUE',
           'API_BQM_HOST_CONTROLLED', 'MAX_SCOPE_SAMPLING_RATE',
           'API_BC_MODIFY_COMPC__LE', 'MAX_HS_MBUF',
           'API_BM_MODE_HFI_INT', 'AiSize', 'API_BC_MODIFY_COMPC__LT',
           'MAX_DATASET_BUF_ID', 'API_BM_CAPMODE_FILTER',
           'API_HS_GAPMODE_POS', 'AI_BOOTSTRAP_VER', 'API_RT_SA_ENA',
           'TY_E_VERSION_ID', 'API_PXI_SET_TTSRC_INTERNAL',
           'API_BM_MSW_SYNC_MASK', 'TY_MIL_COM_WITH_VALUE',
           'ty_api_hs_bc_xfer_x_ls', 'API_BITE_ERR_BOARD_ENABLE',
           'MIN_SKIP_CNT', 'API_RT_SWM_AND', 'API_HS_BM_HW_TRG_MASK',
           'UINT_LEAST64_MAX', 'UINT_FAST64_MAX',
           'API_ERR_ERRSPEC_BPOS_NOT_IN_RANGE', 'Ai_UInt64_Union',
           'API_ERR_REPLAY_NOT_AVAILABLE',
           'API_ERR_PARAM7_NOT_IN_RANGE',
           'API_DATA_QUEUE_TSW_OFFSET_START', 'API_BITE_ALL',
           'API_HS_RT_MODE_CONFIGURED_DYTAGS',
           'API_RT_ENABLE_SA_INT_XFER', 'API_ERR_PARAM11_IS_NULL',
           '__USE_LARGEFILE', 'API_BC_ACYC_SEND_ON_TIMETAG',
           'SCOPE_BUFFER_FLAG_TRIGGER', '_FEATURES_H',
           'API_SYSTAG_FCT_CHECKSUM', 'TY_API_BM_DYTAG_MON_READ_CTRL',
           'TY_API_BM_STACK_FND', 'TY_BOARD_INFO_MAX',
           'API_ERR_PARAM2_IS_NULL', 'API_UTIL_CMD_READ_SW_VERSIONS',
           'API_ERR_SERVER_INVALID_VERSION',
           'ty_api_bm_dytag_mon_def', 'ty_api_data_queue_write',
           'TY_BOARD_INFO_BOARD_CONFIG', 'API_HS_XMT_MID_POS',
           'API_BITE_ERR_HS_INT_SIM_BCRT',
           'API_BITE_ERR_HS_INT_MON_ERR_CNT',
           'TY_BOARD_INFO_OFFS_GLOBAL', 'AI_MEMTYPE_RX_MEM',
           'MAX_SYSTAG_STEP_FCT5', 'MAX_SYSTAG_STEP_FCT7',
           'MAX_SYSTAG_STEP_FCT6', 'MIN_FIFO_ID',
           'API_ERR_ERRSPEC_CONTIG_NOT_IN_RANGE',
           'API_BITE_ERR_MODE_ISOL_A_BM', 'API_BM_TRG_SPEC_RXA_MASK',
           'API_BM_READ_CTP', 'TY_BOARD_INFO_HAS_EXTERNAL_IRIG',
           'API_UPDATE_FAILED', 'MAX_TCB_SOT',
           'MAX_BM_STACK_ENTRY_READMODE', 'TY_IR_CAPABILITIES',
           'DBG_ALL', 'API_FILE_FLAG_APPEND',
           'TG_EXT_SET_REPLAY_ADDR', 'UINT8_C',
           'API_ERR_TCBINV_NOT_IN_RANGE', 'API_SREC_CHKS_OK',
           'API_ERR_ACK', 'AI_PLATFORM_CPCIX_3U_AYS',
           'API_DEVICE_MODE_FULL', 'API_SCOPE_COUPLING_STUB_3V',
           'API_MODE_RES_EXEC_SYS', 'TY_API_HS_RX_SELECT',
           'API_MODE_SHOW_PARAM_TABLE', 'SCOPE_BUFFER_PRIMARY',
           'API_BC_START_INSTR_TABLE_DBA',
           'API_ERR_RCV_SA_NOT_IN_RANGE', 'API_RT_SWM_OR',
           'API_ERR_PARAM10_NOT_IN_RANGE', 'API_LLC_MODECODE',
           'TY_API_GET_MEM_INFO', 'API_BM_PULSE_STROBE_ON_TRG',
           'API_MEM_PART_ERR', 'API_ERR_SERVER',
           'API_BM_STOP_EVENT_OCCURED', 'ty_api_hs_rt_mid_read_in',
           'AI_PLATFORM_PCIE_CARD', 'TY_API_OPEN',
           'TY_API_VERSION_INFO', 'API_RT_RSP_SEC_BUS',
           'api_scope_trigger_strobe_type',
           'TY_API_HS_RT_MID_STATUS_QUEUE', 'TYPE_APE1553_4',
           'API_MODULE_MASK', 'API_BUF_READ_FROM_LAST',
           'ty_api_bc_mframe', 'API_BM_MSG_ERR_MODECODE',
           'TY_API_SERVERINFO', 'TY_API_RT_ERR',
           'TY_API_HS_RT_MID_STATUS_INFO', 'TYPE_APX1553_4',
           'API_BSM_TX_KEEP_SAME', 'TYPE_APX1553_1',
           'API_CAL_CPL_DIRECT', 'API_LLC_RT_SUB',
           'TY_BOARD_INFO_PARTNO', 'API_BM_ET_IWGAP_MASK',
           'ty_api_mem_biu_size', 'TY_API_HS_BC_MODE_CTRL',
           'api_file_upload_in', 'API_BITE_ERR_SHARED_RAM_CMD',
           'API_ERR_FRAME_XID_NOT_IN_RANGE',
           'ty_coupling_capabilities_union',
           'API_ERR_CMD_NOT_SUPPORTED_BY_FW',
           'API_HS_GPIO_CMD_SYS2_START', 'API_BM_READ_ETP',
           'API_CHN_SINGLE_3910_DUAL_1553',
           'ty_api_hs_bc_xfer_read_in', 'TY_BOARD_INFO_COUPLING',
           'API_BC_REPORT_NO_ERR', 'MAX_IR_EVENT_BUF',
           'TYPE_AMCE1553_4', 'INT_LEAST64_MAX', 'TYPE_AMCE1553_1',
           'TYPE_AMCE1553_2', 'HINSTANCE',
           'API_BITE_ERR_TIMING_MFRM_1', 'TYPE_AVX3910Xp_2',
           'API_TARGET_ERROR_OFFSET', 'API_RT_REPORT_ERR_FRAME_COD',
           'API_CPL_WRAP', 'MAX_MSG_BUF', 'MAX_HS_GAP_TIME_MODE_01',
           'API_DYTAG_FCT_NEG_TRIANGLE', 'AI_PLATFORM_ANET',
           'API_PBI_APX_MILSCOPE', 'API_HS_CTX_RISE_MIN',
           'MAX_BM_MSGFLT_MODE', 'API_BSP_WRONG_SYS_W98_W2000_SW',
           'API_ERR_ADDR_NOT_VALID', 'API_BSP_WRONG_SYS_WNT_SW',
           'API_BM_MENSW_TRIG_MASK', 'AI_MEMTYPE_REF_MEM',
           'TY_API_QUEUE_TABLE', 'API_BC_TYPE_RTRT',
           'API_BITE_SHARED_RAM', 'MIN_HS_BUFFER_ID',
           'API_HS_BC_MODE_CONFIGURED_DYTAGS', 'API_MODULE_7',
           'API_MODULE_4', 'API_MODULE_5', 'TY_API_BC_XFER',
           'API_MODULE_8', 'API_MODULE_9', 'MAX_TCB_EOM',
           'ty_api_ef_bc_xfer_x_common', 'TYPE_AEC1553_1',
           'API_ERR_INVALID_DRIVER_HANDLE', 'APIEF_BC_XFER_TYPE_MCBR',
           'API_HS_BC_TYPE_BCRT', 'API_DEVICE_MODE_SF', 'API_DIS',
           'API_SYSTAG_FCT_NEG_TRIANGLE', 'AI_PLATFORM_PCIE',
           'API_ERR_PARAM11_NOT_IN_RANGE', 'API_BM_SEARCH_CMD2_MASK',
           'MAX_HEADER_ID', 'API_BM_ET_ALTER_MASK', 'int_fast16_t',
           'AI_PLATFORM_PCIX', 'API_ERR_TYPE_HSSA', 'INT32_C',
           'API_MEMTYPE_LOCAL', 'TYPE_AVX1553_2', 'TYPE_AVX1553_1',
           'MAX_API_SQM_MODE', 'TY_API_HS_TRACK_DEF_OUT',
           'TYPE_AVX1553_4', 'API_HS_RT_EFEX_PROTOCOL',
           'TYPE_AVX1553_8', 'MIN_HS_ERR_BPOS', '__USE_XOPEN2K8XSI',
           'API_HS_RCV_RT_POS', 'API_BITE_ERR_GLOBAL_RAM_BIU',
           'TY_VERSION_OUT', 'API_EF_TRIG_S', 'DBG_TRACE_PBAPRO',
           'API_HS_CTX_REG_FALL', 'API_LLA_START_MASK', 'AiUInt',
           'API_ERR_TYPE_PHYSICAL_ERROR_SUPPRESSION',
           'TYPE_ACX_EFA_1_DS_TWO_PBIS', 'API_MODULE_10',
           'API_MODULE_11', 'API_MODULE_12', 'API_HS_BM_AW_TRG_MASK',
           'API_MODULE_14', 'API_MODULE_15', 'API_MODULE_16',
           'API_FILE_FLAG_OVERWRITE', 'API_MODULE_18',
           'API_MODULE_19', 'MAX_ERR_TYPE',
           'API_ERR_FRAME_CNT_NOT_IN_RANGE', 'API_ERR_HOST_TO_TARGET',
           'API_ERR_MEMORY_INVALID', 'uint32_t', 'MIN_ERR_BCBITS',
           'API_TRACK_RTADDR_POS', 'TY_API_DATA_QUEUE_WRITE',
           'API_IRIG_PRESENT', 'MAX_HS_MIDTYPE',
           'API_HS_BM_ENTRY_LS_CORRELATION', 'ty_api_reset_info',
           'API_SCOPE_COUPLING_STUB', 'MAX_DATA_WORDS', 'AI_ANS_VER',
           'API_DSUB_RS232', 'API_BM_MODE_START_EVENT_INT',
           'API_RT_MODE_CONFIGURED_DYTAGS', 'API_ERR_AGAIN',
           'API_BITE_ERR_GLOBAL_RAM_BM', 'TYPE_ASE1553_1',
           'ty_irig_capabilities_b', 'TYPE_ASE1553_4',
           'API_ERR_SUBPARAM8_NOT_IN_RANGE', 'MAX_EXECSYS_MODE',
           'API_PBI_APX_STANDARD', 'API_ERR_SUBPARAM3_NOT_IN_RANGE',
           'API_LLC_RT_ADDR', 'API_HS_ERR_TYPE_GAP',
           'API_ERR_TCBEOM_NOT_IN_RANGE', 'API_MODULE_13',
           'API_BITE_ERR_BC_BROAD_ISOL_A_BM', 'MIN_CONTIG_GAPERROR',
           'ty_api_bm_dytag_mon_read_ctrl', 'AI_DEVICE_GROUP_COUNT',
           '__ty_e_device_group', 'TYPE_ACX3910Xp',
           'TY_API_HS_TRACK_PREALLOC_IN', 'API_ERR_WCNT_NOT_IN_RANGE',
           'API_FLASH_SECTOR_EF_BIU1', 'API_INT_REPLAY',
           'API_FLASH_SECTOR_EF_BIU2', 'MAX_BM_MSGFLT_FORMAT',
           'ty_api_ef_bc_xfer_stat', 'API_BITE_TIMING',
           'API_BM_ET_STAT_MASK', 'AI_TARGET_OS_VER',
           'TYPE_AVX3910_2', 'API_RT_STATUS_HALTED',
           'API_LLA_STAT_MASK', 'TYPE_AVX_EFA_2_DS_TWO_PBIS',
           'intmax_t', 'API_MAX_MEMORY_BARS',
           'SCOPE_BUFFER_SECONDARY', 'API_TRG_BM_CHN2',
           'API_CAL_BUS_PRIMARY', 'MAX_BQM',
           'ty_api_bm_dytag_mon_act', 'ty_api_rt_sa_status_queue',
           'int_least8_t', 'TY_API_EF_BC_RESP_SIM_MODE',
           'API_QUEUE_SIZE_64', 'API_ERR_SYSTAG_STEP_NOT_IN_RANGE',
           'MAX_HS_SW_EXCEPTION', 'ty_api_bc_dytag', 'ty_api_bc_xfer',
           'ty_api_ef_rt_descriptor', 'MAX_TCB_INDEX',
           'API_HS_CTX_FALL_MIN', 'MAX_SCOPE_TRG_MODE',
           'API_MODULE_17', 'MAX_API_SERVER_PER_SYSTEM', 'AiInt',
           'API_ERR_PARAM10_IS_NULL', 'API_HS_BC_MSG_TAG_BUS_MASK',
           'ty_api_open', '__USE_BSD', 'TY_API_MEM_BIU_INFO',
           'API_DYTAG_FCT_SAWTOOTH_8_LOW', '__CONCAT',
           'API_SCOPE_MODE_LESS_THAN_SAMPLES', 'ptrdiff_t',
           'API_BC_RSP_AUTOMATIC', 'API_ERR_OS_NOT_SUPPORTED',
           'XFER_DESC_FIELD_TRTYPE', 'API_HS_HSXMT_STARTDEL_MASK',
           'TY_VER_NO', 'API_RESET_WITHOUT_MONITOR',
           'API_BUF_NOT_USED', 'API_IRIG_INTERN',
           'API_BC_HLT_HALT_ON_ERR_EXCEPT', 'API_HS_GPIO_CMD_BITE',
           'API_MILSCOPE_TYPE_AYE', 'MAX_DATA_WORDPOS',
           'API_SCOPE_OPR_CHANNEL_B', 'API_SCOPE_OPR_CHANNEL_A',
           'API_DATA_QUEUE_STATUS_RESUMED', 'API_DYTAG_FCT_DISABLE',
           'API_MILSCOPE_TYPE_NONE', 'API_BM_TRG_SPEC_DW_MASK',
           'API_SPECIAL_VER_MASK', 'API_MEMTYPE_IO',
           'API_ERR_PARAM13_IS_NULL',
           'API_BITE_ERR_HS_BC_BROAD_ELECT_AA', 'AI_DEVICE_AYE_ASP',
           'API_TRACK_DONT_CLR_UDF', 'API_PBI_DUAL_1553_ONE_BIU',
           'API_INT_RT', 'ty_ir_capabilities_union',
           'API_BC_RSP_NO_SW2_EXPECTED', 'int8_t', 'TYPE_AVI1553_2',
           'TYPE_AVI1553_1', 'TYPE_AMCX1553_4',
           'API_BC_SWXM_DBCA_MASK', 'API_RT_ENABLE_DUAL_REDUNDANT',
           'ty_api_ef_bc_internal', 'API_HS_BC_MSG_TAG_ITIME_MASK',
           'API_ERR_NO_SPACE_LEFT', 'UINT_LEAST8_MAX',
           'ty_api_rt_sa_status_info', 'ty_e_mem_type',
           'ty_api_hs_bc_status', 'API_BM_ET_LCNT_MASK',
           'API_HS_RX_SEL_2_VALID_PRE', 'TY_API_SET_MEM_INFO',
           'API_BM_MENSW_STOP_MASK', 'MAX_PROTOCOL_MODE',
           'API_ERR_HS_HSIR_NOT_IN_RANGE', 'API_BC_START_IMMEDIATELY',
           'TY_API_RT_BH_INFO', 'API_BM_MSG_FLT_FORMAT_1',
           'TY_API_EF_RT_DESCRIPTOR', 'API_BM_MSG_FLT_FORMAT_0',
           'API_BM_NO_OVERFLOW', 'API_ERR_LS_CMD_ON_HS_BIU',
           'AiHandle', 'API_ERR_TYPE_WORD_CNT_HIGH',
           'API_BM_MSG_ERR_ILLEGL', 'API_SYSTAG_STEP_CHECKSUM_PLUS',
           'AI_MEMTYPE_TX_MEM', 'ty_api_bc_srvw_con',
           'API_ERR_PARAM5_IS_NULL', 'MAX_SREC_MODE',
           'API_DATA_QUEUE_STATUS_LOC_OVERFLOW',
           'API_SCOPE_MODE_COMMAND_SYNC', '__va_arg_pack_len',
           'TYPE_ANET3910Xp', 'API_BITE_ERR_BUS',
           'API_SCOPE_QUEUE_SIZE', 'ty_ver_no', 'AiUInt32',
           'SIG_ATOMIC_MIN', 'API_HS_BM_LS_TRG_POS',
           'API_BC_REPORT_ERR_SW2_NOT_RCV', 'TY_GETMEM_RT_DESCR',
           '_ATFILE_SOURCE', 'TYPE_ACX1553_1', 'TYPE_ACX1553_2',
           '__glibc_unlikely', 'TY_API_EF_BM_STACK_ENTRY',
           'TYPE_ACX1553_8', 'api_scope_trg_strobe',
           'API_SCOPE_TRG_STROBE_MON',
           'API_HS_ERR_TYPE_ALTERNATE_BUS',
           'API_HS_GPIO_CMD_SYS1_START',
           'API_HS_ERR_TYPE_END_DEL_NO_END',
           'TYPE_AVX1553_4_TWO_PBIS', 'API_BC_ERRSPEC_BPOS_POS',
           'API_SREC_START',
           'API_ERR_HS_HSERR_ERRSPEC_WPOS_NOT_IN_RANGE',
           'MAX_SCOPE_TRG_SRC', 'API_ERR_CON_NOT_ALLOWED', 'API_ERR_BUFFER_TOO_SMALL',
           'API_BC_TIC_INT_ON_STAT_EXCEPT',
           'API_HS_BUF_ALLOC_SUCCESSFUL',
           'API_ERR_SUBPARAM10_IS_NULL', 'API_BM_TRG_SPEC_ST_MASK',
           'API_SYSTAG_SUSPEND', 'ty_api_track_scan_in', 'MAX_LS_BUS',
           'TYPE_ACX1553_4_DS_TWO_PBIS', 'API_BC_SRVW_DIS',
           'TYPE_ACX3910', 'TY_API_HS_BC_ERROR', 'API_PROTOCOL_1553',
           'TY_API_SCOPE_SAMPLE_PACKET', '__ASMNAME',
           'ty_api_hs_track_def_out', 'int_least16_t',
           'MAX_HS_DYTAG_WORD_MODE', 'API_BM_ET_HCNT_MASK',
           'TY_API_RT_DYTAG', 'API_SRV_OS_VER_WIN98',
           'API_DEVICE_MODE_SIM', 'API_FLASH_SECTOR_APX_BIU2',
           'API_FLASH_SECTOR_APX_BIU1', 'INT_FAST64_MIN',
           'API_ERR_FUNCTION_NOT_SUPPORTED',
           'API_BITE_ERR_INT_PAT_00', 'NUM_SCOPE_SAMPLE_PACKETS',
           'UINTMAX_C', '__USE_POSIX199309', 'MIN_HS_BC_MODE_CTRL',
           'MAX_API_BC_XACYC', 'API_BITE_ERR_HS_INT_MON_TX_CNT_REP',
           'ty_driver_info', 'MIN_DYTAG_MON_ID', 'API_BC_FWI_SKIP',
           'API_ERR_DQUEUE_ASP_OPEN', 'ty_api_hs_rt_mid_status_queue',
           'API_SYSTAG_FCT_COMP', 'MAX_DATA_QUEUE_CONTROL_MODE',
           'API_BC_FWI_WTRG', 'API_ERR_TYPE_MANCHESTER_LOW',
           'API_ERR_BC_NOT_AVAILABLE', 'MAX_API_DLL_INST',
           'API_HS_CTX_OVRSHOOT_MAX', 'API_NET_IO_ERR', '__PMT',
           'uint_fast8_t', 'ty_api_rt_msg_all_dsp_rt',
           'API_SCOPE_OPR_CHANNEL_AB', 'API_RT_ENABLE_MONITORING',
           'API_HS_RT_DISABLE_INT', 'ty_api_hs_rt_bh_info',
           'INT8_MAX', 'TY_BOARD_INFO_IS_HS_REDUNDANT',
           'API_BUF_FULL', 'API_RT_MODE', 'TY_API_RT_MODE_CTRL',
           'API_RT_MODE_OPERATION_CTRL', 'API_CHN_DUAL_EFEX',
           'API_RT_TYPE_ALL', 'TY_API_RT_SA_STATUS_EX',
           'API_BITE_ERR_HS_TIMING_INIT', 'MIN_HS_MSGSIZE',
           'AI_VERSION_STRINGL', 'API_HS_BC_TYPE_BCBR',
           'API_HS_BM_TRG_BF_OCCURED', 'MAX_HS_RT_MODE',
           'API_BM_TTMODE_LOW_HIGH', 'INTPTR_MIN',
           'API_ERR_DQUEUE_REM_BUFTYPE_NOT_IN_RANGE',
           'ty_api_bc_error', 'int_least64_t',
           'API_BM_ENTRY_CW_SECONDARY', 'API_BITE_PASSED',
           'TY_API_DISCOVER_RESPONSE', 'TY_API_TRACK_PREALLOC_OUT',
           'AI_FPGA_VER', 'API_RT_TYPE_TRANSMIT_MODECODE',
           '__USE_XOPEN_EXTENDED', 'API_BM_MODE_NO_INT',
           'API_UTIL_CMD_EF_TIME_OUT_DEF', 'INT_LEAST32_MAX',
           'TY_API_INI_INFO', 'API_BM_WRITE_AEI', 'API_BIU_4',
           'API_BIU_7', 'API_BIU_6', 'API_BIU_1', 'API_BIU_3',
           'API_BIU_2', 'API_BIU_8', 'TY_BOARD_INFO_DISCRETE_CNT',
           'TY_API_HS_BC_ERR',
           'API_ERR_HS_LSERR_ERRSPEC_BCBITS_NOT_IN_RANGE',
           'API_BC_START_RT_MODECODE', 'AI_MEMTYPE_GLOBAL_EXTENSION',
           'api_scope_trg_ex',
           'API_ERR_HS_LSERR_ERRSPEC_WPOS_NOT_IN_RANGE',
           'MAX_EF_SWITCHTYPE', 'ty_api_gen_io_board_type_list',
           'API_ERR_BIU_NOT_ACTIVE', 'API_TOGGLE_BUS_KEEP',
           'API_ERR_IRIG_MIN_NOT_IN_RANGE',
           'ty_api_ef_bm_stack_entry', 'AI_DEVICE_AMC_ASP',
           'API_BC_INSTR_STROBE', 'MIN_HS_BH_BUF_SIZE',
           'INT_FAST8_MIN', 'API_BITE_ERR_HS_INT_TT_FAST',
           'ty_api_gen_io_get_board_out', 'TY_API_E_UPDATE_STATUS',
           'XFER_DESC_FIELD_CW1_CW2', 'API_BC_FWI_CALL',
           'API_ERR_SUBPARAM3_IS_NULL', 'WINT_MIN',
           'TY_COUPLING_CAPABILITIES', 'API_EF_BM_CMD_TRG_POS',
           '__USE_ISOC99', 'API_UTIL_CMD_WRITE_NOVRAM',
           'TYPE_AXE1553_4', 'TY_API_IRIG_SOURCE',
           'API_BITE_ERR_BC_TIMEOUT_ISOL_B_BM',
           'ty_api_bc_fw_rsrc_desc', 'ty_api_hs_bm_act',
           'INT_LEAST8_MAX', 'API_RT_SA_XFER_INT',
           'API_ERR_INVALID_DEVICE_STATE', 'API_HS_BM_LS_TRG_MASK',
           'API_TBM_TRANSFER', 'MIN_BC_FRAME_TIME', 'AI_PCI_LCA_VER',
           '__USE_XOPEN', 'API_BUF_EMPTY',
           'API_DATA_QUEUE_CTRL_MODE_STOP', 'DBG_DQUEUE',
           'ty_api_intr_loglist_entry', 'TY_API_HS_BC_XFER_INFO',
           'MAX_HS_TRACK_LEN', 'TYPE_AVI3910',
           'AI_PLATFORM_XMC_NOREPLAY_NOERROR', 'API_BM_BUSY',
           'ty_api_hs_bc_xfer_status', 'TYPE_ACX_EFA_1_TWO_PBIS',
           'TY_API_RT_SA', 'API_ERR_PARAM8_IS_NULL', 'INT16_MAX',
           'API_ERR_HS_XFER_XFERTYPE_NOT_IN_RANGE',
           'API_ERR_QUEUE_OVERFLOW', 'TY_API_HS_REP_STATUS',
           'API_BM_ENTRY_DW_SECONDARY', 'API_BM_MSW_STOP_MASK',
           'API_BM_MSW_EVENT_MASK', 'TY_API_BM_INI_MSG_FLT_REC',
           'API_MODE_SET_TRANSP_INTR', 'ty_api_hs_track_scan_out',
           'API_PBI_SINGLE_1553_DBTE', 'API_BC_FWI_DELAY',
           'TY_API_BC_MODE_CTRL', 'API_LLC_TRANS_ID',
           'TY_API_EF_BC_XFER_STATUS',
           'API_SCOPE_TRG_STROBE_DISCRETE',
           'API_ERR_PARAM13_NOT_IN_RANGE',
           'API_BM_MBUF_ENTRY_EC_MASK',
           'API_SYSTAG_STEP_CHECKSUM_XOR', 'API_SCOPE_STATUS',
           'API_HS_BC_ERRSPEC_BPOS_MASK', 'int_fast64_t',
           'API_CPL_TRF', 'API_SCOPE_MODE_BIU', 'API_BUF_RT_MSG',
           'API_DATA_QUEUE_ID_MIL_SCOPE', 'API_ERR_INVALID_RT_SA',
           'API_HS_BUF_ENTRY_HEADER_SIZE',
           'API_HS_BC_MSG_TAG_WCNT_MASK', 'API_BUF_READ_FROM_CURRENT',
           'TY_API_REP_STATUS', 'TY_API_HS_BM_ACT',
           'ty_api_track_read_out', 'API_BM_MSG_ERR_BIT_SET',
           'TY_API_TRACK_SCAN_IN', 'API_BC_TYPE_BCRT',
           'AI_PLATFORM_VMEX_A', 'API_HS_GPIO_RESET_INFO',
           'API_RCV_BUS_PRIMARY', 'API_HS_MAX_DATA_WORDS',
           'MAX_HS_ERR_BPOS', 'API_ERR_CREATE_EVENT', '__USE_ISOC95',
           'TYPE_AXC1553_2', 'TY_API_HS_BC_XFER_STATUS_EX',
           'API_ERR_INVALID_CON', 'MAX_HS_WPOS', 'API_INT_BC',
           'TYPE_AXC1553_1', 'TY_API_HS_TRACK_DEF_IN',
           'API_BITE_ERR_HS_TRANSFER', 'API_INT_BM',
           'API_ERR_DQUEUE_LOC_MEMSIZE_NOT_IN_RANGE',
           'TY_API_RT_SA_STATUS_INFO', '__USE_SVID',
           'API_HS_CAL_CHANNEL_A', 'API_HS_CAL_CHANNEL_B',
           'AI_PLATFORM_PCI_E_1L', 'API_IRIG_NOT_PRESENT',
           'TY_API_EF_RT_MC_DEF', 'API_MODULE_26', 'MAX_HS_NOPRE',
           'TY_API_BC_SRVW_CON', 'TY_API_BM_STACKP_DSP', 'WORD',
           'API_REP_HALTED', 'API_HSSA_DEF',
           'TY_API_TRACK_PREALLOC_IN', 'PTRDIFF_MIN',
           'ty_api_pxi_con', 'API_ERR_BM_NOT_AVAILABLE',
           'APIEF_BC_XFER_TYPE_EXRTBR',
           'API_BITE_ERR_HS_INT_TT_TIMEOUT', 'MAX_CONTIG_GAPERROR',
           'API_REP_NO_INT', 'TY_API_HS_BM_FW_MON_BUFFER_ENTRY',
           'API_BC_BUF', 'TY_API_BC_ACYC', 'API_HS_RX_SEL_FW_DEFAULT',
           'AI_MEMTYPE_SHARED', 'API_DEVICE_MODE_IS_NOREPLAY_NOERROR',
           'MAX_HS_WCM', 'MAX_API_C1760_C02',
           'TY_API_BC_XFER_EVENT_QUEUE', 'MAX_SYSTAG_MODE',
           'API_TRG_BM_HS', 'AI_PLATFORM_PCI_SHORT', 'TYPE_AME1553_1',
           '__USE_EXTERN_INLINES', 'API_SQM_AS_QSIZE',
           'API_BC_MODIFY_TYPE_JUMP', 'API_ERR_WRONG_MODULE',
           'API_HS_FMOD_NORM', '__REDIRECT_NTH_LDBL',
           'API_BC_TYPE_MASK_TRANSFER', 'ai_uint64_union',
           'API_ERR_BIP2_BOOT_FAILED', 'API_HS_BC_TYPE_STATUS_ENTRY',
           'ty_api_bc_xfer_status_ex', 'ty_mil_com_ack_with_value',
           'AI_PLATFORM_PCIE_PCIX_BASED', 'DWORD',
           'MIN_CONTIG_ZEROERROR', 'API_HS_RX_SEL_8_VALID_PRE',
           'API_BM_ET_ERR_MASK', 'API_HS_BC_MSG_TAG_MERR_MASK',
           'TYPE_AXI1553_2', 'API_ERR_SUBPARAM9_IS_NULL',
           '_XOPEN_SOURCE_EXTENDED', 'API_BITE_ERR_INT_MILBUS',
           'ty_api_gen_io_get_boards_in', 'API_ERR_PARAM9_IS_NULL',
           'API_ERR_INVALID_HANDLE', 'API_ERR_XID_NOT_IN_RANGE',
           'API_BM_ET_PAR_MASK', 'API_BC_MODIFY_WRTYP_16BIT',
           'API_HS_MIN_DATA_WORDS', 'API_BM_SEARCH_DATA_MASK',
           'ty_api_board_capabilities', 'TY_VER_INFO', 'AiULong',
           'API_ERR_TIC_NOT_IN_RANGE', 'API_ERR_TYPE_DATA_SYNC',
           'TY_API_EF_BC_SYNC_TIME_DEF', 'TY_BOARD_INFO_SIZE_GLOBAL',
           'ty_api_intr_regs', 'MIN_DATA_BITLEN',
           'API_ERR_RTDYTAG_MAX_NOT_IN_RANGE',
           'API_ERR_TYPE_BUS_SWITCH', 'API_HS_CTX_PULSE_MIN',
           'API_CAL_BUS_SECONDARY', 'MAX_SCOPE_TRG_TBT',
           'API_TRACK_TYPE_BC', '_BSD_SOURCE',
           'API_ERR_RTDYTAG_TAGFCT_NOT_IN_RANGE',
           'TYPE_AVX1553_2_TWO_PBIS', 'MAX_HS_BH_BUF_SIZE',
           'API_SCOPE_MODE_DISCRETES',
           'GET_LOCAL_MODULE_HANDLE_KEEP_HS_FLAG',
           'AI_DESCRIPTION_STRINGL', 'TYPE_AVX_EFAXp_4_TWO_PBIS',
           'API_INT_TRG_TT', 'API_ERR_TYPE_NO_INJECTION',
           'API_BITE_ERR_HS_BC_BROAD_ELECT_AA_BM',
           'TY_BOARD_INFO_DEVICE_TYPE', '__USE_LARGEFILE64',
           'MAX_SW_MASK_CONTROL', 'API_ERR_NO_MODULE_EXTENSION',
           'API_BM_ENTRY_GAP_MASK', 'API_BM_MBUF_ENTRY_TYPE_MASK',
           'API_HS_LSIR_MASK', 'TY_API_SCOPE_TRG_EX',
           'API_CHN_DUAL_3910', 'API_UTIL_CMD_SWITCH_EFA_EFEX',
           'API_BM_HALTED', 'MAX_RETRY',
           'AI_PLATFORM_MINI_PCIE_CARD_AP', 'ty_api_version_info',
           'int_fast8_t', 'API_HS_GPIO_CMD_SYS2_END',
           'API_DSUB_TRG_IN', 'API_INT_BC_BRANCH',
           'API_ERR_HS_HSERR_ERRSPEC_BPOS_NOT_IN_RANGE',
           'MAX_API_MODULE', 'API_REP_CET', 'AiUInt16',
           'Ai_Int64_Union', 'API_EF_SWITCH_TO_EFA', 'INTMAX_MAX',
           'ty_api_ef_bc_resp_sim_mode', 'ty_api_queue_table',
           'API_BM_WRITE_HTM', 'API_TRG_RT_CHN1', 'AI_DEVICE_AMC',
           'API_TRG_RT_CHN3', 'API_TRG_RT_CHN4', 'API_FLASH_OK',
           'API_ERR_TYPE_GAP', 'ty_version_out',
           'TY_API_GEN_IO_DEV_VEN_LIST', 'API_BM_WRITE_HTC', '__bos',
           'API_RT_ENABLE_SIMULATION', 'API_MODE_BMINI_CLEAR_BUFFER',
           'API_PBI_3910', 'API_CAL_XMT_FULL_RANGE_PRI',
           'api_device_config', 'TY_API_PXI_CON', 'int16_t',
           'AI_MONITOR_VER', 'API_EF_BM_HW_TRG_MASK', '__warnattr',
           'API_FLASH_SECTOR_EF_LCA', 'API_EF_RTMODE_DUAL',
           'API_BM_TRG_SPEC_WPOS_MASK', 'TYPE_APX1553_2',
           'SCOPE_WAIT_TIMEOUT', 'API_BSM_RX_DISCARD',
           'ty_api_ef_bc_internal_mode',
           'TY_API_HS_BC_XFER_STATUS_XFER', 'API_BM_TIMETAG_SEC_MASK',
           'API_BC_ACYC_SEND_IMMEDIATELY', 'AI_MEMTYPE_GLOBAL_DIRECT',
           'API_BRW_BUFSTAT_MASK', 'API_ERR_SCOPE_DMA_STATUS_BUSY',
           'ty_api_hs_track_scan_in', 'API_ERR_HID_NOT_IN_RANGE',
           'API_ERR_FRAME_INSTR_NOT_IN_RANGE',
           'TY_API_BC_XFER_STATUS_INFO', 'MIN_RT_MODE_CTRL',
           'API_ENA_INIT', 'API_HS_CTX_REG_VERSION', 'UINTPTR_MAX',
           'API_ERR_MAXIMUM', 'API_RT_SING', 'uint16_t',
           'API_ERR_WRONG_BIU', 'API_HS_ERR_TYPE_END_DEL_INV',
           'INT16_MIN', 'AI_MEMTYPE_GLOBAL', 'API_SYSTAG_BITNB_POS',
           'API_BM_WRITE_ETI', 'API_LCA_BIU1_VER_MASK',
           'API_BITE_ERR_HS_BCRT_ISOL_AB',
           'APIEF_BC_XFER_TYPE_EERTRT', '__USE_MISC',
           'TY_API_SCOPE_TRIGGER_STROBE_TYPE',
           'API_ERR_PARAM6_NOT_IN_RANGE', 'MAX_HS_MSGIDTYPE',
           'API_BM_ET_GAP_MASK',
           'API_ERR_HS_LSERR_CONTIG_NOT_IN_RANGE', 'TY_API_INTR_REGS',
           'API_RT_SWM_NXW_AND', 'AI_PLATFORM_CPCI_3U',
           'TY_API_MEM_BIU_SIZE', 'MAX_RT_SA', 'AiReturn',
           'ty_api_hs_bh_modify',
           'API_ERR_ERROR_INJECTION_NOT_AVAILABLE',
           'API_ERR_SYSTAG_BPOS_NOT_IN_RANGE', 'TY_API_TRACK_DEF_OUT',
           'API_BM_TRG_SPEC_CW2_MASK', 'API_BM_MSG_NO_ERR',
           'TY_API_EF_BC_INTERNAL_MODE', 'UINT16_MAX',
           'API_HS_LSCHN_MASK', 'LPDWORD', 'UINT_FAST32_MAX',
           'API_REP_REC_AREA_OFFSET', 'API_SCOPE_SRC_PRIMARY',
           'API_ERR_PARAM14_NOT_IN_RANGE', 'ty_api_hs_rt_mode_ctrl',
           '__USE_POSIX199506', 'API_ERR_DMA_DEST_INVALID',
           'API_RT_MODE_BUSY', 'API_BITE_ERR_HS_INT_MON_TX_CNT',
           'ty_api_hs_track_read_out',
           'API_RESET_ONLY_IF_NOT_ALREADY_RESETTED', 'IS_HS_ACCESS',
           'API_SERVER_REGISTERED', 'AI_PLATFORM_CPCIE_3U_ZYNQMP',
           'TY_BOARD_INFO_SERIAL', 'MAX_RT_SA_TYPE', 'INT_FAST16_MAX',
           'API_ERR_POS1_GREATER_THAN_POS2', 'AiBool32',
           'API_SCOPE_COUPLING_EXTERN_3V',
           'API_CHN_SINGLE_EFEX_DUAL_1553', 'INT_LEAST16_MIN',
           'MAX_DYTAG_FCT', 'TY_API_SCOPE_BUFFER_FLAGS',
           'API_BC_INSTR_SKIP', 'APIEF_BC_HS_XFER',
           'API_EF_SWITCH_OK', 'API_SCOPE_OFFSET_COMP_GET',
           'MAX_LS_IR', 'API_BITE_ERR_BC_BROAD_ELECT_B',
           'API_ERR_TYPE_ZERO_CROSS_NEG', 'API_HS_BC_ECW_TYPE_MASK',
           'TY_API_SCOPE_CALIBRATION_INFO',
           'SCOPE_BUFFER_FLAG_FILLED', 'API_HS_CTX_STATUS_DRDY_POS',
           '__REDIRECT_LDBL', 'MAX_HS_BUS', 'ty_api_hs_systag',
           'AI_PLATFORM_MINI_PCIE_CARD', 'ty_api_track_def_in',
           'API_BITE_ERR_HS_INT_TT_SLOW', 'API_BC_FWI_RESMF',
           'MAX_SCOPE_TRG_NB_SAMPLES', 'TY_API_DRIVER_INFO',
           'API_ERR_HS_CMD_ON_LS_BIU', 'TY_API_INTR_EVENT_LIST',
           'API_ERR_CMD_NOT_FOUND', 'API_LLA_UPDATE_MASK',
           'API_BM_SEARCH_STAT_MASK', '__USE_ATFILE',
           'API_ERR_IRIG_DAY_NOT_IN_RANGE',
           'API_ERR_DMA_WRITE_NOT_SUPPORTED', 'DBG_CLOSE',
           'API_DEVICE_MODE_NOREPLAY_NOERROR',
           'API_HS_RT_TYPE_MODECODE', 'API_BM_START_EVENT_OCCURED',
           'INT64_MAX', 'TY_API_EF_BM_TRG_COND', 'api_irig_source',
           'ty_api_bc_fw_rsrc', 'API_LITTLE_ENDIAN_MODE',
           'AI_DEVICE_ZYNQMP_ASP', 'API_BC_START_FAST',
           'TY_API_GENIO_TEST_SEQ_ARRAY', 'API_BUF_BC_MSG',
           'API_HS_LSCHN_POS', 'API_ERR_NAK', 'API_BSIZEM_DYNAMIC',
           'API_CHN_SINGLE_3910', 'TYPE_AVX_EFAXp_1_DS_TWO_PBIS',
           'API_STREAM_8', 'ty_api_board_info', 'API_STREAM_2',
           'API_STREAM_3', 'API_STREAM_1', 'API_STREAM_6',
           'API_STREAM_7', 'API_STREAM_4', 'API_STREAM_5',
           'ty_api_ver_info_values', 'API_RT_DISABLE_SA',
           'API_BITE_ERR_INT_WRONG_PBI', 'TY_API_BM_REC',
           '_ISOC95_SOURCE', 'DBG_ERRORMSG',
           'API_BM_TIMETAG_HOURS_MASK', 'ty_api_c1760_con',
           'MAX_API_BM_MSG_FLT_REC', 'API_BC_GAP_MODE_FAST',
           'ty_api_set_mem_layout', 'MAX_SYSTAG_CON',
           'ty_api_scope_setup', 'AiShort',
           'API_HS_ERR_TYPE_MANCHESTER_HIGH', 'API_MAX_PHYSICAL_BIU',
           'TY_API_EF_BC_INTERNAL_FRAME', 'TY_API_BM_DYTAG_MON_DEF',
           'N23API_SCOPE_SAMPLE_PACKET3DOT_2E',
           'API_SYSTAG_FCT_POS_RAMP', 'AiUInt64',
           'API_ERR_HS_LSCHN_NOT_IN_RANGE', '__SYSCALL_WORDSIZE',
           'ty_api_hs_track_def_in', 'MAX_GENIO_TEST_SEQ_ARRAY_SIZE',
           'API_HS_RX_SEL_EXT_LOGIC',
           'API_BC_ACYC_SEND_AT_END_OF_FRAME',
           'API_SYSTAG_SA_MID_MASK',
           'CREATE_MODULE_HANDLE_FROM_LOCAL', 'API_LLA_STOP_MASK',
           'MAX_RESET_CONTROL', 'TYPE_ACX_EFAXp_1_TWO_PBIS',
           'API_HS_RX_SEL_LS_AW', 'API_HS_RT_MODE_SIMULATION',
           'MAX_ERR_BPOS', 'ty_api_bm_ini_msg_flt_rec',
           'TYPE_ACX1553_2_TWO_PBIS', 'API_ERR_SXH_NOT_IN_RANGE',
           'API_BC_SRVW_MULTIPLE', 'INT8_C', 'TY_API_BH_MODIFY',
           'AiInt64', 'GET_LOCAL_MODULE_HANDLE',
           'ty_api_hs_track_read_in', 'TY_API_BC_XFER_STATUS_EX',
           'MAX_RT_ADDR', 'MAX_TCB_TT', 'API_BM_NO_STROBE',
           'ty_api_bm_tcb', 'AI_PLATFORM_PCIE_4L_AYS', 'USB_EEPROM',
           'API_SYSTAG_STEP_2S_COMP', 'API_TOGGLE_BUS_ALT',
           'uint_least64_t', 'API_RESET_ERROR_BITS', '__USE_UNIX98',
           'MAX_HS_BM_ENTRY_TYPE', 'API_HS_RT_TYPE_TRANSMIT_MID',
           'API_SYSTAG_FCT_NEG_RAMP', 'ty_api_ef_bc_resp_sim',
           'MAX_SCOPE_TRG_HOLDOFF', 'TYPE_AVX_EFA_1_TWO_PBIS',
           'AI_IO_LCA_VER_BIU4', 'AI_IO_LCA_VER_BIU3',
           'AI_IO_LCA_VER_BIU2', 'AI_IO_LCA_VER_BIU1',
           'MAX_GAP_TIME_MODE_01', 'TY_API_DATA_QUEUE_STATUS',
           'API_MODE_TIMETAG_SOURCE', 'ty_api_data_queue_status',
           'ty_api_bh_modify', 'API_BITE_ERR_HS_INTERN_SELFTEST',
           'API_REP_BUSY', 'API_ERR_INVALID_RT_SA_TYPE',
           'API_SYSTAG_FCT_DISABLE',
           'API_CAL_CPL_EXT_WRAP_AROUND_LOOP', 'API_HS_HSIR_MASK',
           'ty_api_intr_loglist_lld_union', 'ty_api_data_queue_read',
           'TY_BOARD_INFO_BIU_COUNT', 'API_BM_TRG_HS_EVENT',
           'API_BITE_ERR_INT_PAT_FF', 'API_HS_BC_TYPE_RTBC',
           'API_ERR_1760_BUFID_NOT_IN_RANGE', 'API_MODULE_1',
           'API_ERR_FRAME_ID_NOT_IN_RANGE', 'API_MAX_LOGICAL_BIU',
           'API_HS_BUF_ID_OUT_OF_RANGE', 'API_HS_BC_TYPE_RTBR',
           'API_HS_CTX_STATUS_ICMD', 'API_ERR_MYMON_ERROR',
           'API_ERR_DQUEUE_LOC_BUFTYPE_NOT_IN_RANGE',
           'API_TRACK_TYPE_RT', 'int64_t',
           'API_HS_ERR_TYPE_NO_INJECTION', 'AiBoolean',
           'ty_api_lib_info', 'API_ERR_DEVICE_NOT_FOUND',
           'API_BQM_STAY_LAST', 'AI_PLATFORM_CPCI_6U',
           'API_PROTOCOL_1553_A', 'API_DATA_QUEUE_CTRL_MODE_RESUME',
           'API_BM_MODE_STOP_EVENT_INT', 'API_BC_FWI_WMFT',
           'API_BC_FW_MAKE_INSTR', 'API_ERR_HS_XFER_MID_NOT_IN_RANGE',
           'ty_api_hs_rep_status', 'API_ERR_SERVER_CONNECT',
           'MIN_SYSTAG_STEP_FCT7', 'MAX_BUS', 'INT_REQUEST_COUNT_MAX',
           'TY_API_BOARD_INFO', 'API_RT_SA_USAGE_BUF_INIT',
           'TY_API_HS_RT_STATUS_DSP', 'API_ERR_INVALID_SIZE',
           'API_BC_XFER_BUSB', 'API_BC_XFER_BUSA',
           'ty_api_mem_sim_buf', 'ty_api_hsls_bc_xfer',
           'TY_API_PACKET_UPDATE_STATUS_OUT',
           'API_BITE_ERR_HS_BCRT_ISOL_BB', 'ty_api_rt_sa_msg_dsp',
           'API_BITE_ERR_HS_BCRT_ISOL_BA', 'API_BM_MSG_ERR_BOTH_CHN',
           '_BITS_WCHAR_H', 'API_BM_ENTRY_NOT_FOUND', 'API_MODULE_2',
           'API_ERR_PARAM3_IS_NULL', 'API_ERR_1760_C02_NOT_IN_RANGE',
           'MAX_HS_INT_MODE', 'API_MODULE_3', 'AI_SYS_DRV_VER',
           'TY_IRIG_CAPABILITIES', 'TY_API_RT_SA_MSG_DSP',
           'APIEF_BC_XFER_TYPE_EXRTRT', 'API_BM_TRG_EXTERNAL_EVENT',
           'BSWAP32', 'API_BITE_ERR_RTRT_ISOL_B_BM',
           'API_TRACK_SA_MID_POS', 'ai_uint64_union_ull']
