import numpy as np


class BmMessage:
    def __init__(self):
        self._data     = []
        self._ttl      = None
        self._tth      = None
        self._cw1      = None
        self._cw2      = None
        self._sw1      = None
        self._sw2      = None
        self._error    = []

    def dump(self):
        if not self._ttl == None: print("TTL: 0x%08x" % (self._ttl))
        if not self._tth == None: print("TTH: 0x%08x" % (self._tth))
        if not self._cw1 == None: print("CW1: ", self._cw1 )
        if not self._cw2 == None: print("CW2: ", self._cw2 )
        print("Data: ", [hex(x) for x in self._data] )

        if not self._sw1 == None: print("SW1: ", self._sw1 )
        if not self._sw2 == None: print("SW2: ", self._sw2 )
        if len(self._error) > 0: print("Error: ", self._error )

    def fromArray(self, input ):
        """
        Load data from numpy array
        """
        self._data = []

        if len(input) < 3:
            raise('Not enough data (%d entries)' % len(input))

        if len(input) > 38:
            raise('To much data (%d entries)' % len(input) )

        buffer_index = 0
        for i, value in enumerate(input):
            type    = (value >> 28)       # Bits 28 .. 31
            payload = (value & 0x3ffffff) # Bits  0 .. 26

            if (i == 0) and (type != 0x3) :
                raise('No time tag high found at index 0')

            if (i == 1) and (type != 0x2) :
                raise('No time tag low found at index 1')

            if( type == 0x1):
                # Error Word
                self._error.append(payload)
            elif( type == 0x2 ):
                # Time Tag Low Word
                self._ttl = payload
            elif( type == 0x3 ):
                # Time Tag High Word
                self._tth = payload
            elif( type == 0x8 ):
                # Command Word Primary
                cmd = {}
                cmd['RT']    =  ((payload>>11) & 0x1F)
                cmd['TX']    =  ((payload>>10) & 0x1)
                cmd['SA']    =  ((payload>>5) & 0x1F)
                cmd['WC']    =  ((payload)& 0x1F)
                cmd['BUS']   =  1 # Primary

                self._cw1 = cmd
            elif( type == 0x9 ):
                # Command Word 2 Primary
                cmd = {}
                cmd['RT']    =  ((payload>>11) & 0x1F)
                cmd['TX']    =  ((payload>>10) & 0x1)
                cmd['SA']    =  ((payload>>5) & 0x1F)
                cmd['WC']    =  ((payload)& 0x1F)
                cmd['BUS']   =  1 # Primary
                self._cw2 = cmd
            elif( type == 0xa ):
                # Data Word Primary
                self._data.append(payload & 0xFFFF)
            elif( type == 0xb ):
                # Status Word Primary
                sw = {}
                sw['RT']        =  ( (payload>>11) & 0x1F )
                sw['STATUS']    =  (payload & 0x7FF)
                sw['BUS']       =  1
                if self._sw1 == None:
                    self._sw1 = sw
                else:
                    self._sw2 = sw
            elif( type == 0xc ):
                # Command Word Secondary
                cmd = {}
                cmd['RT']    =  ((payload>>11) & 0x1F)
                cmd['TX']    =  ((payload>>10) & 0x1)
                cmd['SA']    =  ((payload>>5) & 0x1F)
                cmd['WC']    =  ((payload)& 0x1F)
                cmd['BUS']   =  0 # Secondary
                self._cw1 = cmd
            elif( type == 0xd ):
                # Command Word 2 Secondary
                cmd = {}
                cmd['RT']    =  ((payload>>11) & 0x1F)
                cmd['TX']    =  ((payload>>10) & 0x1)
                cmd['SA']    =  ((payload>>5) & 0x1F)
                cmd['WC']    =  ((payload)& 0x1F)
                cmd['BUS']   =  0 # Secondary
                self._cw2 = cmd
            elif( type == 0xe ):
                # Data Word Secondary
                self._data.append(payload & 0xFFFF)
            elif( type == 0xf ):
                # Status Word Secondary
                sw = {}
                sw['RT']        =  ( (payload>>11) & 0x1F )
                sw['STATUS']    =  (payload & 0x7FF)
                sw['BUS']       =  0
                if self._sw1 == None:
                    self._sw1 = sw
                else:
                    self._sw2 = sw

            else:
                raise('Unknown entry or entry not updated (%x)', value)





class BmMessageParser:
    def __init__(self):
        self._table = None

    def fromfile(self, file ):
        """
        Load data from file
        """
        data   = np.fromfile(file, dtype=np.uint32)
        return self.fromArray(data)

    def fromArray(self, data ):
        """
        Load data from numpy array
        """

        # Search all TTHigh entries
        tth_offsets = [i for i in range(data.shape[0]) if (data[i]>>28 == 0x3) ]

        # extract message arrays
        count = len(tth_offsets)

        bm_message_list = count*[BmMessage]

        for i in range(count):
            if i < count-1:
                message_range = (tth_offsets[i], tth_offsets[i+1]-1)
            else:
                message_range = (tth_offsets[i], data.shape[0])

            msg = BmMessage()
            msg.fromArray(data[message_range[0]:message_range[1]+1])
            bm_message_list[i] = msg

        return bm_message_list

