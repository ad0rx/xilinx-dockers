"""Module for replay functionality

This module handles replay functionality of
AIM MIL devices
"""


__author__ = 'Martin Haag'

from aim_mil.mil_bindings import *
import ctypes
import os

class HsReplay():
    def __init__(self, device, stream):
        self._device    = device
        self._stream    = stream
        self._file_name   = None
        self._file_offset = 0
        self._rpi_count   = 0
        self._half_buffer_size = 0x60000
        self._replay_status = TY_API_HS_REP_STATUS()


    def setup(self, replay_file, count):
        self._file_name = replay_file

        ret = self._stream.api.lib.Api3910CmdHsReplayIni( self._stream.handle, 0, 1, API_REP_HFI_INT, count );

        if ret != API_OK:
            raise AimMilError(ret, "Error: Api3910CmdHsReplayIni: %s." % self._stream.api.error(ret))

    def update_status(self):
        ret = self._stream.api.lib.Api3910CmdHsReplayStatus( self._stream.handle, ctypes.byref(self._replay_status) )

        if ret != API_OK:
            raise AimMilError(ret, "Error: Api3910CmdHsReplayStatus: %s." % self._stream.api.error(ret))

    @property
    def replay_status(self):
        self.update_status()
        return self._replay_status


    @property
    def is_running(self):
        return self._replay_status.uc_Status == API_REP_BUSY


    @property
    def reload(self):
        delta = self._replay_status.ul_RpiCnt - self._rpi_count;

        if( delta > 1 ):
            raise Exception("Error: Replay underrun")

        return True if delta == 1 else False


    @reload.setter
    def reload(self, unused ):
        self._rpi_count += 1


    def feed(self):
        '''
        Read half buffer sized data from file and feed it into the replay buffer.
        '''
        replay_status = self.replay_status

        data_written = AiUInt32()
        with open( self._file_name, "rb" ) as fp:
            c_replay_data = (AiUInt8 * self._half_buffer_size)()
            fp.seek(self._file_offset)
            read_size = fp.readinto(c_replay_data)

            self._file_offset += read_size

            replay_status.ul_Size = read_size

            if read_size > 0:
                ret = self._stream.api.lib.Api3910HsWriteRepData( self._stream.handle, ctypes.byref(replay_status), ctypes.byref(c_replay_data), ctypes.byref(data_written) )

                if ret != API_OK:
                    raise AimMilError(ret, "Error: ApiCmdBCIni: %s." % self._stream.api.error(ret))

                if data_written.value != read_size:
                    raise Exception("ApiWriteRepData only %d bytes out of %d bytes have been written" % (data_written.value, read_size))

                if self.is_running:
                    self.reload = True

