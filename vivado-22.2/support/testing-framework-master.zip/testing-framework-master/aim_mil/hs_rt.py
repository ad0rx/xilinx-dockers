"""Module for handling HS RT functionality

This module provides classes and functions for handling
the Remote Terminal functionality of AIM MIL devices
"""

__author__ = 'Martin Haag'

from aim_mil.mil_bindings import *
from aim_mil.rt import *
import ctypes
import array
import abc


class HSRT(RT):
    """
    Base class of HS RT simulation. 
    """

    def __init__(self, stream, address):
        """
        Constructor.
        Initializes common properties for different RT files
        :param stream: the stream the RT belongs to
        :param address: the RT address
        """
        super().__init__(stream, address)
        self._mids = []

    def setup(self):
        """
        Installs the remote terminal settings on hardware
        """
        super().setup()

    def release(self):
        """
        Disables a remote terminal and all of its sub-addresses, mids
        """
        for mid in self._mids:
            self._mids.release()
        del self._mids[:]

        super().release()


    def setup_mid(self, sub_type, address, word_count=32, qsize=API_QUEUE_SIZE_1 ):
        """
        Sets up a specific MID of the remote terminal
        :param address: mid-address
        :param sub_type: type of RT MID used as parameter in Api3910CmdHsRTMIDDef
        :return: instance of class RTMID
        """
        rt_mid = RTMID(self, sub_type, address, word_count, qsize)
        self._subaddresses.append(rt_mid)
        return rt_mid

    @property
    def hs_rt_status(self):
        """
        Get current status of stream's HS RT
        :return: returns dictionary with status, message and error count entries
        """
        status = TY_API_HS_RT_STATUS_DSP()
        ret = self._stream._api.lib.Api3910CmdHsRTStatus(self._stream._handle, self._address, ctypes.byref(status))

        if ret != API_OK:
            raise Exception("Error: Api3910CmdHsRTStatus: %s." % self._stream._api.error(ret))

        return dict([('messages', status.ul_HsMsgCnt), ('errors', status.ul_HsErrCnt)])

class SimulationHSRT(HSRT):

    """
    This class represents a remote terminal in simulation mode
    """

    def __init__(self, stream, address):
        """
        Constructor
        Initializes and enables a remote terminal in simulation mode on hardware
        :param stream: the stream the remote terminal belongs to
        :param address: the address of the remote terminal
        :return: instance of SimulationRT
        """
        super().__init__(stream, address)
        self._mode = API_RT_ENABLE_SIMULATION
        super().setup()

        # Enable HSSA
        self.setup_subaddr(26, API_RT_TYPE_RECEIVE_SA)


class RTMID(object):

    """
    This class represents a remote terminal MID
    """

    def __init__(self, rt, sub_type, address, word_count=32, qsize=API_QUEUE_SIZE_1):
        """
        Constructor
        Initializes and enables a remote terminal MID on hardware
        :param rt: The RT the MID belongs to
        :param sub_type: The RT MID type as used in Api3910CmdHsRTBHDef
        :param address: the MID
        :return: instance of RTMID
        """
        self._rt = rt
        self._type = sub_type
        self._address = address
        self._word_count = word_count
        self._qsize = qsize
        self._qindex = 1
        self._buffer_address = 0

        self._buffer_id = rt.stream.device.alloc_hs_buffer()

        ret = rt.stream.api.lib.Api3910CmdHsRTBHDef(rt.stream.handle,
                                                    self._buffer_id, 0, 0, 0,
                                                    qsize,
                                                    API_BQM_CYCLIC,
                                                    API_BSM_RX_KEEP_CURRENT,
                                                    API_SQM_ONE_ENTRY_ONLY, 0, 0, 0)

        if ret != API_OK:
            raise Exception("Error: Api3910CmdHsRTBHDef: %s." % rt.stream.api.error(ret))

        raw_data = array.array('H', [0] * 3)
        if sub_type == API_HS_RT_TYPE_TRANSMIT_MID:
            # Initialze FCPA/DA
            # Set FcPa/DA
            raw_data[0] = 0xC000|rt.address
            raw_data[1] = 0x8101
            raw_data[2] = 0

        index = AiUInt16()
        info  = AiUInt16()
        raddr = AiUInt32()

        for i in range(1, (1<<qsize)+1 ):
            # Allocate all the buffers within the queue
            ret = rt.stream.api.lib.Api3910CmdHsBufDef(rt.stream.handle, 
                                                        API_BUF_RT_MSG, 
                                                        self._buffer_id,          # HS HID defined with Api3910CmdHsRTBHDef
                                                        i,                        # Index in buffer queue
                                                        word_count + 3,           # Size of buffer to allocate
                                                        0,                        # Write data to first data word (fcpa/da)
                                                        3,                        # Write only 3 data words (fcpa/da)
                                                        ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(AiUInt16)), # Data array
                                                        ctypes.byref(index), ctypes.byref(info), ctypes.byref(raddr))
            self._buffer_address = raddr

            if ret != API_OK:
                raise Exception("Error: Api3910CmdHsBufDef: %s." % rt.stream.api.error(ret))

        ret = rt.stream.api.lib.Api3910CmdHsRTMIDDef( rt.stream.handle, rt.address, address, self._buffer_id, sub_type, API_RT_SA_ENA, 0)
        
        if ret != API_OK:
            raise Exception("Error: Api3910CmdHsRTMIDDef: %s." % rt.stream.api.error(ret))

    def release(self):
        """
        Disables and releases the sub-address
        """
        ret = self._rt.stream.api.lib.Api3910CmdHsRTMIDDef( self._rt.stream.handle, self._rt, self._address, self._buffer_id, self._type, API_RT_SA_DIS, 0)

        if ret != API_OK:
            raise Exception("Error: Api3910CmdHsRTMIDDef: %s." % self._rt.stream.api.error(ret))

        self._rt.stream.device.free_hs_buffer(self._buffer_id)

    @property
    def qindex(self):
        return self._qindex

    @qindex.setter
    def qindex(self, qindex):
        self._qindex = qindex

    @property
    def data(self):
        """
        Get data buffer
        :return: contents of current buffer as list of int
        """
        raw_data = array.array('H', [0] * self._word_count)
        data_read = AiUInt16()

        ret = self._rt.stream.api.lib.Api3910CmdHsBufRead( self._rt.stream.handle,
                                                        API_BUF_RT_MSG,
                                                        self._buffer_id, 
                                                        self._qindex,
                                                        3, self._word_count,
                                                        None, None,
                                                        ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(AiUInt16)))

        if ret != API_OK:
            raise Exception("Error: Api3910CmdHsBufRead: %s." % self._rt.stream.api.error(ret))

        return raw_data.tolist()

    @data.setter
    def data(self, new_data):
        """
        Set content of current buffer
        :param new_data: data values to set as list of int
        """
        index  = AiUInt16()
        info   = AiUInt16()
        offset = AiUInt32()

        raw_data = array.array('H', new_data)
        
        ret = self._rt.stream.api.lib.Api3910CmdHsBufDef(self._rt.stream.handle,
                                API_BUF_RT_MSG,
                                self._buffer_id,       # HS HID defined with Api3910CmdHsRTBHDef
                                self._qindex,          # Index in buffer queue
                                len(new_data) + 3,     # Size of buffer to update
                                3,                     # Write data to first data word after fcpa/da
                                len(new_data),         # Copy all data
                                ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(AiUInt16)), # Data array
                                ctypes.byref(index), ctypes.byref(info), ctypes.byref(offset))

        if ret != API_OK:
            raise Exception("Error: Api3910CmdHsBufDef: %s." % self._rt.stream.api.error(ret))