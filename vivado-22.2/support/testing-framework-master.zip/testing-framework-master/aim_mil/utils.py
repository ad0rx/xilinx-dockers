"""Module for replay functionality

This module handles replay functionality of
AIM MIL devices
"""


__author__ = 'Martin Haag'

from datetime import datetime
from datetime import timedelta


class Timeout:
    def __init__(self, s):
        self._end_time = datetime.now() + timedelta(seconds=s)

    def restart(self, s):
        self._end_time = datetime.now() + timedelta(seconds=s)

    def is_timed(self):
        return datetime.now() >= self._end_time
