""" Module for handling IRIG time for AIM 429 devices

This module contains classes and functions
for initialization, calculation and usage of IRIG time on AIM 429 devices
"""

__author__ = 'Jochen Pfaadt'

import ctypes


def irig_struct_to_usec( irig_struct ):
    us = 0
    us += irig_struct.microsecond
    us += irig_struct.second *                1000 * 1000
    us += irig_struct.minute *           60 * 1000 * 1000
    us += irig_struct.hour   *      60 * 60 * 1000 * 1000
    us += irig_struct.day    * 24 * 60 * 60 * 1000 * 1000

    return us


def irig_struct_low_only_to_usec( irig_struct ):
    us = 0
    us += irig_struct.microsecond
    us += irig_struct.second *          1000 * 1000
    us += irig_struct.minute *     60 * 1000 * 1000

    return us


def irig_ttlow_to_usec( ttlow ):
    us = 0
    us += ((ttlow & 0x000FFFFF))                   # usec
    us += ((ttlow>>20) & 0x3F) *      1000 * 1000  # second
    us += ((ttlow>>26) & 0x3F) * 60 * 1000 * 1000  # minute

    return us

def irig_tthigh_to_usec( tthigh):
    us = 0
    us += ((tthigh>> 0) & 0x3F)             * 60 * 1000 * 1000 # minute
    us += ((tthigh>> 6) & 0x1F)        * 60 * 60 * 1000 * 1000 # hour
    us += ((tthigh>>11) & 0x1FF)  * 24 * 60 * 60 * 1000 * 1000 # day

    return us

def irig_to_usec( tthigh, ttlow ):
    usec_h = irig_tthigh_to_usec( tthigh)
    usec_l = irig_ttlow_to_usec(ttlow)
    usec = usec_h + usec_l #- (((tthigh>> 0) & 0x3F) * 60 * 1000 * 1000)
    return usec


def usec_to_components( us ):
    day = int(us / 24 / 60 / 60 / 1000 / 1000)
    us -= int(day * 24 * 60 * 60 * 1000 * 1000)

    hour = int(us / 60 / 60 / 1000 / 1000)
    us  -= int(hour * 60 * 60 * 1000 * 1000)

    minute = int(us / 60 / 1000 / 1000)
    us -= int(minute * 60 * 1000 * 1000)

    second = int(us / 1000 / 1000)
    us    -= int(second * 1000 * 1000)

    return day, hour, minute, second, us

def usec_to_tthigh(us):
    ttag = 0
    day, hour, minute, second, us = usec_to_components( us )
    #ttag |= day<<17
    #ttag |= hour<<12
    #ttag |= minute

    ttag += day<<11
    ttag += hour<<6
    ttag += minute

    return ttag


def usec_to_ttlow_inc_min(us):
    ttag = 0
    day, hour, minute, second, us = usec_to_components( us )
    ttag += minute<<26
    ttag += second<<20
    ttag += us

    return ttag

def usec_to_ttlow(us):
    ttag = 0
    day, hour, minute, second, us = usec_to_components( us )
    #ttag += minute<<26
    ttag += second<<20
    ttag += us

    return ttag

def usec_to_ttag(us):
    tth = usec_to_tthigh(us)
    ttl = usec_to_ttlow(us)

    return tth, ttl
