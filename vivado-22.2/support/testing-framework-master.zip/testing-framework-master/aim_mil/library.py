"""Module for handling API library functionality

This module is used for handling AIM MIL C API library
specific functions via python's ctypes module.
"""


__author__ = 'Markus Melcher'

import sys
import ctypes


class Singleton(object):

    def __init__(self, decorated):
        self._decorated = decorated
        self._instance = None

    def instance(self):
        self._instance = (not self._instance is None and self._instance) or self._decorated()
        return self._instance

    def __call__(self, *args, **kwargs):
        raise TypeError('Singleton must be accessed through Instance()')


@Singleton
class Api():
    """
    This class is used for handling access to the AIM MIL
     C API library. It follows the singleton pattern, hence
     only one object of this class can be instantiated
     On creation of the singleton object, ctypes is used to load
      the C API library
    """
    def __init__(self):
        """Loads the API MIL C library via ctypes"""
        if sys.platform.startswith("linux"):
            self._lib = ctypes.cdll.LoadLibrary("libaim_mil.so")
        else:
            self._lib = ctypes.cdll.LoadLibrary("api_mil.24.dll")

    @property
    def lib(self):
        """
        Returns ctypes API library object
        :return : returns the ctypes dll object that wraps the AIM MIL API library
        """
        return self._lib

    def error(self, error_code):
        """
        Converts the API error codes to human readable descriptions
        :param error_code: the error code to return
        :return: returns the error description string
        """
        self._lib.ApiGetErrorDescription.restype = ctypes.c_char_p
        return '%s (%s)' % (self._lib.ApiGetErrorDescription(error_code), hex(error_code))

