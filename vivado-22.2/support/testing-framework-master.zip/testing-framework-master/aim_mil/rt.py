"""Module for handling RT functionality

This module provides classes and functions for handling
the Remote Terminal functionality of AIM MIL devices
"""

__author__ = 'Markus Melcher'

from aim_mil.mil_bindings import *
import aim_mil.error
import ctypes
import array
import abc


class RT(object, metaclass=abc.ABCMeta):

    """
    Abstract class that represents a remote terminal
    and comprises common functionality for different terminal types
    """

    @abc.abstractmethod
    def __init__(self, stream, address):
        """
        Constructor.
        Initializes common properties for different RT files
        :param stream: the stream the RT belongs to
        :param address: the RT address
        """
        self._stream = stream
        self._address = address
        self._subaddresses = []
        self._mode = API_RT_DISABLE_OPERATION


    def setup(self, response_time=8.0):
        """
        Installs the remote terminal settings on hardware
        """
        ret = self._stream.api.lib.ApiCmdRTIni(self._stream.handle, 0, self._address, self._mode,
                                               API_RT_RSP_BOTH_BUSSES, AiFloat(response_time), self._address << 11)

        if ret != API_OK:
            raise Exception("Error: ApiCmdRTIni: %s." % self._stream.api.error(ret))

    def release(self):
        """
        Disables a remote terminal and all of its sub-addresses
        """
        for subaddress in self._subaddresses:
            subaddress.release()
        del self._subaddresses[:]

        ret = self._stream.api.lib.ApiCmdRTIni(self._stream.handle, 0, self._address, API_RT_DISABLE_OPERATION,
                                               0, AiFloat(4.0), 0)

        if ret != API_OK:
            raise Exception("Error: ApiCmdRTIni: %s." % self._stream.api.error(ret))

    @property
    def address(self):
        """
        Get address of remote terminal
        :return: address as int
        """
        return self._address

    @property
    def stream(self):
        """
        Get stream the remote terminal belongs to
        :return: instance of class Stream
        """
        return self._stream

    def setup_subaddr(self, address, sub_type, statusbits):
        """
        Sets up a specific sub-address of the remote terminal
        :param address: sub-address
        :param sub_type: type of RT sub-address used as parameter in ApiCmdRTSACon
        :return: instance of class RTSubAddress
        """
        rt_subaddress = RTSubAddress(self, sub_type, address, statusbits)
        self._subaddresses.append(rt_subaddress)
        return rt_subaddress


    @property
    def status(self):
        """
        Get the status of the remote terminal
        :return: status dict
        """
        rt_status = TY_API_RT_MSG_DSP()

        ret = self._stream.api.lib.ApiCmdRTMsgRead(self._stream.handle, 0, self._address, ctypes.byref(rt_status))

        if ret != API_OK:
            raise aim_mil.error.AimMilError(ret, "Error: ApiCmdRTMsgRead: id=%d %s." % (self._address))

        return dict([('next_status_word', rt_status.nxw ),
                     ('last_status_word', rt_status.lsw),
                     ('last_command_word', rt_status.lcw),
                     ('message_count', rt_status.msg_cnt),
                     ('error_count', rt_status.err_cnt)
                     ])


class SimulationRT(RT):

    """
    This class represents a remote terminal in simulation mode
    """

    def __init__(self, stream, address,response_time=8.0):
        """
        Constructor
        Initializes and enables a remote terminal in simulation mode on hardware
        :param stream: the stream the remote terminal belongs to
        :param address: the address of the remote terminal
        :return: instance of SimulationRT
        """
        super(SimulationRT, self).__init__(stream, address)

        self._mode = API_RT_ENABLE_SIMULATION

        super(SimulationRT, self).setup(response_time)


class RTSubAddress(object):

    """
    This class represents a remote terminal sub-address
    """

    def __init__(self, rt, sub_type, address, statusbits=0):
        """
        Constructor
        Initializes and enables a remote terminal sub-address on hardware
        :param rt: The RT the sub-address belongs to
        :param sub_type: The RT sub-address type as used in ApiCmdRTSACon
        :param address: the sub-address
        :return: instance of RTSubAddress
        """
        self._rt = rt
        self._type = sub_type
        self._address = address
        self._statusbits = statusbits

        self._buffer_id = rt.stream.device.alloc_buffer()
        
        #print("In RTSubAddress, rt = {} sub_type = {} sub_address = {} buffer_id = {}".
              #format(rt,sub_type,address,self._buffer_id))
        if sub_type == API_RT_TYPE_RECEIVE_SA:
            #print("subtype = API_RT_TYPE_RECEIVE_SA")
            subaddrctrl=API_RT_ENABLE_SA_INT_XFER
        elif sub_type == API_RT_TYPE_RECEIVE_MODECODE:
            #print("subtype = API_RT_TYPE_RECEIVE_MODECODE")
            subaddrctrl=API_RT_ENABLE_SA_INT_XFER
        elif sub_type == API_RT_TYPE_TRANSMIT_SA:
            #print("subtype = API_RT_TYPE_TRANSMIT_SA")
            subaddrctrl=API_RT_ENABLE_SA_INT_XFER
        elif sub_type == API_RT_TYPE_TRANSMIT_MODECODE:
            #print("subtype = API_RT_TYPE_TRANSMIT_MODECODE")
            subaddrctrl=API_RT_ENABLE_SA_INT_XFER
            
        rt_buffer_info = TY_API_RT_BH_INFO()
        ret = rt.stream.api.lib.ApiCmdRTBHDef(rt.stream.handle, 0, self._buffer_id, self._buffer_id, 0, 0,
                                              API_QUEUE_SIZE_1, API_BQM_CYCLIC, API_BSM_RX_DISCARD,
                                              API_SQM_ONE_ENTRY_ONLY,
                                              0, 0, ctypes.byref(rt_buffer_info))
        if ret != API_OK:
            raise Exception("Error: ApiCmdRTBHDef: %s." % rt.stream.api.error(ret))

        ret = rt.stream.api.lib.ApiCmdRTSACon(rt.stream.handle, 0, rt.address, self._address, self._buffer_id, sub_type,
                                              subaddrctrl, 0, API_RT_SWM_NXW_OR, statusbits)

        if ret != API_OK:
            raise Exception("Error: ApiCmdRTSACon: %s." % rt.stream.api.error(ret))

    def release(self):
        """
        Disables and releases the sub-address
        """
        ret = self._rt.stream.api.lib.ApiCmdRTSACon(self._rt.stream.handle, 0, self._rt.address, self._address,
                                                    self._buffer_id, 0, API_RT_DISABLE_SA, 0, 0, 0)

        if ret != API_OK:
            raise Exception("Error: ApiCmdRTSACon: %s." % self._rt.stream.api.error(ret))

        self._rt.stream.device.free_buffer(self._buffer_id)

    @property
    def bufferID(self):
      return self._buffer_id
    
    @property
    def data(self):
        """
        Get data buffer
        :return: contents of current buffer as list of int
        """
        raw_data = array.array('H', [0] * 32)
        rid = AiUInt16()
        raddr = AiUInt32()
        ret = self._rt.stream.api.lib.ApiCmdBufRead(self._rt.stream.handle, 0, API_BUF_RT_MSG, self._buffer_id, 0,
                                                    raw_data.buffer_info()[1], ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(AiUInt16)),
                                                    ctypes.byref(rid), ctypes.byref(raddr))
        if ret != API_OK:
            raise Exception("Error: ApiCmdBufRead: %s." % self._rt.stream.api.error(ret))

        return raw_data.tolist()

    @data.setter
    def data(self, new_data):
        """
        Set content of current buffer
        :param new_data: data values to set as list of int
        """
        rid = AiUInt16()
        raddr = AiUInt32()
        raw_data = array.array('H', new_data)
        ret = self._rt.stream.api.lib.ApiCmdBufDef(self._rt.stream.handle, 0, API_BUF_RT_MSG,
                                                   self._buffer_id, 0, len(new_data), ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(AiUInt16)),
                                                   ctypes.byref(rid), ctypes.byref(raddr))
        if ret != API_OK:
            raise Exception("Error: ApiCmdBufDef: %s." % self._rt.stream.api.error(ret))
