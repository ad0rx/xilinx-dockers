"""Module for replay functionality

This module handles replay functionality of
AIM MIL devices
"""


__author__ = 'Martin Haag'

from aim_mil.mil_bindings import *
import ctypes
import os
from aim_mil.error import AimMilError



class LsReplay():
    def __init__(self, device, stream, sync=False):
        self._device    = device
        self._stream    = stream
        self._file_name   = None
        self._file_offset = 0
        self._rpi_count   = 0
        self._half_buffer_size = 0x10000
        self._replay_status = TY_API_REP_STATUS()
        self._sync = API_REP_ABS_TIME if sync else API_REP_NO_ABS_TIME


    def setup(self, replay_file):
        self._file_name = replay_file
        file_size = os.path.getsize(self._file_name)
        ret = self._stream.api.lib.ApiCmdReplayIni( self._stream.handle, 0, 1, 0, 0, 0, self._sync, 0, API_REP_HFI_INT, 0, 0, 0, file_size )

        if ret != API_OK:
            raise AimMilError(ret, "Error: ApiCmdReplayIni: %s." % self._stream.api.error(ret))


    def start(self):
        ret = self._stream.api.lib.ApiCmdReplayStart( self._stream.handle, 0 )

        if ret != API_OK:
            raise AimMilError(ret, "Error: ApiCmdReplayStart: %s." % self._stream.api.error(ret))


    def stop(self):
        ret = self._stream.api.lib.ApiCmdReplayStop( self._stream.handle, 0 )

        if ret != API_OK:
            raise AimMilError(ret, "Error: ApiCmdReplayStop: %s." % self._stream.api.error(ret))


    def update_status(self):
        ret = self._stream.api.lib.ApiCmdReplayStatus( self._stream.handle, 0, ctypes.byref(self._replay_status) )

        if ret != API_OK:
            raise AimMilError(ret, "Error: ApiCmdBCIni: %s." % self._stream.api.error(ret))

    @property
    def replay_status(self):
        self.update_status()
        return self._replay_status


    @property
    def is_running(self):
        return self._replay_status.status == API_REP_BUSY


    @property
    def reload(self):
        delta = self._replay_status.rpi_cnt - self._rpi_count;

        if( delta > 1 ):
            raise Exception("Error: Replay underrun")

        return True if delta == 1 else False


    @reload.setter
    def reload(self, unused ):
        self._rpi_count += 1


    def feed(self):
        '''
        Read half buffer sized data from file and feed it into the replay buffer.
        '''
        replay_status = self.replay_status

        data_written = AiUInt32()
        with open( self._file_name, "rb" ) as fp:
            c_replay_data = (AiUInt8 * self._half_buffer_size)()
            fp.seek(self._file_offset)
            read_size = fp.readinto(c_replay_data)

            self._file_offset += read_size

            replay_status.size = read_size
            if read_size > 0:
                ret = self._stream.api.lib.ApiWriteRepData( self._stream.handle, 0, ctypes.byref(replay_status), ctypes.byref(c_replay_data), ctypes.byref(data_written) )

                if ret != API_OK:
                    raise AimMilError(ret, "Error: ApiCmdBCIni: %s." % self._stream.api.error(ret))

                if data_written.value != read_size:
                    raise Exception("ApiWriteRepData only %d bytes out of %d bytes have been written" % (data_written.value, read_size))

                if self.is_running:
                    self.reload = True

