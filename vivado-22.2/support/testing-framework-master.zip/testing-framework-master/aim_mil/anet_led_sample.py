__author__ = 'Markus Melcher'


import aim_mil.anet_led
import time
import sys


if __name__ == '__main__':
    leds = aim_mil.anet_led.AnetLedFactory.probe_leds()
    print("Available LEDs: " + repr(list(leds.keys())))

    for led in list(leds.values()):
        print("Testing %s LED..." % led.color, end=' ')
        sys.stdout.flush()
        led.switch_on()
        time.sleep(5)
        led.blink(1000)
        time.sleep(5)
        led.switch_off()
        print("Done")
        time.sleep(5)
