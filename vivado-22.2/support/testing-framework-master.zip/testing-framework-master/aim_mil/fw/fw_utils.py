"""Module for fw functionality

This module handles fw functionality of
AIM MIL devices
"""


__author__ = 'Patrick Giesel'

from aim_mil.mil_bindings import *
import ctypes
import os
from aim_mil.error import AimMilError
import time

class FWUtils():
    def __init__(self, stream):
        self._stream    = stream

    def check_fw_cmd(self, cmd):
        # checks, if given fw command was the last executed fw command
        sys_status = AiUInt32()

        # GRAM offset of System Status Word
        offset = 4
        ret = self._stream.api.lib.ApiReadMemData(self._stream.handle, API_MEMTYPE_GLOBAL, offset, 4, ctypes.byref(sys_status))
        if ret != API_OK:
            raise Exception("Error check_fw_cmd: ApiReadMemData: %s." % self._stream.api.error(ret))
            
        cmd_status = (sys_status.value & 0xF8000000) >> 27
        invalid_cmd = (sys_status.value & 0x04000000) >> 26
        if (cmd_status != cmd) or (invalid_cmd != 0):
            return 0
        else:
            return 1

    def exec_fw_cmd(self, cmd):
        # executes given fw command
        syscmd = AiUInt32()

        # GRAM offset of System Command Word
        offset = 0
        ret = self._stream.api.lib.ApiReadMemData(self._stream.handle, API_MEMTYPE_GLOBAL, offset, 4, ctypes.byref(syscmd))
        if ret != API_OK:
            raise Exception("Error exec_fw_cmd: ApiReadMemData: %s." % self._stream.api.error(ret))
        
        if self.check_fw_cmd(0) != 1:
            # init FW with NOCMD
            syscmd.value = syscmd.value & 0x07FFFFFF
            ret = self._stream.api.lib.ApiWriteMemData(self._stream.handle, API_MEMTYPE_GLOBAL, offset, 4, ctypes.byref(syscmd))
            if ret != API_OK:
                raise Exception("Error exec_fw_cmd: ApiWriteMemData (NOCMD): %s." % self._stream.api.error(ret))
            time.sleep(0.1)
            if self.check_fw_cmd(0) != 1:
                raise Exception("Error exec_fw_cmd: check_fw_cmd(nocmd)")
                return 0
                
        # now execute CMD
        syscmd.value = syscmd.value | (cmd << 27)
        ret = self._stream.api.lib.ApiWriteMemData(self._stream.handle, API_MEMTYPE_GLOBAL, offset, 4, ctypes.byref(syscmd))
        if ret != API_OK:
            raise Exception("Error exec_fw_cmd: ApiWriteMemData (CMD): %s." % self._stream.api.error(ret))
        time.sleep(0.1)
        ret = self.check_fw_cmd(cmd)

        # init FW with NOCMD
        syscmd.value = syscmd.value & 0x07FFFFFF
        ret = self._stream.api.lib.ApiWriteMemData(self._stream.handle, API_MEMTYPE_GLOBAL, offset, 4, ctypes.byref(syscmd))
        if ret != API_OK:
            raise Exception("Error exec_fw_cmd: ApiWriteMemData (NOCMD): %s." % self._stream.api.error(ret))
                
        return ret
        

