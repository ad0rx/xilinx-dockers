"""Module for handling AIM MIL errors
"""

__author__ = 'Martin Haag'

import aim_mil.library
import ctypes
import aim_mil.device


class AimMilError(Exception):
    def __init__(self, error_code, message):

        # Call the base class constructor with the parameters it needs
        super(Exception, self).__init__(message)

        # Now for your custom code...
        self._error_code = error_code

    @property
    def error_code(self):
        return self._error_code

    def error_string(self):
        self._lib.ApiGetErrorDescription.restype = ctypes.c_char_p
        return self._lib.ApiGetErrorDescription(self._error_code)


class AimMilValueMissmatch(Exception):
    def __init__(self, expected, received, message):

        # Call the base class constructor with the parameters it needs
        super(Exception, self).__init__(message)

        # Now for your custom code...
        self._message        = message
        self._expected = expected
        self._received  = received

    @property
    def expected(self):
        return self._expected

    @property
    def received(self):
        return self._received

    def error_string(self):
        return self._message


