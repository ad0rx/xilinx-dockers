"""Module for monitor functionality

This module handles bus monitor functionality of
AIM MIL devices
"""


__author__ = 'Markus Melcher'

import aim_mil.device
from aim_mil.mil_bindings import *
import ctypes
from ctypes import *
from aim_mil.error import *

class MonitorQueue(object):

    """
    This class represents a monitor queue that stores bus messages
    """

    def __init__(self, stream):
        """
        Creates and initializes a monitor queue on hardware
        :param stream: the stream to monitor
        :return: instance of class MonitorQueue
        """
        assert isinstance(stream, aim_mil.device.Stream)

        self._stream = stream
        ret = self._stream.api.lib.ApiCmdQueueIni(self._stream.handle, 0)

        if ret != API_OK:
            raise Exception("Error: ApiCmdQueueIni: %s." % self._stream.api.error(ret))

    def start(self):
        """
        Start the monitor queue
        """
        ret = self._stream.api.lib.ApiCmdQueueStart(self._stream.handle, 0)

        if ret != API_OK:
            raise AimMilError(ret, "Error: ApiCmdQueueStart: %s." % self._stream.api.error(ret))

    @property
    def bm_status(self):
        """
        Get current status of stream's bus monitor
        :return: returns dictionary with status, message and error count entries
        """
        status = TY_API_BM_STATUS_DSP()
        ret = self._stream._api.lib.ApiCmdBMStatusRead(self._stream._handle, 0, ctypes.byref(status))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBMStatusRead: %s." % self._stream._api.error(ret))

        return dict([('status', status.msw), ('messages', status.glb_msg_cnt), ('errors', status.glb_err_cnt)])

    @property
    def bm_load(self):
        """
        Get current bus load of stream's bus monitor
        :return: returns dictionary with bus_load_pri, bus_load_sec, bus_load_pri_avg, bus_load_sec_avg,  count entries
        """
        status = TY_API_BM_STATUS_DSP()
        ret = self._stream._api.lib.ApiCmdBMStatusRead(self._stream._handle, 0, ctypes.byref(status))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBMStatusRead: %s." % self._stream._api.error(ret))

        return dict([('bus_load_pri', int(status.bus_load_pri / 100)),
                     ('bus_load_sec', int(status.bus_load_sec / 100)),
                     ('bus_load_pri_avg', int(status.bus_load_pri_avg / 100)),
                     ('bus_load_sec_avg', int(status.bus_load_sec_avg / 100))])

    def read(self):
        """
        Read one bus message from the monitor queue
        :return: dictionary with properties of the message
        """
        queue_entry = TY_API_QUEUE_BUF()

        ret = self._stream.api.lib.ApiCmdQueueRead(self._stream.handle, 0, ctypes.byref(queue_entry))

        if ret != API_OK and ret != API_ERR_QUEUE_EMPTY:
            raise Exception("Error: ApiCmdQueueRead: %s." % self._stream.api.error(ret))
        elif ret == API_ERR_QUEUE_EMPTY:
            return None
        else:
            return {'rt_addr': queue_entry.rt_addr,
                    'sa_mc': queue_entry.sa_mc,
                    'sa_type': queue_entry.sa_type,
                    'rt_addr2': queue_entry.rt_addr2,
                    'sa_mc2': queue_entry.sa_mc2,
                    'sa_type2': queue_entry.sa_type2,
                    'rbf_trw': queue_entry.rbf_trw,
                    'word_cnt': queue_entry.word_cnt,
                    'msg_trw': queue_entry.msg_trw,
                    'status_word1': queue_entry.status_word1,
                    'status_word2': queue_entry.status_word2,
                    'buffer': [queue_entry.buffer[x] for x in range(queue_entry.word_cnt)],
                    'ttag': queue_entry.ttag}

    def read_empty(self, max_msgs=None):
        """
        Read monitor queue until it is empty or specified maximum is reached
        :param max_msgs: maximum number of messages to read
        :return: list of dictionaries, one for each message read
        """
        total_msgs = 0
        stop = (max_msgs == 0 and TRUE) or FALSE
        messages = []

        while not stop:
            message = self.read()

            if message:
                messages.append(message)
                total_msgs += 1

            if not message or (not max_msgs is None and total_msgs >= max_msgs):
                stop = TRUE

        return messages

    def stop(self):
        """
        Stops the monitor queue
        :return:
        """
        ret = self._stream.api.lib.ApiCmdQueueHalt(self._stream.handle, 0)

        if ret != API_OK:
            raise Exception("Error: ApiCmdQueueHalt: %s." % self._stream.api.error(ret))





class MonitorRecording(object):
    """
    This class represents a monitor data queue that stores bus messages
    """

    def __init__(self, stream, file, hs=False):
        """
        Creates and initializes a monitor queue on hardware
        :param stream: the stream to monitor
        :return: instance of class MonitorQueue
        """
        assert isinstance(stream, aim_mil.device.Stream)

        self._stream = stream
        self._file   = file
        self._hs     = hs
        self._id     = self.queue_id(hs)

        ret = self._stream.api.lib.ApiCmdBMIni(self._stream.handle, 0)

        if ret != API_OK:
            raise Exception("Error: ApiCmdBMIni: %s." % self._stream.api.error(ret))

        capture_mode = TY_API_BM_CAP_SETUP()
        capture_mode.cap_mode = API_BM_CAPMODE_RECORDING
        #capture_mode.cap_tat = 800

        ret = self._stream.api.lib.ApiCmdBMCapMode(self._stream.handle, 0, ctypes.byref(capture_mode))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBMCapMode: %s." % self._stream.api.error(ret))

        if hs:
            ret = self._stream.api.lib.Api3910CmdHsBMCapMode( self._stream.handle, API_ENA, 0 )
            if ret != API_OK:
                raise Exception("Error: Api3910CmdHsBMCapMode: %s." % self._stream.api.error(ret))

        ret = self._stream.api.lib.ApiCmdDataQueueOpen(self._stream.handle, self._id, None )

        if ret != API_OK:
            raise Exception("Error: ApiCmdDataQueueOpen: %s." % self._stream.api.error(ret))

    def close(self):
        ret = self._stream._api.lib.ApiCmdDataQueueClose(self._stream._handle, self._id)

        if ret != API_OK:
            raise Exception("Error: ApiCmdDataQueueClose: %s." % self._stream._api.error(ret))

    def start(self):
        """
        Start the monitor queue
        """
        open(self._file, 'w').close()

        ret = self._stream.api.lib.ApiCmdBMStart(self._stream.handle, 0)

        if ret != API_OK:
            raise Exception("Error: ApiCmdBMStart: %s." % self._stream.api.error(ret))

        ret = self._stream.api.lib.ApiCmdDataQueueControl(self._stream.handle, self._id, API_DATA_QUEUE_CTRL_MODE_START)

        if ret != API_OK:
            raise Exception("Error: ApiCmdDataQueueControl: %s." % self._stream.api.error(ret))



    def queue_id(self, hs=False):
        ids = [ 0,
                API_DATA_QUEUE_ID_BM_REC_BIU1,
                API_DATA_QUEUE_ID_BM_REC_BIU2,
                API_DATA_QUEUE_ID_BM_REC_BIU3,
                API_DATA_QUEUE_ID_BM_REC_BIU4,
                API_DATA_QUEUE_ID_BM_REC_BIU5,
                API_DATA_QUEUE_ID_BM_REC_BIU6,
                API_DATA_QUEUE_ID_BM_REC_BIU7,
                API_DATA_QUEUE_ID_BM_REC_BIU8]

        if hs:
            return ids[self._stream._hs_biu]
        else:
            return ids[self._stream._ls_biu]




    @property
    def bm_status(self):
        """
        Get current status of stream's bus monitor
        :return: returns dictionary with status, message and error count entries
        """
        status = TY_API_BM_STATUS_DSP()
        ret = self._stream._api.lib.ApiCmdBMStatusRead(self._stream._handle, 0, ctypes.byref(status))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBMStatusRead: %s." % self._stream._api.error(ret))

        return dict([('enablement', status.men), ('status', status.msw), ('messages', status.glb_msg_cnt), ('errors', status.glb_err_cnt)])

    @property
    def bm_load(self):
        """
        Get current bus load of stream's bus monitor
        :return: returns dictionary with bus_load_pri, bus_load_sec, bus_load_pri_avg, bus_load_sec_avg,  count entries
        """
        status = TY_API_BM_STATUS_DSP()
        ret = self._stream._api.lib.ApiCmdBMStatusRead(self._stream._handle, 0, ctypes.byref(status))

        if ret != API_OK:
            raise Exception("Error: ApiCmdBMStatusRead: %s." % self._stream._api.error(ret))

        return dict([('bus_load_pri', int(status.bus_load_pri / 100)),
                     ('bus_load_sec', int(status.bus_load_sec / 100)),
                     ('bus_load_pri_avg', int(status.bus_load_pri_avg / 100)),
                     ('bus_load_sec_avg', int(status.bus_load_sec_avg / 100))])

    def bytes_in_queue(self):
        """
        Check if there is data to read
        :return: Available bytes
        """
        queue_read = TY_API_DATA_QUEUE_READ()
        queue_read.id            = self._id
        queue_read.bytes_to_read = 0
        queue_read.buffer        = 0

        queue_read_status = TY_API_DATA_QUEUE_STATUS()

        ret = self._stream.api.lib.ApiCmdDataQueueRead(self._stream.handle, ctypes.byref(queue_read), ctypes.byref(queue_read_status))

        if ret == API_OK:
          #raise Exception("Error: ApiCmdDataQueueRead: %s." % self._stream._api.error(ret))

          return queue_read_status.bytes_in_queue
        else:
          return 0

    def read(self):
        """
        Read available data from the recording queue and write it to the file
        """
        bytes_available = self.bytes_in_queue()
        bytes_read      = 0

        if( bytes_available > 0 ):
            data       = (AiUInt8 * bytes_available)()

            queue_read = TY_API_DATA_QUEUE_READ()
            queue_read.id            = self._id
            queue_read.bytes_to_read = bytes_available
            queue_read.buffer        = cast(data, c_void_p)

            queue_read_status = TY_API_DATA_QUEUE_STATUS()

            ret = self._stream.api.lib.ApiCmdDataQueueRead(self._stream.handle, ctypes.byref(queue_read), ctypes.byref(queue_read_status))

            if ret == API_OK:
              #raise Exception("Error: ApiCmdDataQueueRead: %s." % self._stream._api.error(ret))

              bytes_read = queue_read_status.bytes_transfered

              with open( self._file, "ab" ) as fp:
                fp.write(data)

        return bytes_read


    def stop(self):
        """
        Stops the monitor queue
        :return:
        """
        ret = self._stream.api.lib.ApiCmdBMHalt(self._stream.handle, 0)

        if ret != API_OK:
            raise Exception("Error: ApiCmdBMHalt: %s." % self._stream.api.error(ret))

        ret = self._stream._api.lib.ApiCmdDataQueueControl(self._stream._handle, self._id, API_DATA_QUEUE_CTRL_MODE_STOP)

        if ret != API_OK:
            raise Exception("Error: ApiCmdDataQueueControl: %s." % self._stream._api.error(ret))

    def flush(self):
        """
        Flush the monitor queue
        :return:
        """
        ret = self._stream._api.lib.ApiCmdDataQueueControl(self._stream._handle, self._id, API_DATA_QUEUE_CTRL_MODE_FLUSH)

        if ret != API_OK:
            raise Exception("Error: ApiCmdDataQueueControl: %s." % self._stream._api.error(ret))


