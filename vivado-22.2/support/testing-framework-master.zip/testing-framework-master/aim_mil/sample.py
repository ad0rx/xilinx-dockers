


__author__ = 'markus'


import aim_mil.device
from aim_mil.mil_bindings import *
import time


if __name__ == '__main__':

    host = aim_mil.device.Host('local')

    for device in host.devices:
        device.init()

        print("Executing sample program for module %d..." % device.id)

        for stream in device.streams:
            stream.open()
            print("Selftest on stream %d: " % stream.id + repr(stream.selftest()))
            stream.set_coupling(API_CAL_CPL_ISOLATED)
            stream.init_bc()
            stream.init_rts()
            monitor = stream.start_monitoring()
            transfer1 = aim_mil.bc.BcRtTransfer(stream, 4, (1, 2))
            transfer2 = aim_mil.bc.RtBcTransfer(stream, 4, (2, 3))
            transfer3 = aim_mil.bc.RtRtTransfer(stream, 32, (1, 3), (2, 4))

            transfer1.data = [1, 2, 3, 4]

            stream.add_cyclic_transfers([transfer1, transfer2, transfer3])
            stream.setup_default_framing()

            rt1 = stream.setup_receive_rt((1, 2))
            rt2 = stream.setup_transmit_rt((2, 3))
            rt2.data = [5, 6, 7, 8]

            rt3 = stream.setup_transmit_rt((1, 3))
            rt3.data = [128, 256, 512, 1024, 2048]

            rt4 = stream.setup_receive_rt((2, 4))

            print("Starting simulation on stream %d..." % stream.id)
            stream.start_rts()
            stream.start_bc(1000, 0.1)

            bc_status = {'status': API_BC_STATUS_BUSY}
            while bc_status['status'] != API_BC_STATUS_HALTED:
                bc_status = stream.bc_status
                time.sleep(1)

            print("Stopping simulation")

            stream.stop_bc()
            stream.stop_rts()
            monitor.stop()

            print("BC Status: Messages: %d Errors: %d" % (bc_status['messages'], bc_status['errors']))

            print("\tRT 1-2 data: " + repr(rt1.data))
            print("\tRT-BC transfer data: " + repr(transfer2.data))
            print("\tRT-RT transfer data: " + repr(rt4.data))

            monitor_msgs = monitor.read_empty()

            print("Monitor queue received %d messages" % len(monitor_msgs))
            print("\tFirst one is: " + repr(monitor_msgs[0]))