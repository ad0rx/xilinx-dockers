import numpy as np


class MonitorRecordingHsFileParser:
    def __init__(self):
        pass
        # self._file    = None
        # self._data    = None
        # self._current = None

    def fromfile(self, file, offset=0 ):
        """
        Load data from file
        """
        self._file   = file
        self._data   = np.fromfile(self._file, dtype=np.uint32)

        count, = self._data.shape

        # Create offset column
        self._offset = np.arange( offset, offset + count*4, 4, np.uint32 )
        # Create annotated column
        self._text = np.empty( count, dtype='|S32')

    def toascii(self, file):
        map = np.rec.fromarrays((self._offset, self._data, self._text), names=('offset', 'data', 'comment'))
        np.savetxt( file, map, fmt=['%08X','%08X','%s'])

    def anotate(self, stp, ctp, etp ):
        count,    = self._data.shape
        ctp_index = (ctp - self._offset[0]) / 4
        stp_index = (stp - self._offset[0]) / 4
        etp_index = (etp - self._offset[0]) / 4

        self._text[ctp_index] = self._text[ctp_index] + 'CTP '
        self._text[stp_index] = self._text[stp_index] + 'STP '
        self._text[etp_index] = self._text[etp_index] + 'ETP '

        try:
            current_index = ctp_index
            msg_count = 1
            while(True):
                self._text[current_index] = self._text[current_index] + 'MSG%d ' % msg_count
                next_offset = self._data[current_index + 1]
                current_index = (next_offset - self._offset[0]) / 4
                msg_count = msg_count + 1
        except:
            print("Parsing error count %d at index %d next offset 0x%x" % ( msg_count, current_index, next_offset))

