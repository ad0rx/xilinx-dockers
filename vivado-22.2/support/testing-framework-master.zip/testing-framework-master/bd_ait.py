#!/usr/bin/env python3

import faulthandler
import os
import ctypes
import ait  # generated from AIT C headers by ctypesgen
import common
import sys
import array


M1553_API_IO_VERSION = 1
MAX_API_BOARD_CHANNELS = 4

ERRORS = False

BUFFERID = 0

CHAN_FILEDATA = dict() #This maps channum to FileData instances, needed for any BM interrupt on an AIT channel
COUNT = 0

buffer_info = {} #dict of bufferID to counter,length,buffer for buffers that are transmitted (BC for BC_RT and RT for rt transmitters

class FileData:
  def __init__(self,c_chanHandle, channum, userdata, fileobj=None, entries_read=0):
    self._c_chanHandle = c_chanHandle
    self.channum = channum
    self.userdata = userdata
    self._fileobj = fileobj
    self._entries_read = entries_read
    
  @property
  def fileobj(self):
    return self._fileobj
  
  @fileobj.setter   
  def fileobj(self,fo):
    self._fileobj = fo

  @property
  def c_chanHandle(self):
    return self._c_chanHandle
  
  @c_chanHandle.setter   
  def c_chanHandle(self,ch):
    self._c_chanHandle = ch
        
  @property
  def entries_read(self):
    return self._entries_read
  
  @entries_read.setter   
  def entries_read(self,er):
    self._entries_read = er      


def getbuf():
    global BUFFERID
    ret = BUFFERID
    print("AIT BUFFERID = {}".format(BUFFERID))
    BUFFERID += 1
    return ret


def AITErr(errorCode, funcName=''):
    global ERRORS
    if (errorCode != ait.API_OK): 
        errbuf = bytes(512)
        ait.m1553LogErrorString(errorCode,ait.String(errbuf),512)
        errbuf = errbuf.decode("utf-8").rstrip()
        print("AIT Error: code = {} funcName = {} explanation = {}".format(errorCode, funcName, errbuf))
        ERRORS = True
        return False  # Indicate that function failed 
    else:
        #print("AIT Success: {} - {}".format(errorCode, funcName))  
        return True  # Indicate that function succeeded    

class POINT(ctypes.Structure):
  _fields_ = [("x", ctypes.c_int),
              ("y", ctypes.c_int)]

POINTPTR=ctypes.POINTER(POINT)

class USERDATA(ctypes.Structure):
  _fields_ = [
              ("channum", ctypes.c_uint32)         
              ]

USERDATAPTR=ctypes.POINTER(USERDATA)


def updateBuffer(c_chanHandle, bufferID):
  global buffer_info
  
  if not common.WANT_MESSAGE_COUNTER:
    return
  
 
  if bufferID in buffer_info: #bufferID will be in the dict for BC for BC_RT xfers and for RTs that are transmit
    buffer_info[bufferID]["counter"] = (buffer_info[bufferID]["counter"] + 1) % 0XFFFF
    buffer = buffer_info[bufferID]["buffer"]
    buffer[0] = buffer_info[bufferID]["counter"] #Set first word of buffer to new counter
    py_m1553BufSetBuffer(c_chanHandle, bufferID, len(buffer), buffer)

    #print ("\n@@@UPDATED BUFFER COUNTER FOR BUFFERID {} NEW BUFFER {}".format(bufferID,buffer)) 
  #printBufferInfo()
  

def printBufferInfo():
  global buffer_info
  print("\n\nBUFFER INFO:")
  for bufferID in buffer_info: 
    print("BUFFERID: {}, ADDR: {} COUNTER: {} BUFFER:{}".format(bufferID, hex(id(buffer_info[bufferID]["buffer"])), buffer_info[bufferID]["counter"], buffer_info[bufferID]["buffer"]))

#M1553_INT_FUNC_PTR = CFUNCTYPE(UNCHECKED(None), M1553Handle, M1553InterruptType, M1553InterruptLoglistEntryType, M1553Addr)
def py_InterruptFunc(c_chanHandle,interruptType,loglistEntryType,m1553Addr):
  global CHAN_FILEDATA, COUNT, buffer_info
  print("\n***\nIN AIT INTERRUPT FUNCTION.  INTERRUPT TYPE IS {}".format(interruptType))

  
  userdataptr=ctypes.cast(m1553Addr,USERDATAPTR)
  userdata=userdataptr.contents
  channum = userdata.channum
  print("Interrupt userdata.channum = {}".format(channum))
  #print("c_chanHandle from channum = {}".format(hex(id(CHAN_FILEDATA[channum].c_chanHandle))))

  logwordA=loglistEntryType.mLogListWordA
  #print("AITlogwordA is {}".format(bin(logwordA)))
  #logword=loglistEntryType.mLogListWordB
  #print("AITlogwordB is {}".format(bin(logword)))
  logwordC=loglistEntryType.mLogListWordC
  #print("AITlogwordC is {}".format(bin(logwordC)))
  logwordD=loglistEntryType.mLogListWordD
  #print("AITlogwordD is {}".format(bin(logword)))   
  error = logwordA >> 25 & 0b1
    
  if interruptType == ait.M1553_INTERRUPT_RT: #0
    inttype = 'AIT RT INT'
    modeCode = logwordC & 0b11111
    sa = logwordC >> 5 & 0b11111
    direction = logwordC >> 10 & 0b1
    rt = logwordC >> 11 & 0b11111
    bufferID,data = py_m1553BufGetBuffer(c_chanHandle, logwordD & 0b1111111111111111) #16 bit bufferid
    print("RT {} SA {} T/R {} MODECODE {}".format(rt,sa,direction,modeCode))
    print("{}: DIR: {} ERROR {} BUFFERID {}:  {}\n".format(inttype,direction,error,bufferID,[hex(i) for i in data]))
    updateBuffer(c_chanHandle,bufferID)

                             
  elif interruptType == ait.M1553_INTERRUPT_BC: #1
    inttype = 'AIT BC INT'
    transferID = logwordC
    bufferID = logwordD & 0b1111111111111111
    _,data = py_m1553BufGetBuffer(CHAN_FILEDATA[channum].c_chanHandle, bufferID) #16 bit bufferid
    print("{}: XFER: {} ERROR {} BUFFERID {}:  {}\n".format(inttype,transferID,error,bufferID,[hex(i) for i in data]))
    #py_dumpTransferStatus(CHAN_FILEDATA[channum].c_chanHandle, transferID, summary = False)
    updateBuffer(c_chanHandle,bufferID)
    #newBuf = [0x0707]*3
    #py_m1553BufSetBuffer(c_chanHandle, bufferID, len(newBuf), newBuf)   
  elif interruptType == ait.M1553_INTERRUPT_BM: #2
    inttype = 'AIT BM INT'
    #print("{}: COUNT = {}\n".format(inttype,COUNT), file=sys.stderr)
    
    #Look up the file obj for the chan
    filedata = CHAN_FILEDATA[channum]
    entries_read = update_bm_dump(filedata)
    filedata.entries_read += entries_read
    #print("Entries read: {} Total entries read so far: {}".format(entries_read, filedata.entries_read), file=sys.stderr)
  else:
    print("UNKNOWN INTERRUPT TYPE! {}".format(interruptType))
    #COUNT +=1
 
    #if COUNT == 20:
      #sys.exit()
    



INT_FUNC_PTR = ait.M1553_INT_FUNC_PTR(py_InterruptFunc)

def py_m1553Init(structIOversion=M1553_API_IO_VERSION):

    c_boardsFound = ctypes.c_uint32(0)

    AITErr(ait.m1553Init(structIOversion, ctypes.byref(c_boardsFound)), 'ait.m1553Init')
  
    return c_boardsFound.value    


def py_m1553Uninitialize(structIOversion=M1553_API_IO_VERSION):

    AITErr(ait.m1553Uninitialize(structIOversion), 'ait.m1553Uninitialize')


def py_m1553BoardOpen(boardNum):

    c_boardHandle = ait.M1553Handle()
    print("boardNum = {} boardHandle = {}".format(boardNum, c_boardHandle.value))
    AITErr(ait.m1553BoardOpen(boardNum, ctypes.byref(c_boardHandle)), 'ait.m1553BoardOpen')
      
    return c_boardHandle


def py_m1553GetBoardInfo(c_boardHandle):
    
    c_boardInfo = ait.M1553GetBoardInfoOut()
    AITErr(ait.m1553GetBoardInfo(c_boardHandle, ctypes.byref(c_boardInfo)), 'ait.m1553GetBoardInfo')

    print("board channel count = {}".format(c_boardInfo.mChannelCount))
    print("board firmware version = 0x{:08x}".format(c_boardInfo.mFirmwareVersion))
    print("board serial number = {}".format(c_boardInfo.mSerialNumber))
    print("board part number = {}".format(c_boardInfo.mPartNumber))
    print("board variable amplitude = {}".format(c_boardInfo.mVariableAmplitude))             
    return c_boardInfo


def py_m1553ChannelOpen(c_boardHandle, chanNum):

    c_chanHandle = ait.M1553Handle()
    print("boardHandle = {} chanNum = {} chanHandle = {}".format(c_boardHandle.value, chanNum, c_chanHandle.value))

    AITErr(ait.m1553ChannelOpen(c_boardHandle, chanNum, ctypes.byref(c_chanHandle)), 'ait.m1553ChannelOpen')

    return c_chanHandle


def py_m1553ChannelReset(c_chanHandle, reset=ait.M1553_RESET_ALL):
    c_reset = ait.M1553ChannelResetIn(reset)
    ait.m1553ChannelReset(c_chanHandle, ctypes.byref(c_reset))

    
def py_m1553ChannelSetCoupling(c_chanHandle, coupling=ait.M1553_TRANSFORMER):
    c_coupling = ait.M1553ChannelSetCouplingIn(coupling)
    ait.m1553ChannelSetCoupling(c_chanHandle, ctypes.byref(c_coupling))   

    
def py_m1553ChannelSetAmplitude(c_chanHandle, chanNum, amplitude=None):
  if amplitude is None:
    amplitude=common.XMIT_AMPLITUDE
  c_ampout = ait.M1553ChannelGetAmplitudeOut()
  ait.m1553ChannelGetAmplitude(c_chanHandle, ctypes.byref(c_ampout)) 
  print("Original amplitude for channel {} is {}".format(chanNum,c_ampout.mAmplitude))
  print("About to set amplitude {}".format(amplitude,ctypes.c_uint8(amplitude).value))
  c_amplitude = ait.M1553ChannelSetAmplitudeIn(mAmplitude = ctypes.c_uint8(amplitude))
  AITErr(ait.m1553ChannelSetAmplitude(c_chanHandle, ctypes.byref(c_amplitude)),'m1553ChannelSetAmplitude')   
  c_ampoutnew = ait.M1553ChannelGetAmplitudeOut(mAmplitude = ctypes.c_uint8(0))
  AITErr(ait.m1553ChannelGetAmplitude(c_chanHandle, ctypes.byref(c_ampoutnew)),'m1553ChannelGetAmplitude')   
  print("Final amplitude for channel {} is {}".format(chanNum,c_ampoutnew.mAmplitude))
  
def py_m1553ChannelSetResponseTimeout(c_chanHandle, responseTimeout):
    c_respTimeout = ait.M1553ChannelSetResponseTimeoutIn(responseTimeout)
    ait.m1553ChannelSetResponseTimeout(c_chanHandle, ctypes.byref(c_respTimeout))

    
def py_m1553RTInit(c_chanHandle):
    AITErr(ait.m1553RTInit(c_chanHandle), 'm1553RTInit')


def py_m1553BCInit(c_chanHandle):
    ait.m1553BCInit(c_chanHandle)
    
    print("WANT_BBUS is {}".format(common.WANT_BBUS))
    print("REDUNDANT_BUS is {}".format(common.REDUNDANT_BUS))    
    if common.WANT_BBUS:
      mGlobalStartBus = ait.M1553_BUS_SECONDARY
    else:
      mGlobalStartBus = ait.M1553_BUS_PRIMARY
      
    if common.REDUNDANT_BUS:
      mRetryOption=ait.M1553_BC_RETRY_ALTERNATE
    else:
      mRetryOption=ait.M1553_BC_RETRY_DISABLED
      
    c_config = ait.M1553BCSetConfigIn(mRetryOption=mRetryOption,
                                      mGlobalBusMode=ait.M1553_BC_GLOBAL_BUS,
                                      mGlobalStartBus=mGlobalStartBus)
    ait.m1553BCSetConfig(c_chanHandle, ctypes.byref(c_config))

    
def py_m1553BMInit(c_chanHandle):
    ait.m1553BMInit(c_chanHandle)
    c_curmempart = ait.M1553ChannelGetMemPartitionOut()
    
    AITErr(ait.m1553ChannelGetMemPartition(c_chanHandle, ctypes.byref(c_curmempart)), 'ait.m1553ChannelGetMemPartition')
    '''
    print("\n%%%\n%%%Global mem size = {}  Channel mem size = {} BM buffer area size = {} BM buffer area offset = {}".format(c_curmempart.mGlobalMemorySize,
                                                                                                                             c_curmempart.mChannelMemorySize,
                                                                                                                             c_curmempart.mMemoryMap.mBmBufferAreaSize,
                                                                                                                             c_curmempart.mMemoryMap.mBmBufferAreaOffset))
    '''
    c_newmempart = ait.M1553ChannelSetMemPartitionIn(mMemoryMap=c_curmempart.mMemoryMap)
    c_newmempart.mMemoryMap.mBmBufferAreaSize = common.BM_BUFFER_SIZE
    
    AITErr(ait.m1553ChannelSetMemPartition(c_chanHandle, ctypes.byref(c_newmempart)), 'ait.m1553ChannelSetMemPartition')
    
    c_curmempart = ait.M1553ChannelGetMemPartitionOut()
    
    AITErr(ait.m1553ChannelGetMemPartition(c_chanHandle, ctypes.byref(c_curmempart)), 'ait.m1553ChannelGetMemPartition')
    '''
    print("\n%%%\n%%%Global mem size = {}  Channel mem size = {} BM buffer area size = {} BM buffer area offset = {}".format(c_curmempart.mGlobalMemorySize,
                                                                                                                             c_curmempart.mChannelMemorySize,
                                                                                                                             c_curmempart.mMemoryMap.mBmBufferAreaSize,
                                                                                                                             c_curmempart.mMemoryMap.mBmBufferAreaOffset))     
    '''
    c_config = ait.M1553BMConfig(mInterruptMode=ait.M1553_BM_INTERRUPT_HALF_FULL,
                                 mCaptureMode=ait.M1553_BM_CAPTURE_MODE_RECORDING,
                                 mTraceAfterTrigger=ctypes.c_uint32(0),
                                 mBufferSize=ctypes.c_uint32(common.BM_BUFFER_SIZE))#common.BM_BUFFER_SIZE
    c_configin = ait.M1553BMSetConfigIn(c_config)
    ait.m1553BMSetConfig(c_chanHandle, ctypes.byref(c_configin))
    print("Done with the BM init")

 
def py_m1553RTStart(c_chanHandle):
    AITErr(ait.m1553RTStart(c_chanHandle), 'ait.m1553RTStart')

    
def py_m1553BCStart(c_chanHandle, numFrames=None, minorFrameTime=None):
  if numFrames is None:
    numFrames=common.NUM_FRAMES
  if minorFrameTime is None:
    minorFrameTime=common.MINOR_FRAME_TIME
  #print("@#$%@#$% In py_m1553BCStart, setting minor frame time to {}".format(minorFrameTime))
  #print("@#$%@#$% In py_m1553BCStart, common.MINOR_FRAME_TIME = {}".format(common.MINOR_FRAME_TIME))
  c_bcstartin = ait.M1553BCStartIn(mStartMode=ait.M1553_BC_START_IMMEDIATELY,
                                     mCount=ctypes.c_uint32(numFrames),
                                     mFrameTime=ait.M1553Float(minorFrameTime),
                                     mStartAddress=ctypes.c_uint32(0))
  AITErr(ait.m1553BCStart(c_chanHandle, ctypes.byref(c_bcstartin)), 'ait.m1553BCStart')      

def py_m1553BMStart(c_chanHandle):
    AITErr(ait.m1553BMStart(c_chanHandle), 'ait.m1553BMStart')  
    
    
def py_m1553RTStop(c_chanHandle):
    AITErr(ait.m1553RTStop(c_chanHandle), 'ait.m1553RTStop')

    
def py_m1553BCStop(c_chanHandle):
    AITErr(ait.m1553BCStop(c_chanHandle), 'ait.m1553BCStop')    

    
def py_m1553BMStop(c_chanHandle):
    AITErr(ait.m1553BMStop(c_chanHandle), 'ait.m1553BCStop')    

      
def py_m1553ChannelBIT(c_chanHandle, control=ait.M1553_BIT_ALL_TEST):

    c_boardBITin = ait.M1553BoardBITIn(control, 0)    
    c_boardBITout = ait.M1553BoardBITOut((0, 0))        
    ait.m1553ChannelBIT(c_chanHandle, ctypes.byref(c_boardBITin), ctypes.byref(c_boardBITout))

    print("Built In Test Results Result: {:2d}.{:2d}".format(c_boardBITout.mBITStatus[0], c_boardBITout.mBITStatus[1]))
    if (c_boardBITout.mBITStatus[0] != 0):
        print("Self test failed")
    else:
        print("Self test passed")
        
    return


def py_m1553BCSetBufferHeader(c_chanHandle, headerID, bufferID):
    c_mBufferHeader = ait.M1553BufferHeaderDefinitionType(mBufferID=ctypes.c_uint16(bufferID),
                                                          mStatusQueueID=ctypes.c_uint16(headerID),
                                                          mEventQueueID=ctypes.c_uint16(headerID),
                                                          mQueueSize=ait.M1553_QUEUE_SIZE_1,
                                                          mBufferQueueMode=ait.M1553_QUEUE_CYCLIC)
    c_bufferHeaderIn = ait.M1553BCSetBufferHeaderIn(mBufferHeader=c_mBufferHeader)
    
    AITErr(ait.m1553BCSetBufferHeader(c_chanHandle, ctypes.c_uint16(headerID), ctypes.byref(c_bufferHeaderIn)),
           'ait.m1553BCSetBufferHeader')
    return
  
  
def py_m1553RTSASetBufferHeader(c_chanHandle, headerID, bufferID):
    c_mBufferHeader = ait.M1553BufferHeaderDefinitionType(mBufferID=ctypes.c_uint16(bufferID),
                                                          mStatusQueueID=ctypes.c_uint16(headerID),
                                                          mEventQueueID=ctypes.c_uint16(headerID),
                                                          mQueueSize=ait.M1553_QUEUE_SIZE_1,
                                                          mBufferQueueMode=ait.M1553_QUEUE_CYCLIC)
    c_bufferHeaderIn = ait.M1553RTSetBufferHeaderIn(mBufferHeader=c_mBufferHeader)
    
    AITErr(ait.m1553RTSASetBufferHeader(c_chanHandle, ctypes.c_uint16(headerID), ctypes.byref(c_bufferHeaderIn)),
           'ait.m1553RTSASetBufferHeader')
    return
    
def py_m1553BufSetFirstBufferWord(c_chanHandle, bufferID, buffer):
  c_mpDataArrayType = ctypes.c_uint16 * 1
  dataBuffer =[]
  dataBuffer.append(buffer[0])
  
  c_bufferIn = ait.M1553BufSetBufferIn(mWordOffset=ctypes.c_uint8(0),
                                        mSize=ctypes.c_uint8(1),
                                        mpData=c_mpDataArrayType(*dataBuffer),
                                        m1760ChecksumOffset=ctypes.c_uint8(0))
  
  AITErr(ait.m1553BufSetBuffer(c_chanHandle, ctypes.c_uint16(bufferID), ctypes.byref(c_bufferIn)),
           'ait.m1553BufSetBuffer')

def py_m1553BufSetBuffer(c_chanHandle, bufferID, bufferLen, dataBuffer):
  
  #print("\n\n$$$$$ In py_m1553BufSetBuffer, c_chanHandle = {} bufferID = {} bufferLen = {} dataBuffer = {}".format(hex(id(c_chanHandle)),bufferID, bufferLen, dataBuffer))
      
  c_mpDataArrayType = ctypes.c_uint16 * bufferLen
   
  c_bufferIn = ait.M1553BufSetBufferIn(mWordOffset=ctypes.c_uint8(0),
                                        mSize=ctypes.c_uint8(bufferLen),
                                        mpData=c_mpDataArrayType(*dataBuffer),
                                        m1760ChecksumOffset=ctypes.c_uint8(0))
    
  AITErr(ait.m1553BufSetBuffer(c_chanHandle, ctypes.c_uint16(bufferID), ctypes.byref(c_bufferIn)),
           'ait.m1553BufSetBuffer')

    
def py_m1553BufGetBuffer(c_chanHandle, bufferID, size=32):
    c_mpDataGetArrayType = (ctypes.c_uint16 * size)


    c_bufferGetIn = ait.M1553BufGetBufferIn(mWordOffset=ctypes.c_uint8(0),
                                        mSize=ctypes.c_uint8(size),
                                        mpData=c_mpDataGetArrayType(),
                                        m1760ChecksumOffset=ctypes.c_uint8(0))
    c_bufferGetOut = ait.M1553BufGetBufferOut(mBufferId=ctypes.c_uint16(0),
                                              mBufferAddress=ctypes.c_uint32(0),
                                              m1760ChecksumValid=ctypes.c_uint8(0))
    ait.m1553BufGetBuffer(c_chanHandle, ctypes.c_uint16(bufferID), ctypes.byref(c_bufferGetIn), ctypes.byref(c_bufferGetOut))

    print("py_m1553BufGetBuffer output bufferID is {} output address is {}".format(c_bufferGetOut.mBufferId, hex(c_bufferGetOut.mBufferAddress)))
    buffer = c_bufferGetIn.mpData[:c_bufferGetIn.mSize]
    return bufferID,buffer
    

    
def setUpFraming(c_chanHandle, numTransfers, transferStart = 0):
    print("In setUpFraming, numTransfers = {}".format(numTransfers))       
    c_mInstructionTypeArray = ait.M1553BCInstructionType * int(128)
    c_mInstructionType = c_mInstructionTypeArray()
    c_mInstructionParameterArray = ctypes.c_uint16 * int(128)
    c_mInstructionParameter = c_mInstructionParameterArray()
    
    for i in range(0, numTransfers):
        c_mInstructionType[i] = ait.M1553_BC_TRANSFER
        c_mInstructionParameter[i] = ctypes.c_uint16(i+transferStart) 
      
    c_mMinorFrame = ait.M1553BCMinorFrameType(mCount=ctypes.c_uint8(numTransfers),
                                              mInstructionType=c_mInstructionType,
                                              mInstructionParameter=c_mInstructionParameter    
                                              )
 
    c_mMinorFrameIn = ait.M1553BCSetMinorFrameIn(mMinorFrame=c_mMinorFrame)
    AITErr(ait.m1553BCSetMinorFrame(c_chanHandle, ctypes.c_uint16(1),
                             ctypes.byref(c_mMinorFrameIn)), 'ait.m1553BCSetMinorFrame')
  
    c_mMinorFrameIDsArray = ctypes.c_uint8 * int(64)
    c_mMinorFrameIDs = c_mMinorFrameIDsArray()
    c_mMinorFrameIDs[0] = ctypes.c_uint8(1)
    c_mMajorFrame = ait.M1553BCMajorFrameType(mCount=ctypes.c_uint8(1),
                                              mMinorFrameIDs=c_mMinorFrameIDs)
    c_mMajorFrameIn = ait.M1553BCSetMajorFrameIn(mMajorFrame=c_mMajorFrame)
    AITErr(ait.m1553BCSetMajorFrame(c_chanHandle, ctypes.byref(c_mMajorFrameIn)),
           'ait.m1553BCSetMajorFrame')


def py_m1553BCSetTransfer(c_chanHandle, headerID, transferID, transfertype, dataLength,
												xmitrtnum=0, xmitsubaddr=0, rcvrtnum=0, rcvsubaddr=0):
    if dataLength == 32:
      dataLength = 0 #AIM docs state that 0 implies length 32.  Value must fit into a byte.
      
    c_mBCTransferType = ait.M1553BCTransferType(
			mBufferHeaderID=ctypes.c_uint16(headerID),
			mTransferType=transfertype,
			mBus=ait.M1553_BUS_PRIMARY,
			mTransmitRT=ctypes.c_uint8(xmitrtnum),
			mReceiveRT=ctypes.c_uint8(rcvrtnum),
			mTransmitSA=ctypes.c_uint8(xmitsubaddr),
			mReceiveSA=ctypes.c_uint8(rcvsubaddr),
			mWordCount=ctypes.c_uint8(dataLength),
			mInterruptControl=ait.M1553_BC_INTERRUPT_ON_TRANSFER_END,
			mStopControl=ait.M1553_BC_DONT_STOP,
			mRetryEnabled=ait.M1553Boolean(common.REDUNDANT_BUS),
			mStatusWordExceptionHandling=ait.M1553_EXCEPTION_HANDLING_ENABLED,  # If the service request bit of the received status word is set, automatically generate transmit vector word mode code (MC16)
			mExpectedResponse=ait.M1553_BC_RESPONSE_AUTOMATIC,
			mGapModeType=ait.M1553_BC_GAP_MODE_STANDARD,  # Don't handle FAST mode yet.
			mGapTime=ait.M1553Float(common.TRANSFER_GAP_TIME),
			mStatusWordExceptionMask=ctypes.c_uint16()
			)
    # mBCTransferError=M1553BCTransferErrorConfigType
    c_mBCSetTransferIn = ait.M1553BCSetTransferIn(mTransfer=c_mBCTransferType)
    res = AITErr(ait.m1553BCSetTransfer(c_chanHandle, ctypes.c_uint16(transferID), ctypes.byref(c_mBCSetTransferIn)),
								'ait.m1553BCSetTransfer')
    if res: 
      #print("res = {}".format(res))
      #return c_mBCTransferType
      return transferID    
    else:
      return -1

#When this function is invoked, I get a not-implemented error from the AIT code.
def py_m1553BCModeCodeGetEnable(c_chanHandle, transferID):
  c_modeCodeGetEnableIn = ait.M1553ModeCodeGetEnableIn(mBCModecode=ait.M1553_MODE_CODE_SYNCHRONIZE_WITH_DATA)
  c_modeCodeGetEnableOut = ait.M1553ModeCodeGetEnableOut(mTransferID = transferID)
  AITErr(ait.m1553BCModeCodeGetEnable(c_chanHandle, ctypes.byref(c_modeCodeGetEnableIn),ctypes.byref(c_modeCodeGetEnableOut)),'ait.m1553BCModeCodeGetEnable')
  print("For xfer ID {}: M1553_MODE_CODE_SYNCHRONIZE_WITH_DATA is {}",c_modeCodeGetEnableOut.mTransferID,c_modeCodeGetEnableOut.mEnable)

  c_modeCodeGetEnableIn = ait.M1553ModeCodeGetEnableIn(mBCModecode=ait.M1553_MODE_CODE_DYNAMIC_BUS_CONTROL)
  c_modeCodeGetEnableOut = ait.M1553ModeCodeGetEnableOut()
  AITErr(ait.m1553BCModeCodeGetEnable(c_chanHandle, ctypes.byref(c_modeCodeGetEnableIn),ctypes.byref(c_modeCodeGetEnableOut)),'ait.m1553BCModeCodeGetEnable')       
  print("For xfer ID {}: M1553_MODE_CODE_DYNAMIC_BUS_CONTROL is {}",c_modeCodeGetEnableOut.mTransferID,c_modeCodeGetEnableOut.mEnable)         

#When this function is invoked, I get a not-implemented error from the AIT code.
def py_m1553BCModeCodeSetEnable(c_chanHandle,transferID):
  c_modeCodeSetEnableIn = ait.M1553ModeCodeSetEnableIn(mBCModecode=ait.M1553_MODE_CODE_SYNCHRONIZE_WITH_DATA,
                                                        mEnable=True,
                                                        mTransferID=transferID)
  AITErr(ait.m1553BCModeCodeSetEnable(c_chanHandle,ctypes.byref(c_modeCodeSetEnableIn)),'ait.m1553BCModeCodeSetEnable')
  
  c_modeCodeSetEnableIn = ait.M1553ModeCodeSetEnableIn(mBCModecode=ait.M1553_MODE_CODE_DYNAMIC_BUS_CONTROL,
                                                        mEnable=True,
                                                        mTransferID=transferID)
  AITErr(ait.m1553BCModeCodeSetEnable(c_chanHandle,ctypes.byref(c_modeCodeSetEnableIn)),'ait.m1553BCModeCodeSetEnable')            

def py_createTransfer(c_chanHandle, transferID, transfertype, dataBuffer, dataLength,
										xmitrtnum=0, xmitsubaddr=0, rcvrtnum=0,
										rcvsubaddr=0):
  global buffer_info
  print("In py_createTransfer") 
  bufferID = getbuf()
  headerID = bufferID
    
  length = 32
  buffer = [0] * length
  

  if dataBuffer:
    bufferLen = len(dataBuffer)
    buffer[:bufferLen]=dataBuffer
    
  py_m1553BCSetBufferHeader(c_chanHandle, headerID, bufferID)     
  py_m1553BufSetBuffer(c_chanHandle, bufferID, length, buffer)
  #py_m1553BufGetBuffer(c_chanHandle, bufferID, length)
  if transfertype == ait.M1553_BC_TO_RT:
    buffer_info[bufferID] = {"counter":0, "length":length, "buffer":buffer}
    #printBufferInfo()
  print("\n### Before BCSetTransfer, headerID = {} length_modecode = {} buffer = {}".format(headerID, dataLength, buffer))  
  return py_m1553BCSetTransfer(c_chanHandle, headerID, transferID, transfertype, dataLength, xmitrtnum, xmitsubaddr, rcvrtnum, rcvsubaddr)  #Return the transferID if sucessful; else -1


def py_m1553RTModeCodeGetConfig(c_chanHandle,rtnum=None):
  c_modecodeGetOut = ait.M1553RTModeCodeGetConfigOut()
  AITErr(ait.m1553RTModeCodeGetConfig(c_chanHandle, ctypes.c_uint8(rtnum), ctypes.byref(c_modecodeGetOut)),'ait.m1553RTModeCodeGetConfig')
  
  print("MODE CODE CONFIG FOR RT {}: mTxConfigurationModeB = {:08X}".format(rtnum,c_modecodeGetOut.mTxConfigurationModeB))


def py_addRT(c_chanHandle, direction=None, rtnum=None, subaddr=None, dataLength=0, dataBuffer=None, mode=None):
  global buffer_info
  
  print("In py_addRT") 
  bufferID = getbuf()
  headerID = bufferID
      

  length = 32
  buffer = [0] * length
  
  if dataBuffer and len(dataBuffer) and direction == common.Direction.TRANSMIT:
    buffer[:len(dataBuffer)]=dataBuffer

  print("In py_addRT, for RT {}, direction {}, setting buffer {}".format(rtnum,direction,buffer))
      
  py_m1553RTSASetBufferHeader(c_chanHandle, headerID, bufferID)     
  py_m1553BufSetBuffer(c_chanHandle, bufferID, length, buffer)
  py_m1553BufGetBuffer(c_chanHandle, bufferID, length)
  res=py_m1553RTSetConfig(c_chanHandle,rtnum=rtnum)
  
  py_m1553RTModeCodeGetConfig(c_chanHandle,rtnum=rtnum) #Test to print out which mode codes are active
  
  if res:
    py_m1553RTSASetConfig(c_chanHandle, headerID=headerID, rtnum=rtnum, subaddr=subaddr, direction=direction, mode=mode)
      
  if direction == common.Direction.TRANSMIT:
    buffer_info[bufferID] = {"counter":0, "length":length, "buffer":buffer}


def py_m1553RTSetConfig(c_chanHandle,rtnum):
  
  rt = rtnum

  c_mRTSetConfigIn = ait.M1553RTSetConfigIn(mEnableMode=ait.M1553_RT_ENABLE_SIMULATION,
    mBusResponseControl=ait.M1553_RT_RESPONSE_BOTH, 
    mResponseTime=ait.M1553Float(common.RESPONSE_TIME),
    mNextStatusWord=ctypes.c_uint16(rt<< 11),
    mLastCommandWord=ctypes.c_uint16(0xFFFF),
    mLastStatusWord=ctypes.c_uint16(0xFFFF)
    )
  res = AITErr(ait.m1553RTSetConfig(c_chanHandle, ctypes.c_uint8(rtnum), ctypes.byref(c_mRTSetConfigIn)),
                'ait.m1553RTSetConfig')
  
  #print("ait.m1553RTSetConfig result = {}".format(res))  
  return res
  

def py_m1553RTSASetConfig(c_chanHandle, headerID, rtnum, subaddr, direction, mode):
  print("mode is {}".format(mode))
  mRTSAval = subaddr
  if mode:
    print("RT/SA {}/{} direction {} will be set for modecodes".format(rtnum,subaddr,direction))
    modetype = common.MODES[mode][0]
    mRTSAval = int(common.MODES[mode][1])
    if modetype != 'R':
      print("Setting up for modecode T")
      c_mSubAddressType = ait.M1553_RT_TRANSMIT_MODECODE
    else:
      print("Setting up for modecode R")      
      c_mSubAddressType = ait.M1553_RT_RECEIVE_MODECODE
  else:
    print("RT/SA {}/{} direction {} will NOT be set for modecodes".format(rtnum,subaddr,direction))
    if direction == common.Direction.RECEIVE:
      #print("c_mSubAddressType = ait.M1553_RT_RECEIVE_SA")
      c_mSubAddressType = ait.M1553_RT_RECEIVE_SA
    else:
      c_mSubAddressType = ait.M1553_RT_TRANSMIT_SA
  
  if rtnum == common.STATUS_BITS_RT or common.STATUS_BITS_RT == -1:
    statusbits = common.STATUS_BITS
  else:
    statusbits = 0x0000

  print("For RT {}, statusbits are {:04x}".format(rtnum,statusbits))
  c_mRTSAConfigType = ait.M1553RTSAConfigType(mBufferHeaderID = ctypes.c_uint16(headerID),
    mRTSAControl = ait.M1553_RT_ENABLE_SA_INTERRUPT_TRANSFER, #M1553_RT_ENABLE_SA_INTERRUPT_TRANSFER
    #mRTSAResponseControl=ctypes.c_uint8
    mStatusWordMask = ctypes.c_uint16(statusbits),
    mStatusWorddMaskControl = ait.M1553_RT_MASK_NEXT_STATUS_WORD_OR
    )  
  
  c_mRTSASetConfigIn = ait.M1553RTSASetConfigIn(mRT=ctypes.c_uint8(rtnum),
                                            mRTSA=ctypes.c_uint8(mRTSAval), #LISA was subaddr
                                            mTransferType=c_mSubAddressType,
                                            mRTSAProperties=c_mRTSAConfigType
    )
  #print("About to call ait.m1553RTSASetConfig")
  AITErr(ait.m1553RTSASetConfig(c_chanHandle, ctypes.byref(c_mRTSASetConfigIn)),
                'ait.m1553RTSASetConfig') 
  
  
#M1553_INTERRUPT_RT = 0# /usr/local/include/ait_mil/m1553_system.h: 128

#M1553_INTERRUPT_BC = 1# /usr/local/include/ait_mil/m1553_system.h: 128

#M1553_INTERRUPT_BM = 2# 


def py_m1553InstallInterruptHandler(c_chanHandle,interrupttype,chanNum):
  global INT_FUNC_PTR, CHAN_FILEDATA
  #return
  print("Installing the interrupt handler for {} on chan {}".format(interrupttype,chanNum))
  userdata = USERDATA(channum=ctypes.c_uint32(chanNum))   
  if interrupttype == ait.M1553_INTERRUPT_BM:
    print("\n\n\n$$$$$$\n$$$$$$\n$$$$$$Setting up the BM interrupt")
    fo = open(os.path.join(common.BM_OUTPUT_DIR,common.BM_OUTPUT_FILE.replace("C",str(chanNum)).replace("D","AIT")),"wb")
    fo.flush()
    filedata = FileData(c_chanHandle=c_chanHandle, channum=chanNum, userdata = userdata, fileobj=fo) 
  else:
    filedata = FileData(c_chanHandle=c_chanHandle, channum=chanNum, userdata = userdata)
    
  CHAN_FILEDATA[chanNum] = filedata
 
    
  print("About to do the actual install")
  c_mInstallInterruptHandlerIn = ait.M1553InstallInterruptHandlerIn(mType=interrupttype,
    mIntFunc= INT_FUNC_PTR,
    #mUserData=ctypes.cast(POINTPTR(point),ait.M1553Addr))      #ctypes.cast(ctypes.pointer(point),ait.M1553Addr)
    mUserData=ctypes.cast(ctypes.pointer(userdata),ait.M1553Addr)) 

  
  AITErr(ait.m1553InstallInterruptHandler(c_chanHandle, ctypes.byref(c_mInstallInterruptHandlerIn)),
                'ait.m1553InstallInterruptHandler')   
  print("Done with the actual install")

def py_m1553Close(c_Handle):
  AITErr(ait.m1553Close(c_Handle), 'ait.m1553Close')      
   
  
def py_m1553DeleteInterruptHandler(c_chanHandle,interrupttype,chanNum):
  #return   
  c_mDeleteInterruptHandlerIn = ait.M1553DeleteInterruptHandlerIn(mType=interrupttype)  
  AITErr(ait.m1553DeleteInterruptHandler(c_chanHandle, ctypes.byref(c_mDeleteInterruptHandlerIn)),
                'ait.m1553DeleteInterruptHandler')     

 
def update_bm_dump_by_chan(chanNum):
  filedata = CHAN_FILEDATA[chanNum]
  print("Dumping remaining data for BM on channel {}\n".format(chanNum))
  filedata.fileobj.flush()
  update_bm_dump(filedata)

def update_bm_dump(filedata,checkbuflen=True,c_chanHandle=None):
  print("In update_bm_dump")
  
  if filedata:
    c_chanHandle = filedata.c_chanHandle
  

  buff_t = ctypes.c_uint32 * int(common.BM_BUFFER_SIZE/4) #BM_BUFFER_SIZE is in bytes
  buff = buff_t()
  ptr = ctypes.pointer(buff)
  buffaddr = ctypes.cast(ptr,ait.M1553Addr) 

  c_mBMReadIn = ait.M1553BMReadIn(mpBuffer = buffaddr,
                                  mBufferSize = ctypes.c_uint32(common.BM_BUFFER_SIZE),
                                  mUntil = ait.M1553_BM_READ_UNTIL_FILL_POINTER
                                  )  
 
  c_mBMReadOut = ait.M1553BMReadOut(mEntriesRead=ctypes.c_uint32(0))

  AITErr(ait.m1553BMRead(c_chanHandle, ctypes.byref(c_mBMReadIn), ctypes.byref(c_mBMReadOut)), 'ait.m1553BMRead')   

  print("The number of entries dumped is {}".format(c_mBMReadOut.mEntriesRead))
  
  if filedata is None:
 
    for i in range(c_mBMReadOut.mEntriesRead):
      if (i % 7 == 0):
        print("\n") 
      print("{:08x} ".format(buff[i]),end='')

  else :
  
    buffarray = array.array('I',buff[:c_mBMReadOut.mEntriesRead])
    buffarray.tofile(filedata.fileobj)
    filedata.fileobj.flush()
    #filedata.fileobj.close()
  
  return c_mBMReadOut.mEntriesRead

def py_get_individual_rt_statuses(c_chanHandle,RTs):
  for rt in RTs:
    c_rtGetRTStatusOut = ait.M1553RTGetRTStatusOut(mRTRunning = ait.M1553Boolean(0),
                                                   mMessageCount = ctypes.c_uint32(0),
                                                   mErrorCount = ctypes.c_uint32(0),
                                                   mNextStatusWord = ctypes.c_uint16(0),
                                                   mLastStatusWord = ctypes.c_uint16(0),
                                                   mLastCommandWord = ctypes.c_uint16(0)
                                                   )
    
    AITErr(ait.m1553RTGetRTStatus(c_chanHandle, ctypes.c_uint8(rt), ctypes.byref(c_rtGetRTStatusOut)), 'ait.M1553RTGetRTStatus')  
    #print("RT{}: MESSAGES={}\tERRORS={}".format(rt ,c_rtGetRTStatusOut.mMessageCount,c_rtGetRTStatusOut.mErrorCount))

def py_get_global_rt_status(c_chanHandle):
  c_rtGetStatusOut = ait.M1553RTGetStatusOut(mRunning = ait.M1553Boolean(0),
    mMessageCount = ctypes.c_uint32(0),
    mErrorCount = ctypes.c_uint32(0))
  AITErr(ait.m1553RTGetStatus(c_chanHandle, ctypes.byref(c_rtGetStatusOut)),'ait.m1553RTGetStatus')
  return c_rtGetStatusOut.mMessageCount,c_rtGetStatusOut.mErrorCount



def py_dumpTransferStatus(c_chanHandle, transferID, summary = True):

  c_bcGetXferStatusIn = ait.M1553BCGetTransferStatusIn(mResetBufferErrorStatus = ait.M1553Boolean(0),
                                                       mResetBufferStatus = ait.M1553Boolean(0)
                                                       )
  c_XferBufferStatus = ait.M1553BCBufferStatusType()
  c_bcGetXferStatusOut = ait.M1553BCGetTransferStatusOut(mBufferStatus=c_XferBufferStatus)
  AITErr(ait.m1553BCGetTransferStatus(c_chanHandle, ctypes.c_uint16(transferID),ctypes.byref(c_bcGetXferStatusIn),ctypes.byref(c_bcGetXferStatusOut)),'ait.m1553BCGetTransferStatus')
  #print("For AIT xfer ID {}, messages {} errors {} mStatusWord1 {:04X} mStatusWord2 {:04X} ".format(transferID,c_bcGetXferStatusOut.mMessageCount, c_bcGetXferStatusOut.mErrorCount,
                                                                                            #c_bcGetXferStatusOut.mStatusWord1, c_bcGetXferStatusOut.mStatusWord2))
  if common.STATUS_BITS: #Check to see if status words contain the status bits
    if common.checkStatus(c_bcGetXferStatusOut.mStatusWord1) or common.checkStatus(c_bcGetXferStatusOut.mStatusWord2):
      print("\tFor AIT xfer ID {}, expected status bits received".format(transferID))
    else:
      print("\tFor AIT xfer ID {}, expected status bits NOT received!".format(transferID))
  
  if not summary:  #Want a complete dump for debugging
    print("\n\n@@@@@ Transfer stats: transferID = {} mCurrentBufferID = {} mLastBufferOffset = {} mBufferStatus.mBufferFillStatus = {} mBufferStatus.mReceivedBus = {} mBufferStatus.mBufferError = {} ".format(transferID,c_bcGetXferStatusOut.mCurrentBufferID,
                                                                                                                              hex(c_bcGetXferStatusOut.mLastBufferOffset),
                                                                                                                              c_bcGetXferStatusOut.mBufferStatus.mBufferFillStatus,
                                                                                                                              c_bcGetXferStatusOut.mBufferStatus.mReceivedBus,
                                                                                                                              c_bcGetXferStatusOut.mBufferStatus.mBufferError))
    
  return transferID, c_bcGetXferStatusOut.mMessageCount, c_bcGetXferStatusOut.mErrorCount, c_bcGetXferStatusOut.mStatusWord1, c_bcGetXferStatusOut.mStatusWord2
  
def py_m1553BCGetStatus(c_chanHandle):
  c_bcGetStatusOut = ait.M1553BCGetStatusOut()
  AITErr(ait.m1553BCGetStatus(c_chanHandle, ctypes.byref(c_bcGetStatusOut)),'ait.m1553BCGetStatus')
  return c_bcGetStatusOut.mMessageCount,c_bcGetStatusOut.mErrorCount

def py_m1553BMGetStatus(c_chanHandle):
  c_bmGetStatusOut = ait.M1553BMGetStatusOut()
  AITErr(ait.m1553BMGetStatus(c_chanHandle, ctypes.byref(c_bmGetStatusOut)),'ait.m1553BCGetStatus')
  return c_bmGetStatusOut.mMessageCount,c_bmGetStatusOut.mErrorCount

'''
int update_bm_dump(struct hc1553_userdata *bmdump, int checkbuflen)
{
  M1553BMReadIn    bmReadIn = {0};
  M1553BMReadOut  bmReadOut = {0};
  uint32_t    dataSizeBytes = 0x800000; // 8 MB which is way larger than the default half-buffer size.
  uint32_t*    data;

  data = malloc(dataSizeBytes);

  if (verbose_level > 1) {
    fprintf(stderr, "update_bm_dump: %d\n", checkbuflen);
  }

  if (debug_level)
    fprintf(stderr, "Bus Monitor half-buffer interrupt received for channel %d.\n", bmdump->hu_channum);

  bmReadIn.mUntil = M1553_BM_READ_UNTIL_FILL_POINTER;
  bmReadIn.mpBuffer = data;
  bmReadIn.mBufferSize = bmdump->bm_buf_size; // Should only be getting half buffer at most


  if (verbose_level > 1) {
    fprintf(stderr, "update_bm_dump bmReadIn.mBufferSize=%x\n", bmReadIn.mBufferSize);
  }

  // Read the latest Bus Monitor data from the board.
  AIT_CHECK(m1553BMRead(hc1553_env.channels[bmdump->hu_channum], &bmReadIn, &bmReadOut));

  if (debug_level)
    fprintf(stderr, "%d entries read from Bus Monitor on channel %d.\n", bmReadOut.mEntriesRead, bmdump->hu_channum);

  if (debug_level && checkbuflen && bmReadOut.mEntriesRead < bmdump->bm_buf_size / 8) { // bm_buf_size is in bytes, mEntriesREad is in 4-byte BM entries, should be reading 1/2 buffer
    M1553BMGetBufferPointersOut bufptrs = {0};
    AIT_CHECK(m1553BMGetBufferPointers(hc1553_env.channels[bmdump->hu_channum], &bufptrs));
    fprintf(stderr, "ERROR, BM on channel %d fell behind, read just 0x%x entries, baseptr: 0x%08x, fillptr: 0x%08x. next read pointer wrapped past last read location.  Buf size:0x%x\n", bmdump->hu_channum, bmReadOut.mEntriesRead, bufptrs.mStartEntryOffset, bufptrs.mBufferFillOffset, bmdump->bm_buf_size);
  }

  // Write the raw bm capture

  fwrite(data, sizeof(uint32_t), bmReadOut.mEntriesRead, bmdump->raw_fp);
  fflush(bmdump->raw_fp);

  bmdump->entries_read += bmReadOut.mEntriesRead;

  free(data);

  return 1;
}
'''


 
if __name__ == '__main__':
    faulthandler.disable()
    faulthandler.enable(all_threads=True)

    numBoards = py_m1553Init()
    print("numBoards is {}".format(numBoards))
    
    for i in range(0, numBoards):
        print("Opening board {}".format(i))
        
        c_boardHandle = py_m1553BoardOpen(i)
        print("board handle = {}".format(c_boardHandle.value))
        c_boardInfo = py_m1553GetBoardInfo(c_boardHandle)

        for c in range(0, c_boardInfo.mChannelCount):
            print("Finding handle for channel {}".format(c))
            c_chanHandle = py_m1553ChannelOpen(c_boardHandle, c)
            print("{}: chan handle = {}".format(c, c_chanHandle.value))
            print("About to do a channel reset")
            py_m1553ChannelReset(c_chanHandle)
            print("About to do channel self-test")
            py_m1553ChannelBIT(c_chanHandle)
            
