from .waveform_synthesizer import Waveform_Synthesizer
__version_info__=(0,0,2)
__version__=".".join(map(str,__version_info__))
