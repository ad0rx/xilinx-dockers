import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import time
import math

mean = 0
std = .140
rise=14
sig=2.1/2
#sig=.86/2
thresh=.3/2

t = 500000000
t = 5000000

def zv(t):
    return np.random.normal(mean, std, size = t)

def rms(x):
    return np.sqrt(np.mean(x**2))

s = zv(t)

fail={}
high=86
low=40
step=5
high=30
low=10
step=2
numsample=8
for T in range(high,low,-step):
    fail[T] = 0

for i in range(t-2):
    for T in range(high,low,-step):
        thresh = T/100
        x = sorted(s[i:i+numsample])

        if x[0] >= thresh or x[-1] <= -thresh:
            for T in range(T,low,-step):
                fail[T] += 1
            break

for T in range(high,low,-step):
    print(f"For threshold {T/100}: {fail[T]} fails in {t} samples or {fail[T]*10000000/t} in 10^7")
