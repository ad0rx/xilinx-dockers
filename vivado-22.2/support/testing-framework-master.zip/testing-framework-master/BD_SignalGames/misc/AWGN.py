import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import time
import math
from scipy import signal

sample_frequency=400000000
sample_frequency=400000000
cutoff_frequency=28000000
#cutoff_frequency=4000000
mean = 0
std = .140
rise=25
sig=.86/2
#sig=2.1/2
thres=.6/2
#thres=.25/2
# For transformer coupled, 30mV ±5
hys=.03066-.00511

t = 4000
d = 30*100

# Random seed
#Rnd = np.random.default_rng()
# Fixed seed
Rnd = np.random.default_rng(4806)

def zv(t):
    return Rnd.normal(mean, std, size = t)

def rms(x):
    return np.sqrt(np.mean(x**2))

s = np.zeros(t)
S = np.zeros(t)


def outlevel(duration, sign):
    Sig = np.zeros(duration)
    c = 0
    for i in range(0, rise):
        Sig[c] = math.sin(math.radians(i * 90/rise)) * sign * sig
        c += 1
    for i in range(0, duration-rise*2):
        Sig[c] = sign * sig
        c += 1
    for i in range(-rise, 0, 1):
        Sig[c] = math.sin(math.radians(i * 90/rise)) * sign * sig * -1
        c += 1
    return Sig


c = 999
while c + d < t:
    S[c:c+150] = outlevel(150, 1)
    for i in range(0, 150):
        s[c] = sig
        c += 1
    S[c:c+150] = outlevel(150, -1)
    for i in range(0, 150):
        s[c] = -sig
        c += 1
    for j in range(0, 17):
        S[c:c+50] = outlevel(50, 1)
        for i in range(0, 50):
            s[c] = sig
            c += 1
        S[c:c+50] = outlevel(50, -1)
        for i in range(0, 50):
            s[c] = -sig
            c += 1

x = zv(t)
# Square wave
y = s
# Sine wave
y = S
# Add noise
y = y + x

# Butterworth low pass filter, "order" of filter is not principled.
# Useful only with a filter under 25MHz for a 100MHz sample rate
if True:
    # Random order of butterworth
    b, a = signal.butter(1, cutoff_frequency / (sample_frequency/2), 'low')
    y = signal.filtfilt(b, a, y)[::2]

# signal data (true) or discretized
if True:
    plt.plot(y)
    plt.plot(np.ones(t)*thres)
    plt.plot(np.ones(t)*(thres-hys))
    plt.plot(np.ones(t)*-thres)
    plt.plot(np.ones(t)*-(thres-hys))
else:
    # Discretize
    dS = list(map(lambda v: -1 if v < -thres else 1 if v > thres else 0, y))
    plt.plot(dS, ls='', marker='.', ms=1)


plt.show()
