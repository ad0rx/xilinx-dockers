#!/usr/bin/python
#
# ++Copyright Peraton Labs GPR++
#
# Copyright (c) 2021 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton Labs GPR- -
#
# Engineer: SR
# Reviewer: TBD
# Description: Unit tests for waveform_synthesizer.py
#

from waveform_synthesizer import Waveform_Synthesizer as WS
import numpy as np
import unittest
import types



class Test_words16_to_18(unittest.TestCase):

    def test_singleton_even(self):
        self.assertEqual(WS.words16_to_18([0]), [0b100000000000000001])


    def test_singleton_odd(self):
        self.assertEqual(WS.words16_to_18([1]), [0b100000000000000010])


    def test_singleton_high(self):
        self.assertEqual(WS.words16_to_18([0x8000]), [0b110000000000000000])


    def test_singleton_ones(self):
        self.assertEqual(WS.words16_to_18([0xffff]), [0b111111111111111111])




class Test_train_2Msignal_gen(unittest.TestCase):

    def test_singleton_nospace_zeros(self):
        self.assertTrue(np.array_equal(WS.train_2Msignal_gen([0], pre=0, post=0), np.array([-1,-1,-1,1,1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1], dtype=np.int8)))


    def test_singleton_nospace_cmdzero(self):
        self.assertTrue(np.array_equal(WS.train_2Msignal_gen(WS.words16_to_18([0]), pre=0, post=0), np.array([1,1,1,-1,-1,-1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,1,-1], dtype=np.int8)))


    def test_dual_nospace(self):
        self.assertTrue(np.array_equal(WS.train_2Msignal_gen(WS.words16_to_18([0,0]), pre=0, post=0),
                                       np.array([1,1,1,-1,-1,-1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,1,-1,
                                                 -1,-1,-1,1,1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,1,-1], dtype=np.int8)))


    def test_dual_5a(self):
        x = WS.train_2Msignal_gen(WS.words16_to_18([0x5555,0xaaaa]), pre=0, post=0)
        y = np.array([ 1,  1,  1, -1, -1, -1, -1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1,  1, -1,
                      -1, -1, -1,  1,  1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1, -1,  1,  1, -1])
        self.assertTrue(np.array_equal(x, y))


    def test_singleton_space_zeros(self):
        self.assertTrue(np.array_equal(WS.train_2Msignal_gen([0], pre=.000001, post=.000002), np.array([0, 0, -1,-1,-1,1,1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,-1,1,0,0,0,0], dtype=np.int8)))


class Test_random_oracle(unittest.TestCase):

    def subtest_oracle(self, oraclememory, magic, cnt):
        if magic != 0xfeedface:
            assert("Wha?")      # pragma: no cover
        seen = {}
        choices = [1, 5, 10, -1, -5 -10]
        for i in range(cnt):
            x = WS.random_oracle(i%2, i%3, i%5, choices, oraclememory)
            choices[x]
            seen[x] = 1
        return len(seen) == len(choices)


    def test_test(self):
        self.assertFalse(self.subtest_oracle({}, 0xfeedface, 1))


    def test_hash(self):
        self.assertTrue(self.subtest_oracle({}, 0xfeedface, 100))


    def test_Rnd(self):
        Rnd = np.random.default_rng(1)
        oraclememory = {}
        oraclememory['random_oracle_numpy_random_generator'] = Rnd
        self.assertTrue(self.subtest_oracle({}, 0xfeedface, 100))


    def test_Rnd_reproduce(self):
        Rnd = np.random.default_rng(1)
        oraclememory = {}
        oraclememory['random_oracle_numpy_random_generator'] = Rnd
        choices = [ x for x in range(1000000) ]
        self.assertEqual(WS.random_oracle(0, 0, 0, choices, oraclememory), 473188)



class Test_analogizer(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        WS.args = type('Args', (object,), {'debug': 0})
    @classmethod
    def tearDownClass(cls):
        WS.args = None


    def test_zeros(self):
        x = WS.analogizer([0], awgn_rnd=0)
        y = filter(lambda v: abs(v) > .0001, x)
        y = list(y)
        self.assertEqual(len(y), 0)
        self.assertEqual(len(x), 50)


    def test_ones(self):
        x = WS.analogizer([1], awgn_rnd=0, low_pass_filter_mhz=0)
        y = filter(lambda v: v > .8599/2 and v < .8601/2, x)
        y = list(y)
        self.assertEqual(len(y), 50)


    def test_negones(self):
        x = WS.analogizer([-1], awgn_rnd=0, low_pass_filter_mhz=0)
        y = filter(lambda v: v < -.8599/2 and v > -.8601/2, x)
        y = list(y)
        self.assertEqual(len(y), 50)


    def test_test(self):
        x = WS.analogizer([1], awgn_rnd=0, low_pass_filter_mhz=0)
        y = filter(lambda v: v < -.8599/2 and v > -.8601/2, x)
        y = list(y)
        self.assertEqual(len(y), 0)


    def test_slowtrans(self):
        x = WS.analogizer([1,0], raw_samplerate_mhz=4, output_samplerate_mhz=4, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=500)
        self.assertEqual(len(x), 4)
        self.assertEqual(x[0], .86/2)
        self.assertTrue(x[1] < .86/2)
        self.assertTrue(x[1] > 0)
        self.assertEqual(x[3], 0)


    def test_fasttrans(self):
        x = WS.analogizer([1,0], raw_samplerate_mhz=4, output_samplerate_mhz=4, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=0)
        self.assertEqual(len(x), 4)
        self.assertEqual(x[0], .86/2)
        self.assertEqual(x[1], .86/2)
        self.assertEqual(x[2], 0)
        self.assertEqual(x[3], 0)


    def test_slewshape(self):
        sine = WS.analogizer([1,-1], raw_samplerate_mhz=16, output_samplerate_mhz=16, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=250, slew_type='sine')
        linear = WS.analogizer([1,-1], raw_samplerate_mhz=16, output_samplerate_mhz=16, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=250, slew_type='linear')
        self.assertEqual(sine[0], .86/2)
        self.assertEqual(sine[5], .86/2)
        self.assertTrue(sine[6] > 0 and sine[6] < .86/2)
        self.assertEqual(sine[7], 0)
        self.assertTrue(sine[8] < 0 and sine[8] > -.86/2)
        self.assertEqual(sine[9], -.86/2)
        self.assertEqual(sine[15], -.86/2)

        self.assertEqual(linear[0], .86/2)
        self.assertEqual(linear[5], .86/2)
        self.assertTrue(linear[6] > 0 and linear[6] < .86/2)
        self.assertEqual(linear[7], 0)
        self.assertTrue(linear[8] < 0 and linear[8] > -.86/2)
        self.assertEqual(linear[9], -.86/2)
        self.assertEqual(linear[15], -.86/2)

        self.assertTrue(sine[6] > linear[6])
        self.assertTrue(sine[8] < linear[8])


    def test_awgn(self):

        Rnd = np.random.default_rng(1)

        # Takes a long time (3+ min on my system)--many points--since we need to be able to see all noise including below 1kHz at 500MHz sample rate
        samplerate = 500000000
        minfreq = 500

        # Note that the 1553C standard requires .14 RMS, but also requires that .14 RMS energy distributed between 1kHz and 4 MHz
        # Thus, the input to the noise filter has experimentally been discovered to be as listed below.
        # The noise is then band-filtered to the desired range, giving us the 1553C desired RMS.
        noise = WS.analogizer(np.zeros(int(samplerate / minfreq)), awgn_rms=1.133, awgn_rnd=Rnd, low_pass_filter_mhz=0)

        rms = np.sqrt(np.mean(noise**2))
        if False:               # pragma: no cover
            print(rms,len(noise))
            fftabs = np.abs(np.fft.rfft(noise))
            xAxis = [(x / samplerate) for x in range(noise.size)]
            xfreq = np.fft.fftfreq(fftabs.size, 1/samplerate)
            fftabs = fftabs[:int(fftabs.size/2)]
            xfreq = xfreq[:int(xfreq.size/2)]

            import matplotlib.pyplot as plt
            fig,ax = plt.subplots(2)

            ax[0].set_xlim([0, noise.size/samplerate])
            ax[0].set_xlabel('Time (s)')
            ax[0].set_ylabel('Amplitude')
            ax[0].set_title('Oscillascope')
            ax[0].plot(xAxis, noise)

            ax[1].set_xlim([np.amin(xfreq), np.amax(xfreq)])
            ax[1].set_ylim([np.amin(fftabs), np.amax(fftabs)])
            ax[1].set_xlabel('Frequency (Hz)')
            ax[1].set_ylabel('Energy')
            ax[1].set_title('Spectrum')
            ax[1].plot(xfreq, fftabs)

            plt.show()

        self.assertGreater(rms, .139)
        self.assertLess(rms, .141)


    def test_sampling(self):
        """Validate that random is random, non-random isn't, oh and that downsampling properly adjusts output size"""

        Rnd = np.random.default_rng(1)
        oraclememory = {}
        oraclememory['random_oracle_numpy_random_generator'] = Rnd

        r1 = WS.analogizer([1,-1,1,-1,1,-1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=250, user_oraclememory_dict=oraclememory)
        r2 = WS.analogizer([1,-1,1,-1,1,-1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=250, user_oraclememory_dict=oraclememory)
        r3 = WS.analogizer([1,-1,1,-1,1,-1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=250)
        r4 = WS.analogizer([1,-1,1,-1,1,-1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=250, sample_wander_oracle=[0,1,2,3,4])
        s1 = WS.analogizer([1,-1,1,-1,1,-1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=250, sample_wander_oracle=1)
        s2 = WS.analogizer([1,-1,1,-1,1,-1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=250, sample_wander_oracle=1)

        for x in (r1,r2,r3,r4,s1,s2):
            self.assertEqual(x[36], .86/2)
            self.assertLess(x[38], .86/2)
            self.assertGreater(x[61], -.86/2)
            self.assertEqual(x[63], -.86/2)

            self.assertEqual(x[86], -.86/2)
            self.assertGreater(x[88], -.86/2)
            self.assertLess(x[111], .86/2)
            self.assertEqual(x[113], .86/2)

            self.assertEqual(x[136], .86/2)
            self.assertLess(x[138], .86/2)
            self.assertGreater(x[161], -.86/2)
            self.assertEqual(x[163], -.86/2)

            self.assertEqual(x[186], -.86/2)
            self.assertGreater(x[188], -.86/2)
            self.assertLess(x[211], .86/2)
            self.assertEqual(x[213], .86/2)

        R1 = [r1[38], r1[61], r1[88], r1[111], r1[138], r1[161], r1[188], r1[211]]
        R2 = [r2[38], r2[61], r2[88], r2[111], r2[138], r2[161], r2[188], r2[211]]
        R3 = [r3[38], r3[61], r3[88], r3[111], r3[138], r3[161], r3[188], r3[211]]
        R4 = [r4[38], r4[61], r4[88], r4[111], r4[138], r4[161], r4[188], r4[211]]
        S1 = [s1[38], s1[61], s1[88], s1[111], s1[138], s1[161], s1[188], s1[211]]
        S2 = [s2[38], s2[61], s2[88], s2[111], s2[138], s2[161], s2[188], s2[211]]

        self.assertSequenceEqual(S1, S2)
        self.assertTrue(S1 != R2)
        self.assertTrue(S1 != R3)
        self.assertTrue(S1 != R4)
        self.assertTrue(R1 != R2)
        self.assertTrue(R1 != R3)


    def test_ringing(self):
        x = WS.analogizer([1,-1,0,0,1,-1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=10)
        y = WS.analogizer([1,-1,0,0,1,-1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=10, ringing_oracle=WS.ring_oracle_5by2)
        self.assertEqual(x[50], -.86/2)
        self.assertEqual(x[51], -.86/2)
        self.assertEqual(y[50], -.86/2)
        self.assertLess(y[51], -.86/2)


    def test_bias(self):
        x = WS.analogizer([0,0,1,-1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=10)
        y = WS.analogizer([0,0,1,-1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=10, common_mode_offset=1)
        self.assertEqual(x[0], 0)
        self.assertEqual(y[0], 1)
        self.assertEqual(x[101], .86/2)
        self.assertEqual(y[101], 1+.86/2)


    def test_overskewlen(self):
        x = WS.analogizer([1,-1,-1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=500)
        y = WS.analogizer([1,-1,-1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=600)
        self.assertEqual(x[24], .86/2)
        self.assertEqual(y[24], .86/2)
        self.assertLess(x[25], .86/2)
        self.assertLess(y[25], .86/2)
        self.assertGreater(x[74], -.86/2)
        self.assertGreater(y[74], -.86/2)
        self.assertEqual(x[75], -.86/2)
        self.assertGreater(y[75], -.86/2)


    def test_thresholdizer(self):
        x = WS.analogizer([1,-1,-1,1], raw_samplerate_mhz=500, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=250)
        digix = WS.threshold(x, .86/2, -.86/2, .1, .1)
        digiy = WS.threshold(x, .87/2, -.87/2, .1, .1)
        digiz = WS.threshold(x, .86/2, -.86/2, .4, .4)
        self.assertEqual(digix[0], 1)
        self.assertEqual(digiy[0], 0)
        self.assertEqual(digiz[0], 1)
        self.assertEqual(digix[42], 1)
        self.assertEqual(digiz[42], 1)
        self.assertEqual(digix[43], 0)
        self.assertEqual(digiz[43], 1)


    def test_zerowander(self):
        x = WS.analogizer([1,-1,1,-1,1], raw_samplerate_mhz=100, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=95)
        y = WS.analogizer([1,-1,1,-1,1], raw_samplerate_mhz=100, output_samplerate_mhz=100, awgn_rnd=0, low_pass_filter_mhz=0, slew_oracle_ns=95, zero_wandering_oracle_ns=[0,150,0,-150])

        self.assertGreater(x[49], 0)
        self.assertEqual(x[50], 0)
        self.assertLess(x[51], 0)

        self.assertLess(x[99], 0)
        self.assertEqual(x[100], 0)
        self.assertGreater(x[101], 0)

        self.assertGreater(x[149], 0)
        self.assertEqual(x[150], 0)
        self.assertLess(x[151], 0)

        self.assertLess(x[199], 0)
        self.assertEqual(x[200], 0)
        self.assertGreater(x[201], 0)

        self.assertGreater(y[49], 0)
        self.assertEqual(y[50], 0)
        self.assertLess(y[51], 0)

        self.assertLess(y[114], 0)
        self.assertEqual(y[115], 0)
        self.assertGreater(y[116], 0)

        self.assertGreater(y[149], 0)
        self.assertEqual(y[150], 0)
        self.assertLess(y[151], 0)

        self.assertLess(y[184], 0)
        self.assertEqual(y[185], 0)
        self.assertGreater(y[186], 0)



if __name__ == '__main__':
    unittest.main()
