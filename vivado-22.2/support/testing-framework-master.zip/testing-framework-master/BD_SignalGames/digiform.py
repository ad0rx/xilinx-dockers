#! /usr/bin/python3
#
# ++Copyright Peraton Labs GPR++
#
# Copyright (c) 2021 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton Labs GPR- -
#
# Engineer: JTT
# Reviewer: TBD
# Description:
import sys
import os
import stat
import argparse
import re


def sec2nsec(sec):
    return(sec * 1000000000)


def nsec2sec(sec):
    return(round(float(nsec) / 1000000000.0))


def usec2nsec(usec):
    return(usec * 1000)


def sec2usec(sec):
    return(sec * 1000)


def nsec2usec(nsecs, decimal=0):
    usecs = float(nsecs) / 1000.0
    return(round(usecs, ndigits=decimal))


def parity16_parallel_odd(v):
    v &= 0xffff
    v ^= v >> 8
    v ^= v >> 4
    v &= 0xf
    return int(not(((0x6996 >> v) & 1)))

#Currently, this check can be doneonly for files that have square-wave style trasnsitions.
def checkFileForBitSymmetry(infile):

    words = []
    word = []
    bitnum = -1 
    leftcount = 0
    rightcount = 0
    left = None
    right = None
    val = None
    isReset = False
 

    def printit():
        if leftcount not in [50,150] or rightcount not in [50,150]:
            error = "YES"
        else:
            error = ""
        print(f"BITNUM: {bitnum}  \tVAL: {val}  \tleft: {left} \tright: {right} \tleftcount: {leftcount}  \trightcount: {rightcount} \terror: {error}")
        
    def newbit():
        nonlocal bitnum, leftcount, rightcount, left, right, val, isReset
        printit()
        bitnum = (bitnum + 1) % 18
        leftcount = 0
        rightcount = 0
        left = None
        right = None
        val = None
        isReset = True


    
    with open(infile,"r") as f:
        print(f"Looking at {infile}")

        for line in f:
            sl=line.strip()
            if sl == "0":
                sl = 0
            elif sl == "-1":
                sl = -1
            elif sl == "1":
                sl = 1
            #print(f"sl = {sl}")
            if sl == 0 and isReset == False:  #Don't want to keep resetting for contiguous zeros
                newbit()
            elif sl == -1 or sl == 1:
                if left is None:
                    left = sl
                    leftcount += 1
                elif sl == left and val is None:
                    leftcount += 1
                elif sl != left and val is None:
                    right = sl
                    rightcount += 1
                    if left == 1 and right == -1:
                        val = 1
                    elif left == -1 and right == 1:
                        val = 0
                else: #There is a val
                    if sl != right:
                        newbit()
                        left = sl
                        leftcount +=1
                    else:
                        rightcount += 1
                        if (bitnum == 0 and rightcount == 150) or (bitnum > 0 and rightcount == 50):
                            newbit()
                        
                        
                    
                


class ExcessiveMidBitZeros(Exception):
    def __init__(self, zero_count,
                 message="Exessive threshold zeros seen within a single bit"):
        self.zero_count = zero_count
        self.message = message
        super().__init__(self.message)


class UnexpectedLine(Exception):
    def __init__(self, Line, message="Sample seen on unepected line"):
        self.Line = Line
        self.message = message
        super().__init__(message)


class IllegalThresholdTransition(Exception):
    def __init__(self, message="Threshold samples transitionsed from 1/-1 to -1/1 without passing through zero"):
        self.message = message
        super().__init__(self.message)


class UnexpectedCompleteWord(Exception):
    def __init__(self, message="Got a complete 1553 word at an unexpected time"):
        self.message = message
        super().__init__(self.message)


class IllegalThresholdBounce(Exception):
    def __init__(self, message="Threshold samples bounced from 1/-1 to zero and back"):
        self.message = message
        super().__init__(self.message)


class IllegalThresholdSampleValue(Exception):
    def __init__(self, sample, message="Threshold sample was not a valid value"):
        self.sample = sample
        self.message = message
        super().__init__(self.message)


class UnexpectedZeroThresholdSample(Exception):
    def __init__(self, message="Saw zero instead of 1 or -1 at midpoint start"):
        self.message = message
        super().__init__(self.message)


class NotManchesterBit(Exception):
    def __init__(self, message="Did not find zero midpoint crossing to establish bit value"):
        self.message = message
        super().__init__(self.message)


class DigiformManchesterBit():
    # Time: Relative time in ns
    # Line: The line being read
    # bit_length: How long is this bit. Valid values are: 1, 1000, 3, 3000
    # max_zero_count: Maximum number of consecutive zeros we should
    # see while parsing a single bit
    # midpoint_offset: The time (ns) plus/minus around the midpoint
    # where we keep track of the midpoint crossing
    def __init__(self, Line, word_tracker, bit_length=1, max_zero_count=10, midpoint_offset=50, sample_time=10):
        self.Line = Line

        if bit_length == 1000:
            self.bit_length = 1
        elif bit_length == 3000:
            self.bit_length = 3
        else:
            self.bit_length = bit_length
        

        if (self.bit_length != 1) and (self.bit_length != 3):
            raise IllegalBitLength(self.bit_length)

        #self.bit_length = bit_length  #I think this code is extraneous and wrong in some cases.  For instance, if the input bit_length == 1000 or 3000
        self.zero_count = 0
        self.max_zero_count = max_zero_count

        # 1553 standard requires 1MHz bit rate (ie: 1 bit per
        # 1/1000000 of a second)
        #
        # And, yes, these computation have fixed results, but what the hell
        #
        self.samples_per_bit = round((float(sec2usec(bit_length)) / float(sample_time))) #This works out in the end, but this code needs to be fixed.  Are the units of bit length usec?  If sample time is in nsec, then we want usec2nsec.
        self.midpoint_sample = round(float(self.samples_per_bit)/2.0)

        # Now compute the range of samples around the midpoint which
        # will consider as being "in the middle"
        self.midpoint_sample_range = round(self.midpoint_sample * .2)
        self.midpoint_low = self.midpoint_sample - self.midpoint_sample_range
        self.midpoint_high = self.midpoint_sample + self.midpoint_sample_range
        self.sample_count = 0
        self.end_sample_count = round(float(sec2usec(bit_length)) / float(sample_time))

        #print(f"Midpoint: {self.midpoint_sample}: Range: {self.midpoint_sample_range}: Low: {self.midpoint_low}: High: {self.midpoint_high}")

        self.bit_value = None  # Illegal value
        self.finished = False
        self.first_sample = None
        self.looking_at = None
        self.word_tracker = word_tracker # Which Digiform1553Word instance is this Digiform1553Bit instance a part of

    def get_line(self):
        return self.Line

    def set_line(self, line):
        Line = line

    # Add new sample to current bit tracking.
    #
    # The final results will be tuple of (BitStartTime, BitLine, BitValue).
    #
    # Returns True when have a complete bit, False otherwise.
    #
    def add_sample(self, Line, sample):
        if not isinstance(sample, int) or (sample < -1) or (sample > 1):
            raise IllegalThresholdSampleValue(sample)

        if Line != self.Line:
            raise UnexpectedLine(Line)

        # NB: Sample counts start at 1 not 0, so comparisons should be <- and >-
        self.sample_count += 1

        #print(f"BIT PROCESSING: sample count: {self.sample_count}: midpoint sample: {self.midpoint_sample}: midpoint_start: {self.midpoint_low}: midpoint_end: {self.midpoint_high}")

        if self.sample_count >= self.midpoint_low:
            #print(f"Reached midpoint low: {self.sample_count}: sample: {sample}")
            if self.looking_at is None:
                # This is the first sample that we actually consider
                self.looking_at = sample
                self.first_sample = sample
                if sample == 0:
                    raise UnexpectedZeroThresholdSample

            if self.sample_count <= self.midpoint_high:
                #print(f"Inside midpoint range")
                if self.looking_at == -1:
                    if sample == -1:
                        # Nothing to see here.
                        pass
                    elif sample == 0:
                        self.looking_at = sample
                        self.zero_count = 1
                    else:  # Sample == 1
                        # Transitioned from -1 to 1 directly
                        #If self.max_zero_count == 0, then we allow direct transitions within a bit.  (Actually, since this value is a max zero count, and not a min zero count, it's not clear that the original code should have ever disallowed direct transitions.  But to avoid changing the original code too much, I'll simply allow direct transitions when the max count is 0.)
                        if self.max_zero_count == 0:
                            self.bit_value = 0
                            self.looking_at = sample
                        else:    
                            raise IllegalThresholdTransition

                elif self.looking_at == 0:
                    if sample == -1:
                        if self.first_sample == -1:
                            raise IllegalThresholdBounce
                        else:
                            # We have seen a 1 -> 0 -> -1 progression, so this is a 1
                            self.bit_value = 1
                            self.lookint_at = sample
                    elif sample == 0:
                        self.zero_count += 1
                        if self.zero_count > self.max_zero_count:
                            raise ExcessiveMidBitZeros(self.zero_count)
                    else:  # sample == 1
                        if self.first_sample == 1:
                            raise IllegalThresholdBounce
                        else:
                            # We have seen a -1 -> 0 -> 1 progression, so this is a 0
                            self.bit_value = 0
                            self.looking_at = sample

                else:  # Looking at 1
                    if sample == 1:
                        # Nothing to see here
                        pass
                    elif sample == 0:
                        self.looking_at = sample
                        self.zero_count = 1
                    else:  # sample == -1
                        # Transitioned from 1 to -1 directly
                        #If self.max_zero_count == 0, then we allow direct transitions within a bit.  (Actually, since this value is a max zero count, and not a min zero count, it's not clear that the original code should have ever disallowed direct transitions.  But to avoid changing the original code too much, I'll simply allow direct transitions when the max count is 0.)
                        if self.max_zero_count == 0:
                            self.bit_value = 1
                            self.looking_at = sample
                        else:    
                            raise IllegalThresholdTransition                    
            else:
                #print(f"Reached the end of the midpoint range: {self.sample_count}"                  
                if self.bit_value is None:
                    raise NotManchesterBit
                elif self.max_zero_count == 0:
                    if sample == 0 or self.first_sample == sample:
                        return True

        if self.sample_count >= self.end_sample_count:
            return True

        return False

    def get_bit(self):
        # Return tuple of start line, and bit value
        bit_data = (self.Line, self.bit_value)
        return bit_data


class Digiform1553Word():
    def __init__(self, Line, sample_time, square_wave, transmission_tracker):
        self.Line = Line
        self.sample_time = sample_time
        self.square_wave = square_wave
        self.bit_tracker = None
        self.start_of_word = True
        self.bit_count = 0
        self.word = 0
        self.word_mask = 0
        self.parity = None
        self.transmission_tracker = transmission_tracker # Which Digiform1553Transmission instance is this Digiform1553Word instance a part of

        if self.square_wave:
            self.max_zero_count = 0
        else:
            self.max_zero_count = 10

    def get_line(self):
        return self.Line

    def set_line(self, line):
        self.Line = line

    # Add a new sample to word tracking
    #
    # The results will be tuple of (WordStartTime, WordLine, 18-bit
    # WordValue, WordParity)
    #
    # Returns True when we have a complete word; False otherwise
    #
    def add_sample(self, Line, sample):
        if self.bit_tracker is None:
            if self.start_of_word:
                self.bit_tracker = DigiformManchesterBit(Line, self, bit_length=3, sample_time=self.sample_time,max_zero_count=self.max_zero_count)
                self.start_of_word = False
            else:
                self.bit_tracker = DigiformManchesterBit(Line, self, bit_length=1, sample_time=self.sample_time,max_zero_count=self.max_zero_count)

        if self.bit_tracker.add_sample(Line, sample):
            # We have parsed a complete bit
            bit_data = (self.bit_tracker.get_bit())[1]
            
            #print(f"BIT: {bit_data}")
            self.word_mask = (self.word_mask << 1 | 0x1)
            self.word = (self.word << 1 | bit_data & 0x1) & self.word_mask
            self.bit_count += 1
            self.bit_tracker = None

            if self.bit_count == 18:
                self.parity = parity16_parallel_odd(self.word)
                self.start_of_word = True
                return True

        return False

    def get_word(self):
        word_data = (self.Line, self.word, self.parity)
        #print(f"Getting word: Time: {self.Time}")
        return(word_data)

    @staticmethod
    def word18_to_word20(word):
        sync = (word >> 17) & 0x1
        if sync == 1:
            word20_sync = 0x2
        else:
            word20_sync = 0x0
        return(word20_sync << 18 | word & 0x1ffff)


class Digiform1553Transmission():
    def __init__(self, sample_time=10, square_wave=False):
        self.Time = 0
        self.Line = 0
        self.sample_time = sample_time
        self.square_wave=square_wave
        self.transmissions = []
        self.word_tracker = None
        self.transmission_count = 0
        self.transmissions = []
        self.tracking_transmision = False
        self.zero_count = 0
        self.transmission_start_time = self.Time
        self.words = []
        self.list_sorted = False;

        self.sample_count = 0

        # Determine maximum number of samples between back2back words
        # The spac says the maximum back2back2 idle time is 2 usecs.
        self.max_non_idle_zeros = round(float(usec2nsec(2)) / float(sample_time))

    def get_time(self):
        return self.Time

    def set_time(self, time):
        self.Time = time

    def get_line(self):
        return self.Line

    def set_line(self, line):
        self.Line = line

    def pop_transmission(self):
        if not self.list_sorted:
            def sort_key(e):
                return(e[1])
            self.transmissions.sort(key=sort_key)
            self.list_sorted = True
        return self.transmissions.pop(0)

    def __len__(self):
        return len(self.transmissions)

    #Note that sample_line may now be either a line from a file or a value from an integer array.
    def add_sample(self, sample_line):
        if type(sample_line) != int:
            if re.match(r'^\s*$', sample_line) is not None:
                # Ignore blank lines
                return False

            match = re.match(r'^\s*LINE:([\d]+)\s*$', sample_line)
            if match is not None:
                self.Line = int(match[1])
                self.Time = 0
                return False

            sample = int(sample_line)

        else:
            sample = sample_line

        # Increment time for *all* samples. This is where time is tracked.
        self.Time += self.sample_time


        self.sample_count += 1
        #print(f"SAMPLE: count: {self.sample_count}: value: {sample}")

        # Always count zeros. If we have seen enough of them in a row
        # that we must be between transmissions, then discard
        # everything we're tracking (technically should be nothing,
        # but slight drift in timekeeping during the transmission
        # (particularly if it's long) might result in a sample or two
        # being mistakenly attributed to a new word.
        if sample == 0:
            if self.word_tracker is None:
                self.zero_count += 1
                if self.zero_count >= self.max_non_idle_zeros and self.tracking_transmision:
                    print("TRANSMISSiON END")
                    self.transmission_count += 1
                    transmission_data = (self.Line, self.transmission_start_time, self.words)
                    self.transmissions.append(transmission_data)
                    self.tracking_transmision = False
                    return True
                else:
                    # We're not tracking a tramission (ie: we're in either
                    # response or large gap time) and we're looking at
                    # zero, so the only thing we need to do is track the
                    # time (which we've already done).
                    return False
            
            elif self.square_wave:
                #print("sample == 0, but there is a word tracker, and square_wave == True.  This means there are stray samples, but not a whole word")
                #return False
                self.word_tracker = None
                print("TRANSMISSiON END")
                self.transmission_count += 1
                transmission_data = (self.Line, self.transmission_start_time, self.words)
                self.transmissions.append(transmission_data)
                self.tracking_transmision = False
                return True
            
        else:
            if self.word_tracker is None:
                usec_boundary = int(usec2nsec(nsec2usec(self.Time)))
                skipped_samples = round(float(self.Time-usec_boundary) / float(self.sample_time))
                print(f"NEW WORD START: Time: {self.Time}: skipped_samples: {skipped_samples}: usec_boundary: {usec_boundary}")

                self.word_tracker = Digiform1553Word(self.Line, self.sample_time, self.square_wave, self)
                '''
                if not self.square_wave:
                
                    for count in range(skipped_samples):
                        if self.word_tracker.add_sample(self.Line, 0):
                            raise UnexpectedCompleteWord
                '''
                if not self.tracking_transmision:
                    self.tracking_transmision = True
                    self.words = []
                    if self.square_wave:
                        self.transmission_start_time = self.Time
                        print(f"TRANSMISSION START: Time: {self.Time}")
                    else:
                        self.transmission_start_time = usec_boundary
                        print(f"TRANSMISSION START: Time: {usec_boundary}")
                   

            self.zero_count = 0

        # TODO: Ensure that we have established LINE() before seeing
        # first real sample
        #
        # It would be "cleaner" to create the word_tacker object
        # during init and then just create a new one as soon as we're
        # finished with the curren one, but unfortunately we don't
        # know the LINE number until we've seen in the
        # input. Technically this true about the TIME as well, but, as
        # the time of writing, TIME is not something that the digiform
        # version of the waveform_syntehsizer gives us.
        if self.word_tracker.add_sample(self.Line, sample):
            print("WORD: **0x%02x**" % self.word_tracker.get_word()[1])
            self.words.append(self.word_tracker.get_word()[1])
            self.word_tracker = None

        return False

'''
For an input array of -1's, 0's, and 1's, get the resulting array of array of 1553 words, where the arrays of words are grouped by transmission.
'''
def get1553Words(input,square_wave=False):
    transmission_tracker = Digiform1553Transmission(square_wave=square_wave)
    for i in input:
        transmission_tracker.add_sample(i)

    transmissions = []

    while len(transmission_tracker):
        line, time, words = transmission_tracker.pop_transmission()
        word20s = []
        for word in words:
            word20 = format("%05x" % Digiform1553Word.word18_to_word20(word))
            word20s.append(word20)
        transmissions.append(word20s)

    return transmissions
   

if __name__ == '__main__':
    parser = argparse.ArgumentParser("Convert waveform synthesized threshold values to desired output")
    parser.add_argument('-d', '--debug', default=0, action='count', help='Increasing levels of debugging')
    parser.add_argument('-i', '--input-file', dest='input_file', default="/dev/stdin", type=str, help="Input file name", metavar="filename")
    parser.add_argument('-o', '--output-file', dest='output_file', default="/dev/stdout", type=str, help="Ouput file name", metavar="filename")
    parser.add_argument('-q', '--square_wave', dest='square_wave', default=False, action='store_true', help='Assume square-wave -- no intra-message zeroes')    
#    parser.add_argument('-s', '--stream', dest='stream', default=0, type=int, help="Assume stream-like input")

    args = parser.parse_args()

    transmission_tracker = Digiform1553Transmission(square_wave=args.square_wave)

    if args.output_file != "/dev/stdout":
        output = open(args.output_file, "w")
        sys.stdout = output

    mode = os.stat(args.input_file).st_mode

    if args.square_wave:
        res = checkFileForBitSymmetry(args.input_file)

    in_array = []
    with open(args.input_file,"r") as i:
        for line in i:
            try:
                val = int(line.strip())
            except:
                continue
            
            in_array.append(val)

    #print("square_wave = {}".format(args.square_wave))
    #print("in_array={}".format(in_array))        
    result = get1553Words(in_array,square_wave=args.square_wave)

    print("{}".format(result))

    exit()

        
    
    
    if stat.S_ISFIFO(mode):
        #print("ISFIFO mode")
        print("TIME 0")
        with open(args.input_file, 'r') as ifile:
            line = ifile.readline()
            while line:
                line.strip()
                transmission_tracker.add_sample(line)
                if len(transmission_tracker):
                    line, time, words = transmission_tracker.pop_transmission()
                    word20s = []
                    for word in words:
                        word20 = format("%05x" % Digiform1553Word.word18_to_word20(word))
                        word20s.append(word20)
                    print("RECV(line=%d,time=%.1f,word20=[%s])"%(line, nsec2usec(time,1), ", ".join(word20s)))
                line = ifile.readline()
        print("ENDTIME %.1f" % (nsec2usec(transmission_tracker.get_time(),1)))
    elif stat.S_ISREG(mode):
        #print("ISREG mode")
        with open(args.input_file, 'r') as ifile:
            line = ifile.readline()
            while line:
                line.strip()
                transmission_tracker.add_sample(line)
                line = ifile.readline()

            print("TIME 0")
            while len(transmission_tracker):
                line, time, words = transmission_tracker.pop_transmission()
                word20s = []
                for word in words:
                    word20 = format("%05x" % Digiform1553Word.word18_to_word20(word))
                    word20s.append(word20)
                print("RECV(line=%d,time=%.1f,word20=[%s])"%(line, nsec2usec(time,1), ", ".join(word20s)))
        print("ENDTIME %.1f" % (nsec2usec(transmission_tracker.get_time(),1)))
    sys.exit(0)
