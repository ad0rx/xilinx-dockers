#!/usr/bin/python3
#
# ++Copyright Peraton Labs GPR++
#
# Copyright (c) 2021 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton Labs GPR- -
#
# Engineer: SR
# Reviewer: TBD
# Description: Framework to create 1553 waveforms for testing
#
#
# For transformer coupled systems, voltage range:
# By spec, should not respond: <=2.0Vpp
# By spec, should respond: .86 to 14Vpp
# ASIC targeted minimum: .258Vpp ±5% worse case: .270
# ASIC targeted midpoint: .644Vpp ±5%
# ASIC targeted maximum: 1.030Vpp ±5% worse case: .979
# ASIC number steps: 64 12mVpp
#
# For 1553, zero cross deviation with respect to the PREVIOUS ZERO
# CROSSING of ±150ns.
#
# For 1553, the rise and fall time of the waveform shall be between
# 100 to 300ns when measured from levels of 10 to 90% of full waveform, P2P.
# For a linear rise/fall, this means 125 to 375ns peak-to-peak.
# For a sine rise/fall, this means approximately 169.5 to 508.5ns peak-to-peak.
#
# Overshoot/Ringing shall not exceed ±900mV (transformer)
#
import math
import argparse
import numpy as np
import numbers
from collections import defaultdict
from scipy import signal

args = None


class Waveform_Synthesizer:

    ##! @{ __IAW:1553C@4.3.3.4__
    @staticmethod
    def words16_to_18(words16):
        """Accept as input a list of 16 bit words and translate to 18 bit
        words with 1553-style sync and parity computed"""

        ##! @{ __IAW:1553C@4.3.3.5.2.3,1553C@4.3.3.5.1.6,1553C@4.3.3.5.3.12__
        def parity16_parallel_odd(v):
            v &= 0xffff
            v ^= v >> 8
            v ^= v >> 4
            v &= 0xf
            return int(not(((0x6996 >> v) & 1)))
        ##! @}

        words18 = []

        first = 1
        for word16 in words16:
            ##! __IAW:1553C@4.3.3.5.1.1,1553C@4.3.3.5.2.1,1553C@4.3.3.5.2.2,1553C@4.3.3.5.2.3,1553C@4.3.3.5.1.6,1553C@4.3.3.5.3.12,1553C@4.3.3.5.3.1__
            words18.append(first << 17 | word16 << 1 | parity16_parallel_odd(word16))
            first = 0

        return words18
    ##! @}



    ##! @{ __IAW:1553C@4.3.3.6__
    @staticmethod
    def train_2Msignal_gen(words18, pre=.0001, post=.0001):

        """Translate a list of 18 bit words into a continuous output waveform

        Inputs:
        _words18_: list of 18 bit words with parity and sync bit specified (bit 17 sync, bit 0 parity).
        initial _pre_-transmission gap (seconds), final _post_-transmission gap (seconds),


        Output: 2 MHz manchester encoded high/low/idle data"""

        wlen = len(words18)
        pout = []
        for word18 in words18:
            wlen -= 1
            postval = post if wlen < 1 else 0
            pout.append(Waveform_Synthesizer.simple_2Msignal_gen(pre=pre, post=postval, word=word18))
            pre=0
        return np.concatenate(pout)
    ##! @}



    ##! @{ __IAW:1553C@4.3.3.5.1.1,1553C@4.3.3.3,1553C@4.3.3.2__
    @staticmethod
    def simple_2Msignal_gen(pre=.0001, post=.0001, word=0xe4be1):
        """Translate a target initial silence period, a word, and a post-silence period into 2 MHz samples of manchester encoded high/low/idle"""
        offset = int(pre*2000000)
        signal2M = np.zeros(offset + int(post*2000000) + 20*2, dtype=np.int8)
        if (word & 1<<17):
            # Command/Status word __IAW:1553C@4.3.3.5.1.1,1553C@4.3.3.5.3.1__
            bit=[1,1,1,-1,-1,-1]
        else:
            ##! Data word __IAW:1553C@4.3.3.5.2.1__
            bit=[-1,-1,-1,1,1,1]
        signal2M[offset:offset+6] = bit
        offset += 6
        for i in range(16,-1,-1):
            if (word & 1<<i):
                bit=[1,-1]
            else:
                bit=[-1,1]
            signal2M[offset:offset+2] = bit
            offset += 2
        return(signal2M)
    ##! @}



    ##! @{ __IAW:Unofficial-Aperture Jitter__
    ##!
    ##! Aperture and sampling clock jitter is a process in the analog to
    ##! digitial conversion chain where the phase of the collection of the
    ##! digital signal can drift.  We are simulating this by allowing the
    ##! user to specify a policy (from fixed to random) for selection of
    ##! which raw sample is returned when downconverting from the higher
    ##! fidelity raw internal waveform to the waveform returned to users
    ##! of this generator.  While there is no specific requirement that we
    ##! be able to support a system with jitter, best practices suggest
    ##! that we in fact do this.
    ##!
    @staticmethod
    def random_oracle(traincnt, zxcnt, train_habit_cnt, choice, oraclememory):
        """Implement a pseudo-random oracle, suitable for jitter selection of samples"""

        if 'random_oracle_numpy_random_generator' in oraclememory:
            x = oraclememory['random_oracle_numpy_random_generator'].integers(len(choice))
        else:
            x = abs(hash((traincnt,zxcnt,train_habit_cnt))) % len(choice)
        return x
    ##! @}



    ##! @{ __IAW:1553C@4.5.2.2.1.2,1553C@4.5.1.5.1.1.2__
    @staticmethod
    def ring_oracle_5by2(raw, lastlogicend, targetV, curlogic, lastlogic, traincnt, zxcnt, train_habit_cnt):
        """Implement a ringing oracle with lookback window and ringing dampening.
        Probably not a good electrical model of ringing.  Not really anything to do with 5 and 2"""

        histsize=10

        def isquiet(history):
            diff = 0
            for x in history[0:histsize-1]:
                diff += abs(targetV-x)
            return diff < .008

        def biggest(history):
            diff = 0
            for i in range(histsize-1):
                d = (history[i+1] - history[i]) #/ (histsize-1-i)
                if abs(d) > abs(diff):
                    diff = d
            return diff

        if lastlogicend+2 > len(raw):
            return []               # pragma: no cover

        history=np.array(raw[lastlogicend-histsize+1:lastlogicend+2])
        deltaout = []

    #    print(f"Ringing {lastlogicend}")
        while not isquiet(history):
            recentbig = biggest(history)
            attractor = targetV - history[histsize-1]
            force = recentbig / 1.4 + attractor / 1.9
            history[histsize] = history[histsize-1] + force
    #        print(f"{force} {history} {recentbig} {attractor}")
            deltaout.append(history[histsize]-targetV)
            result = np.empty_like(history)
            result[0:histsize] = history[1:histsize+1]
            history = result

        return(deltaout)
    ##! @}



    ##! @{ __IAW:1553C@4.3.3.3,1553C@4.5.2.1.1.1,1553C@4.5.2.2.1.1,1553C@4.5.2.1.1.2,1553C@4.5.2.2.1.2,1553C@4.5.2.1.1.3,1553C@4.5.2.2.1.3,1553C@4.5.2.1.1.4,1553C@4.5.2.2.1.4,1553C@4.5.2.1.2.1,1553C@4.5.2.2.2.1,1553C@4.5.2.1.2.4,1553C@4.5.2.2.2.4__
    @staticmethod
    def analogizer(input2M,
                   peak_Vpp=.86,
                   raw_samplerate_mhz=500, low_pass_filter_mhz=28,
                   output_samplerate_mhz=100, sample_wander_oracle=None,
                   awgn_rms=0,
                   slew_oracle_ns=140, slew_type="sine",
                   zero_wandering_oracle_ns=0,
                   ringing_oracle=None,
                   common_mode_offset=0,
                   awgn_rnd=np.random.default_rng(),
                   user_oraclememory_dict={},
                   debug=0):

        """Convert an ideal 2MHz input signal into an sampled digital sample such as you might get from an oscilloscope.

        Allow specification of the peak to peak maximum voltage (with a super slow slew (e.g. > 250 ns) you might not ever actually reach that peak for a specific transmission

        Allow specification of the raw sample rate (typically 500 MHz) which represents the internal-to-function processing speed.
        May be larger than output sample rate due to a high low_pass_filter setting.

        Allow specification of the low pass filter cutoff frequency.
        Raw sample rate must be at least 4x the low pass filter cutoff frequency or output waveform will be garbage.

        Allow specification of the sample rate (typically 100 MHz).

        The sample_wander_oracle may either be a number (representing a fixed sample point in the raw->output window) or a callable which, given the list of known samples returns the sampled value (1 of N or average or...).

        The awgn_rms specifies the root mean squared amount of additive white gaussian noise (AWGN) to be added to the signal.
        You may pass in a static seeded random number generator for the white noise

        The slew_oracle_ns is either a function or a floating point number representing the number of nanoseconds that the analog sine wave will take to transition from the current value to the next value.
        Note that for transitions to/from zero from/to non-zero, the resulting number will be divided by two.
        The callable will be given an argument representing the location within an ideal 1553 word, from 0 to 20 (for legal 1553 words, illegal 1553 words exist), with half number being the mandatory mid-bit crossings.

        The slew_type may take the values of "sine" or "linear" which represent the shape of the resulting waveform.

        The zero_wandering_oracle_ns is either a number (representing the ± number of nanoseconds within which the sample point randomly wanders) or a callable which returns the nanoseconds offset representing the location within an ideal 1553 word as per the slow_oracle_ns.
        Note that the desired zero crossing figure may not be achievable due to slow skews (skew will never start more than 250ns before the zero crossing) and/or samplerate quantization.

        The ringing_oracle is a callable which returns the positive or negative offset from an ideal (peak or zero) voltage. Takes as arguments the location in the ideal word as per slew_oracle_ns, the sample number after that ideal moment, the peak_Vpp, the current and previous input2M value.

        The common_mode_offset is either a number (representing a fixed (non-random) common mode offset in Volts peak-to-peak) or a callable oracle (ala ringing_oracle) returning the new common mode offset.

        user_oraclememory_dict allows a user to pass in a dict which oracles can use for arbitrary data storage or passing. Shared by all oracles, or use unique names please.

        Returns an numpy array containing the sampled voltages of the input signal.
        """

        # For some reason with class have to initialize later
        if sample_wander_oracle is None:
            sample_wander_oracle = Waveform_Synthesizer.random_oracle

        # Define later
        habits_len = None
        rawlen = None
        raw = None
        # initialize history
        zxcnt = 0                   # How many zero-crossing have we observed for the current train
        traincnt = 0		# How many continuous sequences of data have we seen?
        lastlogic = None		# Actual value of last logic level
        lastlogiczero = 0           # Actually first non-zero in the most recent sequence of non-zeros aka lastlogiczero+1
        lastlogicend = None         # The offset, in raw, that we have last completed a transition (for determining ringing)
        lastset = -1                # The offset, in raw, that we have last set a voltage level
        habit_cnt = 0               # How many habits (half-bits) have we seen, with the first numbered one
        curraw = 0                  # The offset, in curraw, that this (logiccnt) half-bit
        last_qbit_len = None	# How many raw samples did half of the most recent habit (so a quarter-bit) take

        oraclememory = defaultdict(lambda: 0)


        ##! @{ __IAW:1553C@4.5.2.1.1.3,1553C@4.5.2.2.1.3__
        def zv(t, rms=1.132, band_pass_khz=(1, 4000), Rnd=np.random.default_rng()):
            """Additive White Gaussian Noise Generator

            Specify number of samples you want, and the RMS, and you get a
            numpy array of random noises.  Note that since the mean is zero,
            rms happens to be equal to standard deviation (WIN).

            Specify the band-pass in KHz

            Note that this provides all-frequency white noise.  1553 spec
            wants the .14 RMS noise distributed over 4MHz, which is very
            very different.  The default configuration creates such a thing,
            via a 1.14 rms all-spectrum white noise filtered to 4MHz

            """

            skip1 = skip2 = 0
            if band_pass_khz:
                skip1=raw_samplerate_mhz * 10
                skip2=raw_samplerate_mhz * 10

            noise = Rnd.normal(0, rms, size = t + skip1 + skip2)

            if band_pass_khz:
                rawnoise = noise
                # Add few initial zeros to prevent the band pass filter from going insane
                skip_zeros = raw_samplerate_mhz * 10
                noise = np.zeros(t + skip1 + skip2 + skip_zeros)
                noise[skip_zeros:] = rawnoise
                nyq = raw_samplerate_mhz * 1000 / 2.0
                low = band_pass_khz[0] / nyq
                high = band_pass_khz[1] / nyq
                sos = signal.butter(10, [low, high], 'band', output='sos')
                noise = signal.sosfiltfilt(sos, noise)[skip_zeros + skip1:-skip2]

            return noise
        ##! @}

        def habit2raw(pos):
            """Transform the 500 ns (aka 2MHz) half-bit offsets into a starting time defined in sample"""
            rawpos = math.ceil((pos) * raw_samplerate_mhz / 2.0)
            if rawlen and rawpos >= rawlen:
                rawpos = rawlen-1
            return rawpos

        def ns2raw(ns):
            """Transform a possibly fractional number of ns (typically relative to the start of input2M) to a specific offset relative to raw"""
            rawpos = math.ceil((ns) * raw_samplerate_mhz/1000.0)
            if rawpos >= rawlen:
                rawpos = rawlen-1   # pragma: no cover
            return rawpos

        def raw2ns(rawpos):
            """Transform a possibly fractional number of ns (typically relative to the start of input2M) to a specific offset relative to raw"""
            ns = (rawpos) * 1000.0 / raw_samplerate_mhz
            return ns

        def genNumFromOracle(user_info, oraclename, traincnt, zxcnt, train_habit_cnt, choices=None):
            """Compute a number from an oracle

            First is some user provided information which is either a number directly
            OR it is an array with a list of numbers
            OR it is a callable that will be passed the other arguments (plus oraclememory defaultdict) to return the number

            Second is the type of oracle (used for oracle memory)

            Next is a count (1 based) of which train (continuous transmission sequence with no idle time) this number is part of.

            After that is a zero-crossing count, with the initial rise being count "0", all following mid-bit or (optional) interbit zero crossing get incrementing numbers, and the final trailing edge having the next count even though it does not really cross zero (absent ringing).

            Then, we have a count of half-bits for this continuous sequence of transmissions, with the train leading edge being habit_cnt 0.

            Finally, we have a optional number of choices used to constrain the output set

            Returns a number."""

            # Numbers get used directly
            if isinstance(user_info, numbers.Number):
                if choices is not None and len(choices):
                    return user_info % len(choices)
                else:
                    return user_info

            # Array like objects get all values used in sequence, infinitely
            if hasattr(user_info, "__getitem__"):
                itemnum = user_info[oraclememory[oraclename]]
                oraclememory[oraclename] += 1
                if oraclememory[oraclename] >= len(user_info):
                    oraclememory[oraclename] = 0
                if choices is not None and len(choices):
                    return itemnum % len(choices)
                else:
                    return itemnum

            if callable(user_info):
                return user_info(traincnt, zxcnt, train_habit_cnt, choices, user_oraclememory_dict)

            raise ValueError("Unknown type %s for user_info"%str(type(user_info)))   # pragma: no cover


        ##! @{ __IAW:1553C@4.5.2.1.2.1,1553C@4.5.2.2.2.1__
        def genslew(thislogic, lastlogic, slew_type, slew_duration, rawstart):
            """Modify the output array to represent the requested transition.
            We always modify the output array until the end of transition (though it may be overwritten).

            thislogic represents the target peak logic level post-slew (multiply by peak_Vpp/2 for target voltage).

            lastlogic represent the prevent peak logic level pre-slew (don't assume it was peak_Vpp/2)

            slew_type describes the slew shape, from ('sine','linear') (linear can also be thought of as trapazoidal)

            slew_duration describes how long an ideal PEAK TO PEAK transition should take, in (potentially fractional) nanoseconds

            rawstart represents the offset into the raw sample space that this transition should start."""

            targetV = thislogic * peak_Vpp / 2.0
            srawlen = ns2raw(slew_duration)
            slew_end = rawstart + srawlen

            if slew_end > rawlen:
                slew_end = rawlen   # pragma: no cover

            if srawlen == 0:
                raw[rawstart] = targetV
                return rawstart


            ##! @{ __IAW:1553C@4.5.2.1.2.1,1553C@4.5.2.2.2.1__
            V = raw[rawstart-1]
            dV = targetV - V
            if slew_type == 'sine':
                # Compute step size in radians for a half-cycle (-90 to +90°)
                dR = math.radians(180)/srawlen
                R = math.radians(-90)

                for pos in range(rawstart, slew_end):
                    # Where we are in the half-cycle
                    R += dR
                    # the voltage over our base based on our position in the half-cycle--percentage distance between 0% and 100%
                    v = (math.sin(R) + 1) / 2 * dV
                    raw[pos] = V + v

            elif slew_type == 'linear':
                ddV = dV / srawlen
                for pos in range(rawstart, slew_end):
                    V += ddV
                    raw[pos] = V
            else:                   # pragma: no cover
                raise ValueError("Unknown slew_type %s"%str(slew_type))
            ##! @}

            if debug > 1:
                print(f"Slew from {rawstart} to {slew_end} {slew_duration}ns is {srawlen}")  # pragma: no cover
            return slew_end-1
        ##! @}


        # Initialization of critical sizing
        habits_len = len(input2M)
        rawlen = habit2raw(habits_len)
        raw = np.zeros(rawlen)


        # Generate the current half-bit as output, going back in history (never more than a habit) to make the right transition to this state
        for curlogic in input2M:
            # Compute the critical output information about this and the next half-bit we are outputting
            curraw = habit2raw(habit_cnt)
            habit_cnt += 1
            next_curraw = habit2raw(habit_cnt)
            habit_len = next_curraw - curraw
            qbit_len = round(habit_len / 2.0)
            lastlogicend = None

            # Process the different special cases
            if lastlogic is None:
                # Special-case: first habit
                lastset = curraw-1
                if curlogic != 0:
                    traincnt += 1

                # We don't actually need to set the raw samples.  Common code below will fill out this habit
                pass

            elif lastlogic == curlogic:
                # Last is same as this one
                # We don't actually need to do anything.  Common code below will fill out this habit
                pass

            elif lastlogic == 0:
                # Half transition from idle to high/low
                lastlogiczero = habit_cnt
                zxcnt = 0
                traincnt += 1

                # Start transition immediately on first edge, no predictive nonsense
                slewtime = genNumFromOracle(slew_oracle_ns, "slew", traincnt, zxcnt, habit_cnt-lastlogiczero) / 2
                lastset = lastlogicend = genslew(curlogic, lastlogic, slew_type, slewtime, curraw)

            else:
                # Transition from high/low to low/high/idle
                zxcnt += 1

                # Compute start of transition based on rise time
                slewtime = genNumFromOracle(slew_oracle_ns, "slew", traincnt, zxcnt, habit_cnt-lastlogiczero)
                zerocross_delta = genNumFromOracle(zero_wandering_oracle_ns, "zwo", traincnt, zxcnt, habit_cnt-lastlogiczero)
                startpos = ns2raw(raw2ns(curraw) + zerocross_delta - slewtime/2.0)

                # Prevent empty space before late transition
                if startpos > lastset + 1:
                    missing = startpos - lastset - 1
                    raw[lastset+1:startpos] = np.ones(missing) * raw[lastset]

                # We cannot start transition before the previous bit's mid-way point
                if startpos < curraw - last_qbit_len:
                    startpos = curraw - last_qbit_len

                # Actually code the transition
                lastset = lastlogicend = genslew(curlogic, lastlogic, slew_type, slewtime, startpos)

            ##! Add ringing @{ __IAW:1553C@4.5.2.1.1.2,1553C@4.5.2.2.1.2__
            if ringing_oracle and lastlogicend:
                rings = ringing_oracle(raw, lastlogicend, curlogic * peak_Vpp / 2, curlogic, lastlogic, traincnt, zxcnt, habit_cnt-lastlogiczero)
                if len(rings) > 0:
                    ringend=lastlogicend + len(rings)
                    if ringend > rawlen:
                        ringend = rawlen	# pragma: no cover
                    missing = ringend - lastlogicend - 1
                    raw[lastlogicend+1:ringend] = np.ones(missing) * curlogic * peak_Vpp / 2 + rings[:missing]
                    lastset = ringend - 1
            ##! @}

            # Make sure we have filled the current logic level to the end of this habit if necessary
            if lastset < next_curraw:
                missing = next_curraw - (lastset+1)
                if debug > 1:
                    print(f"{curraw},{lastset+1},{next_curraw},missing")   # pragma: no cover
                raw[lastset+1:next_curraw] = np.ones(missing) * curlogic * peak_Vpp / 2
                lastset = next_curraw-1

            # Prepare for next loop through
            lastlogic = curlogic
            last_qbit_len = qbit_len

        # Make sure we have filled the last voltage to end of buffer
        missing = rawlen-lastset-1
        if missing:
            raw[lastset+1:rawlen] = np.ones(missing) * raw[lastset]
            lastset = rawlen-1

        # Add additive white gaussian noise
        if awgn_rms:
            ##! __IAW:1553C@4.5.2.1.2.4,1553C@4.5.2.2.2.4_
            raw += zv(rawlen, awgn_rms, Rnd=awgn_rnd)

        # Perform low pass filter
        if low_pass_filter_mhz:
            sos = signal.butter(10, low_pass_filter_mhz / (raw_samplerate_mhz/2), 'low', output='sos')
            raw = signal.sosfiltfilt(sos, raw)
            rawlen = len(raw)

        # Sub(?)sample to output frequency, adding DC Bias
        outlen = math.ceil(rawlen * output_samplerate_mhz / raw_samplerate_mhz)
        output = np.zeros(outlen)
        for i in range(outlen):
            rawlo = math.floor(i * raw_samplerate_mhz / output_samplerate_mhz)
            rawhi = math.ceil((i+1) * raw_samplerate_mhz / output_samplerate_mhz)
            if rawlo >= rawlen:
                rawlo = rawlen-1    # pragma: no cover
            if rawhi > rawlen:
                rawhi = rawlen    # pragma: no cover
            subspace = raw[rawlo:rawhi]
            if debug > 3:
                print(f"{rawlo} {rawhi} {subspace} {outlen} {rawlen} {len(raw)}")  # pragma: no cover
            output[i] = subspace[int(genNumFromOracle(sample_wander_oracle, "swo", 0, 0, i, choices=subspace))]

            # Add DC bias
            if common_mode_offset:
                output[i] += genNumFromOracle(common_mode_offset, "cmo", 0, 0, i)

        return(output)
    ##! @}




    ##! @{ __IAW:1553C@4.5.2.1.2.1,1553C@4.5.2.2.2.1__
    @staticmethod
    def threshold(input, threshold_hi, threshold_lo, hysteresis_hi, hysteresis_lo):
        """Digitize the analog signal, using the thresholds and hysteresi"""
        out = np.zeros(len(input), dtype=np.int8)
        lasts = 0

        threshold_hih = threshold_hi - abs(hysteresis_hi)
        threshold_loh = threshold_lo + abs(hysteresis_lo)

        cnt = 0
        for volt in input:
            if volt >= threshold_hi:
                lasts = 1
            elif volt >= threshold_hih and lasts == 1:
                lasts = 1
            elif volt <= threshold_lo:
                lasts = -1
            elif volt <= threshold_loh and lasts == -1:
                lasts = -1
            else:
                lasts = 0
            out[cnt] = lasts
            cnt += 1
        return(out)
    ##! @}




def main():                     # pragma: no cover
    global args
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', default=0, action='count', help='Increasing levels of debugging')
    parser.add_argument('--add_ringing', action='store_true', help='Add a lame model of ringing to signal')
    parser.add_argument('--awgn_rms', default=0, type=float, help='RMS for the AWGN, 1553 test uses .14')
    parser.add_argument('--pre_idle', default=0.00001, type=float, help='How long to idle line before signal', metavar='seconds')
    parser.add_argument('--post_idle', default=0.00001, type=float, help='How long to idle line after signal', metavar='seconds')
    parser.add_argument('--awgn_seed', default=4806, type=int, help='Default value for AWGN random number seed, -1 for fully random')
    parser.add_argument('--internal_mhz', default=500, type=float, help='Internal sampling frequency for low pass filter', metavar='mhz')
    parser.add_argument('--low_pass_filter_mhz', default=28, type=float, help='Low pass filter cutoff', metavar='mhz')
    parser.add_argument('--output_mhz', default=100, type=float, help='Output frequency', metavar='mhz')
    parser.add_argument('--threshold', default=.62, type=float, help='Threshold for detection algorithm', metavar="Vpp")
    parser.add_argument('--threshold_hi', type=float, help='Threshold for detection algorithm', metavar="V")
    parser.add_argument('--threshold_lo', type=float, help='Threshold for detection algorithm', metavar="-V")
    parser.add_argument('--hysteresis', default=.035, type=float, help='Hysteresis detection algorithm', metavar="V")
    parser.add_argument('--hysteresis_hi', type=float, help='Hysteresis detection algorithm', metavar="V")
    parser.add_argument('--hysteresis_lo', type=float, help='Hysteresis detection algorithm', metavar="-V")
    parser.add_argument('--slew', default=140, type=float, help='How long a peak to peak slew takes', metavar="ns")
    parser.add_argument('--slewshape', default='sine', help='The shape of a slew', metavar='sine|linear')
    parser.add_argument('--peak', default=.86, type=float, help='Top analog signal level', metavar="Vpp")
    parser.add_argument('--zero_wander_list', type=float, action='append', help='Specify a round-robin list of zero crossing wandering', metavar="ns")
    parser.add_argument('--fixed_jitter', default=Waveform_Synthesizer.random_oracle, help='Select this sample (0 to internal_mhz/output_mhz)')
    parser.add_argument('--jitter_seed', default=1, type=int, help='Default value for random jitter selction seed, -1 for fully random')
    parser.add_argument('--common_mode_offset', default=0, type=float, help='Amount of DC common mode to bias signal', metavar="V")

    args = parser.parse_args()

    if args.zero_wander_list is None:
        args.zero_wander_list = [0]

    if args.threshold_hi is None:
        args.threshold_hi = args.threshold / 2
    if args.threshold_lo is None:
        args.threshold_lo = -args.threshold / 2
    if args.hysteresis_hi is None:
        args.hysteresis_hi = args.hysteresis
    if args.hysteresis_lo is None:
        args.hysteresis_lo = -args.hysteresis

    if isinstance(args.fixed_jitter, str):
        args.fixed_jitter = int(args.fixed_jitter)

    if args.awgn_seed == -1:
        aRnd = np.random.default_rng()
    else:
        aRnd = np.random.default_rng(args.awgn_seed)

    if args.jitter_seed == -1:
        jRnd = np.random.default_rng()
    else:
        jRnd = np.random.default_rng(args.jitter_seed)
    user_oraclememory = {'random_oracle_numpy_random_generator': jRnd}

    # Seed for word to send
    R2 = np.random.default_rng(1)

    wave = Waveform_Synthesizer.analogizer(Waveform_Synthesizer.train_2Msignal_gen(words18=Waveform_Synthesizer.words16_to_18([R2.integers(0xffff), R2.integers(0xffff)]), pre=args.pre_idle, post=args.post_idle),
                      peak_Vpp=args.peak,
                      raw_samplerate_mhz=args.internal_mhz,
                      low_pass_filter_mhz=args.low_pass_filter_mhz,
                      output_samplerate_mhz=args.output_mhz,
                      sample_wander_oracle=args.fixed_jitter,
                      awgn_rms = args.awgn_rms,
                      zero_wandering_oracle_ns=args.zero_wander_list,
                      slew_oracle_ns=args.slew,
                      slew_type=args.slewshape,
                      ringing_oracle=Waveform_Synthesizer.ring_oracle_5by2 if args.add_ringing else None,
                      common_mode_offset=args.common_mode_offset,
                      awgn_rnd = aRnd,
                      debug = args.debug,
                      user_oraclememory_dict = user_oraclememory)

    import matplotlib.pyplot as plt
    fig,ax = plt.subplots(1)
    ax.set_xlabel('Time (ns)')
    ax.set_ylabel('Amplitude (V)')
    ax.set_title('Oscilloscope')
    xAxis = [(x * 1000 / args.output_mhz) for x in range(wave.size)]
    ax.plot(xAxis, wave, marker='o', markersize=.5, linestyle='-', linewidth=.5)
    t = len(wave)
    ax.plot(xAxis, np.ones(t)*args.threshold_hi)
    ax.plot(xAxis, np.ones(t)*(args.threshold_hi-args.hysteresis_hi))
    ax.plot(xAxis, np.ones(t)*args.threshold_lo)
    ax.plot(xAxis, np.ones(t)*(args.threshold_lo-args.hysteresis_lo))
    plt.show()

    fig,ax = plt.subplots(1)
    ax.set_xlabel('Time (ns)')
    ax.set_ylabel('Hi/Idle/Low')
    ax.set_title('Line Inputs')
    digiform = Waveform_Synthesizer.threshold(wave, args.threshold_hi, args.threshold_lo, args.hysteresis_hi, args.hysteresis_lo)
    ax.plot(xAxis, digiform, marker='o', markersize=.5, linestyle='')
    plt.show()



if __name__ == '__main__':
    main()                      # pragma: no cover
