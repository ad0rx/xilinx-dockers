/**
 * @file m1553_system.h
 * @brief MIL-STD-1553 Initialization specific entry points
 *
 *  Created on: 7/9/2010
 *   
 *	- $HeadURL: http://ait-subversion/svn/Owl1553/OWL1553/tags/v3.0.2/C-Api/common/m1553_system.h $
 *	- $Date: 2019-02-18 15:41:36 -0600 (Mon, 18 Feb 2019) $
 *	- $Revision: 6974 $
 *	- $Author: motttj $
 *
 * Copyright (c) 2010 by Avionics Interface Technologies
 *  - Omaha, NE USA
 *  - Beavercreek, OH USA
 *  .
 * All rights reserved.  No part of this software may
 * be published, distributed, translated or otherwise
 * reproduced by any means or for any purpose without
 * the prior written consent of Avionics Interface Technologies. 
 */

#ifndef M1553_SYSTEM_H
#define M1553_SYSTEM_H

#include "m1553_cdef.h"
#include "m1553_common.h"
//#include "PXIeBoardTriggerLines.h"

/**
 * @brief Discrete output line driver settings. The nomenclature of this 
 *  enumeration is described by National Instruments document ID: 3JAF2BVB. 
 *  See http://digital.ni.com/public.nsf/allkb/0C5091E9099059BC86256FC1007947AA
 *  for details.
 */
typedef enum
{
    /**
     * @brief Configure the channel as a TTL output driver. 
     * In the off state the driver will supply a path to ground.
	 * Valid for local PMC discretes.
	 * Valid for Backplane triggers.
	 * Valid for local USB discretes.
     */
    M1553_DISCRETE_PUSH_PULL,	// TTL
    /**
     * @brief Configure the channel as open emitter line driver (pull up). 
     *  In the off state the driver will float. A sinking input is required for proper operation. 
	 * Valid for local PMC discretes.
	 * Not valid for Backplane triggers.
	 * Not valid for local USB discretes.
     */
    M1553_DISCRETE_LINE_DRIVER,		// Open Emitter
    /**
     * @brief Configure the channel as open collector output driver 
     *  (pull down). Active outputs will disable the emitter. In the off 
     *  state the driver will supply a path to ground. A sourcing input 
     *  is required for proper operation. 
	 * Valid for local PMC discretes.
	 * Not valid for Backplane triggers.
	 * Not valid for local USB discretes.
     */
     M1553_DISCRETE_OPEN_COLLECTOR,	// Open collector
     /**
     * @brief Disable the transmitter for this discrete line, and only allow it to 
     *   receive.
	 * Valid for local PMC discretes.
	 * Valid for Backplane triggers.
	 * Valid for local USB discretes.
     */
     M1553_DISCRETE_RECEIVER	// Receiver
} M1553DiscreteDriverType;

/**
 * @brief Trigger functionality types. Trigger lines can be routed to/from discrete I/O
 *   lines to control external interfaces on BC or BM events.
 */
typedef enum {
    /**
     * @brief The bus controller input trigger for a given channel.
     *  Only one discrete input line can be routed to a channel's bus controller input.
     */
    M1553_TRIG_BC_INPUT,
    /**
     * @brief The bus controller output trigger for a given channel.
     */
    M1553_TRIG_BC_OUTPUT,
    /**
     * @brief The bus monitor input trigger for a given channel.
     *  Only one disrete input line can be routed to a channel's bus monitor input.
     */
    M1553_TRIG_BM_INPUT,
    /**
     * @brief The bus monitor output trigger for a given channel.
     */
    M1553_TRIG_BM_OUTPUT,
} M1553TriggerFunctionType;

/**
 * @brief Interrupt types. An event handler is associated with one of these
 *  event types.
 */
typedef enum
{
    /**
     * @brief Interrupt on RT related events.
     */
    M1553_INTERRUPT_RT = 0,
    /**
     * @brief Interrupt on BC related events.
     */
    M1553_INTERRUPT_BC = 1,
    /**
     * @brief Interrupt on BM related events.
     */
    M1553_INTERRUPT_BM = 2,
    /**
     * @brief Interrupt on replay related events.
     */
    M1553_INTERRUPT_REPLAY = 3,
    /**
     * @brief Interrupt on BC branch related events.
     */
    M1553_INTERRUPT_BC_BRANCH = 4,
	/**
     * @brief Interrupt on Discrete IO Line Events.
     */
    M1553_INTERRUPT_DISCRETE = 5
} M1553InterruptType;

/**
 * @brief Carrier digital IO mode select.
 */
typedef enum
{
    /**
     * @brief Select a front panel IO line
     */
    M1553_CARRIER_FRONT_PANEL_IO = 0,
    /**
     * @brief Select a rear IO line
     */
    M1553_CARRIER_BACKPLANE_IO = 1
} M1553TriggerModeType;

/**
 * @brief This function pointer will be passed to the driver for interrupt 
 *  processing.
 */
typedef void  ( *M1553_INT_FUNC_PTR) (
/**
 * @brief The channel handle associated with the channel responsible for the 
 *  interrupt event.
 */
M1553Handle aChannelHandle, 
/**
 * @brief The interrupt type for this event.
 */
M1553InterruptType aType,
/**
 * @brief See M1553InterruptLoglistEntryType.
 */
M1553InterruptLoglistEntryType aInterruptInfo,
/**
 * @brief The user defined pointer provided to m1553InstIntHandler() when the 
 *  interrupt handler was registered.
 */
M1553Addr aUserFunc);

/**
 * @brief Available device level events.
 */
typedef enum {
	/**
	* Event (eventType):
	*		None
	*
	* Event information (eventInfo):
	*		None
	*/
	DEVICE_EVENT_NONE		= 0x00000000,
	DEVICE_EVENT_RT			= 0x00000001,
	DEVICE_EVENT_BC			= 0x00000002,
	DEVICE_EVENT_BM			= 0x00000004,
	DEVICE_EVENT_REPLAY		= 0x00000008,
	DEVICE_EVENT_BC_BRANCH	= 0x00000010,
	DEVICE_EVENT_DISCRETE	= 0x00000020
} TY_DEVICE_EVENT_TYPES;

/**
 * @brief Event notification structure passed to the user-defined callback routine when called.
 */
typedef struct {

	/**
	* Handle for channel generating this event.
	*/
	M1553Handle aChannelHandle;
	/**
	* Type of callback event.
	* @sa M1553InterruptType
	*/
	M1553InterruptType aType;
	/**
	* Contents of interrupt log list entry that generated this event
	* @sa M1553InterruptLoglistEntryType
	*/
	M1553InterruptLoglistEntryType aInterruptInfo;
	/**
	* Pointer to a user-defined data structure that gets passed to 
	* the user-defined callback function when called.
	*/
	M1553Addr aUserData;

} TY_DEVICE_EVENT_NOTIFY;

/**
 * @brief Input control for initialization operation.
 */
typedef enum
{
    /**
     * @brief Reset all configurations on the device.
     */
    M1553_RESET_ALL = 0,
    /**
     * @brief Reinitialize the current memory hardware configuration.
     */
    M1553_RESET_INITIALIZE_MEMORY = 1,
    /**
     * @brief Reset memory partitions to their default state.
     *  M1553_INIT_CLEAR_MEMORY is implied.
     */
    M1553_RESET_MEMORY_PARTITIONS = 2,
    /**
     * @brief Clear out all pending interrupts
     */
    M1553_RESET_INTERRUPT_REGISTERS = 3
} M1553ResetMode;

/**
 * @brief MIL-STD-1553 protocols.
 */
typedef enum
{
    /**
     * @brief MIL-STD-1553A
     */
    M1553_PROTOCOL_1553A = 0,
    /**
     * @brief MIL-STD-1553B
     */
    M1553_PROTOCOL_1553B = 1
} M1553MilProtocolType;


/**
 * @brief MIL-STD-1553 bus transfer rate 
 */
typedef enum
{
    /**
     * @brief 1 MHz. 
     */
    M1553_BIT_RATE_1MHZ = 0,
    /**
     * @brief 500 KHz.
     */
    M1553_BIT_RATE_500KHZ = 1
} M1553ChannelBitrate;

/**
* Select the MIL-STD-1553 Coupling mode for the selected channel 
*/
typedef enum
{
    /**
     * @brief Isolated on-board termination. This is the default power up
     *  state.
     */
    M1553_ISOLATED = 0,
    /**
     * @brief Transformer coupling.
     */
    M1553_TRANSFORMER = 1,
    /**
     * @brief Direct coupling
     */
    M1553_DIRECT = 2,
    /**
     * @brief External coupled. This coupling mode provides the standard
     *  transformer coupling plus simulation of the bus stub coupling. This
     *  allows the device to be plugged directly into another transformer
     *  coupled device.
     */
    M1553_EXTERNAL = 3,
    /**
     * @brief Digital wrap-around loop
     */
    M1553_WRAP = 4
} M1553CouplingType;

/**
 * @brief License modes. 
 */
typedef enum
{
    /**
     * @brief Full license. BC, RT, BM, and Replay functions are all 
     *  enabled.
     */
    M1553_LICENSE_FULL = 0,
    /**
     * @brief Simulator only mode. Only BC or RT can be used. BM functions
     *  are disabled.
     */
    M1553_LICENSE_SIMULATOR_ONLY = 1,
    /**
     * @brief Single function mode. Only one of BC or RT or BM can be used
     *  at a time.
     */
    M1553_LICENSE_SINGLE_FUNCTION = 2,
    /**
     * @brief Bus Monitor only.
     */
    M1553_LICENSE_MONITOR_ONLY = 3,
    /**
     * @brief There is no 1553 channel available.
     */
    M1553_LICENSE_NOT_PRESENT = 4
} M1553BoardLicenseType;

/**
 * @brief Hardware form factor. Identifies the physical configuration of
 *  the hardware.
 */
typedef enum
{
	/** 
	* @brief The device is an unkown form factor
	**/
	M1553_RESERVED0 = 0x0, 
    /**
     * @brief The device is a PMC form factor device.
     */
    M1553_PMC = 0x1,
	/**
	* @brief The device is a VME form factor device
	**/
	M1553_VME = 0x2,
	/**
	* @brief The device is a VXI form factor device
	**/
	M1553_VXI = 0x3,
	/** 
	* @brief The device is a cPCI form factor device
	**/
	M1553_CPCI = 0x4,
	/** 
	* @brief The device is a PC Card (PCMCIA) form factor device
	**/
	M1553_PCCARD = 0x5,
	/** 
	* @brief The device is a PC Express Card (Express Card) form factor device
	**/
	M1553_EXRESSCARD = 0x6,
	/** 
	* @brief The device is a PCI/PCI-x form factor card
	**/
	M1553_PCIX = 0x7,
	/**
	* @brief The device is a USB form factor device
	**/
	M1553_USB = 0x8,
	/** 
	* @brief The device is an XMC form factor device.
	**/
	M1553_XMC = 0x9,
	/** 
	* @brief The device is a PC/104+ form factor device
	**/
	M1553_PC104P = 0xA,
	/** 
	* @brief The device is PXI Express form factor device
	**/
	M1553_PXIE = 0xB,
	/**
	* @brief The device is a PCI Express form factor device
	*/
	M1553_PCI_EXPRESS = 0xC,
	/** 
	* @brief The device is an unknown form factor
	**/
	M1553_RESERVEDFD = 0xD,
	/** 
	* @brief The device is a PXI form factor device
	**/
	M1553_PXI = 0xE,
	/** 
	* @brief The device is an unknown form factor
	**/
	M1553_RESERVEDF = 0xF

} M1553DeviceBackplane;

/**
 * @brief Compatibility statuses
 */
typedef enum
{
    /**
     * @brief The firmware, driver, and library versions are all compatible.
     */
    M1553_COMPATIBLE = 0,
    /**
     * @brief The firmware is not compatible. The firmware version is not 
     *  compatible with either the library and driver
     */
    M1553_FIRMWARE_NOT_COMPATIBLE = 1
} M1553SoftwareCompatibility;

/**
 * @brief IRIG source type. The IRIG time can be synchronized to either
 *  internal or external clock sources.
 */
typedef enum
{
    /**
     * @brief Internal. The IRIG source is the internal hardware clock.
     */
    M1553_IRIG_SOURCE_INTERNAL = 0,
    /**
     * @brief External. The IRIG source must be applied to the IRIG input
     *  digital IO lines.
     */
    M1553_IRIG_SOURCE_EXTERNAL = 1,
	///**
 //    * @brief PXIe Internal. The IRIG source is synchronized to the one second pulse generated by the PXIe clock.
 //    *  digital IO lines.
 //    */
 //   M1553_IRIG_SOURCE_INTERNAL_PXIE = 2

} M1553IrigSourceType;

/**
 * @brief Hardware Coupling Capabilities
 */
typedef struct 
{
    /**
    * @brief Network coupling capable. The network coupling mode is
    *  available.
    */
    M1553Boolean mNetworkCoupling;

    /**
    * @brief Transformer coupling capable. The transformer coupling mode
    *  is available.
    */
    M1553Boolean mTransformerCoupling;

    /**
    * @brief Direct coupling capable. The direct coupling mode is available.
    */
    M1553Boolean mDirectCoupling;

    /**
     * @brief Isolated coupling capable. The isolated coupling mode is 
     *  available.
     */
    M1553Boolean mIsolatedCoupling;

    /**
    * @brief Digital wrap coupling capable. The digital wrap coupling mode is 
    *  available (loopback on-board without on-board termination).
    */
    M1553Boolean mDigitalWrapCoupling;

    /**
    * @brief Fixed coupling mode. If the device is a "fixed" coupling mode
    *  device, then the non-isolated/loopback modes are not software
    *  selectable (a hardware modification or cable arrangement determines
    *  the coupling mode).
    */
    M1553Boolean mFixedCoupling;

} M1553CouplingCapabilities;

/**
 * @brief IRIG capabilities
 */
typedef struct  
{
    /**
     * @brief IRIG signal is sinusoidal. 
     * <p>FALSE: Square wave carrier signal</p>
     * <p>TRUE: Sinusoidal carrier signal</p>
     */
    M1553Boolean mSinusoidalCarrier;
    /**
    * @brief The IRIG signal is free-wheeling. Free Wheeling IRIG signals 
    *  will maintain an internally synchronized signal when it loses 
    *  synchronization with an external signal.
    */
    M1553Boolean mFreeWheeling;
    /**
     * @brief The IRIG source is switchable between internal and external
     *  modes.
     */
    M1553Boolean mSwitchable;
} M1553IrigCapabilities;

/**
* @brief Structure containing the board type and configuration information
*/
typedef struct 
{
    /**
     * @brief The device platform (hardware backplane).
     */
    M1553DeviceBackplane mDeviceBackplane;
    /**
     * @brief The 1553 board type
     */
    M1553BoardLicenseType mBoardType;
    /**
     * @brief The firmware version loaded on the device.
     */
    uint32_t mFirmwareVersion;
    /**
     * @brief Software compatibility.
     *  The application interface will check that the firmware version on this 
     *  device is compatible with the version of the system driver and this 
     *  application interface. If an incompatibility exists, this value will 
     *  indicate what incompatibilities exist.
     */
    M1553SoftwareCompatibility mSoftwareCompatibility;
    /**
     * @brief The number of 1553 channels available.
     */
    uint8_t mChannelCount;
    /**
     * @brief The board serial number.
     */
    uint32_t mSerialNumber;
    /**
     * @brief The board part number
     */
    uint32_t mPartNumber;
    /**
    * @brief The output has variable amplitude controls.
    */
    M1553Boolean mVariableAmplitude;
    /**
    * @brief Coupling capabilities. Defines what modes of coupling the
    *  device is capable of operating with.
    * @sa M1553CouplingCapabilities
    */
    M1553CouplingCapabilities mCouplingCapabilities;
    /**
    * @brief IRIG capabilities. Defines what IRIG hardware capabilities are
    *  available on the hardware.
    * @sa M1553IrigCapabilities
    */
    M1553IrigCapabilities mIrigCapabilities;
    /**
     * @brief The global RAM size. All channels' memory are mapped into the
     *  global RAM area.
     */
    uint32_t mGlobalRamSize;
    /**
    * @brief Each channel's mapped memory size.
    * Each channel has a space in global RAM that is mapped for it's registers 
    *  and descriptors. This is an array of each channel's RAM size.
    */
    uint32_t mChannelMemorySize[MAX_API_BOARD_CHANNELS];
    /**
    * @brief Each channel's mapped memory offset.
    * Each channel has a space in global RAM that is mapped for it's registers 
    *  and descriptors. This is an array of each channel's RAM offset.
    */
    uint32_t mChannelMemoryOffset[MAX_API_BOARD_CHANNELS];

    /**
     * @brief  PCI Configuration Registers.
     * <p> Configuration Register Definition 
     * </p>
     * <table> 
     * 	<tr><td>Reg Number</td><td>Reg Name</td><td>Bits</td><td>Value</td><td>Description</td></tr>
     *	<tr><td>0</td><td>VEN_ID</td><td>15:0</td><td>-</td><td>Vendor ID</td></tr>
     *	<tr><td>0</td><td>DEV_ID</td><td>31:16</td><td>-</td><td>Device ID</td></tr>
     *	<tr><td>1</td><td>CMD_REG</td><td>15:0</td><td>-</td><td>Command Regiser</td></tr>
     *	<tr><td>1</td><td>ST_REG</td><td>31:16</td><td>-</td><td>Status Regiser</td></tr>
     *	<tr><td>2</td><td>REV</td><td>7:0</td><td>-</td><td>Revision ID</td></tr>
     *	<tr><td>2</td><td>CLS</td><td>31:8</td><td>-</td><td>Class Code Bytes</td></tr>
     *	<tr><td>3</td><td>CSIZE</td><td>7:0</td><td>-</td><td>Cache Line Size</td></tr>
     *	<tr><td>3</td><td>LTIM</td><td>15:8</td><td>-</td><td>Latency Timer</td></tr>
     *	<tr><td>3</td><td>HTYP</td><td>23:16</td><td>-</td><td>Header Type</td></tr>
     *	<tr><td>3</td><td>BIST</td><td>31:24</td><td>-</td><td>Built In Self Test</td></tr>
     *	<tr><td>4</td><td>BADDR0</td><td>31:0</td><td>-</td><td>Base Address Register 0</td></tr>
     *	<tr><td>5</td><td>BADDR1</td><td>31:0</td><td>-</td><td>Base Address Register 1</td></tr>
     *	<tr><td>6</td><td>BADDR2</td><td>31:0</td><td>-</td><td>Base Address Register 2</td></tr>
     *	<tr><td>7</td><td>BADDR3</td><td>31:0</td><td>-</td><td>Base Address Register 3</td></tr>
     *	<tr><td>8</td><td>BADDR4</td><td>31:0</td><td>-</td><td>Base Address Register 4</td></tr>
     *	<tr><td>9</td><td>BADDR5</td><td>31:0</td><td>-</td><td>Base Address Register 5</td></tr>
     *	<tr><td>10</td><td>CIS</td><td>31:0</td><td>-</td><td>CIS Pointer</td></tr>
     *	<tr><td>11</td><td>SUB_VEN_ID</td><td>15:0</td><td>-</td><td>Subsytem Vendor ID</td></tr>
     *	<tr><td>11</td><td>SUB_DEV_ID</td><td>31:16</td><td>-</td><td>Subsytem Device ID</td></tr>
     *	<tr><td>12</td><td>RADDR</td><td>31:0</td><td>-</td><td>Expansion ROM Base Addr</td></tr>
     *	<tr><td>13</td><td>RES1</td><td>31:0</td><td>-</td><td>Reserved 1</td></tr>
     *	<tr><td>14</td><td>RES2</td><td>31:0</td><td>-</td><td>Reserved 2</td></tr>
     *	<tr><td>15</td><td>IRQ</td><td>7:0</td><td>-</td><td>Interrupt Number</td></tr>
     *	<tr><td>15</td><td>IPIN</td><td>15:8</td><td>-</td><td>Interrupt Pin</td></tr>
     *	<tr><td>15</td><td>MINB</td><td>23:16</td><td>-</td><td>Minimum Burst</td></tr>
     *	<tr><td>15</td><td>MAXL</td><td>31:24</td><td>-</td><td>Maximum Latency</td></tr>
     * </table>
     */
    uint32_t mPciConfigRegisters[16];
} M1553GetBoardInfoOut;

/**
* @brief Structure containing status information for the STC3100 Battery Monitor.
* Only supported by the USB version of the m1553 Device.
*/
typedef struct 
{
    /**
     * @brief Coulomb counter data.
	 * A 16-bit binary number coded in 2's complement format.
	 * Bit 15 is the sign bit and bits 0 to 14 are the data bits.
	 * The LSB value is 6.70 uV.h
     */
    uint16_t	mChargeDataRaw;
    /**
     * @brief The number of gas gauge conversion operations
	 * Unsigned 16-bit binary number.
	 * When counter reaches maximum value of 0xFFFF, 
	 * it wraps to zero and continues counting.
     */
    uint16_t	mConversionCounter;
    /**
     * @brief The last measured value of the battery current.
	 * A 14-bit binary number coded in 2's complement format.
	 * Bit 13 is the sign bit and bits 0 to 12 are the data bits.
	 * The LSB value is 11.77 uV.h
     */
    uint16_t	mCurrentValueRaw;
    /**
     * @brief The battery voltage value.
	 * A 12-bit binary number using the 2's complement binary format.
	 * Bit 11 is the sign bit and bits 0 to 10 are the data bits.
	 * The LSB value is 2.44 mV
     */
    uint16_t	mVoltageValueRaw;
    /**
     * @brief The battery temperature value.
	 * A 12-bit binary number using the 2's complement binary format.
	 8 Bit 11 is the signe bit and bits 0 to 10 are the data bits.
	 * The LSB value is 0.125 degrees C
     */
    uint16_t	mTemperatureValueRaw;
    /**
     * @brief The STC3100 part type.
	 * Should be a value of 0x10.
     */
    uint8_t		mPartType;
    /**
     * @brief The unique device number for the battery monitor.
	 * Bits 31:00
     */
    uint32_t	mDeviceIdLow;
    /**
     * @brief The unique device number for the battery monitor.
	 * Bits 47:32
     */
    uint32_t	mDeviceIdHigh;
    /**
     * @brief The CRC value for the 48-bit device number.
	 * Bits 47:32
     */
    uint8_t		mDeviceIdCrc;
    /**
     * @brief The battery AC charger connection status.
	 * TRUE - Charger AC is present.
	 * FALSE - Charger AC is not present.
     */
	M1553Boolean	mChargerACPresent;
    /**
     * @brief The charging state of the battery.
	 * TRUE - Battery is charging.
	 * FALSE - Battery is not charging.
     */
	M1553Boolean	mChargingBattery;

} M1553USBGetBatteryInfoOut;

/**
 * @brief Possible states for front panel LEDs (Red, Green or Off)
 */
typedef enum
{
    M1553_USB_LED_STATE_OFF,
    M1553_USB_LED_STATE_GREEN,
    M1553_USB_LED_STATE_RED
} M1553USBFrontPanelLEDState;

/**
* @brief Structure containing indexing parameters to operate
* front panel LEDs on the USB 1553 device.
* Only supported by the USB version of the m1553 Device.
*/
typedef struct 
{
    /**
     * @brief Channel number as labeled on front panel (1 or 2)
     */
    uint32_t					mFrontPanelChannel;
    /**
     * @brief Bus number as labeled on front panel (PRI or SEC)
     */
    M1553BusType				mFrontPanelBus;
    /**
     * @brief Desired state of specified LED (Red, Green or Off)
     */
	M1553USBFrontPanelLEDState	mLedState;
} M1553USBSetFrontPanelLEDin;

/**
 * @brief The output structure for m1553GetSystemInformation()
 * <p>Versions for the system driver and application interface library are in the
 *  format "Major.Minor.Maintenance.Build". For example, if the Major, Minor, 
 *  Maintenance and Build versions are 1, 2, 3, 4 respectively, the version 
 *  should be visualized as "1.2.3.4".</p>
 *  <p>A major release indicates that code compiling and binary backwards 
 *  compatibility will be broken (This is generally an interface redesign). A 
 *  Minor release change indicates that the library may have been modified and 
 *  recompiled (generally bug-fixes, and feature enhancements). Maintenenace 
 *  version changes indicate a bug fix releases for Major/Minor release. Build 
 *  version changes should be fit and functionaly identical to releases within 
 *  a specific Major/Minor/Maintenance release.</p>
 */
typedef struct  
{
    /**
     * @brief System driver major version
     */
    uint32_t mSystemDriverMajorVersion;
    /**
     * @brief System driver minor version
     */
    uint32_t mSystemDriverMinorVersion;
    /**
     * @brief System driver maintenance version
     */
    uint32_t mSystemDriverMaintenanceVersion;
    /**
     * @brief System driver build version
     */
    uint32_t mSystemDriverBuildVersion;
    /**
     * @brief Application interface library major version
     */
    uint32_t mLibraryMajorVersion;
    /**
     * @brief Application interface library minor version
     */
    uint32_t mLibraryMinorVersion; 
    /**
     * @brief Application interface library maintenance version
     */
    uint32_t mLibraryMaintenanceVersion;
    /**
     * @brief Application interface library build version
     */
    uint32_t mLibraryBuildVersion;
} M1553GetSystemInformationOut;

/**
 * @brief Input structure for m1553InstallInterruptHandler()
 */
typedef struct  
{
    /**
     * @brief Interrupt Type. Defines the type of interrupt to be 
     *  associated with the interrupt handler.
     */
    M1553InterruptType mType;
    /**
     * @brief Interrupt handler. This is a pointer to the host application's
     *  function to be called when an interrupt is issued.
     */
    M1553_INT_FUNC_PTR mIntFunc;
    /**
     * @brief User defined data. This will be provided as an input to the 
     *  interrupt handler function (pointed to by mIntFunc). This can be 
     *  any value that is desirable to have access to from within to scope 
     *  of the interrupt handler routine.
     */
    M1553Addr mUserData;
} M1553InstallInterruptHandlerIn;

/**
 * @brief Output structure for m1553DeleteInterruptHandler()
 */
typedef struct  
{
    /**
     * @brief The interrupt type that was previously associated with an
     *  interrupt handler by the function m1553InstallInterruptHandler()
     */
    M1553InterruptType mType;
} M1553DeleteInterruptHandlerIn;

/**
 * @brief The output structure for m1553ChannelGetInterrupts()
 */
typedef struct  
{
    /**
     * @brief Interrupt count. The number of interrupts available in the 
     *  array of interrupt details, mpInterruptInfo.
     */
    uint32_t mInterruptCount;
    /**
     * @brief Detailed interrupt information. This array of
     *  M1553InterruptLoglistEntryType structures contains detailed
     *  interrupt information for each interrupt. The number of structures 
     *  available in the array is defined by mInterruptCount.
     */
    M1553InterruptLoglistEntryType* mpInterruptInfo;
} M1553ChannelGetInterruptsIn;

/**
* Select the MIL-STD-1553 Self Test mode 
*/
typedef enum
{
    /**
     * @brief no test selected for bit test.
     */
    M1553_BIT_NO_TEST = 0,
    /**
     * @brief Run all ram, transfer, and IRIG tests.
	 * Currently runs the following tests:
	 *	M1553_BIT_IRIG_TEST
	 *	M1553_BIT_TRANSFER_TEST
	 *	M1553_BIT_INTERRUPT_TEST
	 *	M1553_BIT_RAM_TEST
     */
    M1553_BIT_ALL_TEST = 1,
    /**
     * @brief RAM Memory test.
     */
     M1553_BIT_RAM_TEST = 2,
    /**
     * @brief Exhaustive RAM Memory test.
	 * Currently not implemented
     */
     M1553_BIT_FULL_RAM_TEST = 3,
    /**
     * @brief IO Memory test.
	 * Currently not implemented
     */
     M1553_BIT_IO_TEST = 4,
    /**
     * @brief PLX Memory test.
	 * Currently not implemented
     */
     M1553_BIT_PLX_TEST = 5,
    /**
     * @brief Isolated on-board transfer test.
     */
     M1553_BIT_TRANSFER_TEST = 6,
    /**
     * @brief Isolated on-board interrupt test.
     */
     M1553_BIT_INTERRUPT_TEST = 7,
    /**
     * @brief Isolated on-board IRIG test.
     */
     M1553_BIT_IRIG_TEST = 8

} M1553BITControl;

/**
 * @brief The input structure for m1553BoardBIT()
 */
typedef struct  
{
    /**
     * @brief Controls the built in tests to be executed.
     */
    M1553BITControl mControl;

    /**
     * @brief Test control parameter. Currently not used by any tests.
     */
    uint32_t mParam;

} M1553BoardBITIn;

/**
 * @brief The output structure for m1553BoardBite()
 */
typedef struct  
{
    /**
     * @brief The built in test execution results.
     *  The first byte indicates the test in which a failure was detected.
     *  The second byte indicates the error status.
     *  <table>
     *   <tr><th>Test</th><th>Error Value</th></tr>
     *   <tr><th>M1553_BIT_NO_TEST</th><th>N/A</th></tr>
     *   <tr><th>M1553_BIT_ALL_TEST</th><th>N/A</th></tr>
     *   <tr><th>M1553_BIT_RAM_TEST</th><th>0: No Error\n!0: Error code</th></tr>
     *   <tr><th>M1553_BIT_FULL_RAM_TEST</th><th>0: No Error\n!0: Error code</th></tr>
     *   <tr><th>M1553_BIT_IO_TEST</th><th>0: No Error\n!0: Error code</th></tr>
     *   <tr><th>M1553_BIT_PLX_TEST</th><th>0: No Error\n!0: Error code</th></tr>
     *   <tr><th>M1553_BIT_TRANSFER_TEST</th><th>0: No Error\n!0: Error code</th></tr>
     *   <tr><th>M1553_BIT_INTERRUPT_TEST</th><th>0: No Error\n!0: Error code</th></tr>
     *   <tr><th>M1553_BIT_IRIG_TEST</th><th>0: No Error\n!0: Error code</th></tr>
     *  </table>
     */
    uint8_t mBITStatus[2];
} M1553BoardBITOut;

/**
 * @brief The input structure for m1553BoardSetIrigTime()
 */
typedef struct
{
    /**
     * @brief IRIG time. The on-board IRIG time will be set to this value.
     */
    M1553IrigTimeType mIrigTime;
    /**
     * @brief  IRIG source.
     */
    M1553IrigSourceType mIrigSource;
} M1553BoardSetIrigTimeIn;

/**
 * @brief The output structure for m1553BoardGetIrigTime()
 */
typedef struct  
{
    /**
     * @brief IRIG time
     */
    M1553IrigTimeType mIrigTime;
    /**
    * @brief  IRIG source.
    */
    M1553IrigSourceType mIrigSource;

    /**
    * @brief  The IRIG is synchronized. Indicates whether or not the internal
    *  IRIG clock time is synchronized to its source (mIrigSource).
    */
    M1553Boolean mIrigIsSynchronized;
} M1553BoardGetIrigTimeOut;


/**
 * @brief Output structure for m1553BoardGetDiscreteCount().
 */
typedef struct
{
    /**
     * @brief The number of discrete IO lines available on the board.
     */
    uint32_t mCount;
} M1553BoardGetDiscreteCountOut;

/**
 * @brief Output structure for m1553BoardGetBackplaneDiscreteCount().
 */
typedef struct
{
    /**
     * @brief The number of backplane digital IO lines available on the board.
     */
    uint32_t mCount;
} M1553BoardGetBackplaneDiscreteCountOut;

/**
 * @brief Input structure for m1553BoardSetDiscreteConfig().
 */
typedef struct
{
    /**
     * @brief The discrete driver type. See M1553DiscreteDriverType.
     */
    M1553DiscreteDriverType mDriverType;
    /**
     * @brief The discrete polarity. TRUE = Active High, FALSE = Active Low
     */
	M1553Boolean			mPolarity;
} M1553BoardSetDiscreteConfigIn;

/**
 * @brief Input structure for m1553BoardSetCarrierDiscreteConfig(). If the
 *  mode is set to M1553_CARRIER_BACKPLANE_IO, then this is configuration
 *  parameters for the interface to the backplane from the carrier device.
 *  If the mode is M1553_CARRIER_FRONT_PANEL_IO then this is the configuration
 *  parameters for the interface to the front panel. The front panel interface
 *  is shared between the FPGA on the PMC and the FPGA on the carrier, so be
 *  careful not to set both interfaces as outputs.
 */
typedef struct
{
    /**
     * @brief The trigger driver type. See M1553DiscreteDriverType.
     *  Currently, only M1553_DISCRETE_PUSH_PULL and M1553_DISCRETE_RECEIVER
     *  are supported.
     */
    M1553DiscreteDriverType mDriverType;
    /**
     * @brief The discrete polarity. TRUE = Active High, FALSE = Active Low
     */
	M1553Boolean			mPolarity;
    /**
     * @brief Trigger event select. If the mode is M1553_CARRIER_BACKPLANE_IO,
     *  then this will select a front panel trigger line to listen for events
     *  to be regenerated on this rear IO line. If the mode is 
     *  M1553_CARRIER_FRONT_PANEL_IO, then this will select a rear IO trigger
     *  line to listen for events to be regenerated on this front panel trigger
     *  line.
     */
    int16_t                mTriggerSelect;
} M1553BoardSetCarrierDiscreteConfigIn;

/**
 * @brief Output structure for m1553BoardGetDiscreteConfig().
 */
typedef struct
{
    /**
     * @brief The discrete driver type. See M1553DiscreteDriverType.
     */
    M1553DiscreteDriverType mDriverType;
    /**
     * @brief The discrete polarity. TRUE = Active High, FALSE = Active Low
     */
	M1553Boolean			mPolarity;
} M1553BoardGetDiscreteConfigOut;

/**
 * @brief Output structure for m1553BoardGetCarrierDiscreteConfig().
 */
typedef struct
{
    /**
     * @brief The trigger driver type. See M1553DiscreteDriverType.
     */
    M1553DiscreteDriverType mDriverType;

    /**
     * @brief The discrete polarity. TRUE = Active High, FALSE = Active Low
     */
	M1553Boolean			mPolarity;
    /**
     * @brief Trigger event select. If the mode is M1553_CARRIER_BACKPLANE_IO,
     *  then this will select a front panel trigger line to listen for events
     *  to be regenerated on this rear IO line. If the mode is 
     *  M1553_CARRIER_FRONT_PANEL_IO, then this will select a rear IO trigger
     *  line to listen for events to be regenerated on this front panel trigger
     *  line.
     */
    int16_t                mTriggerSelect;
} M1553BoardGetCarrierDiscreteConfigOut;

/**
 * @brief Input structure for m1553BoardSetTriggerRoute()
 */
typedef struct
{
    /**
     * @brief Trigger strobe select. See M1553TriggerFunctionType.
     */
    M1553TriggerFunctionType mTriggerType;
    /**
     * @brief Trigger Index. Range is 0 to 15, and is generally equal to the 
     *  channel index. If the range is beyond the channel index, the route
     *  will be ignored.
     */
    uint32_t mTriggerIndex;
    /**
     * @brief Discrete index to connect with. This discrete should be 
     *  configured via m1553BoardSetDiscreteConfig() prior to routing. If 
     *  an index is used beyond the maximum discrete index, the route is
     *  ignored.
     */
    uint32_t mDiscreteIndex;
} M1553BoardSetTriggerRouteIn;

/**
 * @brief Input structure for m1553BoardGetTriggerRoute().
 */
typedef struct
{
    /**
     * @brief Trigger strobe select. See M1553TriggerFunctionType.
     */
    M1553TriggerFunctionType mTriggerType;
    /**
     * @brief Index. 
	 * For trigger types: M1553_TRIG_BM_INPUT, M1553_TRIG_BC_INPUT
	 * specify the channel index (range 0 to 3).
	 *
	 * For trigger types: M1553_TRIG_BM_OUTPUT, M1553_TRIG_BC_OUTPUT
	 * specify the discrete index (range 0 to 9).
     */
    uint32_t mIndex;
} M1553BoardGetTriggerRouteIn;

/**
 * @brief Output structure for m1553BoardGetTriggerRoute().
 */
typedef struct
{
    /**
     * @brief Index. 
	 * For trigger types: M1553_TRIG_BM_INPUT, M1553_TRIG_BC_INPUT
	 * this is the current discrete index selected for the specified channel index (range 0 to 9).
	 *
	 * For trigger types: M1553_TRIG_BM_OUTPUT, M1553_TRIG_BC_OUTPUT
	 * this is the current channel index for the specified discrete index (range 0 to 3).
     */
    uint32_t mIndex;
} M1553BoardGetTriggerRouteOut;

/**
 * @brief Output structure for m1553BoardGetDiscreteEvent().
 */
typedef struct  
{
    /**
     * @brief TRUE if a discrete event occurred since the last call to 
     *  m1553BoardGetDiscreteEvent(). False otherwise.
     */
    M1553Boolean mEventOccurred;
} M1553BoardGetDiscreteEventOut;

/**
 * @brief Input structure for m1553BoardSetDiscreteState().
 */
typedef struct  
{
    /**
     * @brief TRUE to set the state to the on state. False to set the 
     *  state to it's off state.
     */
    M1553Boolean mState;
} M1553BoardSetDiscreteStateIn;

/**
 * @brief Output structure for m1553BoardGetDiscreteState().
 */
typedef struct  
{
    /**
     * @brief TRUE if the discrete's state is the on state. False if it is
     *  the off state.
     */
    M1553Boolean mState;
} M1553BoardGetDiscreteStateOut;

/**
 * @brief Input structure for m1553BoardSetAllDiscreteStates().
 */
typedef struct  
{
    /**
     * @brief Bit wise settings of the discretes. 0: Off, 1: On. 
     *  Bit 0: Discrete 0 ... Bit 9: Discrete 9
     */
    uint32_t mDiscreteStates;
    /**
     * @brief Bit wise mask for applying discrete states.
     *  Bit 0: Discrete 0 ... Bit 9: Discrete 9
     */
    uint32_t mDiscreteStatesMask;
} M1553BoardSetAllDiscreteStatesIn;

/**
 * @brief Output structure for m1553BoardGetAllDiscreteStates().
 */
typedef struct  
{
    /**
     * @brief Bit wise settings of the discretes. 0: Off, 1: On. 
     *  Bit 0: Discrete 0 ... Bit 9: Discrete 9
     */
    uint32_t mDiscreteStates;
} M1553BoardGetAllDiscreteStatesOut;

/**
 * @brief Input structure for m1553BoardSetDiscretePulseLength().
 */
typedef struct  
{
    /**
     * @brief The input pulse length in nanoseconds. The pulse length is 
     *  set with an 8 nanosecond resolution. 
     *  The maximum value is 524,280 nanoseconds.
     *  The minimum value is 16ns.
	 *  Default startup value: 1 microsecond.
     */ 
    uint32_t aInputPulseLength;
    /**
     * @brief The output pulse length in nanoseconds. The pulse length is 
     *  set with an 8 nanosecond resolution.
     *  The maximum value is 524,280 nanoseconds.
     *  The minimum value is 16ns.
	 *  Default startup value: 2 microseconds.
     */ 
    uint32_t aOutputPulseLength;
}M1553BoardSetDiscretePulseLengthIn;

/**
 * @brief Output structure for m1553BoardGetDiscretePulseLength().
 */
typedef struct  
{
    /**
     * @brief The input pulse length in nanoseconds. 
     */ 
    uint32_t aInputPulseLength;
    /**
     * @brief The output pulse length in nanoseconds.
     */ 
    uint32_t aOutputPulseLength;
}M1553BoardGetDiscretePulseLengthOut;

/**
 * @brief Input structure for m1553BoardSetCarrierDiscretePulseLength().
 */
typedef struct  
{
    /**
     * @brief The input pulse length in nanoseconds. The pulse length is 
     *  set with a 10 nanosecond resolution. 
     *  The maximum value is 655,350 nanoseconds.
     *  The minimum value is 20ns.
	 *  Default startup value: 1 microsecond.
     */ 
    uint32_t aBackplaneInputPulseLength;
    /**
     * @brief The output pulse length in nanoseconds. The pulse length is 
     *  set with a 10 nanosecond resolution.
     *  The maximum value is 655,350 nanoseconds.
     *  The minimum value is 20ns.
	 *  Default startup value: 2 microseconds.
     */ 
    uint32_t aBackplaneOutputPulseLength;
    
    /**
     * @brief The input pulse length in nanoseconds. The pulse length is 
     *  set with a 10 nanosecond resolution. 
     *  The maximum value is 655,350 nanoseconds.
     *  The minimum value is 20ns.
	 *  Default startup value: 1 microsecond.
     */ 
    uint32_t aFrontPanelInputPulseLength;
    /**
     * @brief The output pulse length in nanoseconds. The pulse length is 
     *  set with a 10 nanosecond resolution.
     *  The maximum value is 655,350 nanoseconds.
     *  The minimum value is 20ns.
	 *  Default startup value: 2 microseconds.
     */ 
    uint32_t aFrontPanelOutputPulseLength;
}M1553BoardSetCarrierDiscretePulseLengthIn;

/**
 * @brief Output structure for m1553BoardGetCarrierDiscretePulseLength().
 */
typedef struct  
{
    /**
     * @brief The input pulse length in nanoseconds. The pulse length is 
     *  set with a 10 nanosecond resolution. 
     *  The maximum value is 655,350 nanoseconds.
     *  The minimum value is 20ns.
	 *  Default startup value: 1 microsecond.
     */ 
    uint32_t aBackplaneInputPulseLength;
    /**
     * @brief The output pulse length in nanoseconds. The pulse length is 
     *  set with a 10 nanosecond resolution.
     *  The maximum value is 655,350 nanoseconds.
     *  The minimum value is 20ns.
	 *  Default startup value: 2 microseconds.
     */ 
    uint32_t aBackplaneOutputPulseLength;
    
    /**
     * @brief The input pulse length in nanoseconds. The pulse length is 
     *  set with a 10 nanosecond resolution. 
     *  The maximum value is 655,350 nanoseconds.
     *  The minimum value is 20ns.
	 *  Default startup value: 1 microsecond.
     */ 
    uint32_t aFrontPanelInputPulseLength;
    /**
     * @brief The output pulse length in nanoseconds. The pulse length is 
     *  set with a 10 nanosecond resolution.
     *  The maximum value is 655,350 nanoseconds.
     *  The minimum value is 20ns.
	 *  Default startup value: 2 microseconds.
     */ 
    uint32_t aFrontPanelOutputPulseLength;
}M1553BoardGetCarrierDiscretePulseLengthOut;

/**
* @brief The input structure for m1553ChannelReset()
*/
typedef struct  
{
    /**
     * @brief Reset Control. See M1553ResetMode. Determines what portions
     *  of the hardware should be reset.
     */
    M1553ResetMode mMode;
} M1553ChannelResetIn;

/**
 * @brief The input structure for m1553ChannelSetResponseTimeout()
 */
typedef struct
{
    /**
     * @brief BC response timeout. Range: 0 - 63.75 microseconds in steps 
     *  of 0.25 microseconds.
     */
    M1553Float mResponseTimeout;
} M1553ChannelSetResponseTimeoutIn;

/**
 * @brief The output structure for m1553ChannelGetResponseTimeout()
 */
typedef struct
{
    /**
     * @brief BC response timeout.
     */
    M1553Float mResponseTimeout;
} M1553ChannelGetResponseTimeoutOut;

/** 
 * @brief The input structure for m1553ChannelSetMilbusProtocol()
 */
typedef struct
{
    /**
     * @brief MilBus protocol. Defines the RT operation as either 1553A 
     *  or 1553B protocol.
     */
    M1553MilProtocolType mMilProtocol;
    /**
     * @brief Set all RT's. Use the value of mMilProtocol to set all RT's.
     *  If TRUE, then mRT is ignored.
     */
    M1553Boolean mSetAllRTs;
    /**
     * @brief The RT address to configure. If mSetAllRTs is TRUE, this
     *  parameter is ignored.
     * Range: 0-31.
     */
    uint8_t mRT;
} M1553ChannelSetMilbusProtocolIn;

/**
 * @brief The output structure for m1553ChannelGetMilbusProtocol()
 */
typedef struct
{
    /**
     * @brief MilBus protocol. Indicates that the RT operation is either 1553A 
     *  or 1553B protocol.
     */
    M1553MilProtocolType mMilProtocol;
} M1553ChannelGetMilbusProtocolOut;

/**
 * @brief Channel Register map
 *  All addresses are byte offsets from the channel's memory. The Channel 
 *  registers are mapped from IO space into the channel memory space.
 * @sa m1553RamChannelGetData()
 * @sa m1553RamChannelSetData()
 */
typedef struct 
{
    /**
     * @brief Size of the system control block
     */
    uint32_t mSystemControlBlockSize;
    /**
     * @brief System control block channel byte offset
     */
    uint32_t mSystemControlBlockOffset;

    /**
     * @brief Size of the miscellaneous BC block
     */
    uint32_t mMiscellaneousBcBlockSize;
    /**
     * @brief Address of the miscellaneous BC block
     */
    uint32_t mMiscellaneousBcBlockOffset;

    /**
     * @brief Size of the @link M1553InterruptLoglistEntryType Interrupt 
     *  Log List @endlink area
     */
    uint32_t mInterruptLoglistSize;
    /**
     * @brief Address of the @link M1553InterruptLoglistEntryType Interrupt 
     *  Log List @endlink
     */
    uint32_t mInterruptLoglistOffset;

    /**
     * @brief Size of the remote terminal descriptor block
     */
    uint32_t mRtDescriptorBlockSize;
    /**
     * @brief Address of the remote terminal descriptor block
     */
    uint32_t mRtDescriptorBlockOffset;

    /**
     * @brief Size of the bus monitor trigger control block
     */
    uint32_t mBmTriggerControlBlockSize;
    /**
     * @brief Address of the bus monitor trigger control block
     */
    uint32_t mBmTriggerControlBlockOffset;

    /**
     * @brief Size of the bus monitor activity block
     */
    uint32_t mBmActivityBlockSize;
    /**
     * @brief Address of the bus monitor activity block
     */
    uint32_t mBmActivityBlockOffset;
} M1553ChannelRegisterMap;

/**
 * @brief Channel data and control area memory map.
 *  All addresses are byte offsets from the channel's memory.
 * @sa m1553RamChannelGetData()
 * @sa m1553RamChannelSetData()
 */
typedef struct
{
    /**
     * @brief Size of the remote terminal subaddress descriptor area
     */
    uint32_t mRtSaDescriptorAreaSize;
    /**
     * @brief Address of the remote terminal subaddress descriptor area
     */
    uint32_t mRtSaDescriptorAreaOffset;

    /**
     * @brief Size of the remote terminal buffer header area
     */
    uint32_t mRtBufferHeaderAreaSize;
    /**
     * @brief Address of the remote terminal buffer header area
     */
    uint32_t mRtBufferHeaderAreaOffset;

    /**
     * @brief Size of the remote terminal status queue area
     */
    uint32_t mRtStatusQueueAreaSize;
    /**
     * @brief Address of the remote terminal status queue area
     */
    uint32_t mRtStatusQueueAreaOffset;

    /**
     * @brief Size of the remote terminal event queue area
     */
    uint32_t mRtEventQueueAreaSize;
    /**
     * @brief Address of the remote terminal event queue area
     */
    uint32_t mRtEventQueueAreaOffset;

    /**
     * @brief Size of the bus controller buffer header block
     */
    uint32_t mBcBufferHeaderAreaSize;
    /**
     * @brief Address of the bus controller buffer header block
     */
    uint32_t mBcBufferHeaderAreaOffset;

    /**
     * @brief Size of the bus controller status queue area
     */
    uint32_t mBcStatusQueueAreaSize;
    /**
     * @brief Address of the bus controller status queue area
     */
    uint32_t mBcStatusQueueAreaOffset;

    /**
     * @brief Size of the bus controller event queue area 
     */
    uint32_t mBcEventQueueAreaSize;
    /**
     * @brief Address of the bus controller event queue area 
     */
    uint32_t mBcEventQueueAreaOffset;

    /**
     * @brief Size of the bus controller transfer descriptor block area
     */
    uint32_t mBcTransferDescriptorAreaSize;
    /**
     * @brief Address of the bus controller transfer descriptor block area
     */
    uint32_t mBcTransferDescriptorAreaOffset;

    /**
     * @brief Size of the bus controller instruction list pointer area
     */
    uint32_t mBcHighPriorityInstructionListAreaSize;
    /**
     * @brief Address of the bus controller instruction list pointer area
     */
    uint32_t mBcHighPriorityInstructionListAreaOffset;

    /**
     * @brief Size of the bus controller low priority instruction list pointer area
     */
    uint32_t mBcLowPriorityInstructionListAreaSize;
    /**
     * @brief Address of the bus controller low priority instruction list pointer area
     */
    uint32_t mBcLowPriorityInstructionListAreaOffset;

    /**
     * @brief Size of the bus controller acyclic instruction list pointer area
     */
    uint32_t mBcAcyclicInstructionListAreaSize;
    /**
     * @brief Address of the bus controller acyclic instruction list pointer area
     */
    uint32_t mBcAcyclicInstructionListAreaOffset;

    /**
     * @brief Size of the BC/RT buffer area
     */
    uint32_t mBcRtBufferAreaSize;
    /**
     * @brief Offset of the BC/RT buffer area
     */
    uint32_t mBcRtBufferAreaOffset;

    /**
     * @brief Size of the the bus monitor buffer area
     */
    uint32_t mBmBufferAreaSize;
    /**
     * @brief Address of the the bus monitor buffer area
     */
    uint32_t mBmBufferAreaOffset;

    /**
     * @brief Size of the replay buffer area
     */
    uint32_t mReplayBufferAreaSize;
    /**
     * @brief Address of the replay buffer area
     */
    uint32_t mReplayBufferAreaOffset;
} M1553ChannelMemoryMap;

/**
 * @brief Number of indices available for the bus controller and remote 
 *  terminal related descriptors.
 */
typedef struct 
{
    /**
     * @brief Number of remote terminal buffer header descriptors
     */
    uint32_t mRtBufferHeaderDescriptorCount;
    /**
     * @brief The size of remote terminal buffer header descriptor
     */
    uint32_t mRtBufferHeaderDescriptorSize;
    /**
     * @brief Number of remote terminal status queue descriptors
     */
    uint32_t mRtStatusQueueDescriptorCount;
    /**
     * @brief The size of remote terminal status queue descriptors
     */
    uint32_t mRtStatusQueueDescriptorSize;
    /**
     * @brief Number of remote terminal event queue descriptors
     */
    uint32_t mRtEventQueueDescriptorCount;
    /**
     * @brief The size of remote terminal event queue descriptors
     */
    uint32_t mRtEventQueueDescriptorSize;
    /**
     * @brief Number of bus controller buffer header descriptors
     */
    uint32_t mBcBufferHeaderDescriptorCount;
    /**
     * @brief The size of bus controller buffer header descriptors
     */
    uint32_t mBcBufferHeaderDescriptorSize;
    /**
     * @brief Number of bus controller status queue descriptors
     */
    uint32_t mBcStatusQueueDescriptorCount;
    /**
     * @brief The size of bus controller status queue descriptors
     */
    uint32_t mBcStatusQueueDescriptorSize;
    /**
     * @brief Number of bus controller event queue descriptors
     */
    uint32_t mBcEventQueueDescriptorCount;
    /**
     * @brief The size of bus controller event queue descriptors
     */
    uint32_t mBcEventQueueDescriptorSize;
    /**
     * @brief Number of bus controller transfer descriptors
     */
    uint32_t mBcTransferDescripterCount;
    /**
     * @brief The size of bus controller transfer descriptors
     */
    uint32_t mBcTransferDescripterSize;
    /**
     * @brief Number of BC-RT buffer descriptors
     */
    uint32_t mBcRtBufferDescripterCount;
    /**
     * @brief The size of BC-RT buffer descriptors
     */
    uint32_t mBcRtBufferDescripterSize;

} M1553ChannelMemoryDescriptorCounts;

/**
 * @brief 1553 Memory Layout input structure for m1553ChannelSetMemPartition()
 */
typedef struct 
{
    /**
     * @brief The channel's memory map.
     */
    M1553ChannelMemoryMap mMemoryMap;
} M1553ChannelSetMemPartitionIn;

/**
 * @brief 1553 memory layout information returned by 
 *  m1553ChannelGetMemPartition()
 */
typedef struct 
{
    /**
     * @brief The channel's register map.
     */
    M1553ChannelRegisterMap mRegisterMap;
    /**
     * @brief The channel's memory map.
     */
    M1553ChannelMemoryMap mMemoryMap;
    /**
     * @brief The size and number of descriptors statically allocated in 
     *  the memory map, mMemoryMap
     */
    M1553ChannelMemoryDescriptorCounts mDescriptorCounts;
    /**
     * @brief The total (global) memory size
     */
    uint32_t mGlobalMemorySize;
    /**
     * @brief This channel's total RAM size (each channel is mapped into 
     *  the global memory)
     */
    uint32_t mChannelMemorySize;
} M1553ChannelGetMemPartitionOut;

/**
 * @brief The input structure for m1553ChannelSetTestSignal()
 */
typedef struct  
{
    /**
     * @brief Select the channel's primary or secondary bus.
     */
    M1553BusType mBus;
    /**
     * @brief Set to TRUE for enabled or FALSE for disabled.
     */
    M1553Boolean mEnabled;
} M1553ChannelSetTestSignalIn;

/**
 *  @brief The output structure for m1553ChannelGetCoupling()
 */
typedef struct  
{
    /**
     * @brief The 1553 bus coupling mode 
     */
    M1553CouplingType mBusCoupling;
} M1553ChannelGetCouplingOut;

/**
 * @brief The input structure for m1553ChannelSetCoupling()
 */
typedef struct  
{
    /**
     * @brief The 1553 bus coupling mode 
     */
    M1553CouplingType mBusCoupling;
} M1553ChannelSetCouplingIn;

/**
 * @brief The input structure for m1553ChannelSetAmplitude()
 */
typedef struct
{
    /**
     * @brief The bus amplitude.
     * 0:0% ... 255:100%
     */
    uint8_t mAmplitude;
} M1553ChannelSetAmplitudeIn;

/**
 * @brief The output structure for m1553ChannelGetAmplitude()
 */
typedef struct
{
    /**
     * @brief The bus amplitude.
     * 0:0% ... 255:100%
     */
    uint8_t mAmplitude;
} M1553ChannelGetAmplitudeOut;

/**
 * @brief The input structure for m1553ChannelSetBitRate()
 */
typedef struct
{
    /**
     * @brief The channel's bit rate.
     */
    M1553ChannelBitrate mBitrate;
} M1553ChannelSetBitRateIn;

/**
 * @brief The output structure for m1553ChannelGetBitRate()
 */
typedef struct
{
    /**
     * @brief The channel's bit rate.
     */
    M1553ChannelBitrate mBitrate;
} M1553ChannelGetBitRateOut;

/**
 * @brief The input structure for m1553BoardSetPXIStarTriggerConfig().
 */
typedef struct  
{
    /**
     * Use TRUE to define the backplane input as active high, or FALSE
     *  for active low.
     */
    M1553Boolean mPolarityActiveHigh;
    /**
     * Use TRUE to enable the star trigger function or FALSE to disable it.
     *  When enabled, the IRIG clock will reset to the last time that was
     *  written each time a star trigger occurs. Use m1553BoardSetIrigTime()
     *  to write the reset value.
     */
    M1553Boolean mEnabled;
}M1553BoardSetPXIStarTriggerConfigIn;


// PXIe-m1553 Event Routing Selection Table
// Select an input to route to an ouput
// Not all combinations are valid
typedef enum
{
	DISCRETE_CHAN_0,	// 0x00
	DISCRETE_CHAN_1,	// 0x01
	DISCRETE_CHAN_2,	// 0x02
	DISCRETE_CHAN_3, 	// 0x03
	DISCRETE_CHAN_4,	// 0x04
	DISCRETE_CHAN_5,	// 0x05
	DISCRETE_CHAN_6,	// 0x06
	DISCRETE_CHAN_7,	// 0x07
	DISCRETE_CHAN_8,	// 0x08
	DISCRETE_CHAN_9,	// 0x09
	PXI_TRIGGER_0,		// 0x0A
	PXI_TRIGGER_1,		// 0x0B
	PXI_TRIGGER_2,		// 0x0C
	PXI_TRIGGER_3,		// 0x0D
	PXI_TRIGGER_4,		// 0x0E
	PXI_TRIGGER_5,		// 0x0F
	PXI_TRIGGER_6,		// 0x10
	PXI_TRIGGER_7,		// 0x11
	PXIE_DSTARA,		// 0x12
	PXIE_DSTARB,		// 0x13
	PXIE_DSTARC,		// 0x14
	MON_STROBE_0,		// 0x15
	MON_STROBE_1,		// 0x16
	MON_STROBE_2,		// 0x17
	MON_STROBE_3,		// 0x18
	BC_STROBE_0,		// 0x19
	BC_STROBE_1,		// 0x1A
	BC_STROBE_2,		// 0x1B
	BC_STROBE_3,		// 0x1C
	// reserved_0		// 0x1D
	// reserved_1		// 0x1E
	NO_INPUT_ROUTED		// 0x1F

} TY_PXIE_BOARD_ROUTE_SEL;


    /**
    * @brief Identifier for MIL-STD-1553 GC device
    */
#define ADMIN_DEV_TYPE_MIL_STD_1553_GC	0x00000008

/**
 * @defgroup m1553System System Functions
 * @brief These are the Initialization functions that initialize, query, and 
 *  close the communications with the 1553 modules.   
 * @{
 */


/** 
 * @name API Initialization Routines
 * @brief Description of the functions used to establish communication to and 
 *  query the 1553 hardware.
 * @{
 */

/**
 * @brief Initialize the Application Interface and return the number of 
 *  1553 boards found.
 * This must be the first function called in the application program.
 * @param[in] aStructureIoVersion This input is required to be the value of 
 *  M1553_API_IO_VERSION. This defines how the internal library will interpret 
 *  input and output structures to the exported interface functions. Each time
 *  an input or output structure is changed, the definition will be incremented
 *  and the library will be able to interpret previously compiled applications
 *  correctly, without recompiling.
 * @param[out] aBoardsFound The number of compatible 1553 devices found 
 *  in the system.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, aBoardsFound</td>
 *  <tr>
 *  </tr>
 *      <td>#API_ERROR_INCOMPATIBLE_REVISION</td>
 *      <td>aStructureIoVersion is the wrong version</td>
 *  <tr>
 *      <td>#API_NOT_INITIALIZED</td>
 *      <td>Could not initialize aBoardsFound</td>
 *  </tr>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553Init(uint32_t aStructureIoVersion, 
                         uint32_t* aBoardsFound);

/**
 * @brief This function establishes connectivity between the application 
 *  interface and the 1553 board. This must be called before using other 
 *  API library functions that require a board handle. Subsequent calls 
 *  to m1553BoardOpen() with the same board index will return the handle 
 *  previously assigned. Use m1553close() to free memory structures held 
 *  internally by the library when the user application is finished with 
 *  the 1553 hardware resource.
 * @param[in] aBoardIndex The index of the board that should be opened.
 * @param[out] apBoardHandle The board handle (or NULL if the operation 
 *  was a failure).
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error,apBoardHandle</td> 
 *  </tr>
 * </table>
 * @sa m1553Close()
 * @sa m1553ChannelOpen()
 */
M1553_API_FUNC m1553BoardOpen(uint32_t aBoardIndex, 
                              M1553Handle* apBoardHandle);

/**
 * @brief This function establishes connectivity between the application 
 *  interface and a 1553 channel. This must be called before using other 
 *  API library functions that require a channel handle. Subsequent calls 
 *  to m1553ChannelOpen() for the same resource will return the handle 
 *  previously assigned. Use m1553close() to free memory structures held 
 *  internally when the application is finished using the 1553 hardware 
 *  resource.
 * @param[in] aBoardHandle A board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aChannelIndex The index of the channel that should be opened.
 *  Range: 0 - MAX_API_BOARD_CHANNELS.
 * @param[out] apChannelHandle The channel handle (or NULL if the operation 
 *  was a failure).
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error,M1553Handle</td> 
 *  </tr>
 *  <tr>
 *      <td>#CHANNEL_ERROR_INVALID_INDEX</td>
 *      <td>Invalid aChannelIndex passed</td>
 *  </tr>
 * </table>
 * @sa m1553Close()
 * @sa m1553BoardOpen()
 */
M1553_API_FUNC m1553ChannelOpen(M1553Handle aBoardHandle,
                                uint32_t aChannelIndex, 
                                M1553Handle* apChannelHandle);

/**
 * @brief This function will close the application interface for the specified 
 *  resource, previously opened by m1553ChannelOpen() or m1553BoardOpen(), 
 *  and will free any internally held memory structures allocated during 
 *  m1553ChannelOpen() or m1553BoardOpen().
 * @param[in] aHandle Board or channel handle obtained by calling 
 * m1553ChannelOpen() or m1553BoardOpen().
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid aBoardHandle passed</td>
 *  </tr>
 * </table>
 * @sa m1553ChannelOpen(), m1553BoardOpen()
 */
M1553_API_FUNC m1553Close (M1553Handle aHandle);

/**
 * @brief Cleanup and shutdown the API interface and mapping to hardware devices.
 * This routine is the complement to the m1553Init() startup function call.
 * @param[in] aStructureIoVersion This input is required to be the value of 
 *  M1553_API_IO_VERSION. This defines how the internal library will interpret 
 *  input and output structures to the exported interface functions. Each time
 *  an input or output structure is changed, the definition will be incremented
 *  and the library will be able to interpret previously compiled applications
 *  correctly, without recompiling.
 * @param[out] aBoardsFound The number of compatible 1553 devices found 
 *  in the system.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_INCOMPATIBLE_REVISION</td>
 *      <td>aStructureIoVersion is the wrong version</td>
 *  </tr>
 *  <tr>
 *      <td>#API_NOT_INITIALIZED</td>
 *      <td>Could not initialize aBoardsFound</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553Uninitialize (uint32_t aStructureIoVersion);

/**
 * @brief Get the system driver and library version.
 * @param[out] apGetSystemInformationOut A pointer to an output structure 
 *  containing system information.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error,M1553GetSystemInformationOut</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553GetSystemInformation(M1553GetSystemInformationOut *apGetSystemInformationOut);

/** @} */ /* end API Initialization Routines */


/** 
 * @name Interrupt Configuration and Status Routines
 * @brief Description of the functions used to install and remove interrupt 
 *  handlers, and poll for interrupts.
 * @{
 */

/**
 * @brief This function is used to install a user-defined interrupt 
 *  handler function. It is possible to define an interrupt handler for 
 *  BC, RT, BM, Replay, and Branch related interrupts.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[in] apInstallInterruptHandlerIn A pointer to an 
 *  M1553InstallInterruptHandlerIn input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
 *      <td>mType is Invalid</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>mIntFunc is NULL</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553InstallInterruptHandlerIn</td>
 *  </tr>
 * </table>
 * @sa m1553DeleteInterruptHandler()
 */
M1553_API_FUNC m1553InstallInterruptHandler(M1553Handle aChannelHandle, 
                                            const M1553InstallInterruptHandlerIn* apInstallInterruptHandlerIn);


/**
 * @brief This function is used to remove the user-defined interrupt handler 
 *  that was previously installed with the m1553InstallInterruptHandler() 
 *  function. This function will remove the pointer to the interrupt handler 
 *  for a specified interrupt. It is necessary to call this function for 
 *  each interrupt type that has been installed.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open().
 * @param[in] apDeleteInterruptHandlerIn A pointer to an 
 *  M1553DeleteInterruptHandlerIn input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553DeleteInterruptHandlerIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
 *      <td>mType is invalid</td>
 *  </tr>
 * </table>
 * @sa m1553InstallInterruptHandler()
 */
M1553_API_FUNC m1553DeleteInterruptHandler(M1553Handle aChannelHandle,  
                                           const M1553DeleteInterruptHandlerIn* apDeleteInterruptHandlerIn);

/**
 * @brief This function is used to read (and remove) all pending interrupts
 *  from the interrupt queue.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open().
 * @param[out] apGetInterruptsIn A pointer to an 
 *  M1553ChannelGetInterruptsIn output structure containing interrupt 
 *  information.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelGetInterruptsIn</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553ChannelGetInterrupts(M1553Handle aChannelHandle, 
                                         M1553ChannelGetInterruptsIn* apGetInterruptsIn);
/** @} */ /* end of Interrupt Configuration and Status Routines */


/** @} */ /* End of m1553System group    */

/**
 * @defgroup m1553Board Board Functions
 * @brief These are the 1553 Board functions for executing built in tests, 
 *  resetting the hardware, controlling the IRIG circuitry, setting the 
 *  coupling and other board level functions.
 * @{
 */

/** 
 * @name 1553 Board Configuration and Status Routines
 * @brief Description of the functions used to initialize and retrieve status 
 *  for the 1553 hardware.
 * @{
 */

/**
 * @brief Perform  Built-In Test. This function will run a built-in test on the 1553 
 *  board and will return results of the test. Upon running BIT, all 
 *  setups and current activity will be lost. This function may take a very
 *  long time to execute.
 * @param[in] aBoardHandle Board handle obtained by calling m1553Open()
 * @param[in] apBoardBITIn A pointer to the M1553BoardBITIn input 
 *  structure.
 * @param[in] apBoardBITOut A pointer to the M1553BoardBITOut output 
 *  structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardBITIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardBITOut</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardBIT(M1553Handle aBoardHandle, 
                              const M1553BoardBITIn* apBoardBITIn,
                              M1553BoardBITOut* apBoardBITOut);

/**
 * @brief Retrieve board information. This function will retrieve
 *  board serial number, type and configuration information.
 * @param[in] aBoardHandle Board handle obtained by calling m1553Open()
 * @param[out] apGetBoardInfoOut Board type and configuration information.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553GetBoardInfoOut</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553GetBoardInfo(M1553Handle aBoardHandle, 
                                 M1553GetBoardInfoOut* apGetBoardInfoOut);

/**
 * @brief Retrieve battery monitor information for the 1553 USB device.
 * @param[in] aBoardHandle Board handle obtained by calling m1553Open()
 * @param[out] apUsbGetBatteryInfoOut Battery monitor information.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553GetBoardInfoOut</td>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid device</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553USBGetBatteryInfo(M1553Handle aBoardHandle, M1553USBGetBatteryInfoOut* apUsbGetBatteryInfoOut);

/**
 * @brief Operate the front panel LEDs on the USB 1553 device.
 * Must be called once for each LED.
 * @param[in] aBoardHandle Board handle obtained by calling m1553Open()
 * @param[in] apUsbSetLEDIn LED state information.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553GetBoardInfoOut</td>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid device</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553USBSetFrontPanelLED(M1553Handle aBoardHandle, M1553USBSetFrontPanelLEDin* apUsbSetLEDIn);

/**
 * @brief Set the IRIG hardware clock. This defines the time and source of
 *  the hardware IRIG clock.
 * @param[in] aBoardHandle Board handle obtained by calling m1553Open().
 * @param[in] apSetIrigTimeIn A pointer to an M1553BoardSetIrigTimeIn
 *  input structure
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardSetIrigTimeIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
 *      <td>mIrigSource is Invalid</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_OUT_OF_RANGE</td>
 *      <td>mDays is Invalid</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM2_OUT_OF_RANGE</td>
 *      <td>mHour is Invalid</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM3_OUT_OF_RANGE</td>
 *      <td>mMin is Invalid</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM4_OUT_OF_RANGE</td>
 *      <td>mSec is Invalid</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM5_OUT_OF_RANGE</td>
 *      <td>mMilliseconds is Invalid</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM6_OUT_OF_RANGE</td>
 *      <td>mMicroseconds is Invalid</td>
 *  </tr>
 * </table>
 * @sa m1553BoardGetIrigTime()
 */
M1553_API_FUNC m1553BoardSetIrigTime(M1553Handle aBoardHandle, 
                                     const M1553BoardSetIrigTimeIn* apSetIrigTimeIn);

/**
 * @brief Get the current IRIG time and configuration.
 * @param[in] aBoardHandle Board handle obtained by calling m1553Open().
 * @param[out] apGetIrigTimeOut A pointer to an M1553BoardGetIrigTimeOut 
 *  output structure containing IRIG data and synchronization data.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetIrigTimeOut</td>
 *  </tr>
 * </table>
 * @sa m1553BoardSetIrigTime()
 */
M1553_API_FUNC m1553BoardGetIrigTime(M1553Handle aBoardHandle, 
                                     M1553BoardGetIrigTimeOut* apGetIrigTimeOut);

/**
 * @brief Load and ELF File to the on board PPC
 * @param[in] aBoardHandle Board handle obtained by calling m1553Open().
 * @param[in] mode Reserved and should be set to 0
 * @param[in] filename Name of the ELF File
  * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, m1553BoardLoadElf</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardLoadElf(M1553Handle aBoardHandle,  uint8_t mode,  char* filename);

/** 
 * @name Board discrete functions
 *  Functions for manipulating and getting information from the digital
 *  IO hardware on the m1553 board.
 *  
 *  Typical configuration is 10 Discrete I/O lines.
 *  During API startup initialization each DIO line is set to the following defaults:
 *  Line Disabled.
 *  Event-Out cleared.
 *  Event-In cleared.
 *  Line set as M1553_DISCRETE_RECEIVER type.
 *  Bus Monitor Strobe Output set to no valid DIO line.
 *  Bus Controller Strobe Output set to no valid DIO line.
 *  Default PMC Discrete Input time set to 1 microsecond.
 *  Default PMC Discrete Output time set to 2 microseconds.
 *  
 * @{
 */

/**
 * @brief Get the number of digital IO lines available.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[out] apGetDiscreteCountOut A pointer to an 
 *  M1553BoardGetDiscreteCountOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetDiscreteCountOut</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetDiscreteCount(M1553Handle aBoardHandle, M1553BoardGetDiscreteCountOut* apGetDiscreteCountOut);

/**
 * @brief Get the number of backplane digital IO lines available.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[out] apGetBackplaneDiscreteOut A pointer to an 
 *  M1553BoardBackplaneDiscreteCountOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetBackplaneDiscreteCountOut</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_CARRIER_NOT_PRESENT</td>
 *      <td>Backplane carrier card not present</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetBackplaneDiscreteCount(M1553Handle aBoardHandle, M1553BoardGetBackplaneDiscreteCountOut* apGetBackplaneDiscreteCountOut);

/**
 * @brief Enable or Disable the available digital IO lines.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aMask A bit mask to enable/disable the digital IO lines.
 *  Bit 0 is DIO line 0. A bitwise "1" will enable and a bitwise "0" will 
 *  disable. To enable all discretes, just use 0xFFFFFFFF, and indices that
 *  are not physically present will be ignored.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetDiscreteEnable(M1553Handle aBoardHandle,  uint32_t aMask);

/**
 * @brief Enable or Disable interrupts on digital IO lines.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aMask A bit mask to enable/disable the interrupts.
 *  Bit 0 is DIO line 0. A bitwise "1" will enable and a bitwise "0" will 
 *  disable. To enable all discrete interrupts, just use 0xFFFFFFFF, and indices that
 *  are not physically present will be ignored.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetDiscreteInterruptEnable(M1553Handle aBoardHandle,  uint32_t aMask);

/**
 * @brief Get the current Enable or Disable state of the available digital IO lines.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[out] aMask A pointer for a bit mask reflecting the enable/disable 
 *  state of the digital IO lines. Bit 0 is DIO line 0. A bitwise "1" is 
 *  enabled and a bitwise "0" is disabled.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, aMask</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetDiscreteEnable(M1553Handle aBoardHandle,  uint32_t *aMask);

/*
 * @brief Enable or Disable the available backplane digital IO lines.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[out] aBackplaneMask A bit mask for setting the enable/disable 
 *  state of the backplane digital IO lines. Bit 0 is backplane digital IO 
 *  line 0. A bitwise "1" is enabled and a bitwise "0" is disabled.
 * @param[out] aFrontPanelMask A bit mask for setting the enable/disable 
 *  state of the front panel digital IO lines. Bit 0 is digital IO 
 *  line 0. A bitwise "1" is enabled and a bitwise "0" is disabled.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_CARRIER_NOT_PRESENT</td>
 *      <td>Backplane carrier card not present</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetCarrierDiscreteEnable(M1553Handle aBoardHandle, uint32_t aBackplaneMask, uint32_t aFrontPanelMask);

/**
 * @brief Get the current Enable or Disable state of the available backplane 
 *  digital IO lines.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[out] aBackplaneMask A pointer to a bit mask reflecting the enable/disable 
 *  state of the backplane digital IO lines. Bit 0 is backplane digital IO 
 *  line 0. A bitwise "1" is enabled and a bitwise "0" is disabled.
 * @param[out] aFrontPanelMask A pointer to a bit mask reflecting the enable/disable 
 *  state of the front panel digital IO lines. Bit 0 is digital IO 
 *  line 0. A bitwise "1" is enabled and a bitwise "0" is disabled.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, aMask</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_CARRIER_NOT_PRESENT</td>
 *      <td>Backplane carrier card not present</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetCarrierDiscreteEnable(M1553Handle aBoardHandle, uint32_t *aBackplaneMask, uint32_t *aFrontPanelMask);

/**
 * @brief Initialize a digital IO line. This clears any pending events for
 *  the discrete, and reset's the function driver to M1553_DISCRETE_RECEIVER.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardDiscreteReset(M1553Handle aBoardHandle,  
                                       uint32_t aIndex);

/**
 * @brief Initialize a backpane digital IO line. This clears any pending events 
 *  for the digital IO line, and reset's the driver type to 
 *  M1553_DISCRETE_RECEIVER.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aMode Select either a front panel or rear IO trigger line to
 *  reset. If this is a PMC or XMC device on a PXI carrier then there 
 *  are 10 front panel and 8 rear IO lines.
 * @param[in] aIndex The (0 indexed) backplane digital IO line.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_DEVICE_NOT_FOUND</td>
 *      <td>Invalid Board handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_CARRIER_NOT_PRESENT</td>
 *      <td>Backplane carrier card not present</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardCarrierDiscreteReset(M1553Handle aBoardHandle,  
                                              M1553TriggerModeType aMode,
                                              uint32_t aIndex);

/**
 * @brief Sets the discrete configuration. Defines a digital IO line to 
 *  be either input or output. If the discrete is an output the output driver 
 *  mechanism is defined.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @param[in] apSetDiscreteConfigIn A pointer to an 
 *  M1553BoardSetDiscreteConfigIn input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid Channel handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardSetDiscreteConfigIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_INDEX_OUT_OF_RANGE></td>
 *      <td>aIndex is out of range</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
 *      <td>mDriverType is Invalid</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetDiscreteConfig(M1553Handle aBoardHandle,
                                           uint32_t aIndex,
                                           const M1553BoardSetDiscreteConfigIn* apSetDiscreteConfigIn);

/**
 * @brief Gets the discrete configuration.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @param[out] apGetDiscreteConfigOut A pointer to an 
 *  M1553BoardGetDiscreteConfigOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetDiscreteConfigOut</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_INDEX_OUT_OF_RANGE></td>
 *      <td>aIndex is out of range</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetDiscreteConfig(M1553Handle aBoardHandle,
                                           uint32_t aIndex,
                                           M1553BoardGetDiscreteConfigOut* apGetDiscreteConfigOut);


// PXIe-m1553 Event Routing Selection
M1553_API_FUNC m1553BoardSetPXIeEventRoute(M1553Handle aBoardHandle, TY_PXIE_BOARD_ROUTE_SEL aIn, TY_PXIE_BOARD_ROUTE_SEL aOut);


/**
 * @brief Sets the digital IO configuration on a carrier card. If the board
 *  is located on a compatible carrier device, then this function will configure
 *  either the backplane or front panel digital IO interface.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aMode Select either a front panel or rear IO trigger line to
 *  configure. If this is a PMC or XMC device on a PXI carrier then there 
 *  are 10 front panel and 8 rear IO lines.
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @param[in] apSetCarrierDiscreteConfigIn A pointer to an 
 *  M1553BoardSetCarrierDiscreteConfigIn input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardSetCarrierDiscreteConfigIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID></td>
 *      <td>mDriverType is invalid</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_CARRIER_NOT_PRESENT</td>
 *      <td>Backplane carrier card not present</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetCarrierDiscreteConfig(M1553Handle aBoardHandle,
                                                  M1553TriggerModeType aMode,
                                                  uint32_t aIndex,
                                                  const M1553BoardSetCarrierDiscreteConfigIn* apSetCarrierDiscreteConfigIn);

/**
 * @brief Gets the digital IO configuration from the carrier card.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aMode Select either a front panel or rear IO trigger line to
 *  configure. If this is a PMC or XMC device on a PXI carrier then there 
 *  are 10 front panel and 8 rear IO lines.
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @param[out] apGetCarrierDiscreteConfigOut A pointer to an 
 *  M1553BoardGetCarrierDiscreteConfigOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetCarrierDiscreteConfigOut</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_CARRIER_NOT_PRESENT</td>
 *      <td>Backplane carrier card not present</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetCarrierDiscreteConfig(M1553Handle aBoardHandle,
                                                  M1553TriggerModeType aMode,
                                                  uint32_t aIndex,
                                                  M1553BoardGetCarrierDiscreteConfigOut* apGetCarrierDiscreteConfigOut);

/**
 * @brief Set a route between an internal trigger and an external discrete
 * @param[in] aBoardHandle Board handle obtained by calling m1553BoardOpen().
 * @param[in] apSetTriggerRouteIn Trigger routing configuration
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardRouteTriggerIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
 *      <td>mTriggerType is Invalid</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetTriggerRoute(M1553Handle aBoardHandle, 
                                      const M1553BoardSetTriggerRouteIn * apSetTriggerRouteIn);

/**
 * @brief Get an existing route between an internal trigger and an external discrete
 * @param[in] aBoardHandle Board handle obtained by calling m1553BoardOpen().
 * @param[in] apGetTriggerRouteIn Specify Route info to get
 * @param[out] apGetTriggerRouteOut Returned trigger route configuration
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetTriggerRouteIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetTriggerRouteOut</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetTriggerRoute(M1553Handle aBoardHandle, 
                                      const M1553BoardGetTriggerRouteIn * apGetTriggerRouteIn,
									  M1553BoardGetTriggerRouteOut * apGetTriggerRouteOut);

/**
 * @brief Generate an event or pulse for a specified discrete. Only valid
 *  for discretes configured as outputs. The output event will have a pulse
 *  length defined by the global pulse length configuration parameter defined
 *  by calling m1553BoardSetDiscretePulseLength().
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_INDEX_OUT_OF_RANGE</td>
 *      <td>aIndex is out of range</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetDiscreteEvent(M1553Handle aBoardHandle,  
                                          uint32_t aIndex);

/**
 * @brief Generate an event or pulse for a specified discrete located on
 *  the carrier card. If the board is installed on a compatible carrier card,
 *  then it is possible to generate discrete events from the hosted board,
 *  or the carrier. Only valid for discretes configured as outputs. The 
 *  output event will have a pulse length defined by the global pulse 
 *  length configuration parameter defined by calling 
 *  m1553BoardSetCarrierDiscretePulseLength().
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aMode Select either a front panel or rear IO trigger line to
 *  configure. If this is a PMC or XMC device on a PXI carrier then there 
 *  are 10 front panel and 8 rear IO lines.
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_INDEX_OUT_OF_RANGE</td>
 *      <td>aIndex is out of range</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetCarrierDiscreteEvent(M1553Handle aBoardHandle,  
                                                 M1553TriggerModeType aMode,
                                                 uint32_t aIndex);

/**
 * @brief Check for discrete input events. Only valid for input discretes.
 *  This will check to see if a discrete input event has occurred. It is
 *  indeterminable if more than one event has occurred. This clears the
 *  hardware event flag so that the discrete line is primed to detect
 *  another event.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @param[out] apGetDiscreteEventOut A pointer to an
 *  M1553BoardGetDiscreteEventOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_INDEX_OUT_OF_RANGE></td>
 *      <td>aIndex is out of range</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetDiscreteEventOut</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetDiscreteEvent(M1553Handle aBoardHandle,
                                          uint32_t aIndex,
                                          M1553BoardGetDiscreteEventOut* apGetDiscreteEventOut);

/**
 * @brief Check for discrete events on a specified discrete located on
 *  the carrier card. If the board is installed on a compatible carrier card,
 *  then it is possible to detect discrete events from the hosted board,
 *  or the carrier. This will check to see if a discrete input event has 
 *  occurred. It is indeterminable if more than one event has occurred. 
 *  This clears the hardware event flag so that the discrete line is primed 
 *  to detect another event.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aMode Select either a front panel or rear IO trigger line to
 *  configure. If this is a PMC or XMC device on a PXI carrier then there 
 *  are 10 front panel and 8 rear IO lines.
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @param[out] apGetDiscreteEventOut A pointer to an
 *  M1553BoardGetDiscreteEventOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_INDEX_OUT_OF_RANGE></td>
 *      <td>aIndex is out of range</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetDiscreteEventOut</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetCarrierDiscreteEvent(M1553Handle aBoardHandle,
                                                 M1553TriggerModeType aMode,
                                                 uint32_t aIndex,
                                                 M1553BoardGetDiscreteEventOut* apGetDiscreteEventOut);


/**
 * @brief Modifies a discrete state. Only valid for output drivers.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @param[in] apSetDiscreteStateIn A pointer to an
 *  M1553BoardSetDiscreteStateIn input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_INDEX_OUT_OF_RANGE></td>
 *      <td>aIndex is out of range</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardSetDiscreteStateIn</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetDiscreteState(M1553Handle aBoardHandle,  
                                          uint32_t aIndex,
                                          M1553BoardSetDiscreteStateIn* apSetDiscreteStateIn);


/**
 * @brief Modifies the state of a discrete located on a carrier card. Only 
 *  valid for discretes on carrier cards that are configured as outputs.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aMode Select either a front panel or rear IO trigger line to
 *  configure. If this is a PMC or XMC device on a PXI carrier then there 
 *  are 10 front panel and 8 rear IO lines.
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @param[in] apSetDiscreteStateIn A pointer to an
 *  M1553BoardSetDiscreteStateIn input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_INDEX_OUT_OF_RANGE></td>
 *      <td>aIndex is out of range</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardSetDiscreteStateIn</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetCarrierDiscreteState(M1553Handle aBoardHandle,  
                                                 M1553TriggerModeType aMode,
                                                 uint32_t aIndex,
                                                 M1553BoardSetDiscreteStateIn* apSetDiscreteStateIn);

/**
 * @brief Retrieves the discrete state.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @param[in] apGetDiscreteStateOut A pointer to an
 *  M1553BoardGetDiscreteStateOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_INDEX_OUT_OF_RANGE></td>
 *      <td>aIndex is out of range</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetDiscreteStateOut</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetDiscreteState(M1553Handle aBoardHandle,  
                                          uint32_t aIndex,
                                          M1553BoardGetDiscreteStateOut* apGetDiscreteStateOut);

/**
 * @brief Retrieves the state of a discrete located on a carrier card.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aMode Select either a front panel or rear IO trigger line to
 *  configure. If this is a PMC or XMC device on a PXI carrier then there 
 *  are 10 front panel and 8 rear IO lines.
 * @param[in] aIndex The (0 indexed) digital IO line.
 * @param[in] apGetDiscreteStateOut A pointer to an
 *  M1553BoardGetDiscreteStateOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_INDEX_OUT_OF_RANGE></td>
 *      <td>aIndex is out of range</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetDiscreteStateOut</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetCarrierDiscreteState(M1553Handle aBoardHandle,  
                                                 M1553TriggerModeType aMode,
                                                 uint32_t aIndex,
                                                 M1553BoardGetDiscreteStateOut* apGetDiscreteStateOut);

/**
 * @brief Modifies all output discrete states.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] apSetAllDiscreteStatesIn A pointer to an 
 *  M1553BoardSetAllDiscreteStatesIn input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardSetAllDiscreteStatesIn</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetAllDiscreteStates(M1553Handle aBoardHandle,  
                                              M1553BoardSetAllDiscreteStatesIn* apSetAllDiscreteStatesIn);

/**
 * @brief Modifies all carrier device discrete (front panel or backplane, 
 *  but not both at once) output states.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aMode Select either a front panel or rear IO trigger line to
 *  configure. If this is a PMC or XMC device on a PXI carrier then there 
 *  are 10 front panel and 8 rear IO lines.
 * @param[in] apSetAllDiscreteStatesIn A pointer to an 
 *  M1553BoardSetAllDiscreteStatesIn input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardSetAllDiscreteStatesIn</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetAllCarrierDiscreteStates(M1553Handle aBoardHandle,  
                                                     M1553TriggerModeType aMode,
                                                     M1553BoardSetAllDiscreteStatesIn* apSetAllDiscreteStatesIn);

/**
 * @brief Reads the discrete state. 
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[out] apGetAllDiscreteStatesOut A pointer to an
 *  M1553BoardGetAllDiscreteStatesOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardSetAllDiscreteStatesIn</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetAllDiscreteStates(M1553Handle aBoardHandle,
                                              M1553BoardGetAllDiscreteStatesOut* apGetAllDiscreteStatesOut);

/**
 * @brief Reads the carrier device (front panel or backplane, but not both 
 *  at once) discrete states. 
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] aMode Select either a front panel or rear IO trigger line to
 *  configure. If this is a PMC or XMC device on a PXI carrier then there 
 *  are 10 front panel and 8 rear IO lines.
 * @param[out] apGetAllDiscreteStatesOut A pointer to an
 *  M1553BoardGetAllDiscreteStatesOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardSetAllDiscreteStatesIn</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetAllCarrierDiscreteStates(M1553Handle aBoardHandle,
                                                     M1553TriggerModeType aMode,
                                                     M1553BoardGetAllDiscreteStatesOut* apGetAllDiscreteStatesOut);

/**
 * @brief Defines the pulse length for input and output trigger 
 *  events. This determines the backplane trigger's output pulse for when this 
 *  IO line is used as a trigger pulse. For input lines this value can be used
 *  to filter out short events.  This is a board-wide setting (all triggers 
 *  on all channels).
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] apSetDiscretePulseLengthIn A pointer to an 
 *  M1553BoardSetDiscretePulseLengthIn input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardSetDiscretePulseLengthIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_OUT_OF_RANGE</td>
 *      <td>aInputPulseLength is out of range</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM2_OUT_OF_RANGE</td>
 *      <td>aOutputPulseLength is out of range</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetDiscretePulseLength(M1553Handle aBoardHandle, 
                                                const M1553BoardSetDiscretePulseLengthIn* apSetDiscretePulseLengthIn);

/**
 * @brief Retrieves the pulse length for input and output trigger 
 *  events. This is the backplane trigger's output pulse for when this 
 *  IO line is used as a trigger pulse. For input lines this value is the
 *  minimum length of time required after a rising edge for an event to remain
 *  active before it is considered a trigger pulse. This is a board-wide
 *  setting (all triggers on all channels).
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] apGetDiscretePulseLengthOut A pointer to an 
 *  M1553BoardGetDiscretePulseLengthOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetDiscretePulseLengthOut</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetDiscretePulseLength(M1553Handle aBoardHandle, 
                                                M1553BoardGetDiscretePulseLengthOut* apGetDiscretePulseLengthOut);
/**
 * @brief  This controls the pulse length for input and output events on the
 *  carrier card. This is only applicable if a supported carrier card is
 *  hosting the PMC or XMC board. The pulse length is controlled separately
 *  for front panel and rear IO. Additionally, the pulse length for front
 *  panel IO (which is directly connected to the hosted PMC/XMC front panel
 *  IO lines), is controlled separately on the PMC/XMC and the carrier.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] apSetDiscretePulseLengthIn A pointer to an 
 *  M1553BoardSetDiscretePulseLengthIn input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardSetDiscretePulseLengthIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_OUT_OF_RANGE</td>
 *      <td>aInputPulseLength is out of range</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM2_OUT_OF_RANGE</td>
 *      <td>aOutputPulseLength is out of range</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_CARRIER_NOT_PRESENT</td>
 *      <td>Backplane carrier card not present</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardSetCarrierDiscretePulseLength(M1553Handle aBoardHandle, 
                                                       const M1553BoardSetCarrierDiscretePulseLengthIn* apSetDiscretePulseLengthIn);
/**
 * @brief This retrieves the pulse length for input and output events on the
 *  carrier card. This is only applicable if a supported carrier card is
 *  hosting the PMC or XMC board. The pulse length is controlled separately
 *  for front panel and rear IO. Additionally, the pulse length for front
 *  panel IO (which is directly connected to the hosted PMC/XMC front panel
 *  IO lines), is controlled separately on the PMC/XMC and the carrier.
 * @param[in] aBoardHandle Board handle obtained by calling 
 *  m1553BoardOpen().
 * @param[in] apGetDiscretePulseLengthOut A pointer to an 
 *  M1553BoardGetDiscretePulseLengthOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#DEV_ERROR_INVALID_DEVICE</td>
 *      <td>Invalid Board Handle passed</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardGetDiscretePulseLengthOut</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_CARRIER_NOT_PRESENT</td>
 *      <td>Backplane carrier card not present</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553BoardGetCarrierDiscretePulseLength(M1553Handle aBoardHandle, 
                                                       M1553BoardGetCarrierDiscretePulseLengthOut* apGetDiscretePulseLengthOut);

/**
 * @brief Configure the PXI Star trigger. This function is used to define
 *  whether the PXI Star trigger is active high or active low. This 
 *  is necessary for configuring the star trigger to properly reset the
 *  IRIG clock when a PXI Star trigger event occurs.
 */
M1553_API_FUNC m1553BoardSetPXIStarTriggerConfig(M1553Handle aBoardHandle, 
                                                 M1553BoardSetPXIStarTriggerConfigIn* apPXIStarTriggerConfigIn);

/** @} */ /* End of Board discrete functions */

/** @} */ /* End of Board Status and Information Routines */

/** @} */ /* End of 1553Board group */

/**
 * @defgroup m1553Channel Channel Functions
 * @brief These are the 1553 Channel functions for executing built in tests, 
 *  resetting the hardware, setting the coupling and other channel related 
 *  functions.
 * @{
 */

/** 
 * @name 1553 Channel Configuration and Status Routines
 * @brief Description of the functions used to initialize the 1553 hardware.
 * @{
 */

/**
 * @brief This function is used to initialize the 1553 memory and register 
 *  space to its defaults.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[in] apResetIn A pointer to an M1553ChannelResetIn input structure
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelResetIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
 *      <td>mMode is invalid</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553ChannelReset(M1553Handle aChannelHandle, 
                                 const M1553ChannelResetIn* apResetIn);

/**
 * @brief Perform  Built-In Test. This function will run a built-in test on the 
 * specified 1553 channel board and will return results of the test. 
 * Upon running BIT, all setups and current activity will be lost for that channel
 * This function may take a very can take a long to execute based on the test selections.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[in] apBoardBITIn A pointer to the M1553BoardBITIn input 
 *  structure.
 * @param[in] apBoardBITOut A pointer to the M1553BoardBITOut output 
 *  structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardBITIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553BoardBITOut</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
 *      <td>M1553BITControl is invalid</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553ChannelBIT(M1553Handle aChannelHandle, 
                              const M1553BoardBITIn* apBoardBITIn,
                              M1553BoardBITOut* apBoardBITOut);

/**
 * @brief This function is used to define the response timeout value of the 
 *  simulation and bus monitor operations. The response timeout value is the 
 *  maximum time the bus controller will wait for a status word response 
 *  from a remote terminal. The response timeout value is set to a default 
 *  of 14 microseconds.
 * @param[in] aChannelHandle Board handle obtained by calling m1553Open()
 * @param[in] apSetResponseTimeoutIn A pointer to the 
 *  M1553ChannelSetResponseTimeoutIn input structure
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelSetResponseTimeoutIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_OUT_OF_RANGE</td>
 *      <td>mResponseTimeout is out of range</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
 *      <td>mResponseTimeout is invalid</td>
 *  </tr>
 * </table>
 * @sa m1553ChannelGetResponseTimeout()
 */
M1553_API_FUNC m1553ChannelSetResponseTimeout(M1553Handle aChannelHandle, 
                                              const M1553ChannelSetResponseTimeoutIn* apSetResponseTimeoutIn);

/**
 * @brief Get the Response Timeout value of the simulation and bus monitor 
 *  operations.
 * @param[in] aChannelHandle Board handle obtained by calling m1553Open()
 * @param[in] apGetResponseTimeoutOut A pointer to the M1553ChannelGetResponseTimeoutOut output structure
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelGetResponseTimeoutOut</td>
 *  </tr>
 * </table>
 * @sa m1553ChannelSetResponseTimeout()
 */
M1553_API_FUNC m1553ChannelGetResponseTimeout(M1553Handle aChannelHandle, 
                                              M1553ChannelGetResponseTimeoutOut* apGetResponseTimeoutOut);

/**
 * @brief Define the 1553 hardware protocol. This defines the way that an 
 *  RT will handle MilBus operations. The default is MIL-STD-1553B.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[in] apSetMilbusProtocolIn A pointer to an
 *  M1553ChannelSetMilbusProtocolIn input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelSetMilbusProtocolIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
 *      <td>mMilProtocol is invalid</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM2_INVALID</td>
 *      <td>mSetAllRTs is invalid</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_OUT_OF_RANGE</td>
 *      <td>mRT is out of range</td>
 *  </tr>
 * </table>
 * @sa m1553ChannelGetMilbusProtocol()
 */
M1553_API_FUNC m1553ChannelSetMilbusProtocol(M1553Handle aChannelHandle, 
                                             const M1553ChannelSetMilbusProtocolIn* apSetMilbusProtocolIn);

/**
 * @brief Get the 1553 hardware protocol.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[in] aRT The RT to retrieve the protocol for. Range: 0 - 31.
 * @param[out] apGetMilbusProtocolOut A pointer to an 
 *  M1553ChannelGetMilbusProtocolOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelGetMilbusProtocolOut</td>
 *  </tr>
 *  <tr>
 *      <td>#M1553_INVALID_RT</td>
 *      <td>aRT is out of range</td>
 *  </tr>
 * </table>
 * @sa m1553ChannelSetMilbusProtocol()
 */
M1553_API_FUNC m1553ChannelGetMilbusProtocol(M1553Handle aChannelHandle, 
                                             uint8_t aRT,
                                             M1553ChannelGetMilbusProtocolOut* apGetMilbusProtocolOut);
/**
 * @brief Define the channel's memory partition. This function is used to 
 *  configure the actual partitioning of the channel's memory structures.
 *  This defines how many buffers, buffer headers, and transfer ID's will
 *  be available when configuring BC and RT simulations. In most cases
 *  the default values will be acceptable (see m1553ChannelGetMemPartition()).
 *  
 *  The only values that are modified by this function are the memory partition sizes.
 *  The memory partition offsets cannot be modified. The offsets are assigned internally
 *  as the new partitions are being allocated.
 *  
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[in] apSetMemPartitionIn A pointer to the input structure 
 *  M1553ChannelSetMemPartitionIn
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelSetMemPartitionIn</td>
 *  </tr>
 * </table>
 * @sa m1553ChannelGetMemPartition()
 */
M1553_API_FUNC m1553ChannelSetMemPartition(M1553Handle aChannelHandle, 
                                           const M1553ChannelSetMemPartitionIn *apSetMemPartitionIn);

/**
 * @brief This function is used to return the actual partitioning of the 
 *  structures setup within the Board Global memory.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[out] apGetMemoryPartitionOut A pointer to an 
 *  M1553ChannelGetMemPartitionOut output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelGetMemPartitionOut</td>
 *  </tr>
 * </table>
 * @sa m1553ChannelSetMemPartition()
 */
M1553_API_FUNC m1553ChannelGetMemPartition(M1553Handle aChannelHandle, 
                                           M1553ChannelGetMemPartitionOut *apGetMemoryPartitionOut);

/** @} */ /* End Channel Configuration Routines */

/** 
 * @name 1553 Channel Coupling and Calibration Routines
 * @brief Description of the functions used to set up the coupling and 
 *  amplitude of the 1553 channel.   
 * @{
 */

/**
 * @brief This function is used to enable/disable the 1 MHz calibration 
 *  test signal on the selected channel.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[in] apSetTestSignalIn A pointer to an M1553ChannelSetTestSignalIn 
 *  input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelSetTestSignalIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
 *      <td>mBus is invalid</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM2_INVALID</td>
 *      <td>mEnabled is invalid</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553ChannelSetTestSignal(M1553Handle aChannelHandle, 
                                         const M1553ChannelSetTestSignalIn* apSetTestSignalIn);
/**
 * @brief Get the coupling mode. Retrieve the current electrical coupling 
 *  mode from the 1553 channel. Channel coupling must be correct before 
 *  the physical channels are connected electrically. Incorrect coupling
 *  configurations will prevent the channel from operating on the MilBus.
 * @depricated
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[out] apGetCouplingOut A pointer to an M1553ChannelGetCouplingOut 
 *  output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelGetCouplingOut</td>
 *  </tr>
 * </table>
 * @sa m1553ChannelSetCoupling()
 */
M1553_API_FUNC m1553ChannelGetCoupling(M1553Handle aChannelHandle, 
                                       M1553ChannelGetCouplingOut* apGetCouplingOut);

/**
 * @brief Get the coupling mode. Retrieve the current electrical coupling 
 *  mode from the 1553 channel. Channel coupling must be correct before 
 *  the physical channels are connected electrically. Incorrect coupling
 *  configurations will prevent the channel from operating on the MilBus.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[out] apGetCouplingOut A pointer to an M1553ChannelGetCouplingOut 
 *  output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelGetCouplingOut</td>
 *  </tr>
 * </table>
 * @sa m1553ChannelSetCoupling()
 */
M1553_API_FUNC m1553ChannelGetBusCoupling(M1553Handle aChannelHandle, 
                                       M1553ChannelGetCouplingOut* apGetCouplingAOut, M1553ChannelGetCouplingOut* apGetCouplingBOut);

/**
 * @brief @Depricated Set the coupling mode. Set the 1553 channel's electrical coupling 
 *  mode. Channel coupling must be correct before the physical channels 
 *  are connected electrically. Incorrect coupling configurations will 
 *  prevent the channel from operating on the MilBus.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[in] apSetCouplingIn A pointer to an input structure for m1553ChannelSetCoupling()
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelSetCouplingIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
 *      <td>mBusCoupling is invalid</td>
 *  </tr>
 * </table>
 * @sa m1553ChannelGetCoupling()
 */
M1553_API_FUNC m1553ChannelSetCoupling(M1553Handle aChannelHandle, 
                                       const M1553ChannelSetCouplingIn* apSetCouplingIn);
/**
 * @brief Set the coupling mode. Set the 1553 channel's electrical coupling 
 *  mode. Channel coupling must be correct before the physical channels 
 *  are connected electrically. Incorrect coupling configurations will 
 *  prevent the channel from operating on the MilBus.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[in] apSetCouplingIn A pointer to an input structure for m1553ChannelSetCoupling()
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelSetCouplingIn</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
 *      <td>mBusCoupling is invalid</td>
 *  </tr>
 * </table>
 * @sa m1553ChannelGetCoupling()
 */
M1553_API_FUNC m1553ChannelSetBusCoupling(M1553Handle aChannelHandle, 
                                       const M1553ChannelSetCouplingIn* apSetCouplingAIn,const M1553ChannelSetCouplingIn* apSetCouplingBIn);
/**
 * @brief Set the channel output amplitude. This function is used to set 
 *  the channel's transmitter output amplitude. The output amplitude can
 *  range from 0 - ~20 volts peak-to-peak when in transformer coupling
 *  mode. This function sets the amplitude in terms of percentage of the
 *  maximum. The maximum voltage depends on the coupling mode.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[in] apSetAmplitudeIn A pointer to an M1553ChannelSetAmplitudeIn
 *  input structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelSetAmplitudeIn</td>
 *  </tr>
 * </table>

 */
M1553_API_FUNC m1553ChannelSetAmplitude(M1553Handle aChannelHandle, 
                                        const M1553ChannelSetAmplitudeIn* apSetAmplitudeIn);
/**
 * @brief Get the channel output amplitude. This function is used to get 
 *  the channel's transmitter output amplitude. The output amplitude can
 *  range from 0 - ~20 volts peak-to-peak when in transformer coupling
 *  mode. This function gets the amplitude in terms of percentage of the
 *  maximum. The maximum voltage depends on the coupling mode.
 * @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
 * @param[out] apGetAmplitudeOut A pointer to an M1553ChannelGetAmplitudeOut 
 *  output structure.
 * @return @link error Error Code @endlink
 * <table>
 *  <tr>
 *      <th>Error</th>
 *      <th>Meaning</th>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_HANDLE_INVALID</td>
 *      <td>Invalid channel handle</td>
 *  </tr>
 *  <tr>
 *      <td>#API_ERROR_NULL_POINTER</td>
 *      <td>Null pointer error, M1553ChannelGetAmplitudeOut</td>
 *  </tr>
 * </table>
 */
M1553_API_FUNC m1553ChannelGetAmplitude(M1553Handle aChannelHandle, 
                                        M1553ChannelGetAmplitudeOut* apGetAmplitudeOut);
/**
* @brief Set the output baud rate.
* @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
* @param[in] apSetBitRateIn A pointer to an M1553ChannelSetBitRateIn input 
*  structure.
* @return @link error Error Code @endlink
* <table>
*  <tr>
*      <th>Error</th>
*      <th>Meaning</th>
*  </tr>
*  <tr>
*      <td>#API_ERROR_HANDLE_INVALID</td>
*      <td>Invalid channel handle</td>
*  </tr>
*  <tr>
*      <td>#API_ERROR_NULL_POINTER</td>
*      <td>Null pointer error, M1553ChannelSetBitRateIn</td>
*  </tr>
*  <tr>
*      <td>#API_ERROR_STRUCT_PARAM1_INVALID</td>
*      <td>mBitrate is invalid</td>
*  </tr>
* </table>
*/
M1553_API_FUNC m1553ChannelSetBitRate(M1553Handle aChannelHandle, 
                                      const M1553ChannelSetBitRateIn* apSetBitRateIn);
/**
* @brief Get the output baud rate.
* @param[in] aChannelHandle Channel handle obtained by calling m1553Open()
* @param[out] apGetBitRateOut A pointer to an M1553ChannelGetBitRateOut 
*  output structure.
* @return @link error Error Code @endlink
* <table>
*  <tr>
*      <th>Error</th>
*      <th>Meaning</th>
*  </tr>
*  <tr>
*      <td>#API_ERROR_HANDLE_INVALID</td>
*      <td>Invalid channel handle</td>
*  </tr>
*  <tr>
*      <td>#API_ERROR_NULL_POINTER</td>
*      <td>Null pointer error, M1553ChannelGetBitRateOut</td>
*  </tr>
* </table>
*/
M1553_API_FUNC m1553ChannelGetBitRate(M1553Handle aChannelHandle, 
                                      M1553ChannelGetBitRateOut* apGetBitRateOut);


/** @} */ /* End of Channel Coupling and Calibration Routines */

/** @} */ /* End of 1553Channel group */

#endif /* !M1553_SYSTEM_H */

