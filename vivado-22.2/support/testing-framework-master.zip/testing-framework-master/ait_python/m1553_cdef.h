/**
 * file m1553_cdef.h
 * brief C type definitions for MIL-STD-1553 API use
 *
 *  Created on: 7/9/2010
 *   
 *	- $HeadURL: http://ait-subversion/svn/Owl1553/OWL1553/tags/v3.0.2/C-Api/common/m1553_cdef.h $
 *	- $Date: 2016-04-15 10:06:43 -0500 (Fri, 15 Apr 2016) $
 *	- $Revision: 6289 $
 *	- $Author: stevet $
 *
 * Copyright (c) 2010 by Avionics Interface Technologies
 *  - Omaha, NE USA
 *  - Beavercreek, OH USA
 *  .
 * All rights reserved.  No part of this software may
 * be published, distributed, translated or otherwise
 * reproduced by any means or for any purpose without
 * the prior written consent of Avionics Interface Technologies. 
 */
#ifndef M1553_CDEF_H
#define M1553_CDEF_H

#if !defined(VXWORKS)
#include <stdint.h>
#endif

#if defined(VISA)
    #include "visa.h"
#endif

#ifdef _WIN32         /* MICROSOFT C */

	#define FuncStr			__FUNCTION__

	#ifdef __cplusplus
		/**
		* @brief API extern declarations for C++
		*/
		#define _M1553_EXTERN extern "C" __declspec( dllexport )
	#else /* __cplusplus */
		/**
		* @brief API extern declarations for C++
		*/
		#define _M1553_EXTERN __declspec( dllexport )
	#endif /* __cplusplus */


    #undef _WIN32_WINNT
	#define _WIN32_WINNT 0x0500

	#include "windows.h"
	/**
	 * @brief Our define declaring this to be the 32-bit Windows DLL
	 */
	#define _M1553_WINDOWS
	/**
	* @brief Prototype calling conventions for standard DLL functions
	*/
	#define _M1553_DLL_FUNC __cdecl
	/**
	* @brief Prototype calling conventions for interrupt service routine functions (event handlers)
	*/
	#define _M1553_ISR_FUNC __cdecl

	/**
	* @brief Define the endian of the host,  if it has not been defined by the compiler options already.
	*/
    #if !defined(HOST_ENDIAN_BIG)
    #  if !defined(HOST_ENDIAN_LITTLE)
	#    define HOST_ENDIAN_LITTLE
    #  endif
    #endif
	
	#define M1553_CALLBACK CALLBACK
	// clear attribute, used only for GNU compiler
	#define M1553_CALLBACK_ATTR 

#elif (defined( LINUX ) || defined(__linux__) || defined( PPC_API )) && defined( __GNUC__ ) /* GNU C/C++ compiler */
	#include <sys/types.h>
	
	#define FuncStr __FUNCTION__

	#ifdef __cplusplus
		/**
		* @brief API extern declarations for C++
		*/
		#define _M1553_EXTERN extern "C" __attribute__ ((visibility ("default")))
	#else /* __cplusplus */
		/**
		* @brief API extern declarations for C++
		*/
		#define _M1553_EXTERN __attribute__ ((visibility ("default")))
	#endif /* __cplusplus */

	/**
	* @brief Prototype calling conventions for standard DLL functions
	*/
	#define _M1553_DLL_FUNC 
	/**
	* @brief Prototype calling conventions for interrupt service routine functions (event handlers)
	*/
	#define _M1553_ISR_FUNC

	#define FALSE   0
	#define TRUE    1

	/**
	* @brief Define the endian of the host
	*/
	//#define HOST_ENDIAN_BIG
	/**
	* @brief Our replacement for this Windows HANDLE type
	*/
	#ifdef PPC_API
		typedef unsigned long HANDLE;
	#endif /* PPC_API	*/
	
	// clear definition of callback calling convention
	#define M1553_CALLBACK
	// set calling convention as GNUC attribute
	#define M1553_CALLBACK_ATTR __attribute__((cdecl))

#elif VXWORKS
	#include <vxWorks.h>
	#ifdef __cplusplus
		/**
		* @brief API extern declarations for C++
		*/
		#define _M1553_EXTERN extern "C"
	#else /* __cplusplus */
		/**
		* @brief API extern declarations for C++
		*/
		#define _M1553_EXTERN
	#endif /* __cplusplus */
	
	#define FuncStr			__FUNCTION__

	/**
	* @brief Prototype calling conventions for standard DLL functions
	*/
	#define _M1553_DLL_FUNC 
	/**
	* @brief Prototype calling conventions for interrupt service routine functions (event handlers)
	*/
	#define _M1553_ISR_FUNC
	/**
	* @brief Define the endian of the host, if it has not been defined by the compiler options already.
	*/
    #if !defined(HOST_ENDIAN_BIG)
    #  if !defined(HOST_ENDIAN_LITTLE)
	#    define HOST_ENDIAN_BIG
    #  endif
    #endif

	// clear definition of callback calling convention
	#define M1553_CALLBACK
	// set calling convention as GNUC attribute
	#define M1553_CALLBACK_ATTR 
	//#define M1553_CALLBACK_ATTR __attribute__((cdecl))
#elif defined(__QNX__)
	#include <sys/types.h>
	#define FuncStr __FUNCTION__

	#ifdef __cplusplus
		/**
		* @brief API extern declarations for C++
		*/
		#define _M1553_EXTERN extern "C" __attribute__ ((visibility ("default")))
	#else /* __cplusplus */
		/**
		* @brief API extern declarations for C++
		*/
		#define _M1553_EXTERN __attribute__ ((visibility ("default")))
	#endif /* __cplusplus */

	/**
	* @brief Prototype calling conventions for standard DLL functions
	*/
	#define _M1553_DLL_FUNC 
	/**
	* @brief Prototype calling conventions for interrupt service routine functions (event handlers)
	*/
	#define _M1553_ISR_FUNC

#if !defined(FALSE)
	#define FALSE 0
#endif

#if !defined(TRUE)
	#define TRUE 1
#endif

#if defined(__BIGENDIAN__)
	/**
	* @brief Define the endian of the host
	*/
	#define HOST_ENDIAN_BIG
#endif
	
	// clear definition of callback calling convention
	#define M1553_CALLBACK
	// set calling convention as GNUC attribute
	#define M1553_CALLBACK_ATTR __attribute__((cdecl))
//#else
//#error Unknown host platform!
#endif /* Platform/Compiler dependent definitions	*/

/***************************************/
/* DATA TYPES                          */
/***************************************/
#ifndef _API_RPC_HEADER

 /**
 * @brief Signed 32-bit integer type
 */
 typedef int             M1553Int;
 /**
 * @brief Unsigned 32-bit integer type
 */
 typedef unsigned int    M1553UInt;
 /**
 * @brief Character data type
 */
 typedef char            M1553Char;
 /**
 * @brief Unsigned character type
 */
 typedef unsigned char   M1553UChar;
 /**
 * @brief Double precision floating point type
 */
 typedef double          M1553Double;
 /**
  * @brief Single precision floating point type
  */
 typedef float           M1553Float;
 /**
  * @brief Address type
  */
 typedef void *          M1553Addr;
 /**
  * @brief Boolean flag (TRUE or FALSE) type
  */
 typedef unsigned char   M1553Boolean;
 /**
  * @brief Function return value
  */
 typedef int              M1553Return;
 /**
  * @brief Function handle value
  */
 typedef struct
 {
     /**
      * @brief The handle value.
      */
     void *value;
 } M1553Handle;

 typedef void *M1553_DEVICE_HANDLE;

#if defined(LINUX) || defined(__linux__) || defined(__QNX__)
#include <stdint.h>
#define CALLBACK
#else
	

#endif /* defined(LINUX) || defined(__linux__) */
#endif                  /* !_API_RPC_HEADER */
/**
* @brief Unsigned 32-bit integer function declaration return type
*/
//#define M1553_API_FUNC _M1553_EXTERN M1553Return  _M1553_DLL_FUNC
#define M1553_API_FUNC __attribute__ ((visibility ("default"))) int
#endif /* !M1553_CDEF_H */

