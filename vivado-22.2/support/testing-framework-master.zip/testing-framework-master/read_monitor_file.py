#!/usr/bin/env python3


from aim_mil.mil_bindings import *
import ctypes
import argparse

from string import Template

BMTEMPLATE = Template("$DDD:$HH:$MM:$SS.$us Ch-$Channel $Bus $RT $TR $SubAddr $Wordcount $RT2 $TR2 $SubAddr2 $Wordcount2 $Status $GapTime_nanosec $Status2 $GapTime2_nanosec $TransmitErrors $ReceiveErrors$DataWords")
#Note that each dataword will have a leading space, so no space is needed before $DataWords

VERBOSE = False

c_uint32 = ctypes.c_uint32

class Generic_bits(ctypes.LittleEndianStructure):
        _fields_ = [
                ("entry", c_uint32, 27),
                ("connection",c_uint32, 1),
                ("type",c_uint32,4)
                ]
        
class Time_Tag_Low_bits(ctypes.LittleEndianStructure):
        _fields_ = [
                ("microseconds", c_uint32, 20),
                ("seconds", c_uint32, 6),
                ("reserved", c_uint32, 1),              
                ("connection",c_uint32, 1),
                ("type",c_uint32,4)
                ]
        
class Time_Tag_High_bits(ctypes.LittleEndianStructure):
        _fields_ = [
                ("minutes", c_uint32, 6),               
                ("hours", c_uint32, 5),
                ("days", c_uint32, 9),
                ("reserved", c_uint32, 7),              
                ("connection",c_uint32, 1),
                ("type",c_uint32,4)
                ]
                
class Command_Word_bits(ctypes.LittleEndianStructure):
        _fields_ = [
                ("datalength_modecode", c_uint32, 5),
                ("SA", c_uint32, 5),    
                ("TR", c_uint32, 1),    
                ("RT", c_uint32, 5),                                                                    
                ("gap", c_uint32, 9),
                ("reserved", c_uint32, 1),
                ("starttrigger", c_uint32, 1),                          
                ("connection",c_uint32, 1),
                ("type",c_uint32,4)
                ]       
                                
class Status_Word_bits(ctypes.LittleEndianStructure):
        _fields_ = [
                ("terminalflag", c_uint32, 1),          
                ("dynamicbuscontrol", c_uint32, 1),             
                ("subsystemflag", c_uint32, 1),         
                ("busy", c_uint32, 1),          
                ("broadcastcommand", c_uint32, 1),              
                ("bwreserved", c_uint32, 3),            
                ("servicerequest", c_uint32, 1),                
                ("instrumentation", c_uint32, 1),               
                ("messageerror", c_uint32, 1),          
                ("RT", c_uint32, 5),            
                ("gap", c_uint32, 9),
                ("reserved", c_uint32, 1),
                ("starttrigger", c_uint32, 1),                          
                ("connection",c_uint32, 1),
                ("type",c_uint32,4)
                ]       
                                
class Data_Word_bits(ctypes.LittleEndianStructure):
        _fields_ = [
                ("data", c_uint32, 16),         
                ("gap", c_uint32, 9),
                ("reserved", c_uint32, 1),
                ("starttrigger", c_uint32, 1),                          
                ("connection",c_uint32, 1),
                ("type",c_uint32,4)
                ]       

class Error_Word_bits(ctypes.LittleEndianStructure):
        _fields_ = [
                ("terminal_no_resp", c_uint32, 1),              
                ("manchester_coding", c_uint32, 1),             
                ("high_bit_count", c_uint32, 1),                
                ("low_bit_count", c_uint32, 1),         
                ("parity", c_uint32, 1),                
                ("inverted_sync", c_uint32, 1),         
                ("interword_gap", c_uint32, 1),         
                ("transmission_both_channels", c_uint32, 1),            
                ("illegal_command_reserved_mode_code", c_uint32, 1),            
                ("early_response_gap_too_short", c_uint32, 1),          
                ("terminal_address_rt_rt_protocol", c_uint32, 1),               
                ("status_word_exception", c_uint32, 1),         
                ("high_word_count", c_uint32, 1),               
                ("low_word_count", c_uint32, 1),                
                ("alternate_bus_response", c_uint32, 1),                
                ("any_error", c_uint32, 1),                     
                ("receive_rt", c_uint32, 1),
                ("transmit_rt", c_uint32, 1),
                ("reserved", c_uint32, 8),
                ("starttrigger", c_uint32, 1),                          
                ("connection",c_uint32, 1),
                ("type",c_uint32,4)
                ]       
                                
class MonitorWord(ctypes.Union):
        _fields_ = [
                ("ew", Error_Word_bits),
                ("dw", Data_Word_bits),
                ("sw", Status_Word_bits),
                ("cw", Command_Word_bits),                              
                ("ttl", Time_Tag_Low_bits),
                ("tth", Time_Tag_High_bits),            
                ("g", Generic_bits),
                ("asword", c_uint32)
                ]


class BMdata:
        def __init__(self):
                self.datadict = dict()

                self.datadict['DD']='???'
                self.datadict['HH']='??'
                self.datadict['MM']='??'
                self.datadict['SS']='??'
                self.datadict['us']='?????'
                self.datadict['Channel']='?'
                self.datadict['Bus']='?'
                self.datadict['RT']='??'
                self.datadict['TR']='?'
                self.datadict['SubAddr']='??'
                self.datadict['Wordcount']='??'
                self.datadict['RT2']='??'
                self.datadict['TR2']='?'
                self.datadict['SubAddr2']='??'
                self.datadict['Wordcount2']='??'
                self.datadict['Status']='????'
                self.datadict['GapTime_nanosec']='????????'
                self.datadict['Status2']='????'
                self.datadict['GapTime2_nanosec']='????????'
                self.datadict['TransmitErrors']='None'
                self.datadict['ReceiveErrors']='None'
                self.datadict['DataWords']= ''
                #The following are pseudo-fields that capture the possibly
                #multiple statuses and gap-times.  These are put into the
                #proper status and gap-time entries before printing.
                self.datadict['Statuses']= []
                self.datadict['GapTimes_nanosec']= []



def handleArgs():
        global VERBOSE
        parser = argparse.ArgumentParser()

        parser.add_argument('-i', '--ifile', help='Input file that contains the raw bus monitor output from a busping run (default:/tmp/busping.rcd)', type=str, required=False, default="/tmp/busping.rcd")
        parser.add_argument('-o', '--ofile', help='Output file that will contain the processed bus monitor output.  If not provided, the output will go to stdout.', type=str, required=False)
        parser.add_argument('-v', '--verbose', help='Set verbose mode', action='store_true')

        args = parser.parse_args()


        if args.verbose:
                VERBOSE = True

        return args


def printwrapper(instring):
        if not VERBOSE:
                return

        print(instring)

        return

def setStatuses(bmdata):
        if bmdata.datadict['Statuses']:
                #For RT-RT, there will be two statuses, with status2 (corresponding to cmd word 2) being seen first
                if len(bmdata.datadict['Statuses']) == 1:
                        bmdata.datadict['Status'] = bmdata.datadict['Statuses'][0]
                        bmdata.datadict['GapTime_nanosec'] = bmdata.datadict['GapTimes_nanosec'][0]
                elif len(bmdata.datadict['Statuses']) == 2:
                        bmdata.datadict['Status2'] = bmdata.datadict['Statuses'][0]
                        bmdata.datadict['GapTime2_nanosec'] = bmdata.datadict['GapTimes_nanosec'][0]                                               
                        bmdata.datadict['Status'] = bmdata.datadict['Statuses'][1]
                        bmdata.datadict['GapTime_nanosec'] = bmdata.datadict['GapTimes_nanosec'][1]
                                                    
def setErrors(bmdata, ew, errorType):
        if not bmdata or not ew or not errorType:
                return
        accumulator = []
        
        if ew.terminal_no_resp:
                accumulator.append('Term_No_Response')
        if ew.manchester_coding:
                accumulator.append('Manchester_Err')             
        if ew.high_bit_count:
                accumulator.append('High_Bit_Count')                
        if ew.low_bit_count:
                accumulator.append('Low_Bit_Count')        
        if ew.parity:
                accumulator.append('Parity_Err')               
        if ew.inverted_sync:
                accumulator.append('Inverted_Sync')        
        if ew.interword_gap:
                accumulator.append('Interword_Gap_Err')        
        if ew.transmission_both_channels:
                accumulator.append('Tx_Both_Buses')            
        if ew.illegal_command_reserved_mode_code:
                accumulator.append('Cmd_Word_Err')           
        if ew.early_response_gap_too_short:
                accumulator.append('Early_Response')          
        if ew.terminal_address_rt_rt_protocol:
                accumulator.append('Term_Addr_Error')              
        if ew.status_word_exception:
                accumulator.append('Status_Error')       
        if ew.high_word_count:
                accumulator.append('High_Word_Count')               
        if ew.low_word_count:
                accumulator.append('Low_Word_Count')              
        if ew.alternate_bus_response:
                accumulator.append('Alt_Bus_Error')

        if len(accumulator):
              bmdata.datadict[errorType] = ":".join(accumulator)  


if __name__ == '__main__':


        args = handleArgs()

        
        ifile = open(args.ifile, "rb")  

        if args.ofile:
                ofile = open(args.ofile, "w")
        else:
                ofile = None

        oput = list()

        
        mw = MonitorWord()
        bmdata = None


        while True:
                monitorItem = ifile.read(4)
                printwrapper("monitorItem = {:032b}".format(int.from_bytes(monitorItem, byteorder='little')))

                if not monitorItem: #Termination condition. Print last record.
                        if bmdata:
                                setStatuses(bmdata)
                                record =  BMTEMPLATE.substitute(bmdata.datadict)
                                print("****" + record)
                                oput.append(record)
                                del bmdata
                        break
                
                mw.asword = int.from_bytes(monitorItem, byteorder='little')
                printwrapper("mw.g.type = {}".format(mw.g.type, "04b"))
                printwrapper("mw.g.connection = {}".format(mw.g.connection, "01b"))
                
                if mw.g.type == 0:
                        printwrapper("Entry Not Updated")
                elif mw.g.type == 1:
                        printwrapper("Have Error Word")
                        printwrapper("mw.ew.terminal_no_resp = {}".format(mw.ew.terminal_no_resp))
                        printwrapper("mw.ew.manchester_coding = {}".format(mw.ew.manchester_coding))
                        printwrapper("mw.ew.high_bit_count = {}".format(mw.ew.high_bit_count))
                        printwrapper("mw.ew.low_bit_count = {}".format(mw.ew.low_bit_count))                                                    
                        printwrapper("mw.ew.parity = {}".format(mw.ew.parity))                                                  
                        printwrapper("mw.ew.inverted_sync = {}".format(mw.ew.inverted_sync))                                                    
                        printwrapper("mw.ew.interword_gap = {}".format(mw.ew.interword_gap))                                                    
                        printwrapper("mw.ew.transmission_both_channels = {}".format(mw.ew.transmission_both_channels))                                                  
                        printwrapper("mw.ew.illegal_command_reserved_mode_code = {}".format(mw.ew.illegal_command_reserved_mode_code))                                                  
                        printwrapper("mw.ew.early_response_gap_too_short = {}".format(mw.ew.early_response_gap_too_short))                                                      
                        printwrapper("mw.ew.terminal_address_rt_rt_protocol = {}".format(mw.ew.terminal_address_rt_rt_protocol))                                                        
                        printwrapper("mw.ew.status_word_exception = {}".format(mw.ew.status_word_exception))                                                    
                        printwrapper("mw.ew.high_word_count = {}".format(mw.ew.high_word_count))                                                        
                        printwrapper("mw.ew.low_word_count = {}".format(mw.ew.low_word_count))                                                  
                        printwrapper("mw.ew.alternate_bus_response = {}".format(mw.ew.alternate_bus_response))                                                  
                        printwrapper("mw.ew.any_error = {}".format(mw.ew.any_error))                                                    
                        printwrapper("mw.ew.receive_rt = {}".format(mw.ew.receive_rt))                                                  
                        printwrapper("mw.ew.transmit_rt = {}".format(mw.ew.transmit_rt))                                                        
                        printwrapper("mw.ew.reserved = {}".format(mw.ew.reserved))                                                      
                        printwrapper("mw.ew.starttrigger = {}".format(mw.ew.starttrigger))
                        if mw.ew.transmit_rt:
                                setErrors(bmdata, mw.ew, 'TransmitErrors')
                        elif mw.ew.receive_rt:
                                setErrors(bmdata, mw.ew, 'ReceiveErrors')       
                elif mw.g.type == 2:

                        printwrapper("Have Time Tag Low Word")                          
                        printwrapper("mw.ttl.seconds = {}".format(mw.ttl.seconds))
                        printwrapper("mw.ttl.microseconds = {}".format(mw.ttl.microseconds))
                        if bmdata:
                                bmdata.datadict['SS']=str(mw.ttl.seconds)
                                bmdata.datadict['us']=str(mw.ttl.microseconds) 
                        else:
                          printwrapper("NO ACTIVE RECORD")
                elif mw.g.type == 3:
                        printwrapper("Have Time Tag High Word")
                        if bmdata:
                                setStatuses(bmdata)
                                record =  BMTEMPLATE.substitute(bmdata.datadict)
                                print("****" + record)
                                oput.append(record)
                                del bmdata
                        bmdata = BMdata()
                        printwrapper("mw.tth.days = {}".format(mw.tth.days))
                        printwrapper("mw.tth.hours = {}".format(mw.tth.hours))
                        printwrapper("mw.tth.minutes = {}".format(mw.tth.minutes))
                        if bmdata:
                          bmdata.datadict['DDD']=str(mw.tth.days)
                          bmdata.datadict['HH']=str(mw.tth.hours)
                          bmdata.datadict['MM']=str(mw.tth.minutes)
                        else:
                          printwrapper("NO ACTIVE RECORD")                          
                elif mw.g.type in [8,12]        :
                        printwrapper("Have Command Word")                               
                        printwrapper("mw.cw.datalength_modecode = {}".format(mw.cw.datalength_modecode))
                        printwrapper("mw.cw.SA = {}".format(mw.cw.SA))
                        printwrapper("mw.cw.TR = {}".format(mw.cw.TR))
                        printwrapper("mw.cw.RT = {}".format(mw.cw.RT))
                        printwrapper("mw.cw.gap = {}".format(mw.cw.gap))
                        printwrapper("mw.cw.reserved = {}".format(mw.cw.reserved))
                        printwrapper("mw.cw.starttrigger = {}".format(mw.cw.starttrigger))
                        if bmdata:
                          bmdata.datadict['RT']="{:0>2}".format(mw.cw.RT)
                          if str(mw.cw.TR) == '0':
                            bmdata.datadict['TR']='R'
                          else:
                            bmdata.datadict['TR']='T'                               
                          bmdata.datadict['SubAddr']="{:0>2}".format(mw.cw.SA)
                          bmdata.datadict['Wordcount']="{:0>2}".format(mw.cw.datalength_modecode)
                          if mw.g.type == 8:
                            bmdata.datadict['Bus']= 'A'
                          else:
                            bmdata.datadict['Bus']= 'B'
                        else:
                          printwrapper("NO ACTIVE RECORD")                                                         
                elif mw.g.type in [9,13]        :
                        printwrapper("Have Command Word")                               
                        printwrapper("mw.cw.datalength_modecode = {}".format(mw.cw.datalength_modecode))
                        printwrapper("mw.cw.SA = {}".format(mw.cw.SA))
                        printwrapper("mw.cw.TR = {}".format(mw.cw.TR))
                        printwrapper("mw.cw.RT = {}".format(mw.cw.RT))
                        printwrapper("mw.cw.gap = {}".format(mw.cw.gap))
                        printwrapper("mw.cw.reserved = {}".format(mw.cw.reserved))
                        printwrapper("mw.cw.starttrigger = {}".format(mw.cw.starttrigger))
                        if bmdata:
                          bmdata.datadict['RT2']=str(mw.cw.RT)
                          if str(mw.cw.TR) == '0':
                            bmdata.datadict['TR2']='R'
                          else:
                            bmdata.datadict['TR2']='T'                              
                          bmdata.datadict['SubAddr2']=str(mw.cw.SA)
                          bmdata.datadict['Wordcount2']=str(mw.cw.datalength_modecode)
                        else:
                          printwrapper("NO ACTIVE RECORD")                                              
                elif mw.g.type in [11,15]:
                        printwrapper("Have Status Word")
                        #Collect the status values into a two-byte value.
                        status = 0
                        status += int(mw.sw.terminalflag)
                        status += int(mw.sw.dynamicbuscontrol) << 1
                        status += int(mw.sw.subsystemflag) << 2
                        status += int(mw.sw.busy) << 3
                        status += int(mw.sw.broadcastcommand) << 4
                        status += int(mw.sw.bwreserved) << 5
                        status += int(mw.sw.servicerequest) << 8
                        status += int(mw.sw.instrumentation) << 9
                        status += int(mw.sw.messageerror) << 10
                        status += int(mw.sw.RT) << 11
                        if bmdata:
                          bmdata.datadict['Statuses'].append("{:04x}".format(status))
                          #The gap times are reported in units of .25 us, or 250 nsec.
                          bmdata.datadict['GapTimes_nanosec'].append("{:08}".format(int(mw.sw.gap)*250))
                        else:
                          printwrapper("NO ACTIVE RECORD")                        
                        printwrapper("mw.sw.terminalflag = {}".format(mw.sw.terminalflag))                                                                                                                                                                      
                        printwrapper("mw.sw.dynamicbuscontrol = {}".format(mw.sw.dynamicbuscontrol))                                                                                                                                                                    
                        printwrapper("mw.sw.subsystemflag = {}".format(mw.sw.subsystemflag))                                                                                                                                                                    
                        printwrapper("mw.sw.busy = {}".format(mw.sw.busy))                                                                                                                                                                      
                        printwrapper("mw.sw.broadcastcommand = {}".format(mw.sw.broadcastcommand))                                                                                                                                                                      
                        printwrapper("mw.sw.bwreserved = {}".format(mw.sw.bwreserved))                                                                                                                                                                  
                        printwrapper("mw.sw.servicerequest = {}".format(mw.sw.servicerequest))                                                                                                                                                                  
                        printwrapper("mw.sw.instrumentation = {}".format(mw.sw.instrumentation))                                                                                                                                                                        
                        printwrapper("mw.sw.messageerror = {}".format(mw.sw.messageerror))                                                                                                                                                                      
                        printwrapper("mw.sw.RT = {}".format(mw.sw.RT))                                                                                                                                                                  
                        printwrapper("mw.sw.gap = {}".format(mw.sw.gap))                                                                                                                                                                        
                        printwrapper("mw.sw.reserved = {}".format(mw.sw.reserved))                                                                                                                                                                      
                        printwrapper("mw.sw.starttrigger = {}".format(mw.sw.starttrigger))                                                                                                                                                                      
                elif mw.g.type in [10,14]:
                        printwrapper("Have Data Word")
                        printwrapper("mw.dw.data = {}".format(mw.dw.data))
                        if bmdata:
                          bmdata.datadict['DataWords'] += " {:04x}".format(int(mw.dw.data))
                        else:
                          printwrapper("NO ACTIVE RECORD")
                        printwrapper("mw.dw.gap = {}".format(mw.dw.gap))                                                                                                                                                                        
                        printwrapper("mw.dw.reserved = {}".format(mw.dw.reserved))                                                                                                                                                                      
                        printwrapper("mw.dw.starttrigger = {}".format(mw.dw.starttrigger))                                                                                                                                                                      

        ifile.close()

        if ofile:
                ofile.write('\n'.join(oput))
                ofile.close()

