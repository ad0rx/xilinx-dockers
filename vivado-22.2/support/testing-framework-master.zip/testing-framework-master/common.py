#!/usr/bin/env python3

import aim_mil.device
import aim_mil.event
from aim_mil.mil_bindings import *
import time
import argparse
import re
import random
import signal
from string import Template
from enum import Enum
import json


TEST_PATTERNS = [
  0x0000,
  0xffff,
  0x5555,
  0xaaaa,
  0xf0f0,
  0x0f0f,
  0x5a5a,
  0xa5a5,
  0x1000,
  0x0001,
  0x0100,
  0x0010,
  0x1100,
  0x0011,
  0x0110,
  0x1011,
  0x1101,
  0x1111,
  0xefff,
  0xfffe,
  0xfeff,
  0xffef,
  0xeeff,
  0xffee,
  0xfeef,
  0xefee,
  0xeefe,
  0xeeee
]

DEVICES={}
RT_INTERRUPT_HANDLES = dict()

STATUSES = {'BM':[], 'BC':[], 'RT':[]}
STATUSTEMPLATE = Template("$statustype\t\tDEVICETYPE:$devtype\t\tCHANNEL:$chan\t\tMESSAGES:$messages\t\tERRORS:$errors")

class Transfer(Enum):
  BCRT = 0
  BCBCAST = 1
  RTBC = 2
  RTRT = 3
  RTBCAST = 4
  MODE = 5
  MODE_BCAST = 6

class Direction(Enum):
  RECEIVE = 0
  TRANSMIT = 1

RT_RANGE = range(0,32) #AIM requires the establishment of broadcast RTs (31)
SUBADDR_RANGE = range(1,31)
LENGTH_RANGE = range(0,33) #0 implies 32 


MODES= {
	"DynamicBusControl": ('N',0b00000),
	"Synchronize": ('N',0b00001),
	"TransmitStatusWord": ('N',0b00010),
	"InitiateSelfTest": ('N',0b00011),
	"TransmitterShutdown": ('N',0b00100),
	"OverrideTransmitterShutdown": ('N',0b00101),
	"InhibitTerminalFlagBit": ('N',0b00110),
	"OverrideInhibitTerminalFlagBit": ('N',0b00111),
	"ResetRemoteTerminal": ('N',0b01000),
	"TransmitVectorWord": ('T',0b10000),
	"SynchronizeWithDataWord": ('R',0b10001),
	"TransmitLastCommandWord": ('T',0b10010),
	"TransmitBuiltInTestWord": ('T',0b10011),
	"SelectedTransmitterShutdown": ('R',0b10100),
	"OverrideSelectedTransmitterShutdown": ('R',0b10110)	
	}


BCAST_MODES = {
	"Synchronize": ('N',0b00001),
	"InitiateSelfTest": ('N',0b00011),
	"TransmitterShutdown": ('N',0b00100),
	"OverrideTransmitterShutdown": ('N',0b00101),
	"InhibitTerminalFlagBit": ('N',0b00110),
	"OverrideInhibitTerminalFlagBit": ('N',0b00111),
	"ResetRemoteTerminal": ('N',0b01000),
	"SynchronizeWithDataWord": ('R',0b10001),
	"SelectedTransmitterShutdown": ('R',0b10100),
	"OverrideSelectedTransmitterShutdown": ('R',0b10110)	
	}

done = False
NUM_FRAMES = 1	#How long to run
NUM_TRANSFERS = 0  #The number of xfers per frame will be calculated from the input
MINOR_FRAME_TIME = .001 #msec
TRANSFER_GAP_TIME = 16 #usec
TRANSFER_GAP_MODE = API_BC_GAP_MODE_STANDARD #0 = API_BC_GAP_MODE_DELAY for time from start of xfer to start of next; 
#1 = API_BC_GAP_MODE_STANDARD for time from end of xfer to start of next
RESPONSE_TIME = 4.0 #usec Must be at least 4.0
RESPONSE_TIMEOUT = 14.0 #usec
FAST_MODE = False

BM_OUTPUT_DIR = "/tmp"
BM_OUTPUT_FILE = "busping-D-C.bm"  #D will be filled in with the device type (AIM or AIT).  C will be filled in with the channel number for that device.
BM_BUFFER_SIZE = 10000

XMIT_AMPLITUDE = 255 #Range is 0 for 0% of maximum to 255 for 100% of maximum
XMIT_AMPLITUDE_CHAN = -1   # -1 for all channels or else a particular channel, starting at 1

STATUS_BITS = 0x0000 #Additional status bits to OR in with the status word
STATUS_BITS_RT = -1 #-1 for all RTs or else a particular RT number from 0-31

WANT_BBUS = False
REDUNDANT_BUS = False

WANT_EXTRA_BMS = True

SLEEP = 5000

WANT_MESSAGE_COUNTER = False

TEST_PATTERN_FILE = None

def checkStatus(observed):
  #First find the RT in the observed status word.  If it is 0, return
  RT = observed >> 11
  
  if STATUS_BITS_RT == RT or STATUS_BITS_RT == -1:
    statusbits = observed & 0x7FF
    #print("For status {:016b}, RT is {} statusbits is {:016b} input_status_bits is {:016b}".format(observed,RT,statusbits,common.STATUS_BITS))
    if statusbits == STATUS_BITS:
      return True
    else:
      return False
  else:
    return True
    
def  setTestPatterns():
  global TEST_PATTERNS
  if TEST_PATTERN_FILE:
    with open(TEST_PATTERN_FILE,'r')  as tp:
      data = json.load(tp)
      patterns = data.get('TestPatterns',None)
      if patterns:
        TEST_PATTERNS = [int(i,16) for i in patterns]
  print("TEST_PATTERNS = {}".format("TEST_PATTERNS"))
    
        
