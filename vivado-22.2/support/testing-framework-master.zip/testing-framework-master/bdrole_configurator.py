#!/usr/bin/env python3
#
# ++Copyright Peraton Labs GPR++
#
# Copyright (c) 2022 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton Labs GPR- -
#
# Engineer: SR
# Reviewer: TBD
# Description: Product simplified security and role configuration for scenarios on the command line
#
# Examples:
#
# * Non-redundant configuration, on (RBUS 0, NBUS/PORT 0, treated as "A"), with three RTs defined, but only two transfers
# $0 --roleports BC=30 --roleports RT1=0 --roleports RT2=30 --roleports RT3=2,3,30 'BCRT(3.5/2)' 'RTBC(2.2/3)'
# a

import argparse
import sys
import os, regex
from dataclasses import dataclass
from enum import Enum
from typing import Iterator, Dict, List, Any, Iterable, Set, Optional
import warnings
import bd_1553gen as b1g
import BDMCA_MemoryMapInt as MM


class Redundancy(Enum):
    """NBus Redundancy Identifier"""

    A = 0
    B = 1
    C = 2
    D = 3


class Roles(Enum):
    """Type of 1553 roles that exist"""

    RT0 = 0
    RT1 = 1
    RT2 = 2
    RT3 = 3
    RT4 = 4
    RT5 = 5
    RT6 = 6
    RT7 = 7
    RT8 = 8
    RT9 = 9
    RT10 = 10
    RT11 = 11
    RT12 = 12
    RT13 = 13
    RT14 = 14
    RT15 = 15
    RT16 = 16
    RT17 = 17
    RT18 = 18
    RT19 = 19
    RT20 = 20
    RT21 = 21
    RT22 = 22
    RT23 = 23
    RT24 = 24
    RT25 = 25
    RT26 = 26
    RT27 = 27
    RT28 = 28
    RT29 = 29
    RT30 = 30
    RT31 = 31
    BC = 32
    BM = 33


@dataclass
class PortAssignment:
    """For a role, which ports it might exist on"""

    role: Roles
    ports: Set[int]


@dataclass
class BDConfig:
    """All information about a specific Bus Defender configuration for an nbus"""

    transfers: List[b1g.ms1553_messageinfo]
    rolesports: List[PortAssignment]
    rbus_id: int
    nbus_ports: Dict[int, Set[int]]
    nbus_redundancy: Dict[int, Redundancy]
    subtransferid: int
    opportunityCount: int
    minorPerMajor: int
    pre_message_gap: int
    rt_response_delay: int
    bc_response_timeout: int


@dataclass
class BDVariable:
    """All information about a variable manipulation.  If value is None, the variable will be read."""

    regname: str
    variable: MM.BusDefenderMemoryMapInfo
    indices: Optional[List[int]] = None
    value: Optional[Any] = None

    def __init__(self, regname, indices=None, value=None):
        self.regname = regname
        self.variable = MM.BDMMI[regname]
        self.indices = indices
        self.value = value


def genconfig_symbolic(config: BDConfig):
    """Translate a configuration into variables that will instantiate that configuration"""

    variables = []  # type: List[BDVariable]
    local_bc = False
    local_bm = False
    local_rtx = {}  # type: Dict[int, b1g.ms1553_messageinfo]
    local_rtx_sa = {}  # type: Dict[int, Set[int]]
    local_rtsa = {}  # type: Dict[int, Set[int]]
    local_rtsa_bit = {}  # type: Dict[int, int]
    d = None  # type: Any

    # Mark start of security configuration
    v = "BD_I_SECURITY_CONFIGURATION_STATUS"
    d = 1  # MM.bd_securityconfiguration.bd_Security_InFlux.value
    variables.append(BDVariable(v, value=d))

    # For each NBUS, figure out the toplogy
    for nbus, redid in config.nbus_redundancy.items():
        nbusports = set(config.nbus_ports[nbus])
        bc_port_set = set()  # type: Set[int]
        bm_port_set = set()  # type: Set[int]
        rts = {}  # type: Dict[Roles, Set[int]]

        # Extract BC & BM ports, and hashify RTs
        for rp in config.rolesports:
            if 30 in rp.ports:
                nbusports.update(set((30,)))
            this_role_port = nbusports.intersection(rp.ports)

            if rp.role == Roles.BC:
                bc_port_set = this_role_port
                if 30 in rp.ports:
                    local_bc = True
            elif rp.role == Roles.BM:
                bm_port_set = this_role_port
                if 30 in rp.ports:
                    local_bm = True
            else:
                rts[rp.role] = this_role_port
                if 30 in rp.ports:
                    local_rtx[rp.role.value] = []
                    local_rtsa_bit[rp.role.value] = 0
                    local_rtsa[rp.role.value] = set()
                    local_rtx_sa[rp.role.value] = set()

        # Figure out if virtual ports are operating
        if 30 in nbusports:

            v = "BD_NTTC_NBUS_VIRTUAL_PORT_PRESENT"
            a = [nbus]
            d = 1
            variables.append(BDVariable(v, indices=a, value=d))

            v = "BD_NTTC_NBUS_ASSIGNED_VIRTUAL_PORT"
            a = [nbus]
            d = config.rbus_id * 4 + redid.value
            variables.append(BDVariable(v, indices=a, value=d))

        v = "BD_NTTC_NBUS_ALLOWED_PHYSICAL_PORTS"
        a = [nbus]
        d = sum([1 << i for i in nbusports.difference(set((30,)))])
        variables.append(BDVariable(v, indices=a, value=d))

        # For every RT, calculate the ports that traffic will come from or go to
        for rtn in range(0, 32):
            role = Roles(rtn)

            if role in rts:
                tf_ports = rts[role]
            else:
                tf_ports = set()
            rt_ports = tf_ports.union(bc_port_set).union(bm_port_set)

            v = "BD_SDCNSCUNSDT_NBUS_ROLE_PORTS_TRANSMIT_FROM"
            a = [rtn, nbus]
            d = sum([1 << i for i in tf_ports])
            variables.append(BDVariable(v, indices=a, value=d))

            v = "BD_SDCNSCUNSDT_NBUS_ROLE_PORTS_RECEIVE_TO"
            a = [rtn, nbus]
            d = sum([1 << i for i in rt_ports])
            variables.append(BDVariable(v, indices=a, value=d))

        # For the BC, calculate the ports that traffic will come from or go to
        rtn = 32
        v = "BD_SDCNSCUNSDT_NBUS_ROLE_PORTS_TRANSMIT_FROM"
        a = [rtn, config.rbus_id]
        d = sum([1 << i for i in bc_port_set])
        variables.append(BDVariable(v, indices=a, value=d))
        v = "BD_SDCNSCUNSDT_NBUS_ROLE_PORTS_RECEIVE_TO"
        a = [rtn, config.rbus_id]
        d = sum([1 << i for i in nbusports])
        variables.append(BDVariable(v, indices=a, value=d))

        def CmdToInt(rtaddr: int, tr: bool, subaddr: int, length: int = 0):
            """Convert for command word components to an int16--endianness may be an issue, but this corresponds to the structure defintion, so both might need to change"""
            return (rtaddr << 0) + (int(tr) << 5) + (subaddr << 6) + (length << 10)

        # Specify metadata rules for each transfer
        gdm = 0
        mdm = 0
        for xfer in config.transfers:
            if xfer.tr == 2:
                tr = False
            else:
                tr = xfer.tr

            CMD1 = CmdToInt(xfer.rtaddr1, tr, xfer.subaddr1, xfer.length)
            if xfer.rtaddr2 is not None:
                CMD2 = CmdToInt(xfer.rtaddr2, not tr, xfer.subaddr2)
            else:
                CMD2 = 0

            # Set the variables for this metadata rule
            v = "BD_SDCMMMMGMMR_NBUS_MD_MATCH_STATEMASK"
            a = [mdm % 128, mdm // 128, nbus]
            d = 0
            variables.append(BDVariable(v, indices=a, value=d))
            v = "BD_SDCMMMMGMMR_NBUS_MD_MATCH_STATECHECK"
            variables.append(BDVariable(v, indices=a, value=d))
            v = "BD_SDCMMMMGMMR_NBUS_MD_MATCH_AUX"
            variables.append(BDVariable(v, indices=a, value=d))
            v = "BD_SDCMMMMGMMR_NBUS_MD_MATCH_COMMAND1"
            d = CMD1
            variables.append(BDVariable(v, indices=a, value=d))
            v = "BD_SDCMMMMGMMR_NBUS_MD_MATCH_COMMAND2"
            d = CMD2
            variables.append(BDVariable(v, indices=a, value=d))
            v = "BD_SDCMMMMGMMR_NBUS_MD_MATCH_COMMAND2_PRESENT"
            d = xfer.rtaddr2 is not None
            variables.append(BDVariable(v, indices=a, value=d))

            mdm += 1

            # If this is a local RT, remember the relevant subaddress, and for transmitters, the transmission
            if xfer.rtaddr1 in local_rtsa:
                local_rtsa[xfer.rtaddr1].add(xfer.subaddr1)
                local_rtsa_bit[xfer.rtaddr1] |= 1 << xfer.subaddr1
                if tr:
                    local_rtx_sa[xfer.rtaddr1].add(xfer.subaddr1)
                    local_rtx[xfer.rtaddr1].append(xfer)
            if xfer.rtaddr2 in local_rtsa:
                local_rtsa[xfer.rtaddr2].add(xfer.subaddr2)
                local_rtsa_bit[xfer.rtaddr2] |= 1 << xfer.subaddr2
                if not tr:
                    local_rtx_sa[xfer.rtaddr2].add(xfer.subaddr2)
                    local_rtx[xfer.rtaddr2].append(xfer)

        # Specify meta-security information
        v = "BD_NRNSC_NBUS_RBUS_ID"
        a = [nbus]
        d = config.rbus_id
        variables.append(BDVariable(v, indices=a, value=d))
        v = "BD_NRNSC_NBUS_METADATA_ACTION"
        d = 0  # MM.bd_Action.bd_PERMIT.value
        variables.append(BDVariable(v, indices=a, value=d))
        v = "BD_NRNSC_NBUS_NUMBER_OF_METADATA_RULES"
        d = mdm
        variables.append(BDVariable(v, indices=a, value=d))
        v = "BD_NRNSC_NBUS_NUMBER_OF_GENERIC_RULES"
        d = gdm
        variables.append(BDVariable(v, indices=a, value=d))

    v = "BD_I_SECURITY_CONFIGURATION_COUNTER"
    d = 1
    variables.append(BDVariable(v, value=d))

    # Mark end of security configuration
    v = "BD_I_SECURITY_CONFIGURATION_STATUS"
    d = 2  # MM.bd_securityconfiguration.bd_Security_Configured.value
    variables.append(BDVariable(v, value=d))

    v = "BD_IPRRC_RBUS_RT_RESPONSE_DELAY"
    variables.append(BDVariable(v, indices=[config.rbus_id], value=config.rt_response_delay))

    v = "BD_GGRC_BUS_MONITOR_ASSUMED_BC_TIMEOUT"
    variables.append(BDVariable(v, value=config.bc_response_timeout))

    # Configure RBUS slots for local RTs that transmit data
    for rt in local_rtx_sa:
        # Set slots
        for xfer in local_rtx[rt]:
            v = "BD_GMCS_MICROCODE_DATA"
            d = f"(struct bd_gs_storage_slot){{.bd_gsss_data_word={xfer.datalist}}}"
            variables.append(BDVariable(v, value=d))
            v = "BD_GMCS_MICROCODE_RBUS_ID"
            d = config.rbus_id
            variables.append(BDVariable(v, value=d))
            v = "BD_GMCS_MICROCODE_SLOT_PRIMARY_ADDRESS"
            d = rt
            variables.append(BDVariable(v, value=d))

            v = "BD_GMCS_MICROCODE_SLOT_SECONDARY_ADDRESS"
            if rt == xfer.rtaddr1:
                d = xfer.subaddr1
            else:
                d = xfer.subaddr2
            variables.append(BDVariable(v, value=d))

            v = "BD_GMCS_MICROCODE_COMMAND"
            d = 5  # MM.bd_Microcode_Commands.bd_Set_Live_RT_Transmit_Slot_by_RBus_RT_and_SA.value
            variables.append(BDVariable(v, value=d))

            # Submit command/read generated ID
            v = "BD_GMCS_MICROCODE_COMMAND_ID"
            variables.append(BDVariable(v))

            # Turn on RT, and activate subaddresses
            v = "BD_IPRRC_RBUS_RTSA_ENABLED"
            a = [rt, config.rbus_id]
            d = local_rtsa_bit[rt]
            variables.append(BDVariable(v, indices=a, value=d))

    def write_transfer(config: BDConfig, numslots: int, transferid: int):
        nonlocal variables
        d = None  # type: Any
        # Construct transfer management structure for these transfer
        v = "BD_GMCS_MICROCODE_DATA"
        d = f"(struct bd_gs_frametransfers){{.bd_gsf_repeats_per_major_frame={config.minorPerMajor}, .bd_gsf_transmission_opportunity_count={config.opportunityCount}, .bd_gsf_number_slot={numslots}, .bd_gsf_pre_message_gap={config.pre_message_gap}}}"
        variables.append(BDVariable(v, value=d))
        v = "BD_GMCS_MICROCODE_RBUS_ID"
        d = config.rbus_id
        variables.append(BDVariable(v, value=d))
        v = "BD_GMCS_MICROCODE_TRANSFER_KEY"
        d = transferid
        variables.append(BDVariable(v, value=d))
        v = "BD_GMCS_MICROCODE_COMMAND"
        d = 9  # MM.bd_Microcode_Commands.bd_Set_BC_Transfer_by_RBus_TransferID.value
        variables.append(BDVariable(v, value=d))

        # Submit command/read generated ID
        v = "BD_GMCS_MICROCODE_COMMAND_ID"
        variables.append(BDVariable(v))

    # Configure local BM (if any)
    if local_bm:
        v = "BD_IPRRC_RBUS_BM_ENABLED"
        d = 1
        variables.append(BDVariable(v, value=d))

    # Configure local BC (if any)
    if local_bc:
        v = "BD_IPRBC_RBUS_BC_RESPONSE_TIMEOUT"
        variables.append(BDVariable(v, indices=[config.rbus_id], value=config.bc_response_timeout))

        slotcnt = 0
        transferid = config.subtransferid
        for xfer in config.transfers:

            # Figure out the words
            CMD1 = CmdToInt(xfer.rtaddr1, tr, xfer.subaddr1, xfer.length)
            if xfer.rtaddr2 is not None:
                CMD2 = CmdToInt(xfer.rtaddr2, not tr, xfer.subaddr2)

            # Construct storage slot for this transfer
            d = f"(struct bd_gs_storage_slot){{.bd_gsss_command1_present=1, .bd_gsss_data_length={xfer.datalen}"
            d += f", .bd_gsss_command1=0x{CMD1:x}"
            if xfer.rtaddr2 is not None:
                d += f", .bd_gsss_command2_present=1, .bd_gsss_command2=0x{CMD2:x}"
            elif xfer.bcxmitd:
                d += f", .bd_gsss_data_word={[f'0x{x:x}' for x in xfer.datalist]}"
            d += f"}}"

            v = "BD_GMCS_MICROCODE_DATA"
            variables.append(BDVariable(v, value=d))
            v = "BD_GMCS_MICROCODE_RBUS_ID"
            d = config.rbus_id
            variables.append(BDVariable(v, value=d))
            v = "BD_GMCS_MICROCODE_SLOT_PRIMARY_ADDRESS"
            d = transferid
            variables.append(BDVariable(v, value=d))
            v = "BD_GMCS_MICROCODE_SLOT_SECONDARY_ADDRESS"
            d = slotcnt
            variables.append(BDVariable(v, value=d))
            v = "BD_GMCS_MICROCODE_COMMAND"
            d = 7  # MM.bd_Microcode_Commands.bd_Set_Live_BC_Slot_by_RBus_TransferID_and_SubSlot.value
            variables.append(BDVariable(v, value=d))

            # Submit command/read generated ID
            v = "BD_GMCS_MICROCODE_COMMAND_ID"
            variables.append(BDVariable(v))

            slotcnt += 1
            if slotcnt >= 32:
                write_transfer(config, slotcnt, transferid)
                slotcnt = 0
                transferid += 1

        write_transfer(config, slotcnt, transferid)

        # Turn on BC

        v = "BD_GMCS_MICROCODE_TRANSFER_BC_ENABLED"
        d = 1
        variables.append(BDVariable(v, value=d))

        v = "BD_GMCS_MICROCODE_RBUS_ID"
        d = config.rbus_id
        variables.append(BDVariable(v, value=d))

        v = "BD_GMCS_MICROCODE_COMMAND"
        d = 14  # MM.bd_Microcode_Commands.bd_Activate_BC_Enable_Selected_Major_Frame_and_Major_Frame_Duration_by_RBus.value
        variables.append(BDVariable(v, value=d))

        v = "BD_GMCS_MICROCODE_TRANSFER_MAJOR_FRAME"
        d = 0
        variables.append(BDVariable(v, value=d))

        v = "BD_GMCS_MICROCODE_TRANSFER_MAJOR_FRAME_DURATION"
        d = 1000
        variables.append(BDVariable(v, value=d))

        # Submit command/read generated ID
        v = "BD_GMCS_MICROCODE_COMMAND_ID"
        variables.append(BDVariable(v))

    return variables


def dump_variables(variables):
    for V in variables:
        if V.value is not None:
            d = V.value
            if isinstance(d, bool):
                d = int(d)
            elif isinstance(d, int):
                if d >= 10:
                    d = f"0x{d:x}"
            print(f"write({V.regname}, {V.variable.cname}, {V.indices}, {d})")
        else:
            print(f"read({V.regname}, {V.variable.cname},{V.indices})")


def main(defaultargs):
    global args
    parser = argparse.ArgumentParser()
    parser.add_argument("--bc-response-timeout", default=13, type=float, help="The number of ųs of bus-idle (2ųs smaller than 1553) time between the end of the previous transmission and the next BC message. 1553A minimum: 9 ųs, 1553B/C minimum: 10ųs. Legal range from 2-32767.5 in .5 ų steps.", metavar="ųs")
    parser.add_argument("--minorPerMajor", default=1, type=int, help="Specify how many times per major frame duration, this minor frame will execute")
    parser.add_argument("--nbusports", action="append", type=lambda x: x.split("=", 1), help="Specify the NBUS (a unique number from 0-11 reflecting the concept of all 1553 devices attached to the same conceptual cable), and the physical ports attached to it.", metavar="nbusid=port[,ports]")
    parser.add_argument("--opportunityCount", default=0, type=int, help="How many times the minor frame will transmit (if a repeating minor frame)")
    parser.add_argument("--pre-message-gap", default=8, type=float, help="The number of ųs of bus-idle (2ųs smaller than 1553) time between the end of the previous transmission and the next BC message. Legal range from 2-32767.5 in .5 ų steps.", metavar="ųs")
    parser.add_argument("--rbus", default=0, type=int, help="Specify which rbus id this configuration applies to")
    parser.add_argument("--roleports", action="append", type=lambda x: x.split("=", 1), help="Specify the port(s) a specific 1553 role exist on.  Roles include 'BC', 'BM', and 'RT#' where # is a number between 0 and 31.", metavar="role=port[,ports]")
    parser.add_argument("--rt-response-delay", default=65, type=float, help="The number of ųs of bus-idle time (2ųs smaller than 1553) between the end of the previous transmission and the next BC message. Legal range from 2-10 (7 for 1553A) in .1 ųs steps.", metavar="ųs")
    parser.add_argument("--subtransferid", default=0, type=int, help="Specify which (sub)transfer id this configuration applies to")
    parser.add_argument("xfercmds", default=[], nargs="*", help="Example 1553 transfer patterns like: BCRT(1.2/4)")
    if defaultargs:
        parser.set_defaults(**defaultargs)
    args = parser.parse_args()
    roleports = []

    if args.roleports is None or len(args.roleports) < 1:
        raise ValueError("Must have --roleports arguments for all 1553 roles is use (BC, RTs, BM)")

    # Normalize the specified roles and ports
    allports = set()
    for role, port_str in args.roleports:
        ports = set(map(lambda x: int(x.lstrip().rstrip(), 0), port_str.split(",")))
        allports.update(set(ports))
        roleports.append(PortAssignment(Roles[role.upper()], ports))

    if args.nbusports is None or len(args.nbusports) < 1:
        args.nbusports = {0: allports}
    else:
        # Normalize the specified nbus and ports
        args.nbusports = dict(map(lambda x: (int(x[0].lstrip().rstrip(), 0), set(map(lambda y: int(y, 0), x[1].split(",")))), args.nbusports))

    # generate the A/B/C/D redundancy entries
    args.nbus_redundancy_id = {}
    x = "A"
    for f in sorted(args.nbusports):
        args.nbus_redundancy_id[f] = Redundancy[x]
        x = chr(ord(x) + 1)

    if not any([x.role == Roles.BC for x in roleports]):
        warnings.warn("Missing Bus Controller Role, good things unlikely to happen")

    # Normalize the user specified transfers
    xfers = [b1g.ms1553_messageinfo(t) for t in args.xfercmds]

    configState = BDConfig(
        xfers,
        roleports,
        rbus_id=args.rbus,
        nbus_ports=args.nbusports,
        nbus_redundancy=args.nbus_redundancy_id,
        subtransferid=args.subtransferid,
        opportunityCount=args.opportunityCount,
        minorPerMajor=args.minorPerMajor,
        pre_message_gap=int(args.pre_message_gap * 2),
        rt_response_delay=int(args.rt_response_delay * 10),
        bc_response_timeout=int(args.bc_response_timeout * 10),
    )

    return genconfig_symbolic(configState), args.xfercmds  # Returns variables,transfers


"""
This function will be called from the coco test harness.
If the BDROLE_CONFIG env var is set, that file will be used, and cfgfile will be ignored.
If it is not set, and a cfgfile is provided as an argument, that file will be used.
Else, if the env var is not set, and no file is provided, the default bdrole_cfg.txt, in the directory where the calling program is run, will be used.
"""


def get_axi_read_write_data(cfgfile="bdrole_cfg.txt"):
    rolecfg = os.getenv("BDROLE_CONFIG", cfgfile)

    argsfile = {}  # type: Dict[str, Any]
    with open(rolecfg, "r") as R:
        for line in R:
            line = line.strip()
            if regex.match(r"\s*(#.*|)$", line):
                continue
            m = regex.match(r"--(\w+?)=(.+)", line)
            if m:
                key, value = m.group(1, 2)
                if key in ("roleports", "nbusports"):
                    if key not in argsfile:
                        argsfile[key] = []
                    argsfile[key].append(value.split("=", 1))
                else:
                    argsfile[key] = int(value)
            else:
                if "=" in line or "(" not in line:
                    raise ValueError(" {}  is not a valid configuration line (--foo=bar or BCRT(1.1/1) or whatever)".format(line))
                if "xfercmds" not in argsfile:
                    argsfile["xfercmds"] = []
                argsfile["xfercmds"].append(line)
    # The arguments are parsed from the file.  Now process them.
    v, xfers = main(argsfile)  # Get variables, transfers
    # Get the information from these variables that is needed to form the axi reads and writes
    axi_read_write_data = get_rw_data(v)
    return axi_read_write_data, xfers


def get_rw_data(variables):
    rw_data = []

    for v in variables:
        rw_data.append((v.regname, v.indices, v.value))

    return rw_data


if __name__ == "__main__":
    argsfile = {}  # type: Dict[str, Any]
    if os.getenv("BDROLE_CONFIG"):
        with open(str(os.getenv("BDROLE_CONFIG")), "r") as R:
            for line in R:
                line = line.strip()
                if regex.match(r"\s*(#.*|)$", line):
                    continue
                m = regex.match(r"--(\w+)=(.+)", line)
                if m:
                    key, value = m.group(1, 2)
                    if key in ("roleports", "nbusports"):
                        if key not in argsfile:
                            argsfile[key] = []
                        argsfile[key].append(value.split("=", 1))
                    else:
                        argsfile[key] = int(value)
                else:
                    if "=" in line or "(" not in line:
                        raise ValueError("Not a valid configuration line (--foo=bar or BCRT(1.1/1) or whatever)")
                    if "xfercmds" not in argsfile:
                        argsfile["xfercmds"] = []
                    argsfile["xfercmds"].append(line)
    v, xfers = main(argsfile)
    dump_variables(v)

# Local Variables:
# blacken-line-length: 320
# eval: (blacken-mode 't)
# End:
