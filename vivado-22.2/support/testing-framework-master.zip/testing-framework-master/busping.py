#!/usr/bin/env python3

import time
import argparse
import re
import random
import signal
import common
import sys
import select
import aim_testharness as AIM_TH
import ait_testharness as AIT_TH


CONTENTSPEC = '(?P<content>\[(\*ZEROES|\*ONES|\*RANDOM|\*T\d+|(\s*\S+(\s*\,\s*\S+){0,31}\s*))?\])'
LOCATIONSPEC = '(?P<location>\@(aim|ait)\d+)'
DATAWORDSPEC = '(?P<dataword>\[\s*[^\s\,]+\s*\])'

DEVICE = re.compile("\((?P<name>\S+?)\s*/\s*(?P<devtype>(AIM|AIT))(\s*/\s*(?P<nickname>\S+))?\)")

RTNUM = ''
RT = re.compile("RT(?P<rtnum>[1-3]?[0-9])\@(?P<devname>\S+?)/(?P<channum>[1-8])")

BC = re.compile("BC\@(?P<devname>\S+?)/(?P<channum>[1-8])")

# BCRT1(R.S/L) Command and data words for Bus Controller to RT pattern
# BCRT2(R.S/L) Status word from destination RT of message
BCRT = re.compile("(?P<xfertype>BCRT)(?P<id>[1-2]?)\((?P<rt>[1-3]?[0-9])\.(?P<subaddr>[1-3]?[0-9])\/(?P<length>[1-3]?[0-9])\){content}?".format(content=CONTENTSPEC))

# BCBCAST1(.S/L) Command and data words for Bus Controller to all RTs pattern
BCBCAST = re.compile("(?P<xfertype>BCBCAST)(?P<id>1?)\(\.(?P<subaddr>[1-3]?[0-9])\/(?P<length>[1-2]?[0-9])\){content}?".format(content=CONTENTSPEC))

# RTBC1(R.S/L) Command word for RT to Bus Controller pattern
# RTBC2(R.S/L) Status and data words for RT to Bus Controller pattern
RTBC = re.compile("(?P<xfertype>RTBC)(?P<id>[1-2]?)\((?P<rt>[1-3]?[0-9])\.(?P<subaddr>[1-3]?[0-9])\/(?P<length>[1-3]?[0-9])\){content}?".format(content=CONTENTSPEC))

# RTRT1(R1.S1/L,R2.S2) Command word for RT2 to RT1 pattern
# RTRT2(R1.S1/L,R2.S2) Status and data words from RT2 for RT2 to RT1 pattern
# RTRT3(R1.S1/L,R2.S2) Status from RT1 for RT2 to RT1 pattern
RTRT = re.compile("(?P<xfertype>RTRT)(?P<id>[1-3]?)\((?P<rt1>[1-3]?[0-9])\.(?P<subaddr1>[1-3]?[0-9])\/(?P<length>[1-3]?[0-9])\,(?P<rt2>[1-3]?[0-9])\.(?P<subaddr2>[1-3]?[0-9])\){content}?".format(content=CONTENTSPEC))

# RTBCAST1(.S1/L,R2.S2) Command word for RT2 to all RTs pattern
# RTBCAST2(.S1/L,R2.S2) Status and data words from RT2 for RT2 to all RTs pattern
RTBCAST = re.compile("(?P<xfertype>RTBCAST)(?P<id>[1-2]?)\(\.(?P<subaddr1>[1-3]?[0-9])\/(?P<length>[1-3]?[0-9])\,(?P<rt2>[1-3]?[0-9])\.(?P<subaddr2>[1-3]?[0-9])\){content}?".format(content=CONTENTSPEC))

# MODE1(R,C) Send a mode code (optional data)
# MODE2(R,C) Respond to a mode code (w/optional data)

MODEKEYS = "|".join(common.MODES.keys())
MODESPEC = "{}".format(MODEKEYS)
mode_match_string = "(?P<xfertype>MODE)(?P<id>[1-2]?)\((?P<rt>[1-3]?[0-9])\,(?P<mode>({mode}))\){dataword}?".format(mode=MODESPEC, dataword=DATAWORDSPEC)
# print ("!!! mode_match_string = {}".format(mode_match_string))
MODE = re.compile(mode_match_string)

BCAST_MODEKEYS = "|".join(common.BCAST_MODES.keys())
BCAST_MODESPEC = "{}".format(BCAST_MODEKEYS)  

# MODE_BCAST1(C)
mode_bcast_match_string = "(?P<xfertype>MODE_BCAST)(?P<id>1?)\((?P<mode>({mode}))\){dataword}?".format(mode=BCAST_MODESPEC, dataword=DATAWORDSPEC)
# print ("!!! mode_bcast_match_string = {}".format(mode_bcast_match_string))
MODE_BCAST = re.compile(mode_bcast_match_string)

args = None
xfers = []

random.seed("busping")

DEVICES = common.DEVICES
NICKNAMES2DEVICES = {}
RTS = {}
BROADCAST_RTS = {}  # AIM Devices require RT 31 to be set up as a receiver on each
# channel that has RTs
XFERS = []
BC_INPUT = None
devtypes = []

RTSA = {}  

def handleArgs():

  parser = argparse.ArgumentParser()

  parser.add_argument('-x', '--xfers', help='xfers: string containing space-separated transfers', type=str, required=True)
  parser.add_argument('-d', '--devs', help='devs: string containing comma-separated devices', type=str, required=True)
  parser.add_argument('-r', '--rts', help='rts: string containing comma-separated rts', type=str, required=True)
  parser.add_argument('-b', '--bc', help='bc: bus controller information', type=str, required=False)
  parser.add_argument('-c', '--configfile', help='configfile: string containing the name of the json config file that contains device and rt info.\n  Device and RT data entered on the command line overwrites those entries from the config file.', type=str, required=False)
  parser.add_argument('-f', '--fast', help='Sets fast mode.  Does not do stream self-test in fast mode.', action='store_true')
  parser.add_argument('-s', '--sleep', help='The amount of time (msec) to sleep before program termination, if number of frames is indefinite (default=5000)', type=int, default=5000)  
  parser.add_argument('--numframes', help='How many frames to send(default 0 means run forever)', type=int, default=0)
  parser.add_argument('--frametime', help='Min length of minor frame, in msec (Default=.001, possibly overridden to a min of 25.0 if message counters are used)', type=float, default=.001)
  parser.add_argument('--gapmode', help='When set to 0(API_BC_GAP_MODE_DELAY) the gap is the time from the start of one transfer to the start of the next. When set to 1(API_BC_GAP_MODE_STANDARD), the gap is the time from the end of one transfer to the start of the next', 
                      type=int, choices=[0,1],default=0)
  parser.add_argument('--gaptime', help='Min gap between transfers (meaning depends on gap mode) and start of the next, range 0-16383 usec (Default=0)', type=int, default=0)
  parser.add_argument('--responsetime', help='RT response time (4.0-63.72us, in steps of .25 us) (default= 4.0us)', type=float, default=4.0)
  parser.add_argument('--responsetimeout', help='Max time that the BC will wait for an RT response (0.0-63.75, in steps of .25 us) Ideally, the response timeout is at least 2 us greater than the response time.  (Default=6.0)  ', type=float, default=6.0)
  parser.add_argument('--xmitamplitude', help='amplitude percentage of max (0 [0 pct] to 255 [100 pct]) (default=128)', type=int, default=128)
  parser.add_argument('--xmitamplitudechan', help='channel for which the amplitude is being set, or -1 for all channels (default=-1)', type=int, default=-1)
  parser.add_argument('--statusbits', help='Additional status bits to OR in with the status word (default=0x0000)', type=int, default=0x0000)
  parser.add_argument('--statusbitsRT', help='-1 for all RTs or else a particular RT number from 0-31 associated with the statusbits (default=-1)', type=int, default=False)
  parser.add_argument('--wantbbus', help='Use the B bus if True (default=False)', type=bool, default=0x0000)
  parser.add_argument('--redundantbus', help='Do retries with the redundant bus; else don\'t retry (default=False)', type=bool, default=False)
  parser.add_argument('--extrabms', help='If true, each channel will have a BM (default=True)', type=bool, default=True)
  parser.add_argument('--wantmsgcounter', help='If True, the first data word of each message buffer will contain an increasing counter (default=False). \nNote that the minor frame time setting will be overridden  if needed to be at least 25 msec, if this is True.', type=bool, default=False)  
  parser.add_argument('--testpatternfile',help='JSON file that contains test patterns to replace the default ones (format: {\'TestPatterns\': [<2-byte-num-0>, <2-byte-num-1>,...]})', type=str)
  args = parser.parse_args()

  # print ("args = {}".format(args))

  # print( "args.xfers = {}".format(args.xfers))

  return args


# convert the input str or number to an int number
def convertToInt(inputstr):
  n = 0
  # Try decimal string or number in other base
  try:
    # print("\nTrying int conversion")
    n = int(inputstr)
    return n
  except:
    pass
  #Try bin string  !!!!Maybe a python bug? int('0b10101',16) produces an output,so this conversion needs to be done before the hex one!!!!
  try:
    # print("Trying binary conversion")
    n = int(inputstr, 2)
    return n
  except:
    pass
  # Try hex string
  try:
    # print("Trying hex conversion")
    n = int(inputstr, 16)
    return n
  except:
    pass
  # Try octal string
  try:
    # print("Trying octal conversion")
    n = int(inputstr, 8)
    return n
  except:
    pass

  print("Could not convert {} to an int.  Returning 0.".format(inputstr))
  return 0


def extractFromConfig(key=None):
  if not key:
    return {}

  return {}


class Bc:

  def __init__(self, bcstr=None):
    global BC_INPUT
    self.devname = None
    self.channum = None

    # print("bcstr = {}".format(bcstr))
    bc   = self.parse(bcstr)
    if bc:
      BC_INPUT = self

  def getPlatformHandle(self):
    # print("In getPlatformHandle, DEVICES is {}".format(DEVICES))
    return DEVICES[self.devname].handle 

  def __repr__(self):
    return "BC devname = {} channum = {}".format(self.devname, self.channum)
      
  def parse(self, bcstr=None):
    ret = False
    # print("input string = {}".format(bcstr))
    
    if not bcstr:
      return ret

    m = BC.match(bcstr)
    if not m:
      print("bc input doesn't match BC pattern".format(bcstr))
      return ret
    
    md = m.groupdict()

    # print("md = {}".format(md))
    channum = int(md.get('channum'))
    devname = md.get('devname')

    if devname:
      if devname in NICKNAMES2DEVICES:  # If the name is a nickname, translate it to the real device name
        devname = NICKNAMES2DEVICES[devname]

    self.devname = devname
    self.channum = channum

    return True


class Device:

  def __init__(self, name=None, nickname=None, devtype=None):

    self.name = name
    self.nickname = nickname
    self.devtype = devtype
    self.rtchans = set()  # The channels for which rts must be set up
    self.bcchan = None  # The channel for which xfers must be set up
    self.handle = None  # This will point to an instantiated AIM or AIT device

  def __repr__(self):
    return "Device name = {} nickname = {} devtype = {}".format(self.name, self.nickname, self.devtype)


class Devices:

  def __init__(self, config=None, devicestrs=None):
    global DEVICES
    if config:
      DEVICES = extractFromConfig(key='devices')
    if devicestrs:
      # print("devicestrs={}".format(devicestrs))
      for devicestr in devicestrs:
        if len(devicestr) == 0 or len(devicestr.strip()) == 0:
          continue
        # print("devicestr = {}".format(devicestr))
        device = self.parse(devicestr)
        if device:
          DEVICES[device.name] = device

    self.createNickname2DeviceMap()

    # print ("The devices are:\n{}".format(DEVICES))
    # print ("The devices by nickname are:\n{}".format(NICKNAMES2DEVICES))

  def parse(self, devicestr=None):
    ret = None
    # print("input string = {}".format(devicestr))
    
    if not devicestr:
      return ret

    m = DEVICE.match(devicestr)
    if not m:
      print("device input {} not of form (name,devtype,nickname)".format(devicestr))
      return ret
    
    md = m.groupdict()

    # print("md = {}".format(md))    

    if not md.get('name') or not md.get('devtype'):
      return ret

    if md.get('nickname'):
      nickname = md.get('nickname')
    else:
      nickname = ''
      
    # print("dev name = {} and devtype = {} and nickname = {}".format(md.get('name'),md.get('devtype'),nickname))
    ret = Device(name=md.get('name'), devtype=md.get('devtype'), nickname=nickname)  

    return ret

  def createNickname2DeviceMap(self):
    global NICKNAMES2DEVICES
    
    for dev in DEVICES:
      name = DEVICES[dev].name
      nickname = DEVICES[dev].nickname
      if len(nickname) and len(name):
        NICKNAMES2DEVICES[nickname] = name
        

class Rt:

  def __init__(self, rtnum=0, devname=None, channum=0, buffer=[]):
    self.rtnum = rtnum
    self.devname = devname
    self.channum = channum
    self.buffer = buffer  # For now, just one buffer

  def getPlatformHandle(self):
    # print("In getPlatformHandle, DEVICES is {}".format(DEVICES))
    return DEVICES[self.devname].handle 

  def __repr__(self):
    return "RT  rtnum = {} devname = {} channum = {}".format(self.rtnum, self.devname, self.channum)


class Rts:
  
  def __init__(self, config=None, rtstrs=None):
    global RTS

    broadcastRT = None
    
    if rtstrs:
      for rtstr in rtstrs:
        if len(rtstr) == 0 or len(rtstr.strip()) == 0:
          continue
        rt = self.parse(rtstr)
        if rt and rt.rtnum:
          RTS[rt.rtnum] = rt
          if (rt.devname, rt.channum) not in BROADCAST_RTS: # and DEVICES[rt.devname].devtype == 'AIM':
            BROADCAST_RTS[(rt.devname, rt.channum)] = Rt(rtnum=31,
                                channum=rt.channum, devname=rt.devname)

  def parse(self, rtstr=None):
    ret = None

    if not rtstr:
      return ret

    # print("RTs.parse input string = {}".format(rtstr))
    m = RT.match(rtstr)
    if not m:    
      print("rt input {} doesn't match rt pattern".format(rtstr))
      return ret
    
    md = m.groupdict()

    rtnum = int(md.get('rtnum'))
    channum = int(md.get('channum'))
    devname = md.get('devname')

    if devname:
      if devname in NICKNAMES2DEVICES:  # If the name is a nickname, translate it to the real device name
        devname = NICKNAMES2DEVICES[devname]

    ret = Rt(rtnum=rtnum, channum=channum, devname=devname)

    return ret


class Xfer:

  def __init__(self, xferdata=None, databuf=None, xferstr=None):
    global DEVICES
    print("xferdata = {}".format(xferdata))
    self.xferstr = xferstr
    self.xfertype = common.Transfer[xferdata.get('xfertype')]
    self.rt = xferdata.get('rt')
    self.subaddr = xferdata.get('subaddr')
    self.rt1 = xferdata.get('rt1')
    self.subaddr1 = xferdata.get('subaddr1')
    self.rt2 = xferdata.get('rt2') 
    self.subaddr2 = xferdata.get('subaddr2')
    self.mode = xferdata.get("mode")
    self.databuf = databuf
    self.idlist = []  # This holds the ids of the messages that are exchanged as part of the transfer.  These ids can range from 1-3, depending on the transfer.
    self.rtnumlist = []
    self.transferHandle = None

    inputlen = xferdata.get('length')
    #The length is the value that is to be written into the 1553 message.  It is not always the length of the databuf, because it sometimes represents the mode code.    
    if self.mode:
      self.length = int(common.MODES[self.mode][1]) #As per the spec, length contains the mode code
    elif inputlen:
      inputlen = int(inputlen)
      if inputlen < 32:
        self.length =  inputlen
      else:
        self.length = 0  #Allow the user specify a buffer length of 32, but this needs to get turned into 0 for the message to fit into 5 bits
    else:
      self.length = 0  #0 indicates a length of 32 words, per the spec  

    # If an explicit id was provided as input, just use that id.  We will handle only that message from the xfer.
    if len(xferdata.get('id').strip()) != 0:
      # print("id = {}  Its type is {}".format(xferdata.get('id'), type(xferdata.get('id'))))
      self.idlist = [int(xferdata.get('id'))]

    if self.rt:
      self.rt = int(self.rt)
      if self.rt in RTS:
        self.rtnumlist.append(self.rt)
      self.subaddr = int(self.subaddr) if self.subaddr else None
    else:
      if self.rt1:
        self.rt1 = int(self.rt1)
        if self.rt1 in RTS:
          self.rtnumlist.append(self.rt1)
        self.subaddr1 = int(self.subaddr1) if self.subaddr1 else None
      if self.rt2:
        self.rt2 = int(self.rt2)
        if self.rt2 in RTS:
          self.rtnumlist.append(self.rt2)
        self.subaddr2 = int(self.subaddr2) if self.subaddr2 else None


    if self.idlist == [] or self.idlist == [1]:
      # We need to handle BC transfers
      if BC_INPUT:
        DEVICES[BC_INPUT.devname].bcchan = BC_INPUT.channum
      else:
        print("Error!! No BC devname and channum provided.  Exiting...")
        sys.exit()

    if self.xfertype == common.Transfer.BCBCAST:
      self.rt = 31;
      self.subaddr = int(self.subaddr) if self.subaddr else None
    elif self.xfertype == common.Transfer.RTBCAST:
      self.rt1 = 31
      self.subaddr1 = int(self.subaddr1) if self.subaddr1 else None
    elif self.xfertype == common.Transfer.MODE_BCAST:
      self.rt = 31;
      self.subaddr = 0 #31 Not sure when 31 gets used, if ever.  Thought it indicated mode broadcast, but maybe not
    elif self.xfertype == common.Transfer.MODE:
      self.subaddr = 31



  def existingRTSA(self,rt,sa):
    global RTSA
    if (rt and RTSA.get(rt) == sa):     
      return True
    else:
      RTSA[rt] = sa
      return False    
    
  def process(self):

    if self.existingRTSA(self.rt,self.subaddr):
      common.NUM_TRANSFERS -= 1
      print("A transfer with this RT/SA {}/{} has already been established.  Not setting up transfer {}".format(self.rt,self.subaddr,self.xferstr))
      return
    
    if self.existingRTSA(self.rt1,self.subaddr1):
      common.NUM_TRANSFERS -= 1
      print("A transfer with this RT/SA {}/{} has already been established.  Not setting up transfer {}".format(self.rt1,self.subaddr1,self.xferstr))
      return
    
    if self.existingRTSA(self.rt2,self.subaddr2):
      common.NUM_TRANSFERS -= 1
      print("A transfer with this RT/SA {}/{} has already been established.  Not setting up transfer {}".format(self.rt2,self.subaddr2,self.xferstr))
      return            
    # print ("About to process the xfer {}".format(self.xferstr))
    # print("The xfertype is {}".format(self.xfertype))

    if self.xfertype == common.Transfer.BCRT:
      self.processBCRT()
      
    elif self.xfertype == common.Transfer.BCBCAST:
      self.processBCBCAST()

    elif self.xfertype == common.Transfer.RTBC:
      self.processRTBC()
      
    elif self.xfertype == common.Transfer.RTRT:
      self.processRTRT()

    elif self.xfertype == common.Transfer.RTBCAST:
      self.processRTBCAST()

    elif self.xfertype == common.Transfer.MODE:
      self.processMODE()

    elif self.xfertype == common.Transfer.MODE_BCAST:
      self.processMODE_BCAST()

  def processBCRT(self):

    # print("Starting process BCRT")
    # print("The idlist is {}".format(self.idlist))
    
    if not self.rt:
      print("Target RT not provided.  Not processing BCRT transfer")
      return
    if not self.subaddr:
      print("Target RT subaddr not provided.  Not processing BCRT transfer")
      return
    
    if len(self.idlist) == 0:  # No explicit message msgid provided
      self.idlist = [1, 2]

    for msgid in self.idlist:
      if msgid == 1:
        # Process MSG 1

        if not BC_INPUT:
          print("Expected BC input not provided.  Not processing BCRT transfer {}".format(self.xferstr))
          return
        
        self.transferHandle = BC_INPUT.getPlatformHandle().addBCRTTransfer(devname=BC_INPUT.devname, channum=BC_INPUT.channum, xferType=common.Transfer.BCRT, rtnum=self.rt, subaddr=self.subaddr, dataLength=self.length, dataBuffer=self.databuf)
        # print("BCRT Msg 1 created")

      elif msgid == 2:
        # Process MSG 2
        
        RT = RTS.get(self.rt)
        if not RT:
          print("Expected RT input for rt {} not provided.  Not processing RT receive for BCRT transfer {}".format(self.rt, self.xferstr))
          return
          
        RT.getPlatformHandle().addRT(devname=RT.devname, channum=RT.channum, direction=common.Direction.RECEIVE, rtnum=self.rt, subaddr=self.subaddr, dataLength=self.length, dataBuffer=None, mode=self.mode)
        # print ("BCRT Msg 2 created")

  def processBCBCAST(self):
    # print("BCBCAST subaddress is {}".format(self.subaddr))
    
    if len(self.idlist) == 0:  # No explicit message msgid provided
      self.idlist = [1]

    for msgid in self.idlist:
      if msgid == 1:
        # Process MSG 1          
        if not BC_INPUT:
          print("Expected BC input not provided.  Not processing BCRT transfer {}".format(self.xferstr))
          return

        self.transferHandle = BC_INPUT.getPlatformHandle().addBCRTTransfer(devname=BC_INPUT.devname, channum=BC_INPUT.channum, xferType=common.Transfer.BCBCAST, rtnum=self.rt, subaddr=self.subaddr, dataLength=self.length, dataBuffer=self.databuf)
        # print("BCBCAST Msg 1 to RT {} created".format(self.rt))

    # For the broadcast transfers, the broadcast RTs needs to be set up as receivers.
    print("BROADCAST_RTS = {}".format(BROADCAST_RTS))
    for RT in BROADCAST_RTS.values():
      print("RT = {}".format(RT))        
      RT.getPlatformHandle().addRT(devname=RT.devname, channum=RT.channum, direction=common.Direction.RECEIVE, rtnum=RT.rtnum, subaddr=self.subaddr, dataLength=self.length, dataBuffer=None, mode=self.mode)    

  def processRTBC(self):
    
    if len(self.idlist) == 0:  # No explicit message msgid provided
      self.idlist = [1, 2]

    for msgid in self.idlist:
      if msgid == 1:
        # Process MSG 1

        if not BC_INPUT:
          print("Expected BC input not provided.  Not processing BCRT transfer {}".format(self.xferstr))
          return
        
        self.transferHandle = BC_INPUT.getPlatformHandle().addRTBCTransfer(devname=BC_INPUT.devname, channum=BC_INPUT.channum, xferType=common.Transfer.RTBC, rtnum=self.rt, subaddr=self.subaddr, dataLength=self.length, dataBuffer=None)
        # print("RTBC Msg 1 created")

      elif msgid == 2:
        # Process MSG 2
        
        RT = RTS.get(self.rt)
        if not RT:
          print("Expected RT input for rt {} not provided.  Not processing RT transmit for RTBC transfer {}".format(self.rt, self.xferstr))
          return
          
        RT.getPlatformHandle().addRT(devname=RT.devname, channum=RT.channum, direction=common.Direction.TRANSMIT, rtnum=self.rt, subaddr=self.subaddr, dataLength=self.length, dataBuffer=self.databuf, mode=self.mode)
        # print ("RTBC Msg 2 created")
      
  def processRTRT(self):
    
    if len(self.idlist) == 0:  # No explicit message msgid provided
      self.idlist = [1, 2, 3]

    for msgid in self.idlist:
      if msgid == 1:
        # Process MSG 1
        if not BC_INPUT:
          print("Expected BC input not provided.  Not processing BCRT transfer {}".format(self.xferstr))
          return
        
        self.transferHandle = BC_INPUT.getPlatformHandle().addRTRTTransfer(devname=BC_INPUT.devname, channum=BC_INPUT.channum, xferType=common.Transfer.RTRT, rt_xmit=(self.rt2, self.subaddr2), rt_rcv=(self.rt1, self.subaddr1), dataLength=self.length, dataBuffer=None)
        # print("RTRT Msg 1 created")        

      elif msgid == 2:
        # Process MSG 2
        print ("Before processing RTRT msg 2 for rt {}, the known RTS are {}".
               format(self.rt2, RTS))
        RT = RTS.get(self.rt2)
        if not RT:
          print("Expected RT input for rt {} not provided.  Not processing RT transmit for RTRT transfer {}".format(self.rt2, self.xferstr))
          return
          
        RT.getPlatformHandle().addRT(devname=RT.devname, channum=RT.channum, direction=common.Direction.TRANSMIT, rtnum=self.rt2, subaddr=self.subaddr2,  dataLength=self.length, dataBuffer=self.databuf, mode=self.mode)
        # print ("RTRT Msg 2 created")

      elif msgid == 3:
        # Process MSG 3
        RT = RTS.get(self.rt1)
        if not RT:
          print("Expected RT input for rt1 {} not provided.  Not processing RT receive for RTRT transfer {}".format(self.rt1, self.xferstr))
          return
          
        RT.getPlatformHandle().addRT(devname=RT.devname, channum=RT.channum, direction=common.Direction.RECEIVE, rtnum=self.rt1, subaddr=self.subaddr1, dataLength=self.length, dataBuffer=None, mode=self.mode)
        # print ("RTRT Msg 3 created")

  def processRTBCAST(self):
    # print("For RTBCAST, the bcast subaddr is {}".format(self.subaddr1))
    RT = None
    if len(self.idlist) == 0:  # No explicit message msgid provided
      self.idlist = [1, 2]

    for msgid in self.idlist:
      if msgid == 1:
        # Process MSG 1
        if not BC_INPUT:
          print("Expected BC input not provided.  Not processing BCRT transfer {}".format(self.xferstr))
          return
        
        self.transferHandle = BC_INPUT.getPlatformHandle().addRTRTTransfer(devname=BC_INPUT.devname, channum=BC_INPUT.channum, xferType=common.Transfer.RTBCAST, rt_xmit=(self.rt2, self.subaddr2), rt_rcv=(self.rt1, self.subaddr1), dataLength=self.length, dataBuffer=None)
        # print("RTRT Msg 1 created")    
      elif msgid == 2:
        # Process MSG 2
        RT = RTS.get(self.rt2)
        if not RT:
          print("Expected RT input for rt2 {} not provided.  Not processing RT transmit for RTRT transfer {}".format(self.rt2, self.xferstr))
          return
          
        RT.getPlatformHandle().addRT(devname=RT.devname, channum=RT.channum, direction=common.Direction.TRANSMIT, rtnum=self.rt2, subaddr=self.subaddr2,  dataLength=self.length, dataBuffer=self.databuf, mode=self.mode)
        # print ("RTRT Msg 2 created")

    # For the broadcast transfers, the broadcast RTs needs to be set up as receivers (except for the RT doing the broadcast)
    print("BROADCAST_RTS = {}".format(BROADCAST_RTS))
    for BRT in BROADCAST_RTS.values():
      print("\n\n@@@@@ BROADCAST_RTS::: BRT = {}".format(BRT))
      
      if RT and BRT.channum == RT.channum and BRT.devname == RT.devname:
        print("Passing on broadcast RT setup:: BRT.channum/devname = {}/{} RT.channum/devname (RTBCAST) = {}/{}".format(BRT.channum,BRT.devname,RT.channum,RT.devname))
        pass
      else:        
        BRT.getPlatformHandle().addRT(devname=BRT.devname, channum=BRT.channum, direction=common.Direction.RECEIVE, rtnum=BRT.rtnum, subaddr=self.subaddr1, dataLength=self.length, dataBuffer=None, mode=self.mode)    


  def processMODE(self):

    # What kind of mode command is this?
    # N -- BC sends mode code without data
    # T -- BC sends mode code, RT responds with 1 data word
    # R -- BC sends mode code with 1 data word
    # print("Mode subaddress is {}".format(self.subaddr))

    variant = common.MODES[self.mode][0]

    print("mode = {} variant = {} databuf = {} length = {}".format(self.mode,variant,self.databuf, self.length))
    
    if len(self.idlist) == 0:  # No explicit message msgid provided
        self.idlist = [1, 2]  # RT will send a data word back

    for msgid in self.idlist:
      if msgid == 1:
        # Process MSG 1          
        if not BC_INPUT:
          print("Expected BC input not provided.  Not processing MODE transfer {} msg 1".format(self.xferstr))
          return
        
        if variant == 'R':
          # If variant != 'T', this looks like a BCRT transfer
          self.transferHandle = BC_INPUT.getPlatformHandle().addBCRTTransfer(devname=BC_INPUT.devname, channum=BC_INPUT.channum, xferType=common.Transfer.MODE, rtnum=self.rt, subaddr=self.subaddr, dataLength=self.length, dataBuffer=self.databuf)

        else:
          # If variant == 'T' or 'N', this looks like an RTBC transfer
          self.transferHandle = BC_INPUT.getPlatformHandle().addRTBCTransfer(devname=BC_INPUT.devname, channum=BC_INPUT.channum, xferType=common.Transfer.MODE, rtnum=self.rt, subaddr=self.subaddr, dataLength=self.length, dataBuffer=None)

        # print("MODE Msg 1 created")
          
      elif msgid == 2:
        # Process MSG 2
        
        RT = RTS.get(self.rt)
        if not RT:
          print("Expected RT input for rt {} not provided.  Not processing RT transmit for MODE transfer {}".format(self.rt, self.xferstr))
          return
        
        if variant == 'R':
          RT.getPlatformHandle().addRT(devname=RT.devname, channum=RT.channum, direction=common.Direction.RECEIVE, rtnum=self.rt, subaddr=self.subaddr, dataLength=self.length, dataBuffer=None, mode=self.mode)
        else:
          RT.getPlatformHandle().addRT(devname=RT.devname, channum=RT.channum, direction=common.Direction.TRANSMIT, rtnum=self.rt, subaddr=self.subaddr, dataLength=self.length, dataBuffer=self.databuf, mode=self.mode)
        # print ("MODE Msg 2 created")

  def processMODE_BCAST(self):
    # What kind of mode command is this?
    # N -- BC sends mode code without data
    # T -- BC sends mode code, RT responds with 1 data word
    # R -- BC sends mode code with 1 data word

    # print("Mode broadcast subaddress is {}".format(self.subaddr))
    variant = common.MODES[self.mode][0]
    # print("mode = {} variant = {} databuf = {} length = {}".format(self.mode,variant,self.databuf, self.length))

    if variant == 'T':
      print("!! Error: Illegal MODE_BCAST mode = {}.  Ignoring xfer".
            format(self.mode))
      return
    
    if len(self.idlist) == 0:  # No explicit message msgid provided
      self.idlist = [1]

    for msgid in self.idlist:
      if msgid == 1:
        # Process MSG 1          
        if not BC_INPUT:
          print("Expected BC input not provided.  Not processing MODE_BCAST transfer {} message 1".format(self.xferstr))
          return

        self.transferHandle = BC_INPUT.getPlatformHandle().addBCRTTransfer(devname=BC_INPUT.devname, channum=BC_INPUT.channum, xferType=common.Transfer.MODE_BCAST, rtnum=self.rt, subaddr=self.subaddr, dataLength=self.length, dataBuffer=self.databuf)
        print("BCRT Msg 1 created")

    # For the broadcast transfers, the broadcast RTs needs to be set up as receivers.
    for RT in BROADCAST_RTS.values():        
      RT.getPlatformHandle().addRT(devname=RT.devname, channum=RT.channum, direction=common.Direction.RECEIVE, rtnum=RT.rtnum, subaddr=self.subaddr, dataLength=self.length, dataBuffer=None, mode=self.mode)    

  def dumpTransferStatus(self, verbose=False):

    MESSAGES = 0
    ERRORS = 0

    #print("For Xfer, transferHandle = {}".format(self.transferHandle))
    if self.transferHandle is not None:
 
      TRANSFERID, MESSAGES, ERRORS, STATUS1, STATUS2 = BC_INPUT.getPlatformHandle().dumpTransferStatus(transferHandle=self.transferHandle)
    
      if verbose:  
        print("T{}: MESSAGES={}\tERRORS={}\tSTATUSWORD1={}\tSTATUSWORD2={}\t{}".format(TRANSFERID, MESSAGES, ERRORS, STATUS1, STATUS2, self.xferstr))
    return MESSAGES, ERRORS
        

class Xfers:

  def __init__(self, xferstrs):
    global XFERS

    # print("@@@@xferstrs == {}".format(xferstrs))
    for xferstr in xferstrs:
      if len(xferstr) == 0 or len(xferstr.strip()) == 0:
        continue
      xfer = self.parse(xferstr)
      # print ("After parse, xfer = {}".format(xfer))
      if xfer:
        XFERS.append(xfer)
        
  def processXfers(self):
    global XFERS
    for xfer in XFERS:
      xfer.process()

  ''' 
  Apply further constraints that can't be caught by the regexp for the
  different fields. For instance, subaddresses can only be 1-30 for non-MODE
  messages.  This takes a dictionary of the possible message params.
  '''

  def checkInputs(self, md):
    ret = True
    
    length = md.get('length')
    if length and int(length) not in common.LENGTH_RANGE:
      print("length {} not in {}".format(length, common.LENGTH_RANGE))
      ret = False
      
    rt = md.get('rt')
    rt1 = md.get('rt1')
    rt2 = md.get('rt2')
    if rt and int(rt) not in common.RT_RANGE:
      print("rt {} not in {}".format(rt, common.RT_RANGE))
      ret = False
    if rt1 and int(rt1) not in common.RT_RANGE:
      print("rt1 {} not in {}".format(rt1, common.RT_RANGE))
      ret = False
    if rt2 and int(rt2) not in common.RT_RANGE:
      print("rt2 {} not in {}".format(rt2, common.RT_RANGE))
      ret = False
      
    subaddr = md.get('subaddr')
    subaddr1 = md.get('subaddr1')
    subaddr2 = md.get('subaddr2')
    # print("subaddr type is {}".format(type(subaddr)))
    if subaddr and int(subaddr) not in common.SUBADDR_RANGE:
      print("subaddr {} not in {}".format(subaddr, common.SUBADDR_RANGE))
      ret = False
    if subaddr1 and int(subaddr1) not in common.SUBADDR_RANGE:
      print("subaddr1 {} not in {}".format(subaddr1, common.SUBADDR_RANGE))
      ret = False
    if subaddr2 and int(subaddr2) not in common.SUBADDR_RANGE:
      print("subaddr2 {} not in {}".format(subaddr2, common.SUBADDR_RANGE))
      ret = False

    return ret

  def formDataBuf(self, content=None, dataword=None, mode=None, length=0):
    # content is used to specify the data words for all transfer types but the mode types.
    # dataword is used to specify the single data word for the mode types, when it exists
    # Both will not be non-None at the same time.

    # This method will produce a data buf in canonical form, which is a list of hex values.
    # It applies the length field to this databuf.

    # print("formDataBuf: content = {} dataword = {} length = {} mode = {}".format(content,dataword,length,mode))
    databuf = []
    databufStr = None
    buflen = 0

    if dataword and content:
      print("ERROR: Both dataword and content can't be non-None!  Exiting ....")
      sys.exit()

    if dataword:  # Mode command explicitly lists a data word
      databufStr = dataword
      buflen = 1
    elif mode:
      if common.MODES[mode][0] == 'T':
        buflen = 1  
      elif common.MODES[mode][0] == 'R':  # Mode command uses a data word, but none provided.  For now, let this default to [0].
        buflen = 1
      else:  # Mode command does not use a data word
        buflen = 0
    else:
      databufStr = content
      buflen = int(length)
      if length == 0:
        buflen = 32

    # Remove all spaces from the databufStr, to make it easier to compare it to known patterns
    if databufStr:
      databufStr = databufStr.replace(' ', '')

    # print("databufStr = ***{}*** buflen = {}".format(databufStr, buflen))

    if databufStr == '[*ZEROES]':
      databuf = [0 for i in range(buflen)]
    elif databufStr == '[*ONES]':
      databuf = [1 for i in range(buflen)]
    elif databufStr == '[*RANDOM]':
      databuf = [random.randint(0, 65535) for i in range(buflen)]
    elif not databufStr:
      databuf = [0 for i in range(buflen)]
    elif databufStr.startswith('[*T'):
      testPatternNum = int(databufStr.split('[*T')[1].split(']')[0])
      if testPatternNum <= len(common.TEST_PATTERNS):
        databuf = [common.TEST_PATTERNS[testPatternNum] for i in range(buflen)]
      else :
        databuf = [0xabcd for i in range(buflen)]      
    else:
      # First strip the brackets from the string representation of the databuf.
      # The split what is left on the commas and form a list from it.
      # Check the length of resulting list.  If greater than length, print a warning and truncate it.
      # If the length is too small, pad it out to length with zeroes.
      # Write the elements of the final databuf in hex form.  If any can't be coerced into a 4-digit
      # hex, then they may not be integers, or may be too large.  If the coercion fails, print an
      # error msg and exit.

      databufStr = databufStr.replace('[', '').replace(']', '')
      # print("databufStr after bracket removal = ***{}***".format(databufStr))
      if len(databufStr) > 0:
        databuf = databufStr.split(',')
      else:
        databuf = []
        
      databuflen = len(databuf)

      print("len(databuf) = {} databuf = {} databuflen = {}".format(len(databuf), databuf, databuflen))

      if databuflen > buflen:
        del databuf[buflen:]
      elif databuflen < buflen:     
        for i in range(databuflen, buflen):
          databuf.append(0)

      # print("len(databuf) = {} databuf = {} databuflen = {}".format(len(databuf),databuf,databuflen))

      databuf = [convertToInt(databuf[i]) for i in range(buflen)]
      
    if not dataword and buflen > 0 and common.WANT_MESSAGE_COUNTER:  #We don't have a mode code transfer, and we want a message counter, so zero out the first word for the counter
      databuf[0] = 0

    return databuf

  def parse(self, xferstr):
    # print("input string = {}".format(xferstr))
    m = BCRT.match(xferstr)
    if not m:
      m = BCBCAST.match(xferstr)
    if not m:
      m = RTBC.match(xferstr)
    if not m:
      m = RTRT.match(xferstr)
    if not m:
      m = RTBCAST.match(xferstr)
    if not m:
      m = MODE.match(xferstr)
    if not m:
      m = MODE_BCAST.match(xferstr)
    if not m:
      print("xfer input {} doesn't match a 1553 pattern".format(xferstr))
      return None
    
    md = m.groupdict()
    # print("xfer match dict = {}".format(md))
    
    valid = self.checkInputs(md)
    if not valid:
      print("Invalid xfer input {} ignored".format(xferstr))
      return None

    databuf = self.formDataBuf(content=md.get('content'), dataword=md.get('dataword'), length=md.get('length'), mode=md.get('mode'))
      
    xfer = Xfer(md, databuf, xferstr)

    return xfer


def test():
  parser = argparse.ArgumentParser()
  parser.set_defaults(bc='BC@aim1/1')
  #parser.set_defaults(bc='BC@ait1/1')
  #parser.set_defaults(bc=None)
  parser.set_defaults(devs='(APE1553-2/AIM/aim1) (224/AIT/ait1)')  
  #parser.set_defaults(rts='RT1@aim1/1 RT2@aim1/1 RT3@ait1/1 RT4@ait1/1 RT5@aim1/1')
  #parser.set_defaults(devs='(APE1553-2/AIM/aim1)')  
  #parser.set_defaults(rts='RT1@aim1/2 RT2@ait1/2 RT3@ait1/3 RT4@ait1/4')
  #parser.set_defaults(rts='RT1@aim1/2 RT2@ait1/2 RT3@ait1/3')  
  parser.set_defaults(rts='RT1@aim1/2  RT2@ait1/2')
  #parser.set_defaults(rts='RT2@ait1/2')
  #parser.set_defaults(rts='RT1@aim1/2')      
  parser.set_defaults(configfile=None) 
  parser.set_defaults(numframes=common.NUM_FRAMES)
  parser.set_defaults(frametime=common.MINOR_FRAME_TIME)
  parser.set_defaults(gaptime=common.TRANSFER_GAP_TIME)
  parser.set_defaults(gapmode=common.TRANSFER_GAP_MODE)
  parser.set_defaults(responsetime=common.RESPONSE_TIME)  
  parser.set_defaults(responsetimeout=common.RESPONSE_TIMEOUT)
  parser.set_defaults(xmitamplitude=common.XMIT_AMPLITUDE)  
  parser.set_defaults(xmitamplitudechan=common.XMIT_AMPLITUDE_CHAN)
  parser.set_defaults(statusbits=common.STATUS_BITS)  
  parser.set_defaults(statusbitsRT=common.STATUS_BITS_RT)
  parser.set_defaults(wantbbus=common.WANT_BBUS)  
  parser.set_defaults(redundantbus=common.REDUNDANT_BUS)
  parser.set_defaults(testpatternfile=common.TEST_PATTERN_FILE)
  #parser.set_defaults(wantbbus=True)  
  #parser.set_defaults(redundantbus=True)
  parser.set_defaults(extrabms=common.WANT_EXTRA_BMS)
  #parser.set_defaults(extrabms=False)       
  parser.set_defaults(fast=False)
  parser.set_defaults(sleep=common.SLEEP)
  parser.set_defaults(wantmsgcounter=common.WANT_MESSAGE_COUNTER)   
  #parser.set_defaults(wantmsgcounter=True)
  #parser.set_defaults(testpatternfile="/home/lbahler/testing-framework/TestPatterns/TP1")

  #parser.set_defaults(xfers='BCRT(1.1/1)[20] BCRT(2.1/1)[40]')
  #args = parser.parse_args([])
  #run(args)  
  
  parser.set_defaults(xfers='BCRT(1.1/3)[*T2] BCRT(2.1/3)[*T4] BCRT(3.1/3)[*T10] BCRT(1.2/3)[*T12] BCRT(2.2/3)[*T14] BCRT(3.2/3)[*T99]')
  #args = parser.parse_args([])
  #run(args)  
  
  parser.set_defaults(xfers='BCRT(1.1/2)[*RANDOM] BCRT(2.2/2)[*RANDOM]')
  #args = parser.parse_args([])
  #run(args)

  #Mode codes without data words
  '''  
  parser.set_defaults(xfers='MODE(1,DynamicBusControl) MODE(2,DynamicBusControl) ')
  args = parser.parse_args([])
  run(args)
  '''    
  parser.set_defaults(xfers='MODE(1,Synchronize) MODE(2,Synchronize) ')
  args = parser.parse_args([])
  run(args)
  '''  
  parser.set_defaults(xfers='BCRT(1.1/2)[*RANDOM] MODE(1,TransmitStatusWord) BCRT(2.2/2)[*RANDOM] MODE(2,TransmitStatusWord) ')
  args = parser.parse_args([])
  run(args)

  parser.set_defaults(xfers='MODE(1,InitiateSelfTest) MODE(2,InitiateSelfTest) ')
  args = parser.parse_args([])
  run(args)

  parser.set_defaults(xfers='MODE(1,TransmitterShutdown) MODE(2,TransmitterShutdown)')
  args = parser.parse_args([])
  run(args)

  parser.set_defaults(xfers='MODE(1,OverrideTransmitterShutdown) MODE(2,OverrideTransmitterShutdown)')
  args = parser.parse_args([])
  run(args)
   
  parser.set_defaults(xfers='MODE(1,InhibitTerminalFlagBit) MODE(2,InhibitTerminalFlagBit) ')
  args = parser.parse_args([])
  run(args)
  
  parser.set_defaults(xfers=' MODE(1,OverrideInhibitTerminalFlagBit) MODE(2,OverrideInhibitTerminalFlagBit)')
  args = parser.parse_args([])
  run(args)
  
  parser.set_defaults(xfers='MODE(1,ResetRemoteTerminal) MODE(2,ResetRemoteTerminal) ')
  args = parser.parse_args([])
  run(args)
  '''   
  #Mode codes with transmit data words
  '''  
  parser.set_defaults(xfers='MODE(1,TransmitVectorWord) MODE(2,TransmitVectorWord)')
  args = parser.parse_args([])
  run(args)
 
  parser.set_defaults(xfers='BCRT(1.1/2)[*RANDOM] MODE(1,TransmitLastCommandWord) BCRT(2.1/2)[*RANDOM] MODE(2,TransmitLastCommandWord)')
  args = parser.parse_args([])
  run(args)
  
  parser.set_defaults(xfers='MODE(1,TransmitBuiltInTestWord) MODE(2,TransmitBuiltInTestWord)')
  args = parser.parse_args([])
  run(args)    
  ''' 
  #Mode codes with receive data words
  '''    
  parser.set_defaults(xfers='MODE(1,SynchronizeWithDataWord) MODE(2,SynchronizeWithDataWord)')
  args = parser.parse_args([])
  run(args)
 
  parser.set_defaults(xfers=' MODE(1,SelectedTransmitterShutdown) MODE(2,SelectedTransmitterShutdown)')
  args = parser.parse_args([])
  run(args)
   
  parser.set_defaults(xfers='MODE(1,OverrideSelectedTransmitterShutdown) MODE(2,OverrideSelectedTransmitterShutdown)')
  args = parser.parse_args([])
  run(args)
  '''   

  #Broadcast mode codes, some with receive data
  ''' 
  parser.set_defaults(xfers='MODE_BCAST(Synchronize)')
  args = parser.parse_args([])
  run(args)
 
  parser.set_defaults(xfers='MODE_BCAST(InitiateSelfTest)')
  args = parser.parse_args([])
  run(args)

  parser.set_defaults(xfers='MODE_BCAST(TransmitterShutdown)')
  args = parser.parse_args([])
  run(args)

  parser.set_defaults(xfers='MODE_BCAST(OverrideTransmitterShutdown)')
  args = parser.parse_args([])
  run(args)

  parser.set_defaults(xfers='MODE_BCAST(InhibitTerminalFlagBit)')
  args = parser.parse_args([])
  run(args)
    
  parser.set_defaults(xfers='MODE_BCAST(OverrideInhibitTerminalFlagBit)')
  args = parser.parse_args([])
  run(args)
   
  parser.set_defaults(xfers='MODE_BCAST(ResetRemoteTerminal)')
  args = parser.parse_args([])
  run(args)

  parser.set_defaults(xfers='MODE_BCAST(SynchronizeWithDataWord)')
  args = parser.parse_args([])
  run(args)

  parser.set_defaults(xfers='MODE_BCAST(SelectedTransmitterShutdown)')
  args = parser.parse_args([])
  run(args)
   
  parser.set_defaults(xfers='MODE_BCAST(OverrideSelectedTransmitterShutdown)')
  args = parser.parse_args([])
  run(args)
 
  ''' 

  parser.set_defaults(xfers='BCRT(2.14/3)[*RANDOM]')
  #args = parser.parse_args([])
  #run(args)

  parser.set_defaults(xfers='BCRT(2.14/3)[*RANDOM]')
  #args = parser.parse_args([])
  #run(args)
  
  
  parser.set_defaults(xfers='BCRT(1.14/5)[*RANDOM]')
  #args = parser.parse_args([])
  #run(args)
  
  parser.set_defaults(xfers='RTBC(1.14/5)[*RANDOM]')
  #args = parser.parse_args([])
  #run(args)
    
  parser.set_defaults(xfers='RTBC(1.2/4)[*ONES] RTBC(2.2/4)[*ONES] MODE(2,TransmitLastCommandWord)')
  # args = parser.parse_args([])
  # run(args)

  parser.set_defaults(xfers='BCBCAST(.13/5)[*RANDOM]')
  #args = parser.parse_args([])
  #run(args)
  
  parser.set_defaults(xfers='RTBCAST(.13/5,2.2)[*RANDOM] RTBCAST(.14/5,3.2)[*RANDOM]')
  #args = parser.parse_args([])
  #run(args)  

  parser.set_defaults(xfers='RTRT(2.3/2,3.3)[*ONES]')
  #args = parser.parse_args([])
  #run(args)

  parser.set_defaults(xfers='RTRT(1.1/3,2.1)[*RANDOM] RTRT(1.3/2,2.3)[*RANDOM]')
  #args = parser.parse_args([])
  #run(args)

  parser.set_defaults(xfers='BCRT(5.1/3)[*ONES] MODE(5,TransmitLastCommandWord)')
  # args = parser.parse_args([])
  # run(args)

'''
  xfers = Xfers(['BCRT1(30.2/3)@aim2','BCRT(2.3/5)@aim1','BCBCAST1(.0/8)@aim1','RTBC1(2.1/32)@aim10',
                 'RTRT(1.1/31,3.2)@aim2','RTBCAST1(.1/34,2.1)@aim2','MODE2(1,Synchronize)@aim1'])
  print("xfers = {}".format(xfers))
  xfers = Xfers(['BCRT1(30.2/3)@aim1','BCRT(2.3/5)@aim1','BCBCAST1(.0/8)@aim1','RTBC1(2.1/32)@aim10',
                 'RTRT(1.1/31,3.2)@aim2','RTBCAST1(.1/34,2.1)@aim2','MODE2(1,Synchronize)@aim1'])
  print("xfers = {}".format(xfers))
  xfers = Xfers(['BCRT1(30.2/3)@aim1','BCRT(2.3/5)@aim1','BCBCAST1(.0/8)@aim1','RTBC1(2.1/32)@aim10',
                 'RTRT(1.1/31,3.2)@aim2','RTBCAST1(.1/34,2.1)@aim2','MODE2(1,Synchronize)@aim1'])
  print("xfers = {}".format(xfers))
  xfers = Xfers(['BCRT1(30.2/3)@aim1','BCRT(2.3/5)@aim1','BCBCAST1(.0/8)@aim1','RTBC1(2.1Sdata /32)@aim10',
                 'RTRT(1.1/31,3.2)@aim2','RTBCAST1(.1/34,2.1)@aim2','MODE2(1,Synchronize)@aim1'])
  print("xfers = {}".format(xfers))
'''  


def run(args):

  global devtypes
  if not args:
    return

  print("args = {}".format(args))
  common.NUM_FRAMES = args.numframes
  common.MINOR_FRAME_TIME = args.frametime
  common.TRANSFER_GAP_MODE = args.gapmode
  common.TRANSFER_GAP_TIME = args.gaptime
  common.RESPONSE_TIME = args.responsetime
  common.RESPONSE_TIMEOUT = args.responsetimeout
  common.XMIT_AMPLITUDE = args.xmitamplitude
  common.XMIT_AMPLITUDE_CHAN = args.xmitamplitudechan
  common.STATUS_BITS = args.statusbits
  common.STATUS_BITS_RT = args.statusbitsRT
  common.WANT_BBUS = args.wantbbus
  common.REDUNDANT_BUS = args.redundantbus
  common.WANT_EXTRA_BMS = args.extrabms   
  common.FAST_MODE = args.fast
  common.SLEEP = args.sleep
  common.WANT_MESSAGE_COUNTER = args.wantmsgcounter
  common.TEST_PATTERN_FILE = args.testpatternfile
  
  if common.WANT_MESSAGE_COUNTER and common.MINOR_FRAME_TIME < 25.0 :
    print("Raising minor frame time to 25. because message counter is being used")
    common.MINOR_FRAME_TIME = 25.
    
  if common.TEST_PATTERN_FILE:
    common.setTestPatterns()  
  
  print("NUM_FRAMES = {}".format(common.NUM_FRAMES))
  print("DEVICES = {}".format(DEVICES))
  print("BC_INPUT = {}".format(BC_INPUT))
  print("RTS = {}".format(RTS))
  print("MINOR FRAME TIME = {}".format(common.MINOR_FRAME_TIME))
  print("WANT_MESSAGE_COUNTER = {}".format(common.WANT_MESSAGE_COUNTER))

  devs = Devices(devicestrs=args.devs.split(' '))  # This instantiates the AIM and AIT classes, as needed
  rts = Rts(rtstrs=args.rts.split(' '))
  if args.bc:
    bc = Bc(bcstr=args.bc)
  else:
    bc = None

  for rtnum in RTS:
    devname = RTS[rtnum].devname
    channum = RTS[rtnum].channum

    DEVICES[devname].rtchans.add(channum)  # For devname, note the channels in use
  

  
  # Parse the xferstrs
  if args.xfers:
    xferstrs = args.xfers.split(' ')
    xferstrs = [item for item in xferstrs if len(item) > 0]
    common.NUM_TRANSFERS = len(xferstrs)
    print("NUM_TRANSFERS = {}".format(common.NUM_TRANSFERS))
    xfers = Xfers(xferstrs=xferstrs)
  # print("DEVICES = {}".format(DEVICES)) #This includes the rt and bc channums that are actually used for each device

  # The known device types are AIM and AIT.  Instantiate them as needed.
  aim = None
  ait = None

  for device in [*DEVICES.values()]:
    if device.devtype == 'AIM':
      if not aim:
        aim = AIM_TH.AIM()
        devtypes.append(aim)
      device.handle = aim
    elif device.devtype == 'AIT':
      if not ait:
        ait = AIT_TH.AIT()
        devtypes.append(ait)
      device.handle = ait 
  
  if args.xfers:
    xfers.processXfers()
  
  #Start the test
  #Start the RTs
  for devtype in devtypes:
    devtype.startBMs()
    devtype.startRTs()

  if common.SLEEP and not common.NUM_FRAMES:  #If a defined sleep time is set, and the xfers are set to run infinitely, then calculate the sleep deadline right before the BC starts
    deadline = round(time.time() * 1000) + common.SLEEP  #current time in millis + sleep duration in millis
    
  #Start the BC, now that the RTs and BMs are started
  if bc:
    bc.getPlatformHandle().startBC()

  common.done = False #This will be set to True when either the defined number of xfers has occurred XOR the stated sleep time has elapsed OR the user has entered on stdin
  while (not common.done):
    i, _, _ = select.select( [sys.stdin], [], [], 1 )  #Wait for 1 second and check to see if the sleep timer has expired or the defined number of xfers has been sent
 
 
    if (i):
      userin = sys.stdin.readline().strip()
      i = None
      if userin == 'q':
        print("The user has quit")
        common.done = True
    elif common.NUM_FRAMES: #Check to see if and defined number of Xfers has happened
      #print("Checking that all the frames have been sent")
      totalTransfers = dumpTransferStatus(verbose=False)
      print("totalTransfers is {}".format(totalTransfers))
      if totalTransfers >= common.NUM_FRAMES * common.NUM_TRANSFERS:
        print("The specified number of frames has been sent")

        common.done = True
    elif common.SLEEP: #Check to see if the alloted time has expired
      if round(time.time() * 1000) >= deadline:
        print("The sleep time has expired")
        common.done = True      

    
  print("HEADING TO THE EXIT")
  
  #Stop the BC, before stopping the RTs and BMs 
  if bc:
    bc.getPlatformHandle().stopBC()
    
  for devtype in devtypes:
    devtype.stopRTs()
    
  for devtype in devtypes:
    devtype.stopBMs()
    
  for devtype in devtypes:        
    devtype.dumpBCStatus()
    devtype.dumpBMStatus()
    devtype.dumpRTStatus()
    devtype.deleteInterruptHandlers()
       
  
  printStatuses()  
  dumpTransferStatus(verbose=True)
  
  for devtype in devtypes:  
    devtype.shutdown()  

def printStatuses():
  print("\n============== BM STATUSES ==============")
  for bmdict in common.STATUSES['BM']:
    print(common.STATUSTEMPLATE.substitute(bmdict,statustype='BM'))
  print("\n============== BC STATUSES ==============")    
  for bcdict in common.STATUSES['BC']:
    print(common.STATUSTEMPLATE.substitute(bcdict,statustype='BC'))
  print("\n============== RT STATUSES ==============")
  for rtdict in common.STATUSES['RT']:
    print(common.STATUSTEMPLATE.substitute(rtdict,statustype='RT'))         
  #print(common.STATUSES)  

# The transfers may span device types, so the method is not class-specific.  
def dumpTransferStatus(verbose):
  global XFERS
  MESSAGES = 0
  ERRORS = 0
 
  if verbose:
    print("\n============== TRANSFER STATUSES ==============")
  for xfer in XFERS:
    #print("About to probe xfer.transferHandle {}".format(xfer.transferHandle))
    (messages, errors) = xfer.dumpTransferStatus(verbose)
    MESSAGES += messages
    ERRORS += errors

  if verbose:
    print("TRANSFER TOTALS: MESSAGES={}\tERRORS={}\n\n".format(MESSAGES, ERRORS))
  return MESSAGES + ERRORS

def signal_handler(sig, frame):
  global BC_INPUT

  print('busping.py received termination signal....')
  common.done = True

  

if __name__ == '__main__':

  signal.signal(signal.SIGINT, signal_handler)
  signal.signal(signal.SIGTERM, signal_handler)
  signal.signal(signal.SIGSEGV, signal_handler)
  signal.signal(signal.SIGQUIT, signal_handler)
    
  if len(sys.argv) == 1:
    test()
  else:
    args = handleArgs()
  
    run(args)
  
