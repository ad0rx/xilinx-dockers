r"""Wrapper for m1553_bc.h

Generated with:
/usr/local/bin/ctypesgen -I . -L /usr/local/lib64/ -l libait_mil.so -o /home/lbahler/ctypesgen/ait.py m1553_bc.h m1553_bm.h m1553_buffer.h m1553_cdef.h m1553_common.h m1553_error_def.h m1553_log.h m1553_replay.h m1553_rt.h m1553_system.h m1553_vme.h VersionInfo.h

Do not modify this file.
"""

__docformat__ = "restructuredtext"

# Begin preamble for Python v(3, 2)

import ctypes, os, sys
from ctypes import *

_int_types = (c_int16, c_int32)
if hasattr(ctypes, "c_int64"):
    # Some builds of ctypes apparently do not have c_int64
    # defined; it's a pretty good bet that these builds do not
    # have 64-bit pointers.
    _int_types += (c_int64,)
for t in _int_types:
    if sizeof(t) == sizeof(c_size_t):
        c_ptrdiff_t = t
del t
del _int_types


class UserString:
    def __init__(self, seq):
        if isinstance(seq, bytes):
            self.data = seq
        elif isinstance(seq, UserString):
            self.data = seq.data[:]
        else:
            self.data = str(seq).encode()

    def __bytes__(self):
        return self.data

    def __str__(self):
        return self.data.decode()

    def __repr__(self):
        return repr(self.data)

    def __int__(self):
        return int(self.data.decode())

    def __long__(self):
        return int(self.data.decode())

    def __float__(self):
        return float(self.data.decode())

    def __complex__(self):
        return complex(self.data.decode())

    def __hash__(self):
        return hash(self.data)
    
    def cmp(self, a,b): #cmp was removed from Python 3
        return (a > b) - (a < b)

    def __cmp__(self, string):
        if isinstance(string, UserString):
            return self.cmp(self.data, string.data)
        else:
            return self.cmp(self.data, string)

    def __le__(self, string):
        if isinstance(string, UserString):
            return self.data <= string.data
        else:
            return self.data <= string

    def __lt__(self, string):
        if isinstance(string, UserString):
            return self.data < string.data
        else:
            return self.data < string

    def __ge__(self, string):
        if isinstance(string, UserString):
            return self.data >= string.data
        else:
            return self.data >= string

    def __gt__(self, string):
        if isinstance(string, UserString):
            return self.data > string.data
        else:
            return self.data > string

    def __eq__(self, string):
        if isinstance(string, UserString):
            return self.data == string.data
        else:
            return self.data == string

    def __ne__(self, string):
        if isinstance(string, UserString):
            return self.data != string.data
        else:
            return self.data != string

    def __contains__(self, char):
        return char in self.data

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.__class__(self.data[index])

    def __getslice__(self, start, end):
        start = max(start, 0)
        end = max(end, 0)
        return self.__class__(self.data[start:end])

    def __add__(self, other):
        if isinstance(other, UserString):
            return self.__class__(self.data + other.data)
        elif isinstance(other, bytes):
            return self.__class__(self.data + other)
        else:
            return self.__class__(self.data + str(other).encode())

    def __radd__(self, other):
        if isinstance(other, bytes):
            return self.__class__(other + self.data)
        else:
            return self.__class__(str(other).encode() + self.data)

    def __mul__(self, n):
        return self.__class__(self.data * n)

    __rmul__ = __mul__

    def __mod__(self, args):
        return self.__class__(self.data % args)

    # the following methods are defined in alphabetical order:
    def capitalize(self):
        return self.__class__(self.data.capitalize())

    def center(self, width, *args):
        return self.__class__(self.data.center(width, *args))

    def count(self, sub, start=0, end=sys.maxsize):
        return self.data.count(sub, start, end)

    def decode(self, encoding=None, errors=None):  # XXX improve this?
        if encoding:
            if errors:
                return self.__class__(self.data.decode(encoding, errors))
            else:
                return self.__class__(self.data.decode(encoding))
        else:
            return self.__class__(self.data.decode())

    def encode(self, encoding=None, errors=None):  # XXX improve this?
        if encoding:
            if errors:
                return self.__class__(self.data.encode(encoding, errors))
            else:
                return self.__class__(self.data.encode(encoding))
        else:
            return self.__class__(self.data.encode())

    def endswith(self, suffix, start=0, end=sys.maxsize):
        return self.data.endswith(suffix, start, end)

    def expandtabs(self, tabsize=8):
        return self.__class__(self.data.expandtabs(tabsize))

    def find(self, sub, start=0, end=sys.maxsize):
        return self.data.find(sub, start, end)

    def index(self, sub, start=0, end=sys.maxsize):
        return self.data.index(sub, start, end)

    def isalpha(self):
        return self.data.isalpha()

    def isalnum(self):
        return self.data.isalnum()

    def isdecimal(self):
        return self.data.isdecimal()

    def isdigit(self):
        return self.data.isdigit()

    def islower(self):
        return self.data.islower()

    def isnumeric(self):
        return self.data.isnumeric()

    def isspace(self):
        return self.data.isspace()

    def istitle(self):
        return self.data.istitle()

    def isupper(self):
        return self.data.isupper()

    def join(self, seq):
        return self.data.join(seq)

    def ljust(self, width, *args):
        return self.__class__(self.data.ljust(width, *args))

    def lower(self):
        return self.__class__(self.data.lower())

    def lstrip(self, chars=None):
        return self.__class__(self.data.lstrip(chars))

    def partition(self, sep):
        return self.data.partition(sep)

    def replace(self, old, new, maxsplit=-1):
        return self.__class__(self.data.replace(old, new, maxsplit))

    def rfind(self, sub, start=0, end=sys.maxsize):
        return self.data.rfind(sub, start, end)

    def rindex(self, sub, start=0, end=sys.maxsize):
        return self.data.rindex(sub, start, end)

    def rjust(self, width, *args):
        return self.__class__(self.data.rjust(width, *args))

    def rpartition(self, sep):
        return self.data.rpartition(sep)

    def rstrip(self, chars=None):
        return self.__class__(self.data.rstrip(chars))

    def split(self, sep=None, maxsplit=-1):
        return self.data.split(sep, maxsplit)

    def rsplit(self, sep=None, maxsplit=-1):
        return self.data.rsplit(sep, maxsplit)

    def splitlines(self, keepends=0):
        return self.data.splitlines(keepends)

    def startswith(self, prefix, start=0, end=sys.maxsize):
        return self.data.startswith(prefix, start, end)

    def strip(self, chars=None):
        return self.__class__(self.data.strip(chars))

    def swapcase(self):
        return self.__class__(self.data.swapcase())

    def title(self):
        return self.__class__(self.data.title())

    def translate(self, *args):
        return self.__class__(self.data.translate(*args))

    def upper(self):
        return self.__class__(self.data.upper())

    def zfill(self, width):
        return self.__class__(self.data.zfill(width))


class MutableString(UserString):
    """mutable string objects

    Python strings are immutable objects.  This has the advantage, that
    strings may be used as dictionary keys.  If this property isn't needed
    and you insist on changing string values in place instead, you may cheat
    and use MutableString.

    But the purpose of this class is an educational one: to prevent
    people from inventing their own mutable string class derived
    from UserString and than forget thereby to remove (override) the
    __hash__ method inherited from UserString.  This would lead to
    errors that would be very hard to track down.

    A faster and better solution is to rewrite your program using lists."""

    def __init__(self, string=""):
        self.data = string

    def __hash__(self):
        raise TypeError("unhashable type (it is mutable)")

    def __setitem__(self, index, sub):
        if index < 0:
            index += len(self.data)
        if index < 0 or index >= len(self.data):
            raise IndexError
        self.data = self.data[:index] + sub + self.data[index + 1 :]

    def __delitem__(self, index):
        if index < 0:
            index += len(self.data)
        if index < 0 or index >= len(self.data):
            raise IndexError
        self.data = self.data[:index] + self.data[index + 1 :]

    def __setslice__(self, start, end, sub):
        start = max(start, 0)
        end = max(end, 0)
        if isinstance(sub, UserString):
            self.data = self.data[:start] + sub.data + self.data[end:]
        elif isinstance(sub, bytes):
            self.data = self.data[:start] + sub + self.data[end:]
        else:
            self.data = self.data[:start] + str(sub).encode() + self.data[end:]

    def __delslice__(self, start, end):
        start = max(start, 0)
        end = max(end, 0)
        self.data = self.data[:start] + self.data[end:]

    def immutable(self):
        return UserString(self.data)

    def __iadd__(self, other):
        if isinstance(other, UserString):
            self.data += other.data
        elif isinstance(other, bytes):
            self.data += other
        else:
            self.data += str(other).encode()
        return self

    def __imul__(self, n):
        self.data *= n
        return self


class String(MutableString, Union):

    _fields_ = [("raw", POINTER(c_char)), ("data", c_char_p)]

    def __init__(self, obj=""):
        if isinstance(obj, (bytes, UserString)):
            self.data = bytes(obj)
        else:
            self.raw = obj

    def __len__(self):
        return self.data and len(self.data) or 0

    def from_param(cls, obj):
        # Convert None or 0
        if obj is None or obj == 0:
            return cls(POINTER(c_char)())

        # Convert from String
        elif isinstance(obj, String):
            return obj

        # Convert from bytes
        elif isinstance(obj, bytes):
            return cls(obj)

        # Convert from str
        elif isinstance(obj, str):
            return cls(obj.encode())

        # Convert from c_char_p
        elif isinstance(obj, c_char_p):
            return obj

        # Convert from POINTER(c_char)
        elif isinstance(obj, POINTER(c_char)):
            return obj

        # Convert from raw pointer
        elif isinstance(obj, int):
            return cls(cast(obj, POINTER(c_char)))

        # Convert from c_char array
        elif isinstance(obj, c_char * len(obj)):
            return obj

        # Convert from object
        else:
            return String.from_param(obj._as_parameter_)

    from_param = classmethod(from_param)


def ReturnString(obj, func=None, arguments=None):
    return String.from_param(obj)


# As of ctypes 1.0, ctypes does not support custom error-checking
# functions on callbacks, nor does it support custom datatypes on
# callbacks, so we must ensure that all callbacks return
# primitive datatypes.
#
# Non-primitive return values wrapped with UNCHECKED won't be
# typechecked, and will be converted to c_void_p.
def UNCHECKED(type):
    if hasattr(type, "_type_") and isinstance(type._type_, str) and type._type_ != "P":
        return type
    else:
        return c_void_p


# ctypes doesn't have direct support for variadic functions, so we have to write
# our own wrapper class
class _variadic_function(object):
    def __init__(self, func, restype, argtypes, errcheck):
        self.func = func
        self.func.restype = restype
        self.argtypes = argtypes
        if errcheck:
            self.func.errcheck = errcheck

    def _as_parameter_(self):
        # So we can pass this variadic function as a function pointer
        return self.func

    def __call__(self, *args):
        fixed_args = []
        i = 0
        for argtype in self.argtypes:
            # Typecheck what we can
            fixed_args.append(argtype.from_param(args[i]))
            i += 1
        return self.func(*fixed_args + list(args[i:]))


def ord_if_char(value):
    """
    Simple helper used for casts to simple builtin types:  if the argument is a
    string type, it will be converted to it's ordinal value.

    This function will raise an exception if the argument is string with more
    than one characters.
    """
    return ord(value) if (isinstance(value, bytes) or isinstance(value, str)) else value

# End preamble

_libs = {}
_libdirs = ['/usr/local/lib64/']

# Begin loader

# ----------------------------------------------------------------------------
# Copyright (c) 2008 David James
# Copyright (c) 2006-2008 Alex Holkner
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in
#    the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of pyglet nor the names of its
#    contributors may be used to endorse or promote products
#    derived from this software without specific prior written
#    permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ----------------------------------------------------------------------------

import os.path, re, sys, glob
import platform
import ctypes
import ctypes.util


def _environ_path(name):
    if name in os.environ:
        return os.environ[name].split(":")
    else:
        return []


class LibraryLoader(object):
    # library names formatted specifically for platforms
    name_formats = ["%s"]

    class Lookup(object):
        mode = ctypes.DEFAULT_MODE

        def __init__(self, path):
            super(LibraryLoader.Lookup, self).__init__()
            self.access = dict(cdecl=ctypes.CDLL(path, self.mode))

        def get(self, name, calling_convention="cdecl"):
            if calling_convention not in self.access:
                raise LookupError(
                    "Unknown calling convention '{}' for function '{}'".format(
                        calling_convention, name
                    )
                )
            return getattr(self.access[calling_convention], name)

        def has(self, name, calling_convention="cdecl"):
            if calling_convention not in self.access:
                return False
            return hasattr(self.access[calling_convention], name)

        def __getattr__(self, name):
            return getattr(self.access["cdecl"], name)

    def __init__(self):
        self.other_dirs = []

    def __call__(self, libname):
        """Given the name of a library, load it."""
        paths = self.getpaths(libname)

        for path in paths:
            try:
                return self.Lookup(path)
            except:
                pass

        raise ImportError("Could not load %s." % libname)

    def getpaths(self, libname):
        """Return a list of paths where the library might be found."""
        if os.path.isabs(libname):
            yield libname
        else:
            # search through a prioritized series of locations for the library

            # we first search any specific directories identified by user
            for dir_i in self.other_dirs:
                for fmt in self.name_formats:
                    # dir_i should be absolute already
                    yield os.path.join(dir_i, fmt % libname)

            # then we search the directory where the generated python interface is stored
            for fmt in self.name_formats:
                yield os.path.abspath(os.path.join(os.path.dirname(__file__), fmt % libname))

            # now, use the ctypes tools to try to find the library
            for fmt in self.name_formats:
                path = ctypes.util.find_library(fmt % libname)
                if path:
                    yield path

            # then we search all paths identified as platform-specific lib paths
            for path in self.getplatformpaths(libname):
                yield path

            # Finally, we'll try the users current working directory
            for fmt in self.name_formats:
                yield os.path.abspath(os.path.join(os.path.curdir, fmt % libname))

    def getplatformpaths(self, libname):
        return []


# Darwin (Mac OS X)


class DarwinLibraryLoader(LibraryLoader):
    name_formats = [
        "lib%s.dylib",
        "lib%s.so",
        "lib%s.bundle",
        "%s.dylib",
        "%s.so",
        "%s.bundle",
        "%s",
    ]

    class Lookup(LibraryLoader.Lookup):
        # Darwin requires dlopen to be called with mode RTLD_GLOBAL instead
        # of the default RTLD_LOCAL.  Without this, you end up with
        # libraries not being loadable, resulting in "Symbol not found"
        # errors
        mode = ctypes.RTLD_GLOBAL

    def getplatformpaths(self, libname):
        if os.path.pathsep in libname:
            names = [libname]
        else:
            names = [format % libname for format in self.name_formats]

        for dir in self.getdirs(libname):
            for name in names:
                yield os.path.join(dir, name)

    def getdirs(self, libname):
        """Implements the dylib search as specified in Apple documentation:

        http://developer.apple.com/documentation/DeveloperTools/Conceptual/
            DynamicLibraries/Articles/DynamicLibraryUsageGuidelines.html

        Before commencing the standard search, the method first checks
        the bundle's ``Frameworks`` directory if the application is running
        within a bundle (OS X .app).
        """

        dyld_fallback_library_path = _environ_path("DYLD_FALLBACK_LIBRARY_PATH")
        if not dyld_fallback_library_path:
            dyld_fallback_library_path = [os.path.expanduser("~/lib"), "/usr/local/lib", "/usr/lib"]

        dirs = []

        if "/" in libname:
            dirs.extend(_environ_path("DYLD_LIBRARY_PATH"))
        else:
            dirs.extend(_environ_path("LD_LIBRARY_PATH"))
            dirs.extend(_environ_path("DYLD_LIBRARY_PATH"))

        if hasattr(sys, "frozen") and sys.frozen == "macosx_app":
            dirs.append(os.path.join(os.environ["RESOURCEPATH"], "..", "Frameworks"))

        dirs.extend(dyld_fallback_library_path)

        return dirs


# Posix


class PosixLibraryLoader(LibraryLoader):
    _ld_so_cache = None

    _include = re.compile(r"^\s*include\s+(?P<pattern>.*)")

    class _Directories(dict):
        def __init__(self):
            self.order = 0

        def add(self, directory):
            if len(directory) > 1:
                directory = directory.rstrip(os.path.sep)
            # only adds and updates order if exists and not already in set
            if not os.path.exists(directory):
                return
            o = self.setdefault(directory, self.order)
            if o == self.order:
                self.order += 1

        def extend(self, directories):
            for d in directories:
                self.add(d)

        def ordered(self):
            return (i[0] for i in sorted(self.items(), key=lambda D: D[1]))

    def _get_ld_so_conf_dirs(self, conf, dirs):
        """
        Recursive funtion to help parse all ld.so.conf files, including proper
        handling of the `include` directive.
        """

        try:
            with open(conf) as f:
                for D in f:
                    D = D.strip()
                    if not D:
                        continue

                    m = self._include.match(D)
                    if not m:
                        dirs.add(D)
                    else:
                        for D2 in glob.glob(m.group("pattern")):
                            self._get_ld_so_conf_dirs(D2, dirs)
        except IOError:
            pass

    def _create_ld_so_cache(self):
        # Recreate search path followed by ld.so.  This is going to be
        # slow to build, and incorrect (ld.so uses ld.so.cache, which may
        # not be up-to-date).  Used only as fallback for distros without
        # /sbin/ldconfig.
        #
        # We assume the DT_RPATH and DT_RUNPATH binary sections are omitted.

        directories = self._Directories()
        for name in (
            "LD_LIBRARY_PATH",
            "SHLIB_PATH",  # HPUX
            "LIBPATH",  # OS/2, AIX
            "LIBRARY_PATH",  # BE/OS
        ):
            if name in os.environ:
                directories.extend(os.environ[name].split(os.pathsep))

        self._get_ld_so_conf_dirs("/etc/ld.so.conf", directories)

        bitage = platform.architecture()[0]

        unix_lib_dirs_list = []
        if bitage.startswith("64"):
            # prefer 64 bit if that is our arch
            unix_lib_dirs_list += ["/lib64", "/usr/lib64"]

        # must include standard libs, since those paths are also used by 64 bit
        # installs
        unix_lib_dirs_list += ["/lib", "/usr/lib"]
        if sys.platform.startswith("linux"):
            # Try and support multiarch work in Ubuntu
            # https://wiki.ubuntu.com/MultiarchSpec
            if bitage.startswith("32"):
                # Assume Intel/AMD x86 compat
                unix_lib_dirs_list += ["/lib/i386-linux-gnu", "/usr/lib/i386-linux-gnu"]
            elif bitage.startswith("64"):
                # Assume Intel/AMD x86 compat
                unix_lib_dirs_list += ["/lib/x86_64-linux-gnu", "/usr/lib/x86_64-linux-gnu"]
            else:
                # guess...
                unix_lib_dirs_list += glob.glob("/lib/*linux-gnu")
        directories.extend(unix_lib_dirs_list)

        cache = {}
        lib_re = re.compile(r"lib(.*)\.s[ol]")
        ext_re = re.compile(r"\.s[ol]$")
        for dir in directories.ordered():
            try:
                for path in glob.glob("%s/*.s[ol]*" % dir):
                    file = os.path.basename(path)

                    # Index by filename
                    cache_i = cache.setdefault(file, set())
                    cache_i.add(path)

                    # Index by library name
                    match = lib_re.match(file)
                    if match:
                        library = match.group(1)
                        cache_i = cache.setdefault(library, set())
                        cache_i.add(path)
            except OSError:
                pass

        self._ld_so_cache = cache

    def getplatformpaths(self, libname):
        if self._ld_so_cache is None:
            self._create_ld_so_cache()

        result = self._ld_so_cache.get(libname, set())
        for i in result:
            # we iterate through all found paths for library, since we may have
            # actually found multiple architectures or other library types that
            # may not load
            yield i


# Windows


class WindowsLibraryLoader(LibraryLoader):
    name_formats = ["%s.dll", "lib%s.dll", "%slib.dll", "%s"]

    class Lookup(LibraryLoader.Lookup):
        def __init__(self, path):
            super(WindowsLibraryLoader.Lookup, self).__init__(path)
            self.access["stdcall"] = ctypes.windll.LoadLibrary(path)


# Platform switching

# If your value of sys.platform does not appear in this dict, please contact
# the Ctypesgen maintainers.

loaderclass = {
    "darwin": DarwinLibraryLoader,
    "cygwin": WindowsLibraryLoader,
    "win32": WindowsLibraryLoader,
    "msys": WindowsLibraryLoader,
}

load_library = loaderclass.get(sys.platform, PosixLibraryLoader)()


def add_library_search_dirs(other_dirs):
    """
    Add libraries to search paths.
    If library paths are relative, convert them to absolute with respect to this
    file's directory
    """
    for F in other_dirs:
        if not os.path.isabs(F):
            F = os.path.abspath(F)
        load_library.other_dirs.append(F)


del loaderclass

# End loader

add_library_search_dirs(['/usr/local/lib64/'])

# Begin libraries
_libs["libait_mil.so"] = load_library("libait_mil.so")

# 1 libraries
# End libraries

# No modules

M1553Int = c_int# /usr/local/include/ait_mil/m1553_cdef.h: 218

M1553UInt = c_uint# /usr/local/include/ait_mil/m1553_cdef.h: 222

M1553Char = c_char# /usr/local/include/ait_mil/m1553_cdef.h: 226

M1553UChar = c_ubyte# /usr/local/include/ait_mil/m1553_cdef.h: 230

M1553Double = c_double# /usr/local/include/ait_mil/m1553_cdef.h: 234

M1553Float = c_float# /usr/local/include/ait_mil/m1553_cdef.h: 238

M1553Addr = POINTER(None)# /usr/local/include/ait_mil/m1553_cdef.h: 242

M1553Boolean = c_ubyte# /usr/local/include/ait_mil/m1553_cdef.h: 246

M1553Return = c_int# /usr/local/include/ait_mil/m1553_cdef.h: 250

# /usr/local/include/ait_mil/m1553_cdef.h: 260
class struct_anon_2(Structure):
    pass

struct_anon_2.__slots__ = [
    'value',
]
struct_anon_2._fields_ = [
    ('value', POINTER(None)),
]

M1553Handle = struct_anon_2# /usr/local/include/ait_mil/m1553_cdef.h: 260

M1553_DEVICE_HANDLE = POINTER(None)# /usr/local/include/ait_mil/m1553_cdef.h: 262

enum_anon_3 = c_int# /usr/local/include/ait_mil/m1553_common.h: 111

M1553_BUFFER_BC_MESSAGE = 1# /usr/local/include/ait_mil/m1553_common.h: 111

M1553_BUFFER_RT_MESSAGE = 2# /usr/local/include/ait_mil/m1553_common.h: 111

M1553BufferHeaderType = enum_anon_3# /usr/local/include/ait_mil/m1553_common.h: 111

enum_anon_4 = c_int# /usr/local/include/ait_mil/m1553_common.h: 156

M1553_QUEUE_SIZE_1 = 0# /usr/local/include/ait_mil/m1553_common.h: 156

M1553_QUEUE_SIZE_2 = 1# /usr/local/include/ait_mil/m1553_common.h: 156

M1553_QUEUE_SIZE_4 = 2# /usr/local/include/ait_mil/m1553_common.h: 156

M1553_QUEUE_SIZE_8 = 3# /usr/local/include/ait_mil/m1553_common.h: 156

M1553_QUEUE_SIZE_16 = 4# /usr/local/include/ait_mil/m1553_common.h: 156

M1553_QUEUE_SIZE_32 = 5# /usr/local/include/ait_mil/m1553_common.h: 156

M1553_QUEUE_SIZE_64 = 6# /usr/local/include/ait_mil/m1553_common.h: 156

M1553_QUEUE_SIZE_128 = 7# /usr/local/include/ait_mil/m1553_common.h: 156

M1553_QUEUE_SIZE_256 = 8# /usr/local/include/ait_mil/m1553_common.h: 156

M1553QueueSizeType = enum_anon_4# /usr/local/include/ait_mil/m1553_common.h: 156

enum_anon_5 = c_int# /usr/local/include/ait_mil/m1553_common.h: 182

M1553_QUEUE_CYCLIC = 0# /usr/local/include/ait_mil/m1553_common.h: 182

M1553_QUEUE_REUSE_LAST = 1# /usr/local/include/ait_mil/m1553_common.h: 182

M1553_QUEUE_HOST_CONTROLLED = 2# /usr/local/include/ait_mil/m1553_common.h: 182

M1553QueueModeType = enum_anon_5# /usr/local/include/ait_mil/m1553_common.h: 182

enum_anon_6 = c_int# /usr/local/include/ait_mil/m1553_common.h: 211

M1553_RX_BUFFER_DISCARD_ERROR = 0# /usr/local/include/ait_mil/m1553_common.h: 211

M1553_RX_BUFFER_KEEP_ERROR = 1# /usr/local/include/ait_mil/m1553_common.h: 211

M1553_TX_BUFFER_KEEP_DATA_ON_ERROR = 0# /usr/local/include/ait_mil/m1553_common.h: 211

M1553_TX_BUFFER_USE_DATA_ON_ERROR = 1# /usr/local/include/ait_mil/m1553_common.h: 211

M1553BufferStoreModeType = enum_anon_6# /usr/local/include/ait_mil/m1553_common.h: 211

# /usr/local/include/ait_mil/m1553_common.h: 352
class struct_anon_7(Structure):
    pass

struct_anon_7.__slots__ = [
    'mLogListWordA',
    'mLogListWordB',
    'mLogListWordC',
    'mLogListWordD',
]
struct_anon_7._fields_ = [
    ('mLogListWordA', c_uint32),
    ('mLogListWordB', c_uint32),
    ('mLogListWordC', c_uint32),
    ('mLogListWordD', c_uint32),
]

M1553InterruptLoglistEntryType = struct_anon_7# /usr/local/include/ait_mil/m1553_common.h: 352

enum_anon_8 = c_int# /usr/local/include/ait_mil/m1553_common.h: 375

M1553_RT_RECEIVE_SA = 0# /usr/local/include/ait_mil/m1553_common.h: 375

M1553_RT_TRANSMIT_SA = 1# /usr/local/include/ait_mil/m1553_common.h: 375

M1553_RT_RECEIVE_MODECODE = 2# /usr/local/include/ait_mil/m1553_common.h: 375

M1553_RT_TRANSMIT_MODECODE = 3# /usr/local/include/ait_mil/m1553_common.h: 375

M1553SubAddressType = enum_anon_8# /usr/local/include/ait_mil/m1553_common.h: 375

enum_anon_9 = c_int# /usr/local/include/ait_mil/m1553_common.h: 392

M1553_STATUS_QUEUE_SIZE_ONE = 1# /usr/local/include/ait_mil/m1553_common.h: 392

M1553_STATUS_QUEUE_ONE_PER_BUFFER = 2# /usr/local/include/ait_mil/m1553_common.h: 392

M1553StatusQueueModeType = enum_anon_9# /usr/local/include/ait_mil/m1553_common.h: 392

# /usr/local/include/ait_mil/m1553_common.h: 454
class struct_anon_10(Structure):
    pass

struct_anon_10.__slots__ = [
    'mBufferID',
    'mStatusQueueID',
    'mEventQueueID',
    'mQueueSize',
    'mBufferQueueMode',
    'mBufferStoreMode',
    'mStatusQueueMode',
    'mEventQueueMode',
]
struct_anon_10._fields_ = [
    ('mBufferID', c_uint16),
    ('mStatusQueueID', c_uint16),
    ('mEventQueueID', c_uint16),
    ('mQueueSize', M1553QueueSizeType),
    ('mBufferQueueMode', M1553QueueModeType),
    ('mBufferStoreMode', M1553BufferStoreModeType),
    ('mStatusQueueMode', M1553StatusQueueModeType),
    ('mEventQueueMode', c_uint8),
]

M1553BufferHeaderDefinitionType = struct_anon_10# /usr/local/include/ait_mil/m1553_common.h: 454

enum_anon_11 = c_int# /usr/local/include/ait_mil/m1553_common.h: 469

M1553_BUS_PRIMARY = 1# /usr/local/include/ait_mil/m1553_common.h: 469

M1553_BUS_SECONDARY = 2# /usr/local/include/ait_mil/m1553_common.h: 469

M1553BusType = enum_anon_11# /usr/local/include/ait_mil/m1553_common.h: 469

enum_anon_12 = c_int# /usr/local/include/ait_mil/m1553_common.h: 488

M1553_BUFFER_NOT_USED = 0# /usr/local/include/ait_mil/m1553_common.h: 488

M1553_BUFFER_FULL = 1# /usr/local/include/ait_mil/m1553_common.h: 488

M1553_BUFFER_EMPTY = 2# /usr/local/include/ait_mil/m1553_common.h: 488

M1553BufferFillStatusType = enum_anon_12# /usr/local/include/ait_mil/m1553_common.h: 488

# /usr/local/include/ait_mil/m1553_common.h: 526
class struct_anon_13(Structure):
    pass

struct_anon_13.__slots__ = [
    'mDays',
    'mHour',
    'mMin',
    'mSec',
    'mMilliseconds',
    'mMicroseconds',
]
struct_anon_13._fields_ = [
    ('mDays', c_uint16),
    ('mHour', c_uint8),
    ('mMin', c_uint8),
    ('mSec', c_uint8),
    ('mMilliseconds', c_uint32),
    ('mMicroseconds', c_uint32),
]

M1553IrigTimeType = struct_anon_13# /usr/local/include/ait_mil/m1553_common.h: 526

enum_anon_14 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 84

M1553_BC_TRANSFER = 1# /usr/local/include/ait_mil/m1553_bc.h: 84

M1553_BC_SKIP = 2# /usr/local/include/ait_mil/m1553_bc.h: 84

M1553_BC_WAIT = 3# /usr/local/include/ait_mil/m1553_bc.h: 84

M1553_BC_STROBE = 4# /usr/local/include/ait_mil/m1553_bc.h: 84

M1553_BC_WAIT_FOR_EXTERNAL = 5# /usr/local/include/ait_mil/m1553_bc.h: 84

M1553_BC_CHANGE_MF_TIME = 6# /usr/local/include/ait_mil/m1553_bc.h: 84

M1553BCInstructionType = enum_anon_14# /usr/local/include/ait_mil/m1553_bc.h: 84

enum_anon_15 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 109

M1553_BC_RETRY_DISABLED = 0# /usr/local/include/ait_mil/m1553_bc.h: 109

M1553_BC_RETRY_ALTERNATE = 1# /usr/local/include/ait_mil/m1553_bc.h: 109

M1553_BC_RETRY_SAME_ALTERNATE = 2# /usr/local/include/ait_mil/m1553_bc.h: 109

M1553_BC_RETRY_2SAME_ALTERNATE = 3# /usr/local/include/ait_mil/m1553_bc.h: 109

M1553RetryType = enum_anon_15# /usr/local/include/ait_mil/m1553_bc.h: 109

enum_anon_16 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 126

M1553_BC_TRANSFER_SPECIFIC_BUS = 0# /usr/local/include/ait_mil/m1553_bc.h: 126

M1553_BC_GLOBAL_BUS = 1# /usr/local/include/ait_mil/m1553_bc.h: 126

M1553BCTransferBusModeType = enum_anon_16# /usr/local/include/ait_mil/m1553_bc.h: 126

enum_anon_17 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 145

M1553_BC_TO_RT = 0# /usr/local/include/ait_mil/m1553_bc.h: 145

M1553_RT_TO_BC = 1# /usr/local/include/ait_mil/m1553_bc.h: 145

M1553_RT_TO_RT = 2# /usr/local/include/ait_mil/m1553_bc.h: 145

M1553TransferType = enum_anon_17# /usr/local/include/ait_mil/m1553_bc.h: 145

enum_anon_18 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 168

M1553_BC_INTERRUPT_DISABLED = 0# /usr/local/include/ait_mil/m1553_bc.h: 168

M1553_BC_INTERRUPT_ON_TRANSFER_END = 1# /usr/local/include/ait_mil/m1553_bc.h: 168

M1553_BC_INTERRUPT_ON_TRANSFER_ERROR = 2# /usr/local/include/ait_mil/m1553_bc.h: 168

M1553_BC_INTERRUPT_ON_STATUS_EXCEPTION = 3# /usr/local/include/ait_mil/m1553_bc.h: 168

M1553BusControllerInterruptType = enum_anon_18# /usr/local/include/ait_mil/m1553_bc.h: 168

enum_anon_19 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 195

M1553_BC_DONT_STOP = 0# /usr/local/include/ait_mil/m1553_bc.h: 195

M1553_BC_STOP_ON_TRANSFER_ERROR = 1# /usr/local/include/ait_mil/m1553_bc.h: 195

M1553_BC_STOP_ON_STATUS_EXCEPTION = 2# /usr/local/include/ait_mil/m1553_bc.h: 195

M1553_BC_STOP_ON_ERROR_AND_STATUS_EXCEPT = 3# /usr/local/include/ait_mil/m1553_bc.h: 195

M1553_BC_STOP_ON_INTERRUPT = 4# /usr/local/include/ait_mil/m1553_bc.h: 195

M1553BCStopType = enum_anon_19# /usr/local/include/ait_mil/m1553_bc.h: 195

enum_anon_20 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 215

M1553_EXCEPTION_HANDLING_DISABLED = 0# /usr/local/include/ait_mil/m1553_bc.h: 215

M1553_EXCEPTION_HANDLING_ENABLED = 1# /usr/local/include/ait_mil/m1553_bc.h: 215

M1553StatusWordExceptionHandlingType = enum_anon_20# /usr/local/include/ait_mil/m1553_bc.h: 215

enum_anon_21 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 242

M1553_BC_RESPONSE_AUTOMATIC = 0# /usr/local/include/ait_mil/m1553_bc.h: 242

M1553_BC_RESPONSE_NO_SW1_EXPECTED = 1# /usr/local/include/ait_mil/m1553_bc.h: 242

M1553_BC_RESPONSE_NO_SW2_EXPECTED = 2# /usr/local/include/ait_mil/m1553_bc.h: 242

M1553ResponseType = enum_anon_21# /usr/local/include/ait_mil/m1553_bc.h: 242

enum_anon_22 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 277

M1553_BC_GAP_MODE_DELAY = 0# /usr/local/include/ait_mil/m1553_bc.h: 277

M1553_BC_GAP_MODE_STANDARD = 1# /usr/local/include/ait_mil/m1553_bc.h: 277

M1553_BC_GAP_MODE_FAST = 2# /usr/local/include/ait_mil/m1553_bc.h: 277

M1553GapModeType = enum_anon_22# /usr/local/include/ait_mil/m1553_bc.h: 277

enum_anon_23 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_DISABLED = 0# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_CMD_SYNC = 1# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_DATA_SYNC = 2# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_PARITY = 3# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_MANCHESTER_LOW = 4# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_MANCHESTER_HIGH = 5# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_GAP = 6# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_WORD_COUNT_HIGH = 7# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_WORD_COUNT_LOW = 8# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_BIT_COUNT_HIGH = 9# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_BIT_COUNT_LOW = 10# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_ZERO_CROSSING_NEGATIVE = 11# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_ZERO_CROSSING_POSITIVE = 12# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553_BC_ERROR_BUS_SWITCH = 13# /usr/local/include/ait_mil/m1553_bc.h: 353

M1553BCTransferErrorType = enum_anon_23# /usr/local/include/ait_mil/m1553_bc.h: 353

enum_anon_24 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 369

M1553_BC_ACYCLIC_SEND_IMMEDIATELY = 0# /usr/local/include/ait_mil/m1553_bc.h: 369

M1553_BC_ACYCLIC_SEND_AT_TIME = 1# /usr/local/include/ait_mil/m1553_bc.h: 369

M1553BCAcyclicSendModeType = enum_anon_24# /usr/local/include/ait_mil/m1553_bc.h: 369

enum_anon_25 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 416

M1553_BC_START_IMMEDIATELY = 0# /usr/local/include/ait_mil/m1553_bc.h: 416

M1553_BC_START_ON_STROBE = 1# /usr/local/include/ait_mil/m1553_bc.h: 416

M1553_BC_START_ON_MODECODE = 2# /usr/local/include/ait_mil/m1553_bc.h: 416

M1553_BC_START_MINOR_FRAME_ON_STROBE = 3# /usr/local/include/ait_mil/m1553_bc.h: 416

M1553_BC_START_SETUP = 4# /usr/local/include/ait_mil/m1553_bc.h: 416

M1553_BC_START_FAST = 5# /usr/local/include/ait_mil/m1553_bc.h: 416

M1553_BC_START_INSTRUCTION = 6# /usr/local/include/ait_mil/m1553_bc.h: 416

M1553BCTransferStartModeType = enum_anon_25# /usr/local/include/ait_mil/m1553_bc.h: 416

enum_anon_26 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 434

M1553_MODE_CODE_SYNCHRONIZE_WITH_DATA = 0# /usr/local/include/ait_mil/m1553_bc.h: 434

M1553_MODE_CODE_DYNAMIC_BUS_CONTROL = 1# /usr/local/include/ait_mil/m1553_bc.h: 434

M1553BCModeCodeType = enum_anon_26# /usr/local/include/ait_mil/m1553_bc.h: 434

# /usr/local/include/ait_mil/m1553_bc.h: 509
class struct_anon_27(Structure):
    pass

struct_anon_27.__slots__ = [
    'mTransferErrorType',
    'mErrorWordPosition',
    'mErrorBitPosition',
    'mErrorBitCount',
    'mSyncBitPattern',
    'mParameter',
]
struct_anon_27._fields_ = [
    ('mTransferErrorType', M1553BCTransferErrorType),
    ('mErrorWordPosition', c_uint8),
    ('mErrorBitPosition', c_uint8),
    ('mErrorBitCount', c_uint8),
    ('mSyncBitPattern', c_uint8),
    ('mParameter', c_uint8),
]

M1553BCTransferErrorConfigType = struct_anon_27# /usr/local/include/ait_mil/m1553_bc.h: 509

# /usr/local/include/ait_mil/m1553_bc.h: 621
class struct_anon_28(Structure):
    pass

struct_anon_28.__slots__ = [
    'mBufferHeaderID',
    'mTransferType',
    'mBus',
    'mTransmitRT',
    'mReceiveRT',
    'mTransmitSA',
    'mReceiveSA',
    'mWordCount',
    'mInterruptControl',
    'mStopControl',
    'mRetryEnabled',
    'mStatusWordExceptionHandling',
    'mExpectedResponse',
    'mGapModeType',
    'mGapTime',
    'mStatusWordExceptionMask',
    'mBCTransferError',
]
struct_anon_28._fields_ = [
    ('mBufferHeaderID', c_uint16),
    ('mTransferType', M1553TransferType),
    ('mBus', M1553BusType),
    ('mTransmitRT', c_uint8),
    ('mReceiveRT', c_uint8),
    ('mTransmitSA', c_uint8),
    ('mReceiveSA', c_uint8),
    ('mWordCount', c_uint8),
    ('mInterruptControl', M1553BusControllerInterruptType),
    ('mStopControl', M1553BCStopType),
    ('mRetryEnabled', M1553Boolean),
    ('mStatusWordExceptionHandling', M1553StatusWordExceptionHandlingType),
    ('mExpectedResponse', M1553ResponseType),
    ('mGapModeType', M1553GapModeType),
    ('mGapTime', M1553Float),
    ('mStatusWordExceptionMask', c_uint16),
    ('mBCTransferError', M1553BCTransferErrorConfigType),
]

M1553BCTransferType = struct_anon_28# /usr/local/include/ait_mil/m1553_bc.h: 621

# /usr/local/include/ait_mil/m1553_bc.h: 652
class struct_anon_29(Structure):
    pass

struct_anon_29.__slots__ = [
    'mBufferHeader',
    'mHeaderOffset',
    'mBufferOffset',
    'mStatusQueueOffset',
    'mEventQueueOffset',
]
struct_anon_29._fields_ = [
    ('mBufferHeader', M1553BufferHeaderDefinitionType),
    ('mHeaderOffset', c_uint32),
    ('mBufferOffset', c_uint32),
    ('mStatusQueueOffset', c_uint32),
    ('mEventQueueOffset', c_uint32),
]

M1553BCGetBufferHeaderOut = struct_anon_29# /usr/local/include/ait_mil/m1553_bc.h: 652

# /usr/local/include/ait_mil/m1553_bc.h: 664
class struct_anon_30(Structure):
    pass

struct_anon_30.__slots__ = [
    'mBufferHeader',
]
struct_anon_30._fields_ = [
    ('mBufferHeader', M1553BufferHeaderDefinitionType),
]

M1553BCSetBufferHeaderIn = struct_anon_30# /usr/local/include/ait_mil/m1553_bc.h: 664

# /usr/local/include/ait_mil/m1553_bc.h: 680
class struct_anon_31(Structure):
    pass

struct_anon_31.__slots__ = [
    'mBufferHeaderIndex',
    'mBufferHeaderOffset',
]
struct_anon_31._fields_ = [
    ('mBufferHeaderIndex', c_uint32),
    ('mBufferHeaderOffset', c_uint32),
]

M1553BCTransferGetBufferHeaderOut = struct_anon_31# /usr/local/include/ait_mil/m1553_bc.h: 680

# /usr/local/include/ait_mil/m1553_bc.h: 692
class struct_anon_32(Structure):
    pass

struct_anon_32.__slots__ = [
    'mTransfer',
]
struct_anon_32._fields_ = [
    ('mTransfer', M1553BCTransferType),
]

M1553BCSetTransferIn = struct_anon_32# /usr/local/include/ait_mil/m1553_bc.h: 692

# /usr/local/include/ait_mil/m1553_bc.h: 707
class struct_anon_33(Structure):
    pass

struct_anon_33.__slots__ = [
    'mTransfer',
    'mTransferOffset',
]
struct_anon_33._fields_ = [
    ('mTransfer', M1553BCTransferType),
    ('mTransferOffset', c_uint32),
]

M1553BCGetTransferOut = struct_anon_33# /usr/local/include/ait_mil/m1553_bc.h: 707

# /usr/local/include/ait_mil/m1553_bc.h: 724
class struct_anon_34(Structure):
    pass

struct_anon_34.__slots__ = [
    'mRT',
    'mSA',
]
struct_anon_34._fields_ = [
    ('mRT', c_uint8),
    ('mSA', c_uint8),
]

M1553BCSetVectorWordSubaddressIn = struct_anon_34# /usr/local/include/ait_mil/m1553_bc.h: 724

# /usr/local/include/ait_mil/m1553_bc.h: 754
class struct_anon_35(Structure):
    pass

struct_anon_35.__slots__ = [
    'mStartMode',
    'mCount',
    'mFrameTime',
    'mStartAddress',
]
struct_anon_35._fields_ = [
    ('mStartMode', M1553BCTransferStartModeType),
    ('mCount', c_uint32),
    ('mFrameTime', M1553Float),
    ('mStartAddress', c_uint32),
]

M1553BCStartIn = struct_anon_35# /usr/local/include/ait_mil/m1553_bc.h: 754

# /usr/local/include/ait_mil/m1553_bc.h: 765
class struct_anon_36(Structure):
    pass

struct_anon_36.__slots__ = [
    'mEnabled',
]
struct_anon_36._fields_ = [
    ('mEnabled', M1553Boolean),
]

M1553BCTransferSetEnableIn = struct_anon_36# /usr/local/include/ait_mil/m1553_bc.h: 765

# /usr/local/include/ait_mil/m1553_bc.h: 776
class struct_anon_37(Structure):
    pass

struct_anon_37.__slots__ = [
    'mEnabled',
]
struct_anon_37._fields_ = [
    ('mEnabled', M1553Boolean),
]

M1553BCTransferGetEnableOut = struct_anon_37# /usr/local/include/ait_mil/m1553_bc.h: 776

# /usr/local/include/ait_mil/m1553_bc.h: 797
class struct_anon_38(Structure):
    pass

struct_anon_38.__slots__ = [
    'mBCModecode',
    'mEnable',
    'mTransferID',
]
struct_anon_38._fields_ = [
    ('mBCModecode', M1553BCModeCodeType),
    ('mEnable', M1553Boolean),
    ('mTransferID', c_uint16),
]

M1553ModeCodeSetEnableIn = struct_anon_38# /usr/local/include/ait_mil/m1553_bc.h: 797

# /usr/local/include/ait_mil/m1553_bc.h: 808
class struct_anon_39(Structure):
    pass

struct_anon_39.__slots__ = [
    'mBCModecode',
]
struct_anon_39._fields_ = [
    ('mBCModecode', M1553BCModeCodeType),
]

M1553ModeCodeGetEnableIn = struct_anon_39# /usr/local/include/ait_mil/m1553_bc.h: 808

# /usr/local/include/ait_mil/m1553_bc.h: 824
class struct_anon_40(Structure):
    pass

struct_anon_40.__slots__ = [
    'mEnable',
    'mTransferID',
]
struct_anon_40._fields_ = [
    ('mEnable', M1553Boolean),
    ('mTransferID', c_uint16),
]

M1553ModeCodeGetEnableOut = struct_anon_40# /usr/local/include/ait_mil/m1553_bc.h: 824

# /usr/local/include/ait_mil/m1553_bc.h: 858
class struct_anon_41(Structure):
    pass

struct_anon_41.__slots__ = [
    'mCount',
    'mInstructionType',
    'mInstructionParameter',
]
struct_anon_41._fields_ = [
    ('mCount', c_uint8),
    ('mInstructionType', M1553BCInstructionType * int(128)),
    ('mInstructionParameter', c_uint16 * int(128)),
]

M1553BCMinorFrameType = struct_anon_41# /usr/local/include/ait_mil/m1553_bc.h: 858

# /usr/local/include/ait_mil/m1553_bc.h: 869
class struct_anon_42(Structure):
    pass

struct_anon_42.__slots__ = [
    'mMinorFrame',
]
struct_anon_42._fields_ = [
    ('mMinorFrame', M1553BCMinorFrameType),
]

M1553BCSetMinorFrameIn = struct_anon_42# /usr/local/include/ait_mil/m1553_bc.h: 869

# /usr/local/include/ait_mil/m1553_bc.h: 880
class struct_anon_43(Structure):
    pass

struct_anon_43.__slots__ = [
    'mMinorFrame',
]
struct_anon_43._fields_ = [
    ('mMinorFrame', M1553BCMinorFrameType),
]

M1553BCGetMinorFrameOut = struct_anon_43# /usr/local/include/ait_mil/m1553_bc.h: 880

# /usr/local/include/ait_mil/m1553_bc.h: 897
class struct_anon_44(Structure):
    pass

struct_anon_44.__slots__ = [
    'mCount',
    'mMinorFrameIDs',
]
struct_anon_44._fields_ = [
    ('mCount', c_uint8),
    ('mMinorFrameIDs', c_uint8 * int(64)),
]

M1553BCMajorFrameType = struct_anon_44# /usr/local/include/ait_mil/m1553_bc.h: 897

# /usr/local/include/ait_mil/m1553_bc.h: 908
class struct_anon_45(Structure):
    pass

struct_anon_45.__slots__ = [
    'mMajorFrame',
]
struct_anon_45._fields_ = [
    ('mMajorFrame', M1553BCMajorFrameType),
]

M1553BCSetMajorFrameIn = struct_anon_45# /usr/local/include/ait_mil/m1553_bc.h: 908

# /usr/local/include/ait_mil/m1553_bc.h: 927
class struct_anon_46(Structure):
    pass

struct_anon_46.__slots__ = [
    'mMajorFrame',
    'mOffset',
]
struct_anon_46._fields_ = [
    ('mMajorFrame', M1553BCMajorFrameType),
    ('mOffset', c_uint32),
]

M1553BCGetMajorFrameOut = struct_anon_46# /usr/local/include/ait_mil/m1553_bc.h: 927

# /usr/local/include/ait_mil/m1553_bc.h: 938
class struct_anon_47(Structure):
    pass

struct_anon_47.__slots__ = [
    'mAcyclicFrame',
]
struct_anon_47._fields_ = [
    ('mAcyclicFrame', M1553BCMinorFrameType),
]

M1553BCSetAcyclicFrameIn = struct_anon_47# /usr/local/include/ait_mil/m1553_bc.h: 938

# /usr/local/include/ait_mil/m1553_bc.h: 949
class struct_anon_48(Structure):
    pass

struct_anon_48.__slots__ = [
    'mAcyclicFrame',
]
struct_anon_48._fields_ = [
    ('mAcyclicFrame', M1553BCMinorFrameType),
]

M1553BCGetAcyclicFrameOut = struct_anon_48# /usr/local/include/ait_mil/m1553_bc.h: 949

# /usr/local/include/ait_mil/m1553_bc.h: 968
class struct_anon_49(Structure):
    pass

struct_anon_49.__slots__ = [
    'mSendMode',
    'mTimeTag',
]
struct_anon_49._fields_ = [
    ('mSendMode', M1553BCAcyclicSendModeType),
    ('mTimeTag', M1553IrigTimeType),
]

M1553BCAcyclicFrameSendIn = struct_anon_49# /usr/local/include/ait_mil/m1553_bc.h: 968

# /usr/local/include/ait_mil/m1553_bc.h: 1007
class struct_anon_50(Structure):
    pass

struct_anon_50.__slots__ = [
    'mBCRunning',
    'mStopInfo',
    'mMessageCount',
    'mErrorCount',
    'mInstructionListOffset',
    'mMajorFrameCount',
]
struct_anon_50._fields_ = [
    ('mBCRunning', M1553Boolean),
    ('mStopInfo', c_uint16),
    ('mMessageCount', c_uint32),
    ('mErrorCount', c_uint32),
    ('mInstructionListOffset', c_uint32),
    ('mMajorFrameCount', c_uint32),
]

M1553BCGetStatusOut = struct_anon_50# /usr/local/include/ait_mil/m1553_bc.h: 1007

enum_anon_51 = c_int# /usr/local/include/ait_mil/m1553_bc.h: 1030

M1553_BC_BUFFER_NO_ERROR = 0# /usr/local/include/ait_mil/m1553_bc.h: 1030

M1553_BC_BUFFER_FRAME_CODING_ERROR = 1# /usr/local/include/ait_mil/m1553_bc.h: 1030

M1553_BC_BUFFER_NO_SW1_ERROR = 2# /usr/local/include/ait_mil/m1553_bc.h: 1030

M1553_BC_BUFFER_NO_SW2_ERROR = 3# /usr/local/include/ait_mil/m1553_bc.h: 1030

M1553BCBufferErrorStatusType = enum_anon_51# /usr/local/include/ait_mil/m1553_bc.h: 1030

# /usr/local/include/ait_mil/m1553_bc.h: 1050
class struct_anon_52(Structure):
    pass

struct_anon_52.__slots__ = [
    'mBufferFillStatus',
    'mReceivedBus',
    'mBufferError',
]
struct_anon_52._fields_ = [
    ('mBufferFillStatus', M1553BufferFillStatusType),
    ('mReceivedBus', M1553BusType),
    ('mBufferError', M1553BCBufferErrorStatusType),
]

M1553BCBufferStatusType = struct_anon_52# /usr/local/include/ait_mil/m1553_bc.h: 1050

# /usr/local/include/ait_mil/m1553_bc.h: 1118
class struct_anon_53(Structure):
    pass

struct_anon_53.__slots__ = [
    'mCommandWord1',
    'mStatusWord1',
    'mCommandWord2',
    'mStatusWord2',
    'mCurrentBufferID',
    'mLastBufferOffset',
    'mBufferStatus',
    'mTimeTagMinutes',
    'mTimeTagSeconds',
    'mTimeTagMicroseconds',
    'mMessageCount',
    'mErrorCount',
    'mLastVectorWord',
    'mServiceRequestCount',
]
struct_anon_53._fields_ = [
    ('mCommandWord1', c_uint16),
    ('mStatusWord1', c_uint16),
    ('mCommandWord2', c_uint16),
    ('mStatusWord2', c_uint16),
    ('mCurrentBufferID', c_uint16),
    ('mLastBufferOffset', c_uint32),
    ('mBufferStatus', M1553BCBufferStatusType),
    ('mTimeTagMinutes', c_uint8),
    ('mTimeTagSeconds', c_uint8),
    ('mTimeTagMicroseconds', c_uint32),
    ('mMessageCount', c_uint32),
    ('mErrorCount', c_uint32),
    ('mLastVectorWord', c_uint32),
    ('mServiceRequestCount', c_uint32),
]

M1553BCGetTransferStatusOut = struct_anon_53# /usr/local/include/ait_mil/m1553_bc.h: 1118

# /usr/local/include/ait_mil/m1553_bc.h: 1138
class struct_anon_54(Structure):
    pass

struct_anon_54.__slots__ = [
    'mResetBufferErrorStatus',
    'mResetBufferStatus',
]
struct_anon_54._fields_ = [
    ('mResetBufferErrorStatus', M1553Boolean),
    ('mResetBufferStatus', M1553Boolean),
]

M1553BCGetTransferStatusIn = struct_anon_54# /usr/local/include/ait_mil/m1553_bc.h: 1138

# /usr/local/include/ait_mil/m1553_bc.h: 1159
class struct_anon_55(Structure):
    pass

struct_anon_55.__slots__ = [
    'mTransferId',
    'mLastVectorWord',
    'mServiceRequestCount',
]
struct_anon_55._fields_ = [
    ('mTransferId', c_uint16),
    ('mLastVectorWord', c_uint16),
    ('mServiceRequestCount', c_uint32),
]

M1553BCVectorWordStatusType = struct_anon_55# /usr/local/include/ait_mil/m1553_bc.h: 1159

# /usr/local/include/ait_mil/m1553_bc.h: 1176
class struct_anon_56(Structure):
    pass

struct_anon_56.__slots__ = [
    'mRT',
    'mResetServiceRequests',
]
struct_anon_56._fields_ = [
    ('mRT', c_uint8),
    ('mResetServiceRequests', M1553Boolean),
]

M1553BCGetVectorWordStatusIn = struct_anon_56# /usr/local/include/ait_mil/m1553_bc.h: 1176

# /usr/local/include/ait_mil/m1553_bc.h: 1187
class struct_anon_57(Structure):
    pass

struct_anon_57.__slots__ = [
    'mVectorWordStatus',
]
struct_anon_57._fields_ = [
    ('mVectorWordStatus', M1553BCVectorWordStatusType),
]

M1553BCGetVectorWordStatusOut = struct_anon_57# /usr/local/include/ait_mil/m1553_bc.h: 1187

# /usr/local/include/ait_mil/m1553_bc.h: 1217
class struct_anon_58(Structure):
    pass

struct_anon_58.__slots__ = [
    'mRetryOption',
    'mServiceRequestVectorEnabled',
    'mGlobalBusMode',
    'mGlobalStartBus',
]
struct_anon_58._fields_ = [
    ('mRetryOption', M1553RetryType),
    ('mServiceRequestVectorEnabled', M1553Boolean),
    ('mGlobalBusMode', M1553BCTransferBusModeType),
    ('mGlobalStartBus', M1553BusType),
]

M1553BCGetConfigOut = struct_anon_58# /usr/local/include/ait_mil/m1553_bc.h: 1217

# /usr/local/include/ait_mil/m1553_bc.h: 1247
class struct_anon_59(Structure):
    pass

struct_anon_59.__slots__ = [
    'mRetryOption',
    'mServiceRequestVectorEnabled',
    'mGlobalBusMode',
    'mGlobalStartBus',
]
struct_anon_59._fields_ = [
    ('mRetryOption', M1553RetryType),
    ('mServiceRequestVectorEnabled', M1553Boolean),
    ('mGlobalBusMode', M1553BCTransferBusModeType),
    ('mGlobalStartBus', M1553BusType),
]

M1553BCSetConfigIn = struct_anon_59# /usr/local/include/ait_mil/m1553_bc.h: 1247

# /usr/local/include/ait_mil/m1553_bc.h: 1299
if _libs["libait_mil.so"].has("m1553BCInit", "cdecl"):
    m1553BCInit = _libs["libait_mil.so"].get("m1553BCInit", "cdecl")
    m1553BCInit.argtypes = [M1553Handle]
    m1553BCInit.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1343
if _libs["libait_mil.so"].has("m1553BCSetConfig", "cdecl"):
    m1553BCSetConfig = _libs["libait_mil.so"].get("m1553BCSetConfig", "cdecl")
    m1553BCSetConfig.argtypes = [M1553Handle, POINTER(M1553BCSetConfigIn)]
    m1553BCSetConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1369
if _libs["libait_mil.so"].has("m1553BCGetConfig", "cdecl"):
    m1553BCGetConfig = _libs["libait_mil.so"].get("m1553BCGetConfig", "cdecl")
    m1553BCGetConfig.argtypes = [M1553Handle, POINTER(M1553BCGetConfigOut)]
    m1553BCGetConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1422
if _libs["libait_mil.so"].has("m1553BCSetBufferHeader", "cdecl"):
    m1553BCSetBufferHeader = _libs["libait_mil.so"].get("m1553BCSetBufferHeader", "cdecl")
    m1553BCSetBufferHeader.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCSetBufferHeaderIn)]
    m1553BCSetBufferHeader.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1460
if _libs["libait_mil.so"].has("m1553BCGetBufferHeader", "cdecl"):
    m1553BCGetBufferHeader = _libs["libait_mil.so"].get("m1553BCGetBufferHeader", "cdecl")
    m1553BCGetBufferHeader.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCGetBufferHeaderOut)]
    m1553BCGetBufferHeader.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1493
if _libs["libait_mil.so"].has("m1553BCTransferGetBufferHeaderIndex", "cdecl"):
    m1553BCTransferGetBufferHeaderIndex = _libs["libait_mil.so"].get("m1553BCTransferGetBufferHeaderIndex", "cdecl")
    m1553BCTransferGetBufferHeaderIndex.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCTransferGetBufferHeaderOut)]
    m1553BCTransferGetBufferHeaderIndex.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1594
if _libs["libait_mil.so"].has("m1553BCSetTransfer", "cdecl"):
    m1553BCSetTransfer = _libs["libait_mil.so"].get("m1553BCSetTransfer", "cdecl")
    m1553BCSetTransfer.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCSetTransferIn)]
    m1553BCSetTransfer.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1627
if _libs["libait_mil.so"].has("m1553BCGetTransfer", "cdecl"):
    m1553BCGetTransfer = _libs["libait_mil.so"].get("m1553BCGetTransfer", "cdecl")
    m1553BCGetTransfer.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCGetTransferOut)]
    m1553BCGetTransfer.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1667
if _libs["libait_mil.so"].has("m1553BCSetVectorWordSubaddress", "cdecl"):
    m1553BCSetVectorWordSubaddress = _libs["libait_mil.so"].get("m1553BCSetVectorWordSubaddress", "cdecl")
    m1553BCSetVectorWordSubaddress.argtypes = [M1553Handle, POINTER(M1553BCSetVectorWordSubaddressIn)]
    m1553BCSetVectorWordSubaddress.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1712
if _libs["libait_mil.so"].has("m1553BCStart", "cdecl"):
    m1553BCStart = _libs["libait_mil.so"].get("m1553BCStart", "cdecl")
    m1553BCStart.argtypes = [M1553Handle, POINTER(M1553BCStartIn)]
    m1553BCStart.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1733
if _libs["libait_mil.so"].has("m1553BCStop", "cdecl"):
    m1553BCStop = _libs["libait_mil.so"].get("m1553BCStop", "cdecl")
    m1553BCStop.argtypes = [M1553Handle]
    m1553BCStop.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1772
if _libs["libait_mil.so"].has("m1553BCTransferSetEnable", "cdecl"):
    m1553BCTransferSetEnable = _libs["libait_mil.so"].get("m1553BCTransferSetEnable", "cdecl")
    m1553BCTransferSetEnable.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCTransferSetEnableIn)]
    m1553BCTransferSetEnable.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1805
if _libs["libait_mil.so"].has("m1553BCTransferGetEnable", "cdecl"):
    m1553BCTransferGetEnable = _libs["libait_mil.so"].get("m1553BCTransferGetEnable", "cdecl")
    m1553BCTransferGetEnable.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCTransferGetEnableOut)]
    m1553BCTransferGetEnable.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1844
if _libs["libait_mil.so"].has("m1553BCModeCodeSetEnable", "cdecl"):
    m1553BCModeCodeSetEnable = _libs["libait_mil.so"].get("m1553BCModeCodeSetEnable", "cdecl")
    m1553BCModeCodeSetEnable.argtypes = [M1553Handle, POINTER(M1553ModeCodeSetEnableIn)]
    m1553BCModeCodeSetEnable.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1873
if _libs["libait_mil.so"].has("m1553BCModeCodeGetEnable", "cdecl"):
    m1553BCModeCodeGetEnable = _libs["libait_mil.so"].get("m1553BCModeCodeGetEnable", "cdecl")
    m1553BCModeCodeGetEnable.argtypes = [M1553Handle, POINTER(M1553ModeCodeGetEnableIn), POINTER(M1553ModeCodeGetEnableOut)]
    m1553BCModeCodeGetEnable.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1941
if _libs["libait_mil.so"].has("m1553BCSetMinorFrame", "cdecl"):
    m1553BCSetMinorFrame = _libs["libait_mil.so"].get("m1553BCSetMinorFrame", "cdecl")
    m1553BCSetMinorFrame.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCSetMinorFrameIn)]
    m1553BCSetMinorFrame.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 1974
if _libs["libait_mil.so"].has("m1553BCGetMinorFrame", "cdecl"):
    m1553BCGetMinorFrame = _libs["libait_mil.so"].get("m1553BCGetMinorFrame", "cdecl")
    m1553BCGetMinorFrame.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCGetMinorFrameOut)]
    m1553BCGetMinorFrame.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 2014
if _libs["libait_mil.so"].has("m1553BCSetMajorFrame", "cdecl"):
    m1553BCSetMajorFrame = _libs["libait_mil.so"].get("m1553BCSetMajorFrame", "cdecl")
    m1553BCSetMajorFrame.argtypes = [M1553Handle, POINTER(M1553BCSetMajorFrameIn)]
    m1553BCSetMajorFrame.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 2040
if _libs["libait_mil.so"].has("m1553BCGetMajorFrame", "cdecl"):
    m1553BCGetMajorFrame = _libs["libait_mil.so"].get("m1553BCGetMajorFrame", "cdecl")
    m1553BCGetMajorFrame.argtypes = [M1553Handle, POINTER(M1553BCGetMajorFrameOut)]
    m1553BCGetMajorFrame.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 2089
if _libs["libait_mil.so"].has("m1553BCSetAcyclicFrame", "cdecl"):
    m1553BCSetAcyclicFrame = _libs["libait_mil.so"].get("m1553BCSetAcyclicFrame", "cdecl")
    m1553BCSetAcyclicFrame.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCSetAcyclicFrameIn)]
    m1553BCSetAcyclicFrame.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 2122
if _libs["libait_mil.so"].has("m1553BCGetAcyclicFrame", "cdecl"):
    m1553BCGetAcyclicFrame = _libs["libait_mil.so"].get("m1553BCGetAcyclicFrame", "cdecl")
    m1553BCGetAcyclicFrame.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCGetAcyclicFrameOut)]
    m1553BCGetAcyclicFrame.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 2166
if _libs["libait_mil.so"].has("m1553BCAcyclicFrameSend", "cdecl"):
    m1553BCAcyclicFrameSend = _libs["libait_mil.so"].get("m1553BCAcyclicFrameSend", "cdecl")
    m1553BCAcyclicFrameSend.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCAcyclicFrameSendIn)]
    m1553BCAcyclicFrameSend.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 2202
if _libs["libait_mil.so"].has("m1553BCGetStatus", "cdecl"):
    m1553BCGetStatus = _libs["libait_mil.so"].get("m1553BCGetStatus", "cdecl")
    m1553BCGetStatus.argtypes = [M1553Handle, POINTER(M1553BCGetStatusOut)]
    m1553BCGetStatus.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 2245
if _libs["libait_mil.so"].has("m1553BCGetVectorWordStatus", "cdecl"):
    m1553BCGetVectorWordStatus = _libs["libait_mil.so"].get("m1553BCGetVectorWordStatus", "cdecl")
    m1553BCGetVectorWordStatus.argtypes = [M1553Handle, POINTER(M1553BCGetVectorWordStatusIn), POINTER(M1553BCGetVectorWordStatusOut)]
    m1553BCGetVectorWordStatus.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 2289
if _libs["libait_mil.so"].has("m1553BCGetTransferStatus", "cdecl"):
    m1553BCGetTransferStatus = _libs["libait_mil.so"].get("m1553BCGetTransferStatus", "cdecl")
    m1553BCGetTransferStatus.argtypes = [M1553Handle, c_uint16, POINTER(M1553BCGetTransferStatusIn), POINTER(M1553BCGetTransferStatusOut)]
    m1553BCGetTransferStatus.restype = c_int

# /usr/local/include/ait_mil/m1553_bc.h: 2297
if _libs["libait_mil.so"].has("m1553BCGetTransferStatusQueueAddress", "cdecl"):
    m1553BCGetTransferStatusQueueAddress = _libs["libait_mil.so"].get("m1553BCGetTransferStatusQueueAddress", "cdecl")
    m1553BCGetTransferStatusQueueAddress.argtypes = [M1553Handle, c_uint16, POINTER(c_uint32)]
    m1553BCGetTransferStatusQueueAddress.restype = c_int

enum_anon_60 = c_int# /usr/local/include/ait_mil/m1553_bm.h: 74

M1553_BM_READ_START_ENTRY = 0# /usr/local/include/ait_mil/m1553_bm.h: 74

M1553_BM_READ_TRIGGER_ENTRY = 1# /usr/local/include/ait_mil/m1553_bm.h: 74

M1553_BM_READ_END_ENTRY = 2# /usr/local/include/ait_mil/m1553_bm.h: 74

M1553_BM_READ_FROM_ADDRESS = 3# /usr/local/include/ait_mil/m1553_bm.h: 74

M1553BMBufferPointerType = enum_anon_60# /usr/local/include/ait_mil/m1553_bm.h: 74

enum_anon_61 = c_int# /usr/local/include/ait_mil/m1553_bm.h: 94

M1553_BM_POSITIVE_OFFSET = 0# /usr/local/include/ait_mil/m1553_bm.h: 94

M1553_BM_NEGATIVE_OFFSET = 1# /usr/local/include/ait_mil/m1553_bm.h: 94

M1553BMOffsetType = enum_anon_61# /usr/local/include/ait_mil/m1553_bm.h: 94

enum_anon_62 = c_int# /usr/local/include/ait_mil/m1553_bm.h: 123

M1553_BM_ERROR_TRIGGER = 0# /usr/local/include/ait_mil/m1553_bm.h: 123

M1553_BM_DIGITAL_IO_TRIGGER = 1# /usr/local/include/ait_mil/m1553_bm.h: 123

M1553_BM_RECEIVED_WORD_TRIGGER = 2# /usr/local/include/ait_mil/m1553_bm.h: 123

M1553_BM_DATA_WORD_TRIGGER = 3# /usr/local/include/ait_mil/m1553_bm.h: 123

M1553BMTriggerType = enum_anon_62# /usr/local/include/ait_mil/m1553_bm.h: 123

enum_anon_63 = c_int# /usr/local/include/ait_mil/m1553_bm.h: 154

M1553_TRIGGER_FUNCTION_DISABLED = 0# /usr/local/include/ait_mil/m1553_bm.h: 154

M1553_MODIFY_TRIGGER0_OR_TRIGGER1 = 1# /usr/local/include/ait_mil/m1553_bm.h: 154

M1553_MODIFY_TRIGGER0_CW1 = 2# /usr/local/include/ait_mil/m1553_bm.h: 154

M1553_MODIFY_TRIGGER0_CW1_CW2 = 3# /usr/local/include/ait_mil/m1553_bm.h: 154

M1553ActivityTriggerFunction = enum_anon_63# /usr/local/include/ait_mil/m1553_bm.h: 154

enum_anon_64 = c_int# /usr/local/include/ait_mil/m1553_bm.h: 183

M1553_BM_INTERRUPT_DISABLED = 0# /usr/local/include/ait_mil/m1553_bm.h: 183

M1553_BM_INTERRUPT_HALF_FULL = 1# /usr/local/include/ait_mil/m1553_bm.h: 183

M1553_BM_INTERRUPT_START_EVENT = 2# /usr/local/include/ait_mil/m1553_bm.h: 183

M1553_BM_INTERRUPT_STOP_EVENT = 3# /usr/local/include/ait_mil/m1553_bm.h: 183

M1553BMInterruptType = enum_anon_64# /usr/local/include/ait_mil/m1553_bm.h: 183

enum_anon_65 = c_int# /usr/local/include/ait_mil/m1553_bm.h: 214

M1553_BM_STROBE_DISABLED = 0# /usr/local/include/ait_mil/m1553_bm.h: 214

M1553_BM_STROBE_HALF_FULL = 1# /usr/local/include/ait_mil/m1553_bm.h: 214

M1553_BM_STROBE_START_EVENT = 2# /usr/local/include/ait_mil/m1553_bm.h: 214

M1553_BM_STROBE_STOP_EVENT = 3# /usr/local/include/ait_mil/m1553_bm.h: 214

M1553BMStrobeType = enum_anon_65# /usr/local/include/ait_mil/m1553_bm.h: 214

enum_anon_66 = c_int# /usr/local/include/ait_mil/m1553_bm.h: 249

M1553_BM_STANDARD_CAPTURE_MODE = 0# /usr/local/include/ait_mil/m1553_bm.h: 249

M1553_BM_CAPTURE_MODE_SNAPSHOT = 1# /usr/local/include/ait_mil/m1553_bm.h: 249

M1553_BM_CAPTURE_MODE_RECORDING = 2# /usr/local/include/ait_mil/m1553_bm.h: 249

M1553BMCaptureModeType = enum_anon_66# /usr/local/include/ait_mil/m1553_bm.h: 249

# /usr/local/include/ait_mil/m1553_bm.h: 308
class struct_anon_67(Structure):
    pass

struct_anon_67.__slots__ = [
    'mInterruptMode',
    'mStrobeMode',
    'mStatusWordExceptionMask',
    'mCaptureMode',
    'mTraceAfterTrigger',
    'mMessageCaptureCount',
    'mFileSize',
    'mBufferSize',
]
struct_anon_67._fields_ = [
    ('mInterruptMode', M1553BMInterruptType),
    ('mStrobeMode', M1553BMStrobeType),
    ('mStatusWordExceptionMask', c_uint16),
    ('mCaptureMode', M1553BMCaptureModeType),
    ('mTraceAfterTrigger', c_uint32),
    ('mMessageCaptureCount', c_uint16),
    ('mFileSize', c_uint16),
    ('mBufferSize', c_uint32),
]

M1553BMConfig = struct_anon_67# /usr/local/include/ait_mil/m1553_bm.h: 308

# /usr/local/include/ait_mil/m1553_bm.h: 319
class struct_anon_68(Structure):
    pass

struct_anon_68.__slots__ = [
    'mConfig',
]
struct_anon_68._fields_ = [
    ('mConfig', M1553BMConfig),
]

M1553BMSetConfigIn = struct_anon_68# /usr/local/include/ait_mil/m1553_bm.h: 319

# /usr/local/include/ait_mil/m1553_bm.h: 330
class struct_anon_69(Structure):
    pass

struct_anon_69.__slots__ = [
    'mConfig',
]
struct_anon_69._fields_ = [
    ('mConfig', M1553BMConfig),
]

M1553BMGetConfigOut = struct_anon_69# /usr/local/include/ait_mil/m1553_bm.h: 330

# /usr/local/include/ait_mil/m1553_bm.h: 471
class struct_anon_70(Structure):
    pass

struct_anon_70.__slots__ = [
    'mEnabled',
    'mInSync',
    'mStrobeTriggerOccured',
    'mErrorTriggerOccurred',
    'mCapturing',
    'mFirstCaptureStarted',
    'mMonitorTriggerStatus',
    'mMessageCount',
    'mErrorCount',
    'mWordCountBusA',
    'mWordCountBusB',
    'mMessageCountBusA',
    'mMessageCountBusB',
    'mErrorCountBusA',
    'mErrorCountBusB',
    'mLoadBusA',
    'mLoadBusB',
    'mLoadBusAAverage',
    'mLoadBusBAverage',
]
struct_anon_70._fields_ = [
    ('mEnabled', M1553Boolean),
    ('mInSync', M1553Boolean),
    ('mStrobeTriggerOccured', M1553Boolean),
    ('mErrorTriggerOccurred', M1553Boolean),
    ('mCapturing', M1553Boolean),
    ('mFirstCaptureStarted', M1553Boolean),
    ('mMonitorTriggerStatus', c_uint8),
    ('mMessageCount', c_uint32),
    ('mErrorCount', c_uint32),
    ('mWordCountBusA', c_uint32),
    ('mWordCountBusB', c_uint32),
    ('mMessageCountBusA', c_uint32),
    ('mMessageCountBusB', c_uint32),
    ('mErrorCountBusA', c_uint32),
    ('mErrorCountBusB', c_uint32),
    ('mLoadBusA', c_uint32),
    ('mLoadBusB', c_uint32),
    ('mLoadBusAAverage', c_uint32),
    ('mLoadBusBAverage', c_uint32),
]

M1553BMGetStatusOut = struct_anon_70# /usr/local/include/ait_mil/m1553_bm.h: 471

# /usr/local/include/ait_mil/m1553_bm.h: 556
class struct_anon_71(Structure):
    pass

struct_anon_71.__slots__ = [
    'mMessageCount',
    'mErrorCount',
    'mErrorAny',
    'mErrorAlternateBus',
    'mErrorLowBitCount',
    'mErrorHighBitCount',
    'mErrorLowWordCount',
    'mErrorHighWordCount',
    'mErrorStatusWordException',
    'mErrorTerminalAddress',
    'mErrorEarlyResponse',
    'mErrorIllegalCommand',
    'mErrorTransmissionOnBothBuses',
    'mErrorInterwordGap',
    'mErrorInvertedSync',
    'mErrorParity',
    'mErrorManchesterCoding',
    'mErrorNoResponse',
]
struct_anon_71._fields_ = [
    ('mMessageCount', c_uint32),
    ('mErrorCount', c_uint32),
    ('mErrorAny', M1553Boolean),
    ('mErrorAlternateBus', M1553Boolean),
    ('mErrorLowBitCount', M1553Boolean),
    ('mErrorHighBitCount', M1553Boolean),
    ('mErrorLowWordCount', M1553Boolean),
    ('mErrorHighWordCount', M1553Boolean),
    ('mErrorStatusWordException', M1553Boolean),
    ('mErrorTerminalAddress', M1553Boolean),
    ('mErrorEarlyResponse', M1553Boolean),
    ('mErrorIllegalCommand', M1553Boolean),
    ('mErrorTransmissionOnBothBuses', M1553Boolean),
    ('mErrorInterwordGap', M1553Boolean),
    ('mErrorInvertedSync', M1553Boolean),
    ('mErrorParity', M1553Boolean),
    ('mErrorManchesterCoding', M1553Boolean),
    ('mErrorNoResponse', M1553Boolean),
]

M1553BMActivityType = struct_anon_71# /usr/local/include/ait_mil/m1553_bm.h: 556

# /usr/local/include/ait_mil/m1553_bm.h: 569
class struct_anon_72(Structure):
    pass

struct_anon_72.__slots__ = [
    'mRTActivity',
]
struct_anon_72._fields_ = [
    ('mRTActivity', M1553BMActivityType),
]

M1553BMGetRTActivityOut = struct_anon_72# /usr/local/include/ait_mil/m1553_bm.h: 569

# /usr/local/include/ait_mil/m1553_bm.h: 581
class struct_anon_73(Structure):
    pass

struct_anon_73.__slots__ = [
    'mRTActivity',
]
struct_anon_73._fields_ = [
    ('mRTActivity', M1553BMActivityType),
]

M1553BMGetRTSAActivityOut = struct_anon_73# /usr/local/include/ait_mil/m1553_bm.h: 581

# /usr/local/include/ait_mil/m1553_bm.h: 611
class struct_anon_74(Structure):
    pass

struct_anon_74.__slots__ = [
    'mStartTriggerOccurred',
    'mStartEntryOffset',
    'mStartTriggerOffset',
    'mBufferFillOffset',
]
struct_anon_74._fields_ = [
    ('mStartTriggerOccurred', M1553Boolean),
    ('mStartEntryOffset', c_uint32),
    ('mStartTriggerOffset', c_uint32),
    ('mBufferFillOffset', c_uint32),
]

M1553BMGetBufferPointersOut = struct_anon_74# /usr/local/include/ait_mil/m1553_bm.h: 611

# /usr/local/include/ait_mil/m1553_bm.h: 685
class struct_anon_75(Structure):
    pass

struct_anon_75.__slots__ = [
    'mSearchStartPointer',
    'mOffsetMode',
    'mOffset',
    'mSearchParameters',
    'mSearchValue',
    'mSearchMask',
]
struct_anon_75._fields_ = [
    ('mSearchStartPointer', M1553BMBufferPointerType),
    ('mOffsetMode', M1553BMOffsetType),
    ('mOffset', c_uint32),
    ('mSearchParameters', c_uint16),
    ('mSearchValue', c_uint16),
    ('mSearchMask', c_uint16),
]

M1553BMFindEntryIn = struct_anon_75# /usr/local/include/ait_mil/m1553_bm.h: 685

# /usr/local/include/ait_mil/m1553_bm.h: 709
class struct_anon_76(Structure):
    pass

struct_anon_76.__slots__ = [
    'mEntryFound',
    'mBufferEntryOffset',
    'mBufferEntry',
]
struct_anon_76._fields_ = [
    ('mEntryFound', M1553Boolean),
    ('mBufferEntryOffset', c_uint32),
    ('mBufferEntry', c_uint32),
]

M1553BMFindEntryOut = struct_anon_76# /usr/local/include/ait_mil/m1553_bm.h: 709

enum_anon_77 = c_int# /usr/local/include/ait_mil/m1553_bm.h: 729

M1553_BM_READ_UNTIL_TRIGGER = 0# /usr/local/include/ait_mil/m1553_bm.h: 729

M1553_BM_READ_UNTIL_END = (M1553_BM_READ_UNTIL_TRIGGER + 1)# /usr/local/include/ait_mil/m1553_bm.h: 729

M1553_BM_READ_UNTIL_FILL_POINTER = (M1553_BM_READ_UNTIL_END + 1)# /usr/local/include/ait_mil/m1553_bm.h: 729

M1553ReadUntilType = enum_anon_77# /usr/local/include/ait_mil/m1553_bm.h: 729

# /usr/local/include/ait_mil/m1553_bm.h: 750
class struct_anon_78(Structure):
    pass

struct_anon_78.__slots__ = [
    'mpBuffer',
    'mBufferSize',
    'mUntil',
]
struct_anon_78._fields_ = [
    ('mpBuffer', M1553Addr),
    ('mBufferSize', c_uint32),
    ('mUntil', M1553ReadUntilType),
]

M1553BMReadIn = struct_anon_78# /usr/local/include/ait_mil/m1553_bm.h: 750

# /usr/local/include/ait_mil/m1553_bm.h: 762
class struct_anon_79(Structure):
    pass

struct_anon_79.__slots__ = [
    'mEntriesRead',
]
struct_anon_79._fields_ = [
    ('mEntriesRead', c_uint32),
]

M1553BMReadOut = struct_anon_79# /usr/local/include/ait_mil/m1553_bm.h: 762

enum_anon_80 = c_int# /usr/local/include/ait_mil/m1553_bm.h: 788

M1553_BM_SEEK_FROM_START = 0# /usr/local/include/ait_mil/m1553_bm.h: 788

M1553_BM_SEEK_FROM_END = (M1553_BM_SEEK_FROM_START + 1)# /usr/local/include/ait_mil/m1553_bm.h: 788

M1553_BM_SEEK_FROM_TRIGGER = (M1553_BM_SEEK_FROM_END + 1)# /usr/local/include/ait_mil/m1553_bm.h: 788

M1553_BM_SEEK_FROM_CURRENT = (M1553_BM_SEEK_FROM_TRIGGER + 1)# /usr/local/include/ait_mil/m1553_bm.h: 788

M1553BMSeekOriginType = enum_anon_80# /usr/local/include/ait_mil/m1553_bm.h: 788

# /usr/local/include/ait_mil/m1553_bm.h: 805
class struct_anon_81(Structure):
    pass

struct_anon_81.__slots__ = [
    'mOffset',
    'mOrigin',
]
struct_anon_81._fields_ = [
    ('mOffset', c_int32),
    ('mOrigin', M1553BMSeekOriginType),
]

M1553BMSeekIn = struct_anon_81# /usr/local/include/ait_mil/m1553_bm.h: 805

# /usr/local/include/ait_mil/m1553_bm.h: 817
class struct_anon_82(Structure):
    pass

struct_anon_82.__slots__ = [
    'mReadPointerOffset',
]
struct_anon_82._fields_ = [
    ('mReadPointerOffset', c_uint32),
]

M1553BMSeekOut = struct_anon_82# /usr/local/include/ait_mil/m1553_bm.h: 817

# /usr/local/include/ait_mil/m1553_bm.h: 1058
class struct_anon_83(Structure):
    pass

struct_anon_83.__slots__ = [
    'mTriggerType',
    'mStrobeEnabled',
    'mInterruptEnabled',
    'mStatusTriggerResetPattern',
    'mStatusTriggerSetPattern',
    'mTriggerParameter',
    'mNextTriggerControlBlock',
    'mEndOfMessage',
    'mTriggerDataWord',
    'mTriggerMask',
    'mLimitInvertRange',
    'mUpperLimitCheck',
    'mLowerLimitCheck',
]
struct_anon_83._fields_ = [
    ('mTriggerType', M1553BMTriggerType),
    ('mStrobeEnabled', M1553Boolean),
    ('mInterruptEnabled', M1553Boolean),
    ('mStatusTriggerResetPattern', c_uint8),
    ('mStatusTriggerSetPattern', c_uint8),
    ('mTriggerParameter', c_uint8),
    ('mNextTriggerControlBlock', c_uint8),
    ('mEndOfMessage', c_uint8),
    ('mTriggerDataWord', c_uint16),
    ('mTriggerMask', c_uint16),
    ('mLimitInvertRange', M1553Boolean),
    ('mUpperLimitCheck', c_uint16),
    ('mLowerLimitCheck', c_uint16),
]

M1553BMTriggerControlBlock = struct_anon_83# /usr/local/include/ait_mil/m1553_bm.h: 1058

# /usr/local/include/ait_mil/m1553_bm.h: 1081
class struct_anon_84(Structure):
    pass

struct_anon_84.__slots__ = [
    'mTriggerControlBlockIndex',
    'mEnabled',
    'mTriggerControlBlock',
]
struct_anon_84._fields_ = [
    ('mTriggerControlBlockIndex', c_uint8),
    ('mEnabled', M1553Boolean),
    ('mTriggerControlBlock', M1553BMTriggerControlBlock),
]

M1553BMSetTriggerControlBlockIn = struct_anon_84# /usr/local/include/ait_mil/m1553_bm.h: 1081

# /usr/local/include/ait_mil/m1553_bm.h: 1093
class struct_anon_85(Structure):
    pass

struct_anon_85.__slots__ = [
    'mTriggerControlBlockIndex',
]
struct_anon_85._fields_ = [
    ('mTriggerControlBlockIndex', c_uint8),
]

M1553BMGetTriggerControlBlockIn = struct_anon_85# /usr/local/include/ait_mil/m1553_bm.h: 1093

# /usr/local/include/ait_mil/m1553_bm.h: 1111
class struct_anon_86(Structure):
    pass

struct_anon_86.__slots__ = [
    'mEnabled',
    'mTriggerControlBlock',
]
struct_anon_86._fields_ = [
    ('mEnabled', M1553Boolean),
    ('mTriggerControlBlock', M1553BMTriggerControlBlock),
]

M1553BMGetTriggerControlBlockOut = struct_anon_86# /usr/local/include/ait_mil/m1553_bm.h: 1111

# /usr/local/include/ait_mil/m1553_bm.h: 1145
class struct_anon_87(Structure):
    pass

struct_anon_87.__slots__ = [
    'mReceiveSA',
    'mTransmitSA',
    'mReceiveMC',
    'mTransmitMC',
]
struct_anon_87._fields_ = [
    ('mReceiveSA', c_uint32),
    ('mTransmitSA', c_uint32),
    ('mReceiveMC', c_uint32),
    ('mTransmitMC', c_uint32),
]

M1553RTSubaddressesType = struct_anon_87# /usr/local/include/ait_mil/m1553_bm.h: 1145

# /usr/local/include/ait_mil/m1553_bm.h: 1157
class struct_anon_88(Structure):
    pass

struct_anon_88.__slots__ = [
    'mIllegalAddresses',
]
struct_anon_88._fields_ = [
    ('mIllegalAddresses', M1553RTSubaddressesType),
]

M1553BMSetRTIllegalsIn = struct_anon_88# /usr/local/include/ait_mil/m1553_bm.h: 1157

# /usr/local/include/ait_mil/m1553_bm.h: 1170
class struct_anon_89(Structure):
    pass

struct_anon_89.__slots__ = [
    'mIllegalAddresses',
]
struct_anon_89._fields_ = [
    ('mIllegalAddresses', M1553RTSubaddressesType),
]

M1553BMGetRTIllegalsOut = struct_anon_89# /usr/local/include/ait_mil/m1553_bm.h: 1170

# /usr/local/include/ait_mil/m1553_bm.h: 1182
class struct_anon_90(Structure):
    pass

struct_anon_90.__slots__ = [
    'mFilteredAddresses',
]
struct_anon_90._fields_ = [
    ('mFilteredAddresses', M1553RTSubaddressesType),
]

M1553BMSetRTFilterIn = struct_anon_90# /usr/local/include/ait_mil/m1553_bm.h: 1182

# /usr/local/include/ait_mil/m1553_bm.h: 1194
class struct_anon_91(Structure):
    pass

struct_anon_91.__slots__ = [
    'mFilteredAddresses',
]
struct_anon_91._fields_ = [
    ('mFilteredAddresses', M1553RTSubaddressesType),
]

M1553BMGetRTFilterOut = struct_anon_91# /usr/local/include/ait_mil/m1553_bm.h: 1194

# /usr/local/include/ait_mil/m1553_bm.h: 1225
class struct_anon_92(Structure):
    pass

struct_anon_92.__slots__ = [
    'mStopTriggerMask',
    'mStopTriggerWord',
    'mStartTriggerMask',
    'mStartTriggerWord',
]
struct_anon_92._fields_ = [
    ('mStopTriggerMask', c_uint8),
    ('mStopTriggerWord', c_uint8),
    ('mStartTriggerMask', c_uint8),
    ('mStartTriggerWord', c_uint8),
]

M1553BMTriggerEventsType = struct_anon_92# /usr/local/include/ait_mil/m1553_bm.h: 1225

# /usr/local/include/ait_mil/m1553_bm.h: 1236
class struct_anon_93(Structure):
    pass

struct_anon_93.__slots__ = [
    'mTriggerEvents',
]
struct_anon_93._fields_ = [
    ('mTriggerEvents', M1553BMTriggerEventsType),
]

M1553BMSetTriggerEventsIn = struct_anon_93# /usr/local/include/ait_mil/m1553_bm.h: 1236

# /usr/local/include/ait_mil/m1553_bm.h: 1247
class struct_anon_94(Structure):
    pass

struct_anon_94.__slots__ = [
    'mTriggerEvents',
]
struct_anon_94._fields_ = [
    ('mTriggerEvents', M1553BMTriggerEventsType),
]

M1553BMGetTriggerEventsOut = struct_anon_94# /usr/local/include/ait_mil/m1553_bm.h: 1247

# /usr/local/include/ait_mil/m1553_bm.h: 1278
class struct_anon_95(Structure):
    pass

struct_anon_95.__slots__ = [
    'mStaticTrigger0Index',
    'mStaticTrigger1Index',
    'mDynamicTrigger0Index',
    'mDynamicTrigger1Index',
]
struct_anon_95._fields_ = [
    ('mStaticTrigger0Index', c_uint8),
    ('mStaticTrigger1Index', c_uint8),
    ('mDynamicTrigger0Index', c_uint8),
    ('mDynamicTrigger1Index', c_uint8),
]

M1553BMInitialTriggers = struct_anon_95# /usr/local/include/ait_mil/m1553_bm.h: 1278

# /usr/local/include/ait_mil/m1553_bm.h: 1289
class struct_anon_96(Structure):
    pass

struct_anon_96.__slots__ = [
    'mInitialTriggers',
]
struct_anon_96._fields_ = [
    ('mInitialTriggers', M1553BMInitialTriggers),
]

M1553BMSetInitialTriggerIndexIn = struct_anon_96# /usr/local/include/ait_mil/m1553_bm.h: 1289

# /usr/local/include/ait_mil/m1553_bm.h: 1300
class struct_anon_97(Structure):
    pass

struct_anon_97.__slots__ = [
    'mInitialTriggers',
]
struct_anon_97._fields_ = [
    ('mInitialTriggers', M1553BMInitialTriggers),
]

M1553BMGetInitialTriggerIndexOut = struct_anon_97# /usr/local/include/ait_mil/m1553_bm.h: 1300

# /usr/local/include/ait_mil/m1553_bm.h: 1335
class struct_anon_98(Structure):
    pass

struct_anon_98.__slots__ = [
    'mRtAddress',
    'mSubAddress',
    'mSubAddressType',
    'mActivityTriggerFunction',
    'mTriggerControlBlock',
]
struct_anon_98._fields_ = [
    ('mRtAddress', c_uint8),
    ('mSubAddress', c_uint8),
    ('mSubAddressType', M1553SubAddressType),
    ('mActivityTriggerFunction', M1553ActivityTriggerFunction),
    ('mTriggerControlBlock', c_uint8),
]

M1553BMSetMessageActivityTriggerIn = struct_anon_98# /usr/local/include/ait_mil/m1553_bm.h: 1335

# /usr/local/include/ait_mil/m1553_bm.h: 1356
class struct_anon_99(Structure):
    pass

struct_anon_99.__slots__ = [
    'mRtAddress',
    'mSubAddress',
    'mSubAddressType',
]
struct_anon_99._fields_ = [
    ('mRtAddress', c_uint8),
    ('mSubAddress', c_uint8),
    ('mSubAddressType', M1553SubAddressType),
]

M1553BMGetMessageActivityTriggerIn = struct_anon_99# /usr/local/include/ait_mil/m1553_bm.h: 1356

# /usr/local/include/ait_mil/m1553_bm.h: 1375
class struct_anon_100(Structure):
    pass

struct_anon_100.__slots__ = [
    'mMonitorActivityTriggerFunction',
    'mTriggerControlBlock',
]
struct_anon_100._fields_ = [
    ('mMonitorActivityTriggerFunction', M1553ActivityTriggerFunction),
    ('mTriggerControlBlock', c_uint8),
]

M1553BMGetMessageActivityTriggerOut = struct_anon_100# /usr/local/include/ait_mil/m1553_bm.h: 1375

# /usr/local/include/ait_mil/m1553_bm.h: 1725
if _libs["libait_mil.so"].has("m1553BMInit", "cdecl"):
    m1553BMInit = _libs["libait_mil.so"].get("m1553BMInit", "cdecl")
    m1553BMInit.argtypes = [M1553Handle]
    m1553BMInit.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 1764
if _libs["libait_mil.so"].has("m1553BMSetConfig", "cdecl"):
    m1553BMSetConfig = _libs["libait_mil.so"].get("m1553BMSetConfig", "cdecl")
    m1553BMSetConfig.argtypes = [M1553Handle, POINTER(M1553BMSetConfigIn)]
    m1553BMSetConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 1792
if _libs["libait_mil.so"].has("m1553BMGetConfig", "cdecl"):
    m1553BMGetConfig = _libs["libait_mil.so"].get("m1553BMGetConfig", "cdecl")
    m1553BMGetConfig.argtypes = [M1553Handle, POINTER(M1553BMGetConfigOut)]
    m1553BMGetConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 1822
if _libs["libait_mil.so"].has("m1553BMStart", "cdecl"):
    m1553BMStart = _libs["libait_mil.so"].get("m1553BMStart", "cdecl")
    m1553BMStart.argtypes = [M1553Handle]
    m1553BMStart.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 1840
if _libs["libait_mil.so"].has("m1553BMStop", "cdecl"):
    m1553BMStop = _libs["libait_mil.so"].get("m1553BMStop", "cdecl")
    m1553BMStop.argtypes = [M1553Handle]
    m1553BMStop.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 1875
if _libs["libait_mil.so"].has("m1553BMGetStatus", "cdecl"):
    m1553BMGetStatus = _libs["libait_mil.so"].get("m1553BMGetStatus", "cdecl")
    m1553BMGetStatus.argtypes = [M1553Handle, POINTER(M1553BMGetStatusOut)]
    m1553BMGetStatus.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 1907
if _libs["libait_mil.so"].has("m1553BMGetAllRTActivity", "cdecl"):
    m1553BMGetAllRTActivity = _libs["libait_mil.so"].get("m1553BMGetAllRTActivity", "cdecl")
    m1553BMGetAllRTActivity.argtypes = [M1553Handle, c_uint8, POINTER(M1553BMGetRTActivityOut)]
    m1553BMGetAllRTActivity.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 1939
if _libs["libait_mil.so"].has("m1553BMGetRTActivity", "cdecl"):
    m1553BMGetRTActivity = _libs["libait_mil.so"].get("m1553BMGetRTActivity", "cdecl")
    m1553BMGetRTActivity.argtypes = [M1553Handle, c_uint8, POINTER(M1553BMGetRTActivityOut)]
    m1553BMGetRTActivity.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 1981
if _libs["libait_mil.so"].has("m1553BMGetRTSAActivity", "cdecl"):
    m1553BMGetRTSAActivity = _libs["libait_mil.so"].get("m1553BMGetRTSAActivity", "cdecl")
    m1553BMGetRTSAActivity.argtypes = [M1553Handle, c_uint8, c_uint8, M1553SubAddressType, POINTER(M1553BMGetRTSAActivityOut)]
    m1553BMGetRTSAActivity.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2011
if _libs["libait_mil.so"].has("m1553BMGetBufferPointers", "cdecl"):
    m1553BMGetBufferPointers = _libs["libait_mil.so"].get("m1553BMGetBufferPointers", "cdecl")
    m1553BMGetBufferPointers.argtypes = [M1553Handle, POINTER(M1553BMGetBufferPointersOut)]
    m1553BMGetBufferPointers.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2050
if _libs["libait_mil.so"].has("m1553BMFindEntry", "cdecl"):
    m1553BMFindEntry = _libs["libait_mil.so"].get("m1553BMFindEntry", "cdecl")
    m1553BMFindEntry.argtypes = [M1553Handle, POINTER(M1553BMFindEntryIn), POINTER(M1553BMFindEntryOut)]
    m1553BMFindEntry.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2089
if _libs["libait_mil.so"].has("m1553BMRead", "cdecl"):
    m1553BMRead = _libs["libait_mil.so"].get("m1553BMRead", "cdecl")
    m1553BMRead.argtypes = [M1553Handle, POINTER(M1553BMReadIn), POINTER(M1553BMReadOut)]
    m1553BMRead.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2130
if _libs["libait_mil.so"].has("m1553BMSeek", "cdecl"):
    m1553BMSeek = _libs["libait_mil.so"].get("m1553BMSeek", "cdecl")
    m1553BMSeek.argtypes = [M1553Handle, POINTER(M1553BMSeekIn), POINTER(M1553BMSeekOut)]
    m1553BMSeek.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2172
if _libs["libait_mil.so"].has("m1553BMSetRTFilter", "cdecl"):
    m1553BMSetRTFilter = _libs["libait_mil.so"].get("m1553BMSetRTFilter", "cdecl")
    m1553BMSetRTFilter.argtypes = [M1553Handle, c_uint8, POINTER(M1553BMSetRTFilterIn)]
    m1553BMSetRTFilter.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2206
if _libs["libait_mil.so"].has("m1553BMGetRTFilter", "cdecl"):
    m1553BMGetRTFilter = _libs["libait_mil.so"].get("m1553BMGetRTFilter", "cdecl")
    m1553BMGetRTFilter.argtypes = [M1553Handle, c_uint8, POINTER(M1553BMGetRTFilterOut)]
    m1553BMGetRTFilter.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2241
if _libs["libait_mil.so"].has("m1553BMSetRTIllegals", "cdecl"):
    m1553BMSetRTIllegals = _libs["libait_mil.so"].get("m1553BMSetRTIllegals", "cdecl")
    m1553BMSetRTIllegals.argtypes = [M1553Handle, c_uint8, POINTER(M1553BMSetRTIllegalsIn)]
    m1553BMSetRTIllegals.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2277
if _libs["libait_mil.so"].has("m1553BMGetRTIllegals", "cdecl"):
    m1553BMGetRTIllegals = _libs["libait_mil.so"].get("m1553BMGetRTIllegals", "cdecl")
    m1553BMGetRTIllegals.argtypes = [M1553Handle, c_uint8, POINTER(M1553BMGetRTIllegalsOut)]
    m1553BMGetRTIllegals.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2323
if _libs["libait_mil.so"].has("m1553BMSetTriggerEvents", "cdecl"):
    m1553BMSetTriggerEvents = _libs["libait_mil.so"].get("m1553BMSetTriggerEvents", "cdecl")
    m1553BMSetTriggerEvents.argtypes = [M1553Handle, POINTER(M1553BMSetTriggerEventsIn)]
    m1553BMSetTriggerEvents.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2351
if _libs["libait_mil.so"].has("m1553BMGetTriggerEvents", "cdecl"):
    m1553BMGetTriggerEvents = _libs["libait_mil.so"].get("m1553BMGetTriggerEvents", "cdecl")
    m1553BMGetTriggerEvents.argtypes = [M1553Handle, POINTER(M1553BMGetTriggerEventsOut)]
    m1553BMGetTriggerEvents.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2402
if _libs["libait_mil.so"].has("m1553BMSetTriggerControlBlock", "cdecl"):
    m1553BMSetTriggerControlBlock = _libs["libait_mil.so"].get("m1553BMSetTriggerControlBlock", "cdecl")
    m1553BMSetTriggerControlBlock.argtypes = [M1553Handle, POINTER(M1553BMSetTriggerControlBlockIn)]
    m1553BMSetTriggerControlBlock.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2430
if _libs["libait_mil.so"].has("m1553BMGetTriggerControlBlock", "cdecl"):
    m1553BMGetTriggerControlBlock = _libs["libait_mil.so"].get("m1553BMGetTriggerControlBlock", "cdecl")
    m1553BMGetTriggerControlBlock.argtypes = [M1553Handle, POINTER(M1553BMGetTriggerControlBlockIn), POINTER(M1553BMGetTriggerControlBlockOut)]
    m1553BMGetTriggerControlBlock.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2461
if _libs["libait_mil.so"].has("m1553BMSetInitialTriggerIndex", "cdecl"):
    m1553BMSetInitialTriggerIndex = _libs["libait_mil.so"].get("m1553BMSetInitialTriggerIndex", "cdecl")
    m1553BMSetInitialTriggerIndex.argtypes = [M1553Handle, POINTER(M1553BMSetInitialTriggerIndexIn)]
    m1553BMSetInitialTriggerIndex.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2487
if _libs["libait_mil.so"].has("m1553BMGetInitialTriggerIndex", "cdecl"):
    m1553BMGetInitialTriggerIndex = _libs["libait_mil.so"].get("m1553BMGetInitialTriggerIndex", "cdecl")
    m1553BMGetInitialTriggerIndex.argtypes = [M1553Handle, POINTER(M1553BMGetInitialTriggerIndexOut)]
    m1553BMGetInitialTriggerIndex.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2537
if _libs["libait_mil.so"].has("m1553BMSetMessageActivityTrigger", "cdecl"):
    m1553BMSetMessageActivityTrigger = _libs["libait_mil.so"].get("m1553BMSetMessageActivityTrigger", "cdecl")
    m1553BMSetMessageActivityTrigger.argtypes = [M1553Handle, POINTER(M1553BMSetMessageActivityTriggerIn)]
    m1553BMSetMessageActivityTrigger.restype = c_int

# /usr/local/include/ait_mil/m1553_bm.h: 2580
if _libs["libait_mil.so"].has("m1553BMGetMessageActivityTrigger", "cdecl"):
    m1553BMGetMessageActivityTrigger = _libs["libait_mil.so"].get("m1553BMGetMessageActivityTrigger", "cdecl")
    m1553BMGetMessageActivityTrigger.argtypes = [M1553Handle, POINTER(M1553BMGetMessageActivityTriggerIn), POINTER(M1553BMGetMessageActivityTriggerOut)]
    m1553BMGetMessageActivityTrigger.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 60
class struct_anon_101(Structure):
    pass

struct_anon_101.__slots__ = [
    'mWordOffset',
    'mSize',
    'mpData',
    'm1760ChecksumOffset',
]
struct_anon_101._fields_ = [
    ('mWordOffset', c_uint8),
    ('mSize', c_uint8),
    ('mpData', POINTER(c_uint16)),
    ('m1760ChecksumOffset', c_uint8),
]

M1553BufSetBufferIn = struct_anon_101# /usr/local/include/ait_mil/m1553_buffer.h: 60

# /usr/local/include/ait_mil/m1553_buffer.h: 96
class struct_anon_102(Structure):
    pass

struct_anon_102.__slots__ = [
    'mWordOffset',
    'mSize',
    'mpData',
    'm1760ChecksumOffset',
]
struct_anon_102._fields_ = [
    ('mWordOffset', c_uint8),
    ('mSize', c_uint8),
    ('mpData', POINTER(c_uint16)),
    ('m1760ChecksumOffset', c_uint8),
]

M1553BufGetBufferIn = struct_anon_102# /usr/local/include/ait_mil/m1553_buffer.h: 96

# /usr/local/include/ait_mil/m1553_buffer.h: 122
class struct_anon_103(Structure):
    pass

struct_anon_103.__slots__ = [
    'mBufferId',
    'mBufferAddress',
    'm1760ChecksumValid',
]
struct_anon_103._fields_ = [
    ('mBufferId', c_uint16),
    ('mBufferAddress', c_uint32),
    ('m1760ChecksumValid', c_uint8),
]

M1553BufGetBufferOut = struct_anon_103# /usr/local/include/ait_mil/m1553_buffer.h: 122

# /usr/local/include/ait_mil/m1553_buffer.h: 143
class struct_anon_104(Structure):
    pass

struct_anon_104.__slots__ = [
    'mWordOffset',
    'mUserData',
    'mUserDataMask',
]
struct_anon_104._fields_ = [
    ('mWordOffset', c_uint8),
    ('mUserData', c_uint16),
    ('mUserDataMask', c_uint16),
]

M1553BufSetBufferWordIn = struct_anon_104# /usr/local/include/ait_mil/m1553_buffer.h: 143

# /usr/local/include/ait_mil/m1553_buffer.h: 182
class struct_anon_105(Structure):
    pass

struct_anon_105.__slots__ = [
    'mHeaderId',
    'mBufferHeaderType',
    'mQueueOffset',
    'mWordOffset',
    'mSize',
    'mpData',
]
struct_anon_105._fields_ = [
    ('mHeaderId', c_uint16),
    ('mBufferHeaderType', M1553BufferHeaderType),
    ('mQueueOffset', c_uint32),
    ('mWordOffset', c_uint8),
    ('mSize', c_uint8),
    ('mpData', POINTER(c_uint16)),
]

M1553BufSetHeaderBufferIn = struct_anon_105# /usr/local/include/ait_mil/m1553_buffer.h: 182

# /usr/local/include/ait_mil/m1553_buffer.h: 223
class struct_anon_106(Structure):
    pass

struct_anon_106.__slots__ = [
    'mHeaderId',
    'mBufferHeaderType',
    'mQueueOffset',
    'mWordOffset',
    'mSize',
    'mpData',
]
struct_anon_106._fields_ = [
    ('mHeaderId', c_uint16),
    ('mBufferHeaderType', M1553BufferHeaderType),
    ('mQueueOffset', c_uint32),
    ('mWordOffset', c_uint8),
    ('mSize', c_uint8),
    ('mpData', POINTER(c_uint16)),
]

M1553BufGetHeaderBufferIn = struct_anon_106# /usr/local/include/ait_mil/m1553_buffer.h: 223

# /usr/local/include/ait_mil/m1553_buffer.h: 239
class struct_anon_107(Structure):
    pass

struct_anon_107.__slots__ = [
    'mBufferId',
    'mBufferAddress',
]
struct_anon_107._fields_ = [
    ('mBufferId', c_uint16),
    ('mBufferAddress', c_uint32),
]

M1553BufGetHeaderBufferOut = struct_anon_107# /usr/local/include/ait_mil/m1553_buffer.h: 239

# /usr/local/include/ait_mil/m1553_buffer.h: 276
class struct_anon_108(Structure):
    pass

struct_anon_108.__slots__ = [
    'mHeaderId',
    'mBufferHeaderType',
    'mQueueOffset',
    'mWordOffset',
    'mUserData',
    'mUserDataMask',
]
struct_anon_108._fields_ = [
    ('mHeaderId', c_uint16),
    ('mBufferHeaderType', M1553BufferHeaderType),
    ('mQueueOffset', c_uint32),
    ('mWordOffset', c_uint8),
    ('mUserData', c_uint16),
    ('mUserDataMask', c_uint16),
]

M1553BufSetHeaderBufferWordIn = struct_anon_108# /usr/local/include/ait_mil/m1553_buffer.h: 276

# /usr/local/include/ait_mil/m1553_buffer.h: 296
class struct_anon_109(Structure):
    pass

struct_anon_109.__slots__ = [
    'mOffset',
    'mSize',
    'mpData',
]
struct_anon_109._fields_ = [
    ('mOffset', c_uint32),
    ('mSize', c_uint32),
    ('mpData', POINTER(c_uint32)),
]

M1553RamSetDataIn = struct_anon_109# /usr/local/include/ait_mil/m1553_buffer.h: 296

# /usr/local/include/ait_mil/m1553_buffer.h: 318
class struct_anon_110(Structure):
    pass

struct_anon_110.__slots__ = [
    'mOffset',
    'mSize',
    'mpData',
]
struct_anon_110._fields_ = [
    ('mOffset', c_uint32),
    ('mSize', c_uint32),
    ('mpData', POINTER(c_uint32)),
]

M1553RamGetDataIn = struct_anon_110# /usr/local/include/ait_mil/m1553_buffer.h: 318

# /usr/local/include/ait_mil/m1553_buffer.h: 329
class struct_anon_111(Structure):
    pass

struct_anon_111.__slots__ = [
    'mSize',
]
struct_anon_111._fields_ = [
    ('mSize', c_uint32),
]

M1553RamGetDataOut = struct_anon_111# /usr/local/include/ait_mil/m1553_buffer.h: 329

enum_anon_112 = c_int# /usr/local/include/ait_mil/m1553_buffer.h: 358

M1553_SEL_ON_BOARD_RAM = 0# /usr/local/include/ait_mil/m1553_buffer.h: 358

M1553_SEL_PPC_RAM = 1# /usr/local/include/ait_mil/m1553_buffer.h: 358

M1553_SEL_PPC_BOOT_DATA_RAM = 2# /usr/local/include/ait_mil/m1553_buffer.h: 358

M1553_SEL_PPC_BOOT_INST_RAM = 3# /usr/local/include/ait_mil/m1553_buffer.h: 358

M1553MemBlockSelectType = enum_anon_112# /usr/local/include/ait_mil/m1553_buffer.h: 358

# /usr/local/include/ait_mil/m1553_buffer.h: 426
if _libs["libait_mil.so"].has("m1553BufSetBuffer", "cdecl"):
    m1553BufSetBuffer = _libs["libait_mil.so"].get("m1553BufSetBuffer", "cdecl")
    m1553BufSetBuffer.argtypes = [M1553Handle, c_uint16, POINTER(M1553BufSetBufferIn)]
    m1553BufSetBuffer.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 474
if _libs["libait_mil.so"].has("m1553BufGetBuffer", "cdecl"):
    m1553BufGetBuffer = _libs["libait_mil.so"].get("m1553BufGetBuffer", "cdecl")
    m1553BufGetBuffer.argtypes = [M1553Handle, c_uint16, POINTER(M1553BufGetBufferIn), POINTER(M1553BufGetBufferOut)]
    m1553BufGetBuffer.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 514
if _libs["libait_mil.so"].has("m1553BufSetBufferWord", "cdecl"):
    m1553BufSetBufferWord = _libs["libait_mil.so"].get("m1553BufSetBufferWord", "cdecl")
    m1553BufSetBufferWord.argtypes = [M1553Handle, c_uint16, POINTER(M1553BufSetBufferWordIn)]
    m1553BufSetBufferWord.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 568
if _libs["libait_mil.so"].has("m1553BufSetHeaderBuffer", "cdecl"):
    m1553BufSetHeaderBuffer = _libs["libait_mil.so"].get("m1553BufSetHeaderBuffer", "cdecl")
    m1553BufSetHeaderBuffer.argtypes = [M1553Handle, POINTER(M1553BufSetHeaderBufferIn)]
    m1553BufSetHeaderBuffer.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 624
if _libs["libait_mil.so"].has("m1553BufGetHeaderBuffer", "cdecl"):
    m1553BufGetHeaderBuffer = _libs["libait_mil.so"].get("m1553BufGetHeaderBuffer", "cdecl")
    m1553BufGetHeaderBuffer.argtypes = [M1553Handle, POINTER(M1553BufGetHeaderBufferIn), POINTER(M1553BufGetHeaderBufferOut)]
    m1553BufGetHeaderBuffer.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 671
if _libs["libait_mil.so"].has("m1553BufSetHeaderBufferWord", "cdecl"):
    m1553BufSetHeaderBufferWord = _libs["libait_mil.so"].get("m1553BufSetHeaderBufferWord", "cdecl")
    m1553BufSetHeaderBufferWord.argtypes = [M1553Handle, POINTER(M1553BufSetHeaderBufferWordIn)]
    m1553BufSetHeaderBufferWord.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 683
if _libs["libait_mil.so"].has("m1553BufCalculate1760Checksum", "cdecl"):
    m1553BufCalculate1760Checksum = _libs["libait_mil.so"].get("m1553BufCalculate1760Checksum", "cdecl")
    m1553BufCalculate1760Checksum.argtypes = [POINTER(c_uint16), c_uint8, POINTER(c_uint16)]
    m1553BufCalculate1760Checksum.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 723
if _libs["libait_mil.so"].has("m1553RamSetData", "cdecl"):
    m1553RamSetData = _libs["libait_mil.so"].get("m1553RamSetData", "cdecl")
    m1553RamSetData.argtypes = [M1553Handle, POINTER(M1553RamSetDataIn)]
    m1553RamSetData.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 753
if _libs["libait_mil.so"].has("m1553RamGetData", "cdecl"):
    m1553RamGetData = _libs["libait_mil.so"].get("m1553RamGetData", "cdecl")
    m1553RamGetData.argtypes = [M1553Handle, POINTER(M1553RamGetDataIn), POINTER(M1553RamGetDataOut)]
    m1553RamGetData.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 794
if _libs["libait_mil.so"].has("m1553MemBlockSetData", "cdecl"):
    m1553MemBlockSetData = _libs["libait_mil.so"].get("m1553MemBlockSetData", "cdecl")
    m1553MemBlockSetData.argtypes = [M1553Handle, M1553MemBlockSelectType, c_uint32, c_uint32, POINTER(c_uint32), POINTER(c_uint32)]
    m1553MemBlockSetData.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 835
if _libs["libait_mil.so"].has("m1553MemBlockGetData", "cdecl"):
    m1553MemBlockGetData = _libs["libait_mil.so"].get("m1553MemBlockGetData", "cdecl")
    m1553MemBlockGetData.argtypes = [M1553Handle, M1553MemBlockSelectType, c_uint32, c_uint32, POINTER(c_uint32), POINTER(c_uint32)]
    m1553MemBlockGetData.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 884
if _libs["libait_mil.so"].has("m1553RamChannelSetData", "cdecl"):
    m1553RamChannelSetData = _libs["libait_mil.so"].get("m1553RamChannelSetData", "cdecl")
    m1553RamChannelSetData.argtypes = [M1553Handle, POINTER(M1553RamSetDataIn)]
    m1553RamChannelSetData.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 914
if _libs["libait_mil.so"].has("m1553RamChannelGetData", "cdecl"):
    m1553RamChannelGetData = _libs["libait_mil.so"].get("m1553RamChannelGetData", "cdecl")
    m1553RamChannelGetData.argtypes = [M1553Handle, POINTER(M1553RamGetDataIn), POINTER(M1553RamGetDataOut)]
    m1553RamChannelGetData.restype = c_int

# /usr/local/include/ait_mil/m1553_buffer.h: 920
if _libs["libait_mil.so"].has("m1553GetBufferPointer", "cdecl"):
    m1553GetBufferPointer = _libs["libait_mil.so"].get("m1553GetBufferPointer", "cdecl")
    m1553GetBufferPointer.argtypes = [M1553Handle, c_uint32, POINTER(c_uint32)]
    m1553GetBufferPointer.restype = c_int

enum_anon_113 = c_int# /usr/local/include/ait_mil/m1553_log.h: 72

LOG_DEBUG = 0# /usr/local/include/ait_mil/m1553_log.h: 72

LOG_INFO = 1# /usr/local/include/ait_mil/m1553_log.h: 72

LOG_NOTICE = 2# /usr/local/include/ait_mil/m1553_log.h: 72

LOG_WARNING = 3# /usr/local/include/ait_mil/m1553_log.h: 72

LOG_ERR = 4# /usr/local/include/ait_mil/m1553_log.h: 72

LOG_CRIT = 5# /usr/local/include/ait_mil/m1553_log.h: 72

LOG_ALERT = 6# /usr/local/include/ait_mil/m1553_log.h: 72

LOG_EMERG = 7# /usr/local/include/ait_mil/m1553_log.h: 72

LOG_NOTHING = 8# /usr/local/include/ait_mil/m1553_log.h: 72

M1553LogPriority = enum_anon_113# /usr/local/include/ait_mil/m1553_log.h: 72

enum_anon_114 = c_int# /usr/local/include/ait_mil/m1553_log.h: 94

LOG_TO_STDOUT = 0# /usr/local/include/ait_mil/m1553_log.h: 94

LOG_TO_STDERR = 1# /usr/local/include/ait_mil/m1553_log.h: 94

LOG_TO_NULL = 2# /usr/local/include/ait_mil/m1553_log.h: 94

LOG_TO_DEBUGGER = 3# /usr/local/include/ait_mil/m1553_log.h: 94

M1553LogDestination = enum_anon_114# /usr/local/include/ait_mil/m1553_log.h: 94

# /usr/local/include/ait_mil/m1553_log.h: 102
if _libs["libait_mil.so"].has("m1553LogDebugConsoleConfig", "cdecl"):
    m1553LogDebugConsoleConfig = _libs["libait_mil.so"].get("m1553LogDebugConsoleConfig", "cdecl")
    m1553LogDebugConsoleConfig.argtypes = [M1553LogDestination, M1553LogPriority]
    m1553LogDebugConsoleConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_log.h: 114
if _libs["libait_mil.so"].has("m1553LogErrorString", "cdecl"):
    m1553LogErrorString = _libs["libait_mil.so"].get("m1553LogErrorString", "cdecl")
    m1553LogErrorString.argtypes = [M1553Return, String, c_size_t]
    m1553LogErrorString.restype = c_int

# /usr/local/include/ait_mil/m1553_replay.h: 105
class struct_anon_115(Structure):
    pass

struct_anon_115.__slots__ = [
    'mAbsoluteTimeReplay',
    'mUseHighTimeTag',
    'mClearEntryType',
    'mNoReplayCount',
    'mCyclicOperation',
    'mNoIntermessageGap',
    'mEnableHalfBufferInterrupt',
    'mEnableReplayStoppedInterrupt',
    'mReplayBufferSize',
]
struct_anon_115._fields_ = [
    ('mAbsoluteTimeReplay', M1553Boolean),
    ('mUseHighTimeTag', M1553Boolean),
    ('mClearEntryType', M1553Boolean),
    ('mNoReplayCount', M1553Boolean),
    ('mCyclicOperation', M1553Boolean),
    ('mNoIntermessageGap', M1553Boolean),
    ('mEnableHalfBufferInterrupt', M1553Boolean),
    ('mEnableReplayStoppedInterrupt', M1553Boolean),
    ('mReplayBufferSize', c_uint32),
]

M1553ReplayInitIn = struct_anon_115# /usr/local/include/ait_mil/m1553_replay.h: 105

# /usr/local/include/ait_mil/m1553_replay.h: 140
class struct_anon_116(Structure):
    pass

struct_anon_116.__slots__ = [
    'mConfigureAllRTsMask',
]
struct_anon_116._fields_ = [
    ('mConfigureAllRTsMask', c_uint32),
]

M1553ReplaySetRTConfigIn = struct_anon_116# /usr/local/include/ait_mil/m1553_replay.h: 140

# /usr/local/include/ait_mil/m1553_replay.h: 158
class struct_anon_117(Structure):
    pass

struct_anon_117.__slots__ = [
    'mConfigureAllRTsMask',
]
struct_anon_117._fields_ = [
    ('mConfigureAllRTsMask', c_uint32),
]

M1553ReplayGetRTConfigOut = struct_anon_117# /usr/local/include/ait_mil/m1553_replay.h: 158

# /usr/local/include/ait_mil/m1553_replay.h: 196
class struct_anon_118(Structure):
    pass

struct_anon_118.__slots__ = [
    'mReplayRunning',
    'mHalfBufferCount',
    'mReplayBufferBaseOffset',
    'mReplayBufferCurrentOffset',
    'mEntryCount',
]
struct_anon_118._fields_ = [
    ('mReplayRunning', M1553Boolean),
    ('mHalfBufferCount', c_uint32),
    ('mReplayBufferBaseOffset', c_uint32),
    ('mReplayBufferCurrentOffset', c_uint32),
    ('mEntryCount', c_uint32),
]

M1553ReplayGetStatusOut = struct_anon_118# /usr/local/include/ait_mil/m1553_replay.h: 196

# /usr/local/include/ait_mil/m1553_replay.h: 223
class struct_anon_119(Structure):
    pass

struct_anon_119.__slots__ = [
    'mData',
    'mOffset',
    'mDataSize',
]
struct_anon_119._fields_ = [
    ('mData', M1553Addr),
    ('mOffset', c_uint32),
    ('mDataSize', c_uint32),
]

M1553ReplayWriteDataIn = struct_anon_119# /usr/local/include/ait_mil/m1553_replay.h: 223

# /usr/local/include/ait_mil/m1553_replay.h: 236
class struct_anon_120(Structure):
    pass

struct_anon_120.__slots__ = [
    'mEntriesWritten',
]
struct_anon_120._fields_ = [
    ('mEntriesWritten', c_uint32),
]

M1553ReplayWriteDataOut = struct_anon_120# /usr/local/include/ait_mil/m1553_replay.h: 236

# /usr/local/include/ait_mil/m1553_replay.h: 259
class struct_anon_121(Structure):
    pass

struct_anon_121.__slots__ = [
    'mData',
    'mOffset',
    'mDataSize',
]
struct_anon_121._fields_ = [
    ('mData', M1553Addr),
    ('mOffset', c_uint32),
    ('mDataSize', c_uint32),
]

M1553ReplayReadDataIn = struct_anon_121# /usr/local/include/ait_mil/m1553_replay.h: 259

# /usr/local/include/ait_mil/m1553_replay.h: 270
class struct_anon_122(Structure):
    pass

struct_anon_122.__slots__ = [
    'mEntriesRead',
]
struct_anon_122._fields_ = [
    ('mEntriesRead', c_uint32),
]

M1553ReplayReadDataOut = struct_anon_122# /usr/local/include/ait_mil/m1553_replay.h: 270

# /usr/local/include/ait_mil/m1553_replay.h: 297
if _libs["libait_mil.so"].has("m1553ReplayInit", "cdecl"):
    m1553ReplayInit = _libs["libait_mil.so"].get("m1553ReplayInit", "cdecl")
    m1553ReplayInit.argtypes = [M1553Handle, POINTER(M1553ReplayInitIn)]
    m1553ReplayInit.restype = c_int

# /usr/local/include/ait_mil/m1553_replay.h: 309
if _libs["libait_mil.so"].has("m1553ReplayReset", "cdecl"):
    m1553ReplayReset = _libs["libait_mil.so"].get("m1553ReplayReset", "cdecl")
    m1553ReplayReset.argtypes = [M1553Handle]
    m1553ReplayReset.restype = c_int

# /usr/local/include/ait_mil/m1553_replay.h: 322
if _libs["libait_mil.so"].has("m1553ReplayRTSetConfig", "cdecl"):
    m1553ReplayRTSetConfig = _libs["libait_mil.so"].get("m1553ReplayRTSetConfig", "cdecl")
    m1553ReplayRTSetConfig.argtypes = [M1553Handle, POINTER(M1553ReplaySetRTConfigIn)]
    m1553ReplayRTSetConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_replay.h: 326
if _libs["libait_mil.so"].has("m1553ReplayRTGetConfig", "cdecl"):
    m1553ReplayRTGetConfig = _libs["libait_mil.so"].get("m1553ReplayRTGetConfig", "cdecl")
    m1553ReplayRTGetConfig.argtypes = [M1553Handle, POINTER(M1553ReplayGetRTConfigOut)]
    m1553ReplayRTGetConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_replay.h: 343
if _libs["libait_mil.so"].has("m1553ReplayStart", "cdecl"):
    m1553ReplayStart = _libs["libait_mil.so"].get("m1553ReplayStart", "cdecl")
    m1553ReplayStart.argtypes = [M1553Handle]
    m1553ReplayStart.restype = c_int

# /usr/local/include/ait_mil/m1553_replay.h: 351
if _libs["libait_mil.so"].has("m1553ReplayStop", "cdecl"):
    m1553ReplayStop = _libs["libait_mil.so"].get("m1553ReplayStop", "cdecl")
    m1553ReplayStop.argtypes = [M1553Handle]
    m1553ReplayStop.restype = c_int

# /usr/local/include/ait_mil/m1553_replay.h: 372
if _libs["libait_mil.so"].has("m1553ReplayGetStatus", "cdecl"):
    m1553ReplayGetStatus = _libs["libait_mil.so"].get("m1553ReplayGetStatus", "cdecl")
    m1553ReplayGetStatus.argtypes = [M1553Handle, POINTER(M1553ReplayGetStatusOut)]
    m1553ReplayGetStatus.restype = c_int

# /usr/local/include/ait_mil/m1553_replay.h: 386
if _libs["libait_mil.so"].has("m1553ReplayWriteData", "cdecl"):
    m1553ReplayWriteData = _libs["libait_mil.so"].get("m1553ReplayWriteData", "cdecl")
    m1553ReplayWriteData.argtypes = [M1553Handle, POINTER(M1553ReplayWriteDataIn), POINTER(M1553ReplayWriteDataOut)]
    m1553ReplayWriteData.restype = c_int

# /usr/local/include/ait_mil/m1553_replay.h: 391
if _libs["libait_mil.so"].has("m1553ReplayReadData", "cdecl"):
    m1553ReplayReadData = _libs["libait_mil.so"].get("m1553ReplayReadData", "cdecl")
    m1553ReplayReadData.argtypes = [M1553Handle, POINTER(M1553ReplayReadDataIn), POINTER(M1553ReplayReadDataOut)]
    m1553ReplayReadData.restype = c_int

enum_anon_123 = c_int# /usr/local/include/ait_mil/m1553_rt.h: 47

M1553_RT_DISABLE = 0# /usr/local/include/ait_mil/m1553_rt.h: 47

M1553_RT_ENABLE_SIMULATION = 1# /usr/local/include/ait_mil/m1553_rt.h: 47

M1553_RT_ENABLE_MONITOR = 2# /usr/local/include/ait_mil/m1553_rt.h: 47

M1553RTEnableModeType = enum_anon_123# /usr/local/include/ait_mil/m1553_rt.h: 47

enum_anon_124 = c_int# /usr/local/include/ait_mil/m1553_rt.h: 66

M1553_RT_RESPONSE_BOTH = 0# /usr/local/include/ait_mil/m1553_rt.h: 66

M1553_RT_RESPONSE_BUSA_ONLY = 1# /usr/local/include/ait_mil/m1553_rt.h: 66

M1553_RT_RESPONSE_BUSB_ONLY = 2# /usr/local/include/ait_mil/m1553_rt.h: 66

M1553RTBusResponseControlType = enum_anon_124# /usr/local/include/ait_mil/m1553_rt.h: 66

enum_anon_125 = c_int# /usr/local/include/ait_mil/m1553_rt.h: 89

M1553_RT_DISABLE_SA = 0# /usr/local/include/ait_mil/m1553_rt.h: 89

M1553_RT_ENABLE_SA = 1# /usr/local/include/ait_mil/m1553_rt.h: 89

M1553_RT_ENABLE_SA_INTERRUPT_TRANSFER = 2# /usr/local/include/ait_mil/m1553_rt.h: 89

M1553_RT_ENABLE_SA_INTERRUPT_ERROR = 3# /usr/local/include/ait_mil/m1553_rt.h: 89

M1553RTSAControlType = enum_anon_125# /usr/local/include/ait_mil/m1553_rt.h: 89

enum_anon_126 = c_int# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_DISABLED = 0# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_STATUS_SYNC = 1# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_DATA_SYNC = 2# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_PARITY = 3# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_MANCHESTER_LOW = 4# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_MANCHESTER_HIGH = 5# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_GAP = 6# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_WORD_COUNT_HIGH = 7# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_WORD_COUNT_LOW = 8# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_BIT_COUNT_HIGH = 9# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_BIT_COUNT_LOW = 10# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_ZERO_CROSSING_NEGATIVE = 11# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_ZERO_CROSSING_POSITIVE = 12# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553_RT_ERROR_ALTERNATE_BUS = 13# /usr/local/include/ait_mil/m1553_rt.h: 164

M1553RTTransferErrorType = enum_anon_126# /usr/local/include/ait_mil/m1553_rt.h: 164

enum_anon_127 = c_int# /usr/local/include/ait_mil/m1553_rt.h: 189

M1553_RT_MASK_OR = 0# /usr/local/include/ait_mil/m1553_rt.h: 189

M1553_RT_MASK_AND = 1# /usr/local/include/ait_mil/m1553_rt.h: 189

M1553_RT_MASK_NEXT_STATUS_WORD_OR = 2# /usr/local/include/ait_mil/m1553_rt.h: 189

M1553_RT_MASK_NEXT_STATUS_WORD_AND = 3# /usr/local/include/ait_mil/m1553_rt.h: 189

M1553RTSAStatusWordControlType = enum_anon_127# /usr/local/include/ait_mil/m1553_rt.h: 189

enum_anon_128 = c_int# /usr/local/include/ait_mil/m1553_rt.h: 208

M1553_RT_BUFFER_NO_ERROR = 0# /usr/local/include/ait_mil/m1553_rt.h: 208

M1553_RT_BUFFER_FRAME_CODING_ERROR = 1# /usr/local/include/ait_mil/m1553_rt.h: 208

M1553_RT_BUFFER_STATUS_WORD_TIMEOUT_ERROR = 2# /usr/local/include/ait_mil/m1553_rt.h: 208

M1553RTBufferErrorStatusType = enum_anon_128# /usr/local/include/ait_mil/m1553_rt.h: 208

# /usr/local/include/ait_mil/m1553_rt.h: 245
class struct_anon_129(Structure):
    pass

struct_anon_129.__slots__ = [
    'mBufferHeaderID',
    'mRTSAControl',
    'mRTSAResponseControl',
    'mStatusWorddMaskControl',
    'mStatusWordMask',
]
struct_anon_129._fields_ = [
    ('mBufferHeaderID', c_uint16),
    ('mRTSAControl', M1553RTSAControlType),
    ('mRTSAResponseControl', c_uint8),
    ('mStatusWorddMaskControl', M1553RTSAStatusWordControlType),
    ('mStatusWordMask', c_uint16),
]

M1553RTSAConfigType = struct_anon_129# /usr/local/include/ait_mil/m1553_rt.h: 245

# /usr/local/include/ait_mil/m1553_rt.h: 306
class struct_anon_130(Structure):
    pass

struct_anon_130.__slots__ = [
    'mTransferErrorType',
    'mErrorWordPosition',
    'mErrorBitPosition',
    'mErrorBitCount',
    'mSyncBitPattern',
    'mParameter',
]
struct_anon_130._fields_ = [
    ('mTransferErrorType', M1553RTTransferErrorType),
    ('mErrorWordPosition', c_uint8),
    ('mErrorBitPosition', c_uint8),
    ('mErrorBitCount', c_uint8),
    ('mSyncBitPattern', c_uint8),
    ('mParameter', c_uint8),
]

M1553RTTransferErrorConfigType = struct_anon_130# /usr/local/include/ait_mil/m1553_rt.h: 306

# /usr/local/include/ait_mil/m1553_rt.h: 326
class struct_anon_131(Structure):
    pass

struct_anon_131.__slots__ = [
    'mBufferFillStatus',
    'mReceivedBus',
    'mBufferError',
]
struct_anon_131._fields_ = [
    ('mBufferFillStatus', M1553BufferFillStatusType),
    ('mReceivedBus', M1553BusType),
    ('mBufferError', M1553RTBufferErrorStatusType),
]

M1553RTBufferStatusType = struct_anon_131# /usr/local/include/ait_mil/m1553_rt.h: 326

# /usr/local/include/ait_mil/m1553_rt.h: 366
class struct_anon_132(Structure):
    pass

struct_anon_132.__slots__ = [
    'mEnableMode',
    'mBusResponseControl',
    'mResponseTime',
    'mNextStatusWord',
    'mLastCommandWord',
    'mLastStatusWord',
]
struct_anon_132._fields_ = [
    ('mEnableMode', M1553RTEnableModeType),
    ('mBusResponseControl', M1553RTBusResponseControlType),
    ('mResponseTime', M1553Float),
    ('mNextStatusWord', c_uint16),
    ('mLastCommandWord', c_uint16),
    ('mLastStatusWord', c_uint16),
]

M1553RTSetConfigIn = struct_anon_132# /usr/local/include/ait_mil/m1553_rt.h: 366

# /usr/local/include/ait_mil/m1553_rt.h: 404
class struct_anon_133(Structure):
    pass

struct_anon_133.__slots__ = [
    'mEnableMode',
    'mBusResponseControl',
    'mResponseTime',
    'mNextStatusWord',
    'mLastCommandWord',
    'mLastStatusWord',
]
struct_anon_133._fields_ = [
    ('mEnableMode', M1553RTEnableModeType),
    ('mBusResponseControl', M1553RTBusResponseControlType),
    ('mResponseTime', M1553Float),
    ('mNextStatusWord', c_uint16),
    ('mLastCommandWord', c_uint16),
    ('mLastStatusWord', c_uint16),
]

M1553RTGetConfigOut = struct_anon_133# /usr/local/include/ait_mil/m1553_rt.h: 404

# /usr/local/include/ait_mil/m1553_rt.h: 416
class struct_anon_134(Structure):
    pass

struct_anon_134.__slots__ = [
    'mResponseTime',
]
struct_anon_134._fields_ = [
    ('mResponseTime', M1553Float),
]

M1553RTSetResponseTimeIn = struct_anon_134# /usr/local/include/ait_mil/m1553_rt.h: 416

# /usr/local/include/ait_mil/m1553_rt.h: 427
class struct_anon_135(Structure):
    pass

struct_anon_135.__slots__ = [
    'mResponseTime',
]
struct_anon_135._fields_ = [
    ('mResponseTime', M1553Float),
]

M1553RTGetResponseTimeOut = struct_anon_135# /usr/local/include/ait_mil/m1553_rt.h: 427

# /usr/local/include/ait_mil/m1553_rt.h: 439
class struct_anon_136(Structure):
    pass

struct_anon_136.__slots__ = [
    'mNextStatusWord',
]
struct_anon_136._fields_ = [
    ('mNextStatusWord', c_uint16),
]

M1553RTSetNextStatusWordIn = struct_anon_136# /usr/local/include/ait_mil/m1553_rt.h: 439

# /usr/local/include/ait_mil/m1553_rt.h: 451
class struct_anon_137(Structure):
    pass

struct_anon_137.__slots__ = [
    'mNextStatusWord',
]
struct_anon_137._fields_ = [
    ('mNextStatusWord', c_uint16),
]

M1553RTGetNextStatusWordOut = struct_anon_137# /usr/local/include/ait_mil/m1553_rt.h: 451

# /usr/local/include/ait_mil/m1553_rt.h: 464
class struct_anon_138(Structure):
    pass

struct_anon_138.__slots__ = [
    'mLastCommandWord',
]
struct_anon_138._fields_ = [
    ('mLastCommandWord', c_uint16),
]

M1553RTSetLastCommandWordIn = struct_anon_138# /usr/local/include/ait_mil/m1553_rt.h: 464

# /usr/local/include/ait_mil/m1553_rt.h: 477
class struct_anon_139(Structure):
    pass

struct_anon_139.__slots__ = [
    'mLastCommandWord',
]
struct_anon_139._fields_ = [
    ('mLastCommandWord', c_uint16),
]

M1553RTGetLastCommandWordOut = struct_anon_139# /usr/local/include/ait_mil/m1553_rt.h: 477

# /usr/local/include/ait_mil/m1553_rt.h: 491
class struct_anon_140(Structure):
    pass

struct_anon_140.__slots__ = [
    'mLastStatusWord',
]
struct_anon_140._fields_ = [
    ('mLastStatusWord', c_uint16),
]

M1553RTSetLastStatusWordIn = struct_anon_140# /usr/local/include/ait_mil/m1553_rt.h: 491

# /usr/local/include/ait_mil/m1553_rt.h: 504
class struct_anon_141(Structure):
    pass

struct_anon_141.__slots__ = [
    'mLastStatusWord',
]
struct_anon_141._fields_ = [
    ('mLastStatusWord', c_uint16),
]

M1553RTGetLastStatusWordOut = struct_anon_141# /usr/local/include/ait_mil/m1553_rt.h: 504

# /usr/local/include/ait_mil/m1553_rt.h: 515
class struct_anon_142(Structure):
    pass

struct_anon_142.__slots__ = [
    'mBufferHeader',
]
struct_anon_142._fields_ = [
    ('mBufferHeader', M1553BufferHeaderDefinitionType),
]

M1553RTSetBufferHeaderIn = struct_anon_142# /usr/local/include/ait_mil/m1553_rt.h: 515

# /usr/local/include/ait_mil/m1553_rt.h: 545
class struct_anon_143(Structure):
    pass

struct_anon_143.__slots__ = [
    'mBufferHeader',
    'mHeaderOffset',
    'mBufferOffset',
    'mStatusQueueOffset',
    'mEventQueueOffset',
]
struct_anon_143._fields_ = [
    ('mBufferHeader', M1553BufferHeaderDefinitionType),
    ('mHeaderOffset', c_uint32),
    ('mBufferOffset', c_uint32),
    ('mStatusQueueOffset', c_uint32),
    ('mEventQueueOffset', c_uint32),
]

M1553RTGetBufferHeaderOut = struct_anon_143# /usr/local/include/ait_mil/m1553_rt.h: 545

# /usr/local/include/ait_mil/m1553_rt.h: 574
class struct_anon_144(Structure):
    pass

struct_anon_144.__slots__ = [
    'mRT',
    'mRTSA',
    'mTransferType',
    'mRTSAProperties',
]
struct_anon_144._fields_ = [
    ('mRT', c_uint8),
    ('mRTSA', c_uint8),
    ('mTransferType', M1553SubAddressType),
    ('mRTSAProperties', M1553RTSAConfigType),
]

M1553RTSASetConfigIn = struct_anon_144# /usr/local/include/ait_mil/m1553_rt.h: 574

# /usr/local/include/ait_mil/m1553_rt.h: 596
class struct_anon_145(Structure):
    pass

struct_anon_145.__slots__ = [
    'mRT',
    'mRTSA',
    'mTransferType',
]
struct_anon_145._fields_ = [
    ('mRT', c_uint8),
    ('mRTSA', c_uint8),
    ('mTransferType', M1553SubAddressType),
]

M1553RTSAGetConfigIn = struct_anon_145# /usr/local/include/ait_mil/m1553_rt.h: 596

# /usr/local/include/ait_mil/m1553_rt.h: 615
class struct_anon_146(Structure):
    pass

struct_anon_146.__slots__ = [
    'mRTSAProperties',
    'mBufferHeaderOffset',
]
struct_anon_146._fields_ = [
    ('mRTSAProperties', M1553RTSAConfigType),
    ('mBufferHeaderOffset', c_uint32),
]

M1553RTSAGetConfigOut = struct_anon_146# /usr/local/include/ait_mil/m1553_rt.h: 615

# /usr/local/include/ait_mil/m1553_rt.h: 639
class struct_anon_147(Structure):
    pass

struct_anon_147.__slots__ = [
    'mRT',
    'mRTSA',
    'mTransferType',
]
struct_anon_147._fields_ = [
    ('mRT', c_uint8),
    ('mRTSA', c_uint8),
    ('mTransferType', M1553SubAddressType),
]

M1553RTSAGetErrorConfigIn = struct_anon_147# /usr/local/include/ait_mil/m1553_rt.h: 639

# /usr/local/include/ait_mil/m1553_rt.h: 650
class struct_anon_148(Structure):
    pass

struct_anon_148.__slots__ = [
    'mRTSAErrorConfig',
]
struct_anon_148._fields_ = [
    ('mRTSAErrorConfig', M1553RTTransferErrorConfigType),
]

M1553RTSAGetErrorConfigOut = struct_anon_148# /usr/local/include/ait_mil/m1553_rt.h: 650

# /usr/local/include/ait_mil/m1553_rt.h: 676
class struct_anon_149(Structure):
    pass

struct_anon_149.__slots__ = [
    'mRT',
    'mRTSA',
    'mTransferType',
    'mRTSAErrorConfig',
]
struct_anon_149._fields_ = [
    ('mRT', c_uint8),
    ('mRTSA', c_uint8),
    ('mTransferType', M1553SubAddressType),
    ('mRTSAErrorConfig', M1553RTTransferErrorConfigType),
]

M1553RTSASetErrorConfigIn = struct_anon_149# /usr/local/include/ait_mil/m1553_rt.h: 676

# /usr/local/include/ait_mil/m1553_rt.h: 688
class struct_anon_150(Structure):
    pass

struct_anon_150.__slots__ = [
    'mRTEnableMode',
]
struct_anon_150._fields_ = [
    ('mRTEnableMode', M1553RTEnableModeType),
]

M1553RTSetEnableIn = struct_anon_150# /usr/local/include/ait_mil/m1553_rt.h: 688

# /usr/local/include/ait_mil/m1553_rt.h: 699
class struct_anon_151(Structure):
    pass

struct_anon_151.__slots__ = [
    'mRTEnableMode',
]
struct_anon_151._fields_ = [
    ('mRTEnableMode', M1553RTEnableModeType),
]

M1553RTGetEnableOut = struct_anon_151# /usr/local/include/ait_mil/m1553_rt.h: 699

# /usr/local/include/ait_mil/m1553_rt.h: 723
class struct_anon_152(Structure):
    pass

struct_anon_152.__slots__ = [
    'mRunning',
    'mMessageCount',
    'mErrorCount',
]
struct_anon_152._fields_ = [
    ('mRunning', M1553Boolean),
    ('mMessageCount', c_uint32),
    ('mErrorCount', c_uint32),
]

M1553RTGetStatusOut = struct_anon_152# /usr/local/include/ait_mil/m1553_rt.h: 723

# /usr/local/include/ait_mil/m1553_rt.h: 756
class struct_anon_153(Structure):
    pass

struct_anon_153.__slots__ = [
    'mRTRunning',
    'mMessageCount',
    'mErrorCount',
    'mNextStatusWord',
    'mLastStatusWord',
    'mLastCommandWord',
]
struct_anon_153._fields_ = [
    ('mRTRunning', M1553Boolean),
    ('mMessageCount', c_uint32),
    ('mErrorCount', c_uint32),
    ('mNextStatusWord', c_uint16),
    ('mLastStatusWord', c_uint16),
    ('mLastCommandWord', c_uint16),
]

M1553RTGetRTStatusOut = struct_anon_153# /usr/local/include/ait_mil/m1553_rt.h: 756

# /usr/local/include/ait_mil/m1553_rt.h: 775
class struct_anon_154(Structure):
    pass

struct_anon_154.__slots__ = [
    'mNextStatusWord',
    'mLastStatusWord',
    'mLastCommandWord',
]
struct_anon_154._fields_ = [
    ('mNextStatusWord', c_uint16),
    ('mLastStatusWord', c_uint16),
    ('mLastCommandWord', c_uint16),
]

M1553RTSetRTStatusIn = struct_anon_154# /usr/local/include/ait_mil/m1553_rt.h: 775

# /usr/local/include/ait_mil/m1553_rt.h: 805
class struct_anon_155(Structure):
    pass

struct_anon_155.__slots__ = [
    'mRT',
    'mSA',
    'mTransferType',
    'mResetBufferErrorStatus',
    'mResetBufferStatus',
]
struct_anon_155._fields_ = [
    ('mRT', c_uint8),
    ('mSA', c_uint8),
    ('mTransferType', M1553SubAddressType),
    ('mResetBufferErrorStatus', M1553Boolean),
    ('mResetBufferStatus', M1553Boolean),
]

M1553RTGetRTSAStatusIn = struct_anon_155# /usr/local/include/ait_mil/m1553_rt.h: 805

# /usr/local/include/ait_mil/m1553_rt.h: 850
class struct_anon_156(Structure):
    pass

struct_anon_156.__slots__ = [
    'mCurrentBufferIndex',
    'mLastBufferOffset',
    'mBufferStatus',
    'mLastCommandWord',
    'mLastStatusWord',
    'mTimeTagMinutes',
    'mTimeTagSeconds',
    'mTimeTagMicroseconds',
]
struct_anon_156._fields_ = [
    ('mCurrentBufferIndex', c_uint16),
    ('mLastBufferOffset', c_uint32),
    ('mBufferStatus', M1553RTBufferStatusType),
    ('mLastCommandWord', c_uint16),
    ('mLastStatusWord', c_uint16),
    ('mTimeTagMinutes', c_uint8),
    ('mTimeTagSeconds', c_uint8),
    ('mTimeTagMicroseconds', c_uint32),
]

M1553RTGetRTSAStatusOut = struct_anon_156# /usr/local/include/ait_mil/m1553_rt.h: 850

# /usr/local/include/ait_mil/m1553_rt.h: 894
class struct_anon_157(Structure):
    pass

struct_anon_157.__slots__ = [
    'mEnableMode',
    'mReceiveSA',
    'mTransmitSA',
    'mReceiveModeCode',
    'mTransmitModeCode',
]
struct_anon_157._fields_ = [
    ('mEnableMode', M1553RTEnableModeType),
    ('mReceiveSA', c_uint32),
    ('mTransmitSA', c_uint32),
    ('mReceiveModeCode', c_uint32),
    ('mTransmitModeCode', c_uint32),
]

M1553RTGetSimulationInfoOut = struct_anon_157# /usr/local/include/ait_mil/m1553_rt.h: 894

# /usr/local/include/ait_mil/m1553_rt.h: 948
class struct_anon_158(Structure):
    pass

struct_anon_158.__slots__ = [
    'mRxConfigurationModeA',
    'mTxConfigurationModeA',
    'mDataConfigurationModeA',
    'mRxConfigurationModeB',
    'mTxConfigurationModeB',
    'mDataConfigurationModeB',
]
struct_anon_158._fields_ = [
    ('mRxConfigurationModeA', c_uint32),
    ('mTxConfigurationModeA', c_uint32),
    ('mDataConfigurationModeA', c_uint32),
    ('mRxConfigurationModeB', c_uint32),
    ('mTxConfigurationModeB', c_uint32),
    ('mDataConfigurationModeB', c_uint32),
]

M1553RTModeCodeSetConfigIn = struct_anon_158# /usr/local/include/ait_mil/m1553_rt.h: 948

# /usr/local/include/ait_mil/m1553_rt.h: 996
class struct_anon_159(Structure):
    pass

struct_anon_159.__slots__ = [
    'mRxConfigurationModeA',
    'mTxConfigurationModeA',
    'mDataConfigurationModeA',
    'mRxConfigurationModeB',
    'mTxConfigurationModeB',
    'mDataConfigurationModeB',
]
struct_anon_159._fields_ = [
    ('mRxConfigurationModeA', c_uint32),
    ('mTxConfigurationModeA', c_uint32),
    ('mDataConfigurationModeA', c_uint32),
    ('mRxConfigurationModeB', c_uint32),
    ('mTxConfigurationModeB', c_uint32),
    ('mDataConfigurationModeB', c_uint32),
]

M1553RTModeCodeGetConfigOut = struct_anon_159# /usr/local/include/ait_mil/m1553_rt.h: 996

# /usr/local/include/ait_mil/m1553_rt.h: 1053
if _libs["libait_mil.so"].has("m1553RTInit", "cdecl"):
    m1553RTInit = _libs["libait_mil.so"].get("m1553RTInit", "cdecl")
    m1553RTInit.argtypes = [M1553Handle]
    m1553RTInit.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1106
if _libs["libait_mil.so"].has("m1553RTSetConfig", "cdecl"):
    m1553RTSetConfig = _libs["libait_mil.so"].get("m1553RTSetConfig", "cdecl")
    m1553RTSetConfig.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTSetConfigIn)]
    m1553RTSetConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1144
if _libs["libait_mil.so"].has("m1553RTGetConfig", "cdecl"):
    m1553RTGetConfig = _libs["libait_mil.so"].get("m1553RTGetConfig", "cdecl")
    m1553RTGetConfig.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTGetConfigOut)]
    m1553RTGetConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1200
if _libs["libait_mil.so"].has("m1553RTSASetBufferHeader", "cdecl"):
    m1553RTSASetBufferHeader = _libs["libait_mil.so"].get("m1553RTSASetBufferHeader", "cdecl")
    m1553RTSASetBufferHeader.argtypes = [M1553Handle, c_uint16, POINTER(M1553RTSetBufferHeaderIn)]
    m1553RTSASetBufferHeader.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1235
if _libs["libait_mil.so"].has("m1553RTSAGetBufferHeader", "cdecl"):
    m1553RTSAGetBufferHeader = _libs["libait_mil.so"].get("m1553RTSAGetBufferHeader", "cdecl")
    m1553RTSAGetBufferHeader.argtypes = [M1553Handle, c_uint16, POINTER(M1553RTGetBufferHeaderOut)]
    m1553RTSAGetBufferHeader.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1293
if _libs["libait_mil.so"].has("m1553RTSASetConfig", "cdecl"):
    m1553RTSASetConfig = _libs["libait_mil.so"].get("m1553RTSASetConfig", "cdecl")
    m1553RTSASetConfig.argtypes = [M1553Handle, POINTER(M1553RTSASetConfigIn)]
    m1553RTSASetConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1336
if _libs["libait_mil.so"].has("m1553RTSAGetConfig", "cdecl"):
    m1553RTSAGetConfig = _libs["libait_mil.so"].get("m1553RTSAGetConfig", "cdecl")
    m1553RTSAGetConfig.argtypes = [M1553Handle, POINTER(M1553RTSAGetConfigIn), POINTER(M1553RTSAGetConfigOut)]
    m1553RTSAGetConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1378
if _libs["libait_mil.so"].has("m1553RTSAGetErrorConfig", "cdecl"):
    m1553RTSAGetErrorConfig = _libs["libait_mil.so"].get("m1553RTSAGetErrorConfig", "cdecl")
    m1553RTSAGetErrorConfig.argtypes = [M1553Handle, POINTER(M1553RTSAGetErrorConfigIn), POINTER(M1553RTSAGetErrorConfigOut)]
    m1553RTSAGetErrorConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1446
if _libs["libait_mil.so"].has("m1553RTSASetErrorConfig", "cdecl"):
    m1553RTSASetErrorConfig = _libs["libait_mil.so"].get("m1553RTSASetErrorConfig", "cdecl")
    m1553RTSASetErrorConfig.argtypes = [M1553Handle, POINTER(M1553RTSASetErrorConfigIn)]
    m1553RTSASetErrorConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1492
if _libs["libait_mil.so"].has("m1553RTSetEnable", "cdecl"):
    m1553RTSetEnable = _libs["libait_mil.so"].get("m1553RTSetEnable", "cdecl")
    m1553RTSetEnable.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTSetEnableIn)]
    m1553RTSetEnable.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1526
if _libs["libait_mil.so"].has("m1553RTGetEnable", "cdecl"):
    m1553RTGetEnable = _libs["libait_mil.so"].get("m1553RTGetEnable", "cdecl")
    m1553RTGetEnable.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTGetEnableOut)]
    m1553RTGetEnable.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1548
if _libs["libait_mil.so"].has("m1553RTStart", "cdecl"):
    m1553RTStart = _libs["libait_mil.so"].get("m1553RTStart", "cdecl")
    m1553RTStart.argtypes = [M1553Handle]
    m1553RTStart.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1568
if _libs["libait_mil.so"].has("m1553RTStop", "cdecl"):
    m1553RTStop = _libs["libait_mil.so"].get("m1553RTStop", "cdecl")
    m1553RTStop.argtypes = [M1553Handle]
    m1553RTStop.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1602
if _libs["libait_mil.so"].has("m1553RTGetStatus", "cdecl"):
    m1553RTGetStatus = _libs["libait_mil.so"].get("m1553RTGetStatus", "cdecl")
    m1553RTGetStatus.argtypes = [M1553Handle, POINTER(M1553RTGetStatusOut)]
    m1553RTGetStatus.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1640
if _libs["libait_mil.so"].has("m1553RTGetRTStatus", "cdecl"):
    m1553RTGetRTStatus = _libs["libait_mil.so"].get("m1553RTGetRTStatus", "cdecl")
    m1553RTGetRTStatus.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTGetRTStatusOut)]
    m1553RTGetRTStatus.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1678
if _libs["libait_mil.so"].has("m1553RTSetRTStatus", "cdecl"):
    m1553RTSetRTStatus = _libs["libait_mil.so"].get("m1553RTSetRTStatus", "cdecl")
    m1553RTSetRTStatus.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTSetRTStatusIn)]
    m1553RTSetRTStatus.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1730
if _libs["libait_mil.so"].has("m1553RTGetRTSAStatus", "cdecl"):
    m1553RTGetRTSAStatus = _libs["libait_mil.so"].get("m1553RTGetRTSAStatus", "cdecl")
    m1553RTGetRTSAStatus.argtypes = [M1553Handle, POINTER(M1553RTGetRTSAStatusIn), POINTER(M1553RTGetRTSAStatusOut)]
    m1553RTGetRTSAStatus.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1763
if _libs["libait_mil.so"].has("m1553RTGetSimulationInfo", "cdecl"):
    m1553RTGetSimulationInfo = _libs["libait_mil.so"].get("m1553RTGetSimulationInfo", "cdecl")
    m1553RTGetSimulationInfo.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTGetSimulationInfoOut)]
    m1553RTGetSimulationInfo.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1800
if _libs["libait_mil.so"].has("m1553RTSetResponseTime", "cdecl"):
    m1553RTSetResponseTime = _libs["libait_mil.so"].get("m1553RTSetResponseTime", "cdecl")
    m1553RTSetResponseTime.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTSetResponseTimeIn)]
    m1553RTSetResponseTime.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1833
if _libs["libait_mil.so"].has("m1553RTGetResponseTime", "cdecl"):
    m1553RTGetResponseTime = _libs["libait_mil.so"].get("m1553RTGetResponseTime", "cdecl")
    m1553RTGetResponseTime.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTGetResponseTimeOut)]
    m1553RTGetResponseTime.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1867
if _libs["libait_mil.so"].has("m1553RTSetNextStatusWord", "cdecl"):
    m1553RTSetNextStatusWord = _libs["libait_mil.so"].get("m1553RTSetNextStatusWord", "cdecl")
    m1553RTSetNextStatusWord.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTSetNextStatusWordIn)]
    m1553RTSetNextStatusWord.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1901
if _libs["libait_mil.so"].has("m1553RTGetNextStatusWord", "cdecl"):
    m1553RTGetNextStatusWord = _libs["libait_mil.so"].get("m1553RTGetNextStatusWord", "cdecl")
    m1553RTGetNextStatusWord.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTGetNextStatusWordOut)]
    m1553RTGetNextStatusWord.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1939
if _libs["libait_mil.so"].has("m1553RTSetLastCommandWord", "cdecl"):
    m1553RTSetLastCommandWord = _libs["libait_mil.so"].get("m1553RTSetLastCommandWord", "cdecl")
    m1553RTSetLastCommandWord.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTSetLastCommandWordIn)]
    m1553RTSetLastCommandWord.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 1973
if _libs["libait_mil.so"].has("m1553RTGetLastCommandWord", "cdecl"):
    m1553RTGetLastCommandWord = _libs["libait_mil.so"].get("m1553RTGetLastCommandWord", "cdecl")
    m1553RTGetLastCommandWord.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTGetLastCommandWordOut)]
    m1553RTGetLastCommandWord.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 2010
if _libs["libait_mil.so"].has("m1553RTSetLastStatusWord", "cdecl"):
    m1553RTSetLastStatusWord = _libs["libait_mil.so"].get("m1553RTSetLastStatusWord", "cdecl")
    m1553RTSetLastStatusWord.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTSetLastStatusWordIn)]
    m1553RTSetLastStatusWord.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 2044
if _libs["libait_mil.so"].has("m1553RTGetLastStatusWord", "cdecl"):
    m1553RTGetLastStatusWord = _libs["libait_mil.so"].get("m1553RTGetLastStatusWord", "cdecl")
    m1553RTGetLastStatusWord.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTGetLastStatusWordOut)]
    m1553RTGetLastStatusWord.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 2079
if _libs["libait_mil.so"].has("m1553RTModeCodeSetConfig", "cdecl"):
    m1553RTModeCodeSetConfig = _libs["libait_mil.so"].get("m1553RTModeCodeSetConfig", "cdecl")
    m1553RTModeCodeSetConfig.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTModeCodeSetConfigIn)]
    m1553RTModeCodeSetConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_rt.h: 2113
if _libs["libait_mil.so"].has("m1553RTModeCodeGetConfig", "cdecl"):
    m1553RTModeCodeGetConfig = _libs["libait_mil.so"].get("m1553RTModeCodeGetConfig", "cdecl")
    m1553RTModeCodeGetConfig.argtypes = [M1553Handle, c_uint8, POINTER(M1553RTModeCodeGetConfigOut)]
    m1553RTModeCodeGetConfig.restype = c_int

enum_anon_160 = c_int# /usr/local/include/ait_mil/m1553_system.h: 71

M1553_DISCRETE_PUSH_PULL = 0# /usr/local/include/ait_mil/m1553_system.h: 71

M1553_DISCRETE_LINE_DRIVER = (M1553_DISCRETE_PUSH_PULL + 1)# /usr/local/include/ait_mil/m1553_system.h: 71

M1553_DISCRETE_OPEN_COLLECTOR = (M1553_DISCRETE_LINE_DRIVER + 1)# /usr/local/include/ait_mil/m1553_system.h: 71

M1553_DISCRETE_RECEIVER = (M1553_DISCRETE_OPEN_COLLECTOR + 1)# /usr/local/include/ait_mil/m1553_system.h: 71

M1553DiscreteDriverType = enum_anon_160# /usr/local/include/ait_mil/m1553_system.h: 71

enum_anon_161 = c_int# /usr/local/include/ait_mil/m1553_system.h: 96

M1553_TRIG_BC_INPUT = 0# /usr/local/include/ait_mil/m1553_system.h: 96

M1553_TRIG_BC_OUTPUT = (M1553_TRIG_BC_INPUT + 1)# /usr/local/include/ait_mil/m1553_system.h: 96

M1553_TRIG_BM_INPUT = (M1553_TRIG_BC_OUTPUT + 1)# /usr/local/include/ait_mil/m1553_system.h: 96

M1553_TRIG_BM_OUTPUT = (M1553_TRIG_BM_INPUT + 1)# /usr/local/include/ait_mil/m1553_system.h: 96

M1553TriggerFunctionType = enum_anon_161# /usr/local/include/ait_mil/m1553_system.h: 96

enum_anon_162 = c_int# /usr/local/include/ait_mil/m1553_system.h: 128

M1553_INTERRUPT_RT = 0# /usr/local/include/ait_mil/m1553_system.h: 128

M1553_INTERRUPT_BC = 1# /usr/local/include/ait_mil/m1553_system.h: 128

M1553_INTERRUPT_BM = 2# /usr/local/include/ait_mil/m1553_system.h: 128

M1553_INTERRUPT_REPLAY = 3# /usr/local/include/ait_mil/m1553_system.h: 128

M1553_INTERRUPT_BC_BRANCH = 4# /usr/local/include/ait_mil/m1553_system.h: 128

M1553_INTERRUPT_DISCRETE = 5# /usr/local/include/ait_mil/m1553_system.h: 128

M1553InterruptType = enum_anon_162# /usr/local/include/ait_mil/m1553_system.h: 128

enum_anon_163 = c_int# /usr/local/include/ait_mil/m1553_system.h: 143

M1553_CARRIER_FRONT_PANEL_IO = 0# /usr/local/include/ait_mil/m1553_system.h: 143

M1553_CARRIER_BACKPLANE_IO = 1# /usr/local/include/ait_mil/m1553_system.h: 143

M1553TriggerModeType = enum_anon_163# /usr/local/include/ait_mil/m1553_system.h: 143

M1553_INT_FUNC_PTR = CFUNCTYPE(UNCHECKED(None), M1553Handle, M1553InterruptType, M1553InterruptLoglistEntryType, M1553Addr)# /usr/local/include/ait_mil/m1553_system.h: 149

enum_anon_164 = c_int# /usr/local/include/ait_mil/m1553_system.h: 187

DEVICE_EVENT_NONE = 0# /usr/local/include/ait_mil/m1553_system.h: 187

DEVICE_EVENT_RT = 1# /usr/local/include/ait_mil/m1553_system.h: 187

DEVICE_EVENT_BC = 2# /usr/local/include/ait_mil/m1553_system.h: 187

DEVICE_EVENT_BM = 4# /usr/local/include/ait_mil/m1553_system.h: 187

DEVICE_EVENT_REPLAY = 8# /usr/local/include/ait_mil/m1553_system.h: 187

DEVICE_EVENT_BC_BRANCH = 16# /usr/local/include/ait_mil/m1553_system.h: 187

DEVICE_EVENT_DISCRETE = 32# /usr/local/include/ait_mil/m1553_system.h: 187

TY_DEVICE_EVENT_TYPES = enum_anon_164# /usr/local/include/ait_mil/m1553_system.h: 187

# /usr/local/include/ait_mil/m1553_system.h: 214
class struct_anon_165(Structure):
    pass

struct_anon_165.__slots__ = [
    'aChannelHandle',
    'aType',
    'aInterruptInfo',
    'aUserData',
]
struct_anon_165._fields_ = [
    ('aChannelHandle', M1553Handle),
    ('aType', M1553InterruptType),
    ('aInterruptInfo', M1553InterruptLoglistEntryType),
    ('aUserData', M1553Addr),
]

TY_DEVICE_EVENT_NOTIFY = struct_anon_165# /usr/local/include/ait_mil/m1553_system.h: 214

enum_anon_166 = c_int# /usr/local/include/ait_mil/m1553_system.h: 238

M1553_RESET_ALL = 0# /usr/local/include/ait_mil/m1553_system.h: 238

M1553_RESET_INITIALIZE_MEMORY = 1# /usr/local/include/ait_mil/m1553_system.h: 238

M1553_RESET_MEMORY_PARTITIONS = 2# /usr/local/include/ait_mil/m1553_system.h: 238

M1553_RESET_INTERRUPT_REGISTERS = 3# /usr/local/include/ait_mil/m1553_system.h: 238

M1553ResetMode = enum_anon_166# /usr/local/include/ait_mil/m1553_system.h: 238

enum_anon_167 = c_int# /usr/local/include/ait_mil/m1553_system.h: 253

M1553_PROTOCOL_1553A = 0# /usr/local/include/ait_mil/m1553_system.h: 253

M1553_PROTOCOL_1553B = 1# /usr/local/include/ait_mil/m1553_system.h: 253

M1553MilProtocolType = enum_anon_167# /usr/local/include/ait_mil/m1553_system.h: 253

enum_anon_168 = c_int# /usr/local/include/ait_mil/m1553_system.h: 269

M1553_BIT_RATE_1MHZ = 0# /usr/local/include/ait_mil/m1553_system.h: 269

M1553_BIT_RATE_500KHZ = 1# /usr/local/include/ait_mil/m1553_system.h: 269

M1553ChannelBitrate = enum_anon_168# /usr/local/include/ait_mil/m1553_system.h: 269

enum_anon_169 = c_int# /usr/local/include/ait_mil/m1553_system.h: 300

M1553_ISOLATED = 0# /usr/local/include/ait_mil/m1553_system.h: 300

M1553_TRANSFORMER = 1# /usr/local/include/ait_mil/m1553_system.h: 300

M1553_DIRECT = 2# /usr/local/include/ait_mil/m1553_system.h: 300

M1553_EXTERNAL = 3# /usr/local/include/ait_mil/m1553_system.h: 300

M1553_WRAP = 4# /usr/local/include/ait_mil/m1553_system.h: 300

M1553CouplingType = enum_anon_169# /usr/local/include/ait_mil/m1553_system.h: 300

enum_anon_170 = c_int# /usr/local/include/ait_mil/m1553_system.h: 330

M1553_LICENSE_FULL = 0# /usr/local/include/ait_mil/m1553_system.h: 330

M1553_LICENSE_SIMULATOR_ONLY = 1# /usr/local/include/ait_mil/m1553_system.h: 330

M1553_LICENSE_SINGLE_FUNCTION = 2# /usr/local/include/ait_mil/m1553_system.h: 330

M1553_LICENSE_MONITOR_ONLY = 3# /usr/local/include/ait_mil/m1553_system.h: 330

M1553_LICENSE_NOT_PRESENT = 4# /usr/local/include/ait_mil/m1553_system.h: 330

M1553BoardLicenseType = enum_anon_170# /usr/local/include/ait_mil/m1553_system.h: 330

enum_anon_171 = c_int# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_RESERVED0 = 0# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_PMC = 1# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_VME = 2# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_VXI = 3# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_CPCI = 4# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_PCCARD = 5# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_EXRESSCARD = 6# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_PCIX = 7# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_USB = 8# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_XMC = 9# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_PC104P = 10# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_PXIE = 11# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_PCI_EXPRESS = 12# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_RESERVEDFD = 13# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_PXI = 14# /usr/local/include/ait_mil/m1553_system.h: 403

M1553_RESERVEDF = 15# /usr/local/include/ait_mil/m1553_system.h: 403

M1553DeviceBackplane = enum_anon_171# /usr/local/include/ait_mil/m1553_system.h: 403

enum_anon_172 = c_int# /usr/local/include/ait_mil/m1553_system.h: 419

M1553_COMPATIBLE = 0# /usr/local/include/ait_mil/m1553_system.h: 419

M1553_FIRMWARE_NOT_COMPATIBLE = 1# /usr/local/include/ait_mil/m1553_system.h: 419

M1553SoftwareCompatibility = enum_anon_172# /usr/local/include/ait_mil/m1553_system.h: 419

enum_anon_173 = c_int# /usr/local/include/ait_mil/m1553_system.h: 442

M1553_IRIG_SOURCE_INTERNAL = 0# /usr/local/include/ait_mil/m1553_system.h: 442

M1553_IRIG_SOURCE_EXTERNAL = 1# /usr/local/include/ait_mil/m1553_system.h: 442

M1553IrigSourceType = enum_anon_173# /usr/local/include/ait_mil/m1553_system.h: 442

# /usr/local/include/ait_mil/m1553_system.h: 486
class struct_anon_174(Structure):
    pass

struct_anon_174.__slots__ = [
    'mNetworkCoupling',
    'mTransformerCoupling',
    'mDirectCoupling',
    'mIsolatedCoupling',
    'mDigitalWrapCoupling',
    'mFixedCoupling',
]
struct_anon_174._fields_ = [
    ('mNetworkCoupling', M1553Boolean),
    ('mTransformerCoupling', M1553Boolean),
    ('mDirectCoupling', M1553Boolean),
    ('mIsolatedCoupling', M1553Boolean),
    ('mDigitalWrapCoupling', M1553Boolean),
    ('mFixedCoupling', M1553Boolean),
]

M1553CouplingCapabilities = struct_anon_174# /usr/local/include/ait_mil/m1553_system.h: 486

# /usr/local/include/ait_mil/m1553_system.h: 510
class struct_anon_175(Structure):
    pass

struct_anon_175.__slots__ = [
    'mSinusoidalCarrier',
    'mFreeWheeling',
    'mSwitchable',
]
struct_anon_175._fields_ = [
    ('mSinusoidalCarrier', M1553Boolean),
    ('mFreeWheeling', M1553Boolean),
    ('mSwitchable', M1553Boolean),
]

M1553IrigCapabilities = struct_anon_175# /usr/local/include/ait_mil/m1553_system.h: 510

# /usr/local/include/ait_mil/m1553_system.h: 618
class struct_anon_176(Structure):
    pass

struct_anon_176.__slots__ = [
    'mDeviceBackplane',
    'mBoardType',
    'mFirmwareVersion',
    'mSoftwareCompatibility',
    'mChannelCount',
    'mSerialNumber',
    'mPartNumber',
    'mVariableAmplitude',
    'mCouplingCapabilities',
    'mIrigCapabilities',
    'mGlobalRamSize',
    'mChannelMemorySize',
    'mChannelMemoryOffset',
    'mPciConfigRegisters',
]
struct_anon_176._fields_ = [
    ('mDeviceBackplane', M1553DeviceBackplane),
    ('mBoardType', M1553BoardLicenseType),
    ('mFirmwareVersion', c_uint32),
    ('mSoftwareCompatibility', M1553SoftwareCompatibility),
    ('mChannelCount', c_uint8),
    ('mSerialNumber', c_uint32),
    ('mPartNumber', c_uint32),
    ('mVariableAmplitude', M1553Boolean),
    ('mCouplingCapabilities', M1553CouplingCapabilities),
    ('mIrigCapabilities', M1553IrigCapabilities),
    ('mGlobalRamSize', c_uint32),
    ('mChannelMemorySize', c_uint32 * int(4)),
    ('mChannelMemoryOffset', c_uint32 * int(4)),
    ('mPciConfigRegisters', c_uint32 * int(16)),
]

M1553GetBoardInfoOut = struct_anon_176# /usr/local/include/ait_mil/m1553_system.h: 618

# /usr/local/include/ait_mil/m1553_system.h: 694
class struct_anon_177(Structure):
    pass

struct_anon_177.__slots__ = [
    'mChargeDataRaw',
    'mConversionCounter',
    'mCurrentValueRaw',
    'mVoltageValueRaw',
    'mTemperatureValueRaw',
    'mPartType',
    'mDeviceIdLow',
    'mDeviceIdHigh',
    'mDeviceIdCrc',
    'mChargerACPresent',
    'mChargingBattery',
]
struct_anon_177._fields_ = [
    ('mChargeDataRaw', c_uint16),
    ('mConversionCounter', c_uint16),
    ('mCurrentValueRaw', c_uint16),
    ('mVoltageValueRaw', c_uint16),
    ('mTemperatureValueRaw', c_uint16),
    ('mPartType', c_uint8),
    ('mDeviceIdLow', c_uint32),
    ('mDeviceIdHigh', c_uint32),
    ('mDeviceIdCrc', c_uint8),
    ('mChargerACPresent', M1553Boolean),
    ('mChargingBattery', M1553Boolean),
]

M1553USBGetBatteryInfoOut = struct_anon_177# /usr/local/include/ait_mil/m1553_system.h: 694

enum_anon_178 = c_int# /usr/local/include/ait_mil/m1553_system.h: 704

M1553_USB_LED_STATE_OFF = 0# /usr/local/include/ait_mil/m1553_system.h: 704

M1553_USB_LED_STATE_GREEN = (M1553_USB_LED_STATE_OFF + 1)# /usr/local/include/ait_mil/m1553_system.h: 704

M1553_USB_LED_STATE_RED = (M1553_USB_LED_STATE_GREEN + 1)# /usr/local/include/ait_mil/m1553_system.h: 704

M1553USBFrontPanelLEDState = enum_anon_178# /usr/local/include/ait_mil/m1553_system.h: 704

# /usr/local/include/ait_mil/m1553_system.h: 725
class struct_anon_179(Structure):
    pass

struct_anon_179.__slots__ = [
    'mFrontPanelChannel',
    'mFrontPanelBus',
    'mLedState',
]
struct_anon_179._fields_ = [
    ('mFrontPanelChannel', c_uint32),
    ('mFrontPanelBus', M1553BusType),
    ('mLedState', M1553USBFrontPanelLEDState),
]

M1553USBSetFrontPanelLEDin = struct_anon_179# /usr/local/include/ait_mil/m1553_system.h: 725

# /usr/local/include/ait_mil/m1553_system.h: 775
class struct_anon_180(Structure):
    pass

struct_anon_180.__slots__ = [
    'mSystemDriverMajorVersion',
    'mSystemDriverMinorVersion',
    'mSystemDriverMaintenanceVersion',
    'mSystemDriverBuildVersion',
    'mLibraryMajorVersion',
    'mLibraryMinorVersion',
    'mLibraryMaintenanceVersion',
    'mLibraryBuildVersion',
]
struct_anon_180._fields_ = [
    ('mSystemDriverMajorVersion', c_uint32),
    ('mSystemDriverMinorVersion', c_uint32),
    ('mSystemDriverMaintenanceVersion', c_uint32),
    ('mSystemDriverBuildVersion', c_uint32),
    ('mLibraryMajorVersion', c_uint32),
    ('mLibraryMinorVersion', c_uint32),
    ('mLibraryMaintenanceVersion', c_uint32),
    ('mLibraryBuildVersion', c_uint32),
]

M1553GetSystemInformationOut = struct_anon_180# /usr/local/include/ait_mil/m1553_system.h: 775

# /usr/local/include/ait_mil/m1553_system.h: 799
class struct_anon_181(Structure):
    pass

struct_anon_181.__slots__ = [
    'mType',
    'mIntFunc',
    'mUserData',
]
struct_anon_181._fields_ = [
    ('mType', M1553InterruptType),
    ('mIntFunc', M1553_INT_FUNC_PTR),
    ('mUserData', M1553Addr),
]

M1553InstallInterruptHandlerIn = struct_anon_181# /usr/local/include/ait_mil/m1553_system.h: 799

# /usr/local/include/ait_mil/m1553_system.h: 811
class struct_anon_182(Structure):
    pass

struct_anon_182.__slots__ = [
    'mType',
]
struct_anon_182._fields_ = [
    ('mType', M1553InterruptType),
]

M1553DeleteInterruptHandlerIn = struct_anon_182# /usr/local/include/ait_mil/m1553_system.h: 811

# /usr/local/include/ait_mil/m1553_system.h: 830
class struct_anon_183(Structure):
    pass

struct_anon_183.__slots__ = [
    'mInterruptCount',
    'mpInterruptInfo',
]
struct_anon_183._fields_ = [
    ('mInterruptCount', c_uint32),
    ('mpInterruptInfo', POINTER(M1553InterruptLoglistEntryType)),
]

M1553ChannelGetInterruptsIn = struct_anon_183# /usr/local/include/ait_mil/m1553_system.h: 830

enum_anon_184 = c_int# /usr/local/include/ait_mil/m1553_system.h: 882

M1553_BIT_NO_TEST = 0# /usr/local/include/ait_mil/m1553_system.h: 882

M1553_BIT_ALL_TEST = 1# /usr/local/include/ait_mil/m1553_system.h: 882

M1553_BIT_RAM_TEST = 2# /usr/local/include/ait_mil/m1553_system.h: 882

M1553_BIT_FULL_RAM_TEST = 3# /usr/local/include/ait_mil/m1553_system.h: 882

M1553_BIT_IO_TEST = 4# /usr/local/include/ait_mil/m1553_system.h: 882

M1553_BIT_PLX_TEST = 5# /usr/local/include/ait_mil/m1553_system.h: 882

M1553_BIT_TRANSFER_TEST = 6# /usr/local/include/ait_mil/m1553_system.h: 882

M1553_BIT_INTERRUPT_TEST = 7# /usr/local/include/ait_mil/m1553_system.h: 882

M1553_BIT_IRIG_TEST = 8# /usr/local/include/ait_mil/m1553_system.h: 882

M1553BITControl = enum_anon_184# /usr/local/include/ait_mil/m1553_system.h: 882

# /usr/local/include/ait_mil/m1553_system.h: 899
class struct_anon_185(Structure):
    pass

struct_anon_185.__slots__ = [
    'mControl',
    'mParam',
]
struct_anon_185._fields_ = [
    ('mControl', M1553BITControl),
    ('mParam', c_uint32),
]

M1553BoardBITIn = struct_anon_185# /usr/local/include/ait_mil/m1553_system.h: 899

# /usr/local/include/ait_mil/m1553_system.h: 924
class struct_anon_186(Structure):
    pass

struct_anon_186.__slots__ = [
    'mBITStatus',
]
struct_anon_186._fields_ = [
    ('mBITStatus', c_uint8 * int(2)),
]

M1553BoardBITOut = struct_anon_186# /usr/local/include/ait_mil/m1553_system.h: 924

# /usr/local/include/ait_mil/m1553_system.h: 939
class struct_anon_187(Structure):
    pass

struct_anon_187.__slots__ = [
    'mIrigTime',
    'mIrigSource',
]
struct_anon_187._fields_ = [
    ('mIrigTime', M1553IrigTimeType),
    ('mIrigSource', M1553IrigSourceType),
]

M1553BoardSetIrigTimeIn = struct_anon_187# /usr/local/include/ait_mil/m1553_system.h: 939

# /usr/local/include/ait_mil/m1553_system.h: 960
class struct_anon_188(Structure):
    pass

struct_anon_188.__slots__ = [
    'mIrigTime',
    'mIrigSource',
    'mIrigIsSynchronized',
]
struct_anon_188._fields_ = [
    ('mIrigTime', M1553IrigTimeType),
    ('mIrigSource', M1553IrigSourceType),
    ('mIrigIsSynchronized', M1553Boolean),
]

M1553BoardGetIrigTimeOut = struct_anon_188# /usr/local/include/ait_mil/m1553_system.h: 960

# /usr/local/include/ait_mil/m1553_system.h: 972
class struct_anon_189(Structure):
    pass

struct_anon_189.__slots__ = [
    'mCount',
]
struct_anon_189._fields_ = [
    ('mCount', c_uint32),
]

M1553BoardGetDiscreteCountOut = struct_anon_189# /usr/local/include/ait_mil/m1553_system.h: 972

# /usr/local/include/ait_mil/m1553_system.h: 983
class struct_anon_190(Structure):
    pass

struct_anon_190.__slots__ = [
    'mCount',
]
struct_anon_190._fields_ = [
    ('mCount', c_uint32),
]

M1553BoardGetBackplaneDiscreteCountOut = struct_anon_190# /usr/local/include/ait_mil/m1553_system.h: 983

# /usr/local/include/ait_mil/m1553_system.h: 998
class struct_anon_191(Structure):
    pass

struct_anon_191.__slots__ = [
    'mDriverType',
    'mPolarity',
]
struct_anon_191._fields_ = [
    ('mDriverType', M1553DiscreteDriverType),
    ('mPolarity', M1553Boolean),
]

M1553BoardSetDiscreteConfigIn = struct_anon_191# /usr/local/include/ait_mil/m1553_system.h: 998

# /usr/local/include/ait_mil/m1553_system.h: 1030
class struct_anon_192(Structure):
    pass

struct_anon_192.__slots__ = [
    'mDriverType',
    'mPolarity',
    'mTriggerSelect',
]
struct_anon_192._fields_ = [
    ('mDriverType', M1553DiscreteDriverType),
    ('mPolarity', M1553Boolean),
    ('mTriggerSelect', c_int16),
]

M1553BoardSetCarrierDiscreteConfigIn = struct_anon_192# /usr/local/include/ait_mil/m1553_system.h: 1030

# /usr/local/include/ait_mil/m1553_system.h: 1045
class struct_anon_193(Structure):
    pass

struct_anon_193.__slots__ = [
    'mDriverType',
    'mPolarity',
]
struct_anon_193._fields_ = [
    ('mDriverType', M1553DiscreteDriverType),
    ('mPolarity', M1553Boolean),
]

M1553BoardGetDiscreteConfigOut = struct_anon_193# /usr/local/include/ait_mil/m1553_system.h: 1045

# /usr/local/include/ait_mil/m1553_system.h: 1070
class struct_anon_194(Structure):
    pass

struct_anon_194.__slots__ = [
    'mDriverType',
    'mPolarity',
    'mTriggerSelect',
]
struct_anon_194._fields_ = [
    ('mDriverType', M1553DiscreteDriverType),
    ('mPolarity', M1553Boolean),
    ('mTriggerSelect', c_int16),
]

M1553BoardGetCarrierDiscreteConfigOut = struct_anon_194# /usr/local/include/ait_mil/m1553_system.h: 1070

# /usr/local/include/ait_mil/m1553_system.h: 1094
class struct_anon_195(Structure):
    pass

struct_anon_195.__slots__ = [
    'mTriggerType',
    'mTriggerIndex',
    'mDiscreteIndex',
]
struct_anon_195._fields_ = [
    ('mTriggerType', M1553TriggerFunctionType),
    ('mTriggerIndex', c_uint32),
    ('mDiscreteIndex', c_uint32),
]

M1553BoardSetTriggerRouteIn = struct_anon_195# /usr/local/include/ait_mil/m1553_system.h: 1094

# /usr/local/include/ait_mil/m1553_system.h: 1114
class struct_anon_196(Structure):
    pass

struct_anon_196.__slots__ = [
    'mTriggerType',
    'mIndex',
]
struct_anon_196._fields_ = [
    ('mTriggerType', M1553TriggerFunctionType),
    ('mIndex', c_uint32),
]

M1553BoardGetTriggerRouteIn = struct_anon_196# /usr/local/include/ait_mil/m1553_system.h: 1114

# /usr/local/include/ait_mil/m1553_system.h: 1130
class struct_anon_197(Structure):
    pass

struct_anon_197.__slots__ = [
    'mIndex',
]
struct_anon_197._fields_ = [
    ('mIndex', c_uint32),
]

M1553BoardGetTriggerRouteOut = struct_anon_197# /usr/local/include/ait_mil/m1553_system.h: 1130

# /usr/local/include/ait_mil/m1553_system.h: 1142
class struct_anon_198(Structure):
    pass

struct_anon_198.__slots__ = [
    'mEventOccurred',
]
struct_anon_198._fields_ = [
    ('mEventOccurred', M1553Boolean),
]

M1553BoardGetDiscreteEventOut = struct_anon_198# /usr/local/include/ait_mil/m1553_system.h: 1142

# /usr/local/include/ait_mil/m1553_system.h: 1154
class struct_anon_199(Structure):
    pass

struct_anon_199.__slots__ = [
    'mState',
]
struct_anon_199._fields_ = [
    ('mState', M1553Boolean),
]

M1553BoardSetDiscreteStateIn = struct_anon_199# /usr/local/include/ait_mil/m1553_system.h: 1154

# /usr/local/include/ait_mil/m1553_system.h: 1166
class struct_anon_200(Structure):
    pass

struct_anon_200.__slots__ = [
    'mState',
]
struct_anon_200._fields_ = [
    ('mState', M1553Boolean),
]

M1553BoardGetDiscreteStateOut = struct_anon_200# /usr/local/include/ait_mil/m1553_system.h: 1166

# /usr/local/include/ait_mil/m1553_system.h: 1183
class struct_anon_201(Structure):
    pass

struct_anon_201.__slots__ = [
    'mDiscreteStates',
    'mDiscreteStatesMask',
]
struct_anon_201._fields_ = [
    ('mDiscreteStates', c_uint32),
    ('mDiscreteStatesMask', c_uint32),
]

M1553BoardSetAllDiscreteStatesIn = struct_anon_201# /usr/local/include/ait_mil/m1553_system.h: 1183

# /usr/local/include/ait_mil/m1553_system.h: 1195
class struct_anon_202(Structure):
    pass

struct_anon_202.__slots__ = [
    'mDiscreteStates',
]
struct_anon_202._fields_ = [
    ('mDiscreteStates', c_uint32),
]

M1553BoardGetAllDiscreteStatesOut = struct_anon_202# /usr/local/include/ait_mil/m1553_system.h: 1195

# /usr/local/include/ait_mil/m1553_system.h: 1218
class struct_anon_203(Structure):
    pass

struct_anon_203.__slots__ = [
    'aInputPulseLength',
    'aOutputPulseLength',
]
struct_anon_203._fields_ = [
    ('aInputPulseLength', c_uint32),
    ('aOutputPulseLength', c_uint32),
]

M1553BoardSetDiscretePulseLengthIn = struct_anon_203# /usr/local/include/ait_mil/m1553_system.h: 1218

# /usr/local/include/ait_mil/m1553_system.h: 1233
class struct_anon_204(Structure):
    pass

struct_anon_204.__slots__ = [
    'aInputPulseLength',
    'aOutputPulseLength',
]
struct_anon_204._fields_ = [
    ('aInputPulseLength', c_uint32),
    ('aOutputPulseLength', c_uint32),
]

M1553BoardGetDiscretePulseLengthOut = struct_anon_204# /usr/local/include/ait_mil/m1553_system.h: 1233

# /usr/local/include/ait_mil/m1553_system.h: 1273
class struct_anon_205(Structure):
    pass

struct_anon_205.__slots__ = [
    'aBackplaneInputPulseLength',
    'aBackplaneOutputPulseLength',
    'aFrontPanelInputPulseLength',
    'aFrontPanelOutputPulseLength',
]
struct_anon_205._fields_ = [
    ('aBackplaneInputPulseLength', c_uint32),
    ('aBackplaneOutputPulseLength', c_uint32),
    ('aFrontPanelInputPulseLength', c_uint32),
    ('aFrontPanelOutputPulseLength', c_uint32),
]

M1553BoardSetCarrierDiscretePulseLengthIn = struct_anon_205# /usr/local/include/ait_mil/m1553_system.h: 1273

# /usr/local/include/ait_mil/m1553_system.h: 1313
class struct_anon_206(Structure):
    pass

struct_anon_206.__slots__ = [
    'aBackplaneInputPulseLength',
    'aBackplaneOutputPulseLength',
    'aFrontPanelInputPulseLength',
    'aFrontPanelOutputPulseLength',
]
struct_anon_206._fields_ = [
    ('aBackplaneInputPulseLength', c_uint32),
    ('aBackplaneOutputPulseLength', c_uint32),
    ('aFrontPanelInputPulseLength', c_uint32),
    ('aFrontPanelOutputPulseLength', c_uint32),
]

M1553BoardGetCarrierDiscretePulseLengthOut = struct_anon_206# /usr/local/include/ait_mil/m1553_system.h: 1313

# /usr/local/include/ait_mil/m1553_system.h: 1325
class struct_anon_207(Structure):
    pass

struct_anon_207.__slots__ = [
    'mMode',
]
struct_anon_207._fields_ = [
    ('mMode', M1553ResetMode),
]

M1553ChannelResetIn = struct_anon_207# /usr/local/include/ait_mil/m1553_system.h: 1325

# /usr/local/include/ait_mil/m1553_system.h: 1337
class struct_anon_208(Structure):
    pass

struct_anon_208.__slots__ = [
    'mResponseTimeout',
]
struct_anon_208._fields_ = [
    ('mResponseTimeout', M1553Float),
]

M1553ChannelSetResponseTimeoutIn = struct_anon_208# /usr/local/include/ait_mil/m1553_system.h: 1337

# /usr/local/include/ait_mil/m1553_system.h: 1348
class struct_anon_209(Structure):
    pass

struct_anon_209.__slots__ = [
    'mResponseTimeout',
]
struct_anon_209._fields_ = [
    ('mResponseTimeout', M1553Float),
]

M1553ChannelGetResponseTimeoutOut = struct_anon_209# /usr/local/include/ait_mil/m1553_system.h: 1348

# /usr/local/include/ait_mil/m1553_system.h: 1371
class struct_anon_210(Structure):
    pass

struct_anon_210.__slots__ = [
    'mMilProtocol',
    'mSetAllRTs',
    'mRT',
]
struct_anon_210._fields_ = [
    ('mMilProtocol', M1553MilProtocolType),
    ('mSetAllRTs', M1553Boolean),
    ('mRT', c_uint8),
]

M1553ChannelSetMilbusProtocolIn = struct_anon_210# /usr/local/include/ait_mil/m1553_system.h: 1371

# /usr/local/include/ait_mil/m1553_system.h: 1383
class struct_anon_211(Structure):
    pass

struct_anon_211.__slots__ = [
    'mMilProtocol',
]
struct_anon_211._fields_ = [
    ('mMilProtocol', M1553MilProtocolType),
]

M1553ChannelGetMilbusProtocolOut = struct_anon_211# /usr/local/include/ait_mil/m1553_system.h: 1383

# /usr/local/include/ait_mil/m1553_system.h: 1449
class struct_anon_212(Structure):
    pass

struct_anon_212.__slots__ = [
    'mSystemControlBlockSize',
    'mSystemControlBlockOffset',
    'mMiscellaneousBcBlockSize',
    'mMiscellaneousBcBlockOffset',
    'mInterruptLoglistSize',
    'mInterruptLoglistOffset',
    'mRtDescriptorBlockSize',
    'mRtDescriptorBlockOffset',
    'mBmTriggerControlBlockSize',
    'mBmTriggerControlBlockOffset',
    'mBmActivityBlockSize',
    'mBmActivityBlockOffset',
]
struct_anon_212._fields_ = [
    ('mSystemControlBlockSize', c_uint32),
    ('mSystemControlBlockOffset', c_uint32),
    ('mMiscellaneousBcBlockSize', c_uint32),
    ('mMiscellaneousBcBlockOffset', c_uint32),
    ('mInterruptLoglistSize', c_uint32),
    ('mInterruptLoglistOffset', c_uint32),
    ('mRtDescriptorBlockSize', c_uint32),
    ('mRtDescriptorBlockOffset', c_uint32),
    ('mBmTriggerControlBlockSize', c_uint32),
    ('mBmTriggerControlBlockOffset', c_uint32),
    ('mBmActivityBlockSize', c_uint32),
    ('mBmActivityBlockOffset', c_uint32),
]

M1553ChannelRegisterMap = struct_anon_212# /usr/local/include/ait_mil/m1553_system.h: 1449

# /usr/local/include/ait_mil/m1553_system.h: 1584
class struct_anon_213(Structure):
    pass

struct_anon_213.__slots__ = [
    'mRtSaDescriptorAreaSize',
    'mRtSaDescriptorAreaOffset',
    'mRtBufferHeaderAreaSize',
    'mRtBufferHeaderAreaOffset',
    'mRtStatusQueueAreaSize',
    'mRtStatusQueueAreaOffset',
    'mRtEventQueueAreaSize',
    'mRtEventQueueAreaOffset',
    'mBcBufferHeaderAreaSize',
    'mBcBufferHeaderAreaOffset',
    'mBcStatusQueueAreaSize',
    'mBcStatusQueueAreaOffset',
    'mBcEventQueueAreaSize',
    'mBcEventQueueAreaOffset',
    'mBcTransferDescriptorAreaSize',
    'mBcTransferDescriptorAreaOffset',
    'mBcHighPriorityInstructionListAreaSize',
    'mBcHighPriorityInstructionListAreaOffset',
    'mBcLowPriorityInstructionListAreaSize',
    'mBcLowPriorityInstructionListAreaOffset',
    'mBcAcyclicInstructionListAreaSize',
    'mBcAcyclicInstructionListAreaOffset',
    'mBcRtBufferAreaSize',
    'mBcRtBufferAreaOffset',
    'mBmBufferAreaSize',
    'mBmBufferAreaOffset',
    'mReplayBufferAreaSize',
    'mReplayBufferAreaOffset',
]
struct_anon_213._fields_ = [
    ('mRtSaDescriptorAreaSize', c_uint32),
    ('mRtSaDescriptorAreaOffset', c_uint32),
    ('mRtBufferHeaderAreaSize', c_uint32),
    ('mRtBufferHeaderAreaOffset', c_uint32),
    ('mRtStatusQueueAreaSize', c_uint32),
    ('mRtStatusQueueAreaOffset', c_uint32),
    ('mRtEventQueueAreaSize', c_uint32),
    ('mRtEventQueueAreaOffset', c_uint32),
    ('mBcBufferHeaderAreaSize', c_uint32),
    ('mBcBufferHeaderAreaOffset', c_uint32),
    ('mBcStatusQueueAreaSize', c_uint32),
    ('mBcStatusQueueAreaOffset', c_uint32),
    ('mBcEventQueueAreaSize', c_uint32),
    ('mBcEventQueueAreaOffset', c_uint32),
    ('mBcTransferDescriptorAreaSize', c_uint32),
    ('mBcTransferDescriptorAreaOffset', c_uint32),
    ('mBcHighPriorityInstructionListAreaSize', c_uint32),
    ('mBcHighPriorityInstructionListAreaOffset', c_uint32),
    ('mBcLowPriorityInstructionListAreaSize', c_uint32),
    ('mBcLowPriorityInstructionListAreaOffset', c_uint32),
    ('mBcAcyclicInstructionListAreaSize', c_uint32),
    ('mBcAcyclicInstructionListAreaOffset', c_uint32),
    ('mBcRtBufferAreaSize', c_uint32),
    ('mBcRtBufferAreaOffset', c_uint32),
    ('mBmBufferAreaSize', c_uint32),
    ('mBmBufferAreaOffset', c_uint32),
    ('mReplayBufferAreaSize', c_uint32),
    ('mReplayBufferAreaOffset', c_uint32),
]

M1553ChannelMemoryMap = struct_anon_213# /usr/local/include/ait_mil/m1553_system.h: 1584

# /usr/local/include/ait_mil/m1553_system.h: 1657
class struct_anon_214(Structure):
    pass

struct_anon_214.__slots__ = [
    'mRtBufferHeaderDescriptorCount',
    'mRtBufferHeaderDescriptorSize',
    'mRtStatusQueueDescriptorCount',
    'mRtStatusQueueDescriptorSize',
    'mRtEventQueueDescriptorCount',
    'mRtEventQueueDescriptorSize',
    'mBcBufferHeaderDescriptorCount',
    'mBcBufferHeaderDescriptorSize',
    'mBcStatusQueueDescriptorCount',
    'mBcStatusQueueDescriptorSize',
    'mBcEventQueueDescriptorCount',
    'mBcEventQueueDescriptorSize',
    'mBcTransferDescripterCount',
    'mBcTransferDescripterSize',
    'mBcRtBufferDescripterCount',
    'mBcRtBufferDescripterSize',
]
struct_anon_214._fields_ = [
    ('mRtBufferHeaderDescriptorCount', c_uint32),
    ('mRtBufferHeaderDescriptorSize', c_uint32),
    ('mRtStatusQueueDescriptorCount', c_uint32),
    ('mRtStatusQueueDescriptorSize', c_uint32),
    ('mRtEventQueueDescriptorCount', c_uint32),
    ('mRtEventQueueDescriptorSize', c_uint32),
    ('mBcBufferHeaderDescriptorCount', c_uint32),
    ('mBcBufferHeaderDescriptorSize', c_uint32),
    ('mBcStatusQueueDescriptorCount', c_uint32),
    ('mBcStatusQueueDescriptorSize', c_uint32),
    ('mBcEventQueueDescriptorCount', c_uint32),
    ('mBcEventQueueDescriptorSize', c_uint32),
    ('mBcTransferDescripterCount', c_uint32),
    ('mBcTransferDescripterSize', c_uint32),
    ('mBcRtBufferDescripterCount', c_uint32),
    ('mBcRtBufferDescripterSize', c_uint32),
]

M1553ChannelMemoryDescriptorCounts = struct_anon_214# /usr/local/include/ait_mil/m1553_system.h: 1657

# /usr/local/include/ait_mil/m1553_system.h: 1668
class struct_anon_215(Structure):
    pass

struct_anon_215.__slots__ = [
    'mMemoryMap',
]
struct_anon_215._fields_ = [
    ('mMemoryMap', M1553ChannelMemoryMap),
]

M1553ChannelSetMemPartitionIn = struct_anon_215# /usr/local/include/ait_mil/m1553_system.h: 1668

# /usr/local/include/ait_mil/m1553_system.h: 1698
class struct_anon_216(Structure):
    pass

struct_anon_216.__slots__ = [
    'mRegisterMap',
    'mMemoryMap',
    'mDescriptorCounts',
    'mGlobalMemorySize',
    'mChannelMemorySize',
]
struct_anon_216._fields_ = [
    ('mRegisterMap', M1553ChannelRegisterMap),
    ('mMemoryMap', M1553ChannelMemoryMap),
    ('mDescriptorCounts', M1553ChannelMemoryDescriptorCounts),
    ('mGlobalMemorySize', c_uint32),
    ('mChannelMemorySize', c_uint32),
]

M1553ChannelGetMemPartitionOut = struct_anon_216# /usr/local/include/ait_mil/m1553_system.h: 1698

# /usr/local/include/ait_mil/m1553_system.h: 1713
class struct_anon_217(Structure):
    pass

struct_anon_217.__slots__ = [
    'mBus',
    'mEnabled',
]
struct_anon_217._fields_ = [
    ('mBus', M1553BusType),
    ('mEnabled', M1553Boolean),
]

M1553ChannelSetTestSignalIn = struct_anon_217# /usr/local/include/ait_mil/m1553_system.h: 1713

# /usr/local/include/ait_mil/m1553_system.h: 1724
class struct_anon_218(Structure):
    pass

struct_anon_218.__slots__ = [
    'mBusCoupling',
]
struct_anon_218._fields_ = [
    ('mBusCoupling', M1553CouplingType),
]

M1553ChannelGetCouplingOut = struct_anon_218# /usr/local/include/ait_mil/m1553_system.h: 1724

# /usr/local/include/ait_mil/m1553_system.h: 1735
class struct_anon_219(Structure):
    pass

struct_anon_219.__slots__ = [
    'mBusCoupling',
]
struct_anon_219._fields_ = [
    ('mBusCoupling', M1553CouplingType),
]

M1553ChannelSetCouplingIn = struct_anon_219# /usr/local/include/ait_mil/m1553_system.h: 1735

# /usr/local/include/ait_mil/m1553_system.h: 1747
class struct_anon_220(Structure):
    pass

struct_anon_220.__slots__ = [
    'mAmplitude',
]
struct_anon_220._fields_ = [
    ('mAmplitude', c_uint8),
]

M1553ChannelSetAmplitudeIn = struct_anon_220# /usr/local/include/ait_mil/m1553_system.h: 1747

# /usr/local/include/ait_mil/m1553_system.h: 1759
class struct_anon_221(Structure):
    pass

struct_anon_221.__slots__ = [
    'mAmplitude',
]
struct_anon_221._fields_ = [
    ('mAmplitude', c_uint8),
]

M1553ChannelGetAmplitudeOut = struct_anon_221# /usr/local/include/ait_mil/m1553_system.h: 1759

# /usr/local/include/ait_mil/m1553_system.h: 1770
class struct_anon_222(Structure):
    pass

struct_anon_222.__slots__ = [
    'mBitrate',
]
struct_anon_222._fields_ = [
    ('mBitrate', M1553ChannelBitrate),
]

M1553ChannelSetBitRateIn = struct_anon_222# /usr/local/include/ait_mil/m1553_system.h: 1770

# /usr/local/include/ait_mil/m1553_system.h: 1781
class struct_anon_223(Structure):
    pass

struct_anon_223.__slots__ = [
    'mBitrate',
]
struct_anon_223._fields_ = [
    ('mBitrate', M1553ChannelBitrate),
]

M1553ChannelGetBitRateOut = struct_anon_223# /usr/local/include/ait_mil/m1553_system.h: 1781

# /usr/local/include/ait_mil/m1553_system.h: 1800
class struct_anon_224(Structure):
    pass

struct_anon_224.__slots__ = [
    'mPolarityActiveHigh',
    'mEnabled',
]
struct_anon_224._fields_ = [
    ('mPolarityActiveHigh', M1553Boolean),
    ('mEnabled', M1553Boolean),
]

M1553BoardSetPXIStarTriggerConfigIn = struct_anon_224# /usr/local/include/ait_mil/m1553_system.h: 1800

enum_anon_225 = c_int# /usr/local/include/ait_mil/m1553_system.h: 1841

DISCRETE_CHAN_0 = 0# /usr/local/include/ait_mil/m1553_system.h: 1841

DISCRETE_CHAN_1 = (DISCRETE_CHAN_0 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

DISCRETE_CHAN_2 = (DISCRETE_CHAN_1 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

DISCRETE_CHAN_3 = (DISCRETE_CHAN_2 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

DISCRETE_CHAN_4 = (DISCRETE_CHAN_3 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

DISCRETE_CHAN_5 = (DISCRETE_CHAN_4 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

DISCRETE_CHAN_6 = (DISCRETE_CHAN_5 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

DISCRETE_CHAN_7 = (DISCRETE_CHAN_6 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

DISCRETE_CHAN_8 = (DISCRETE_CHAN_7 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

DISCRETE_CHAN_9 = (DISCRETE_CHAN_8 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

PXI_TRIGGER_0 = (DISCRETE_CHAN_9 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

PXI_TRIGGER_1 = (PXI_TRIGGER_0 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

PXI_TRIGGER_2 = (PXI_TRIGGER_1 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

PXI_TRIGGER_3 = (PXI_TRIGGER_2 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

PXI_TRIGGER_4 = (PXI_TRIGGER_3 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

PXI_TRIGGER_5 = (PXI_TRIGGER_4 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

PXI_TRIGGER_6 = (PXI_TRIGGER_5 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

PXI_TRIGGER_7 = (PXI_TRIGGER_6 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

PXIE_DSTARA = (PXI_TRIGGER_7 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

PXIE_DSTARB = (PXIE_DSTARA + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

PXIE_DSTARC = (PXIE_DSTARB + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

MON_STROBE_0 = (PXIE_DSTARC + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

MON_STROBE_1 = (MON_STROBE_0 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

MON_STROBE_2 = (MON_STROBE_1 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

MON_STROBE_3 = (MON_STROBE_2 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

BC_STROBE_0 = (MON_STROBE_3 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

BC_STROBE_1 = (BC_STROBE_0 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

BC_STROBE_2 = (BC_STROBE_1 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

BC_STROBE_3 = (BC_STROBE_2 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

NO_INPUT_ROUTED = (BC_STROBE_3 + 1)# /usr/local/include/ait_mil/m1553_system.h: 1841

TY_PXIE_BOARD_ROUTE_SEL = enum_anon_225# /usr/local/include/ait_mil/m1553_system.h: 1841

# /usr/local/include/ait_mil/m1553_system.h: 1896
if _libs["libait_mil.so"].has("m1553Init", "cdecl"):
    m1553Init = _libs["libait_mil.so"].get("m1553Init", "cdecl")
    m1553Init.argtypes = [c_uint32, POINTER(c_uint32)]
    m1553Init.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 1928
if _libs["libait_mil.so"].has("m1553BoardOpen", "cdecl"):
    m1553BoardOpen = _libs["libait_mil.so"].get("m1553BoardOpen", "cdecl")
    m1553BoardOpen.argtypes = [c_uint32, POINTER(M1553Handle)]
    m1553BoardOpen.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 1967
if _libs["libait_mil.so"].has("m1553ChannelOpen", "cdecl"):
    m1553ChannelOpen = _libs["libait_mil.so"].get("m1553ChannelOpen", "cdecl")
    m1553ChannelOpen.argtypes = [M1553Handle, c_uint32, POINTER(M1553Handle)]
    m1553ChannelOpen.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 1991
if _libs["libait_mil.so"].has("m1553Close", "cdecl"):
    m1553Close = _libs["libait_mil.so"].get("m1553Close", "cdecl")
    m1553Close.argtypes = [M1553Handle]
    m1553Close.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2020
if _libs["libait_mil.so"].has("m1553Uninitialize", "cdecl"):
    m1553Uninitialize = _libs["libait_mil.so"].get("m1553Uninitialize", "cdecl")
    m1553Uninitialize.argtypes = [c_uint32]
    m1553Uninitialize.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2038
if _libs["libait_mil.so"].has("m1553GetSystemInformation", "cdecl"):
    m1553GetSystemInformation = _libs["libait_mil.so"].get("m1553GetSystemInformation", "cdecl")
    m1553GetSystemInformation.argtypes = [POINTER(M1553GetSystemInformationOut)]
    m1553GetSystemInformation.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2082
if _libs["libait_mil.so"].has("m1553InstallInterruptHandler", "cdecl"):
    m1553InstallInterruptHandler = _libs["libait_mil.so"].get("m1553InstallInterruptHandler", "cdecl")
    m1553InstallInterruptHandler.argtypes = [M1553Handle, POINTER(M1553InstallInterruptHandlerIn)]
    m1553InstallInterruptHandler.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2116
if _libs["libait_mil.so"].has("m1553DeleteInterruptHandler", "cdecl"):
    m1553DeleteInterruptHandler = _libs["libait_mil.so"].get("m1553DeleteInterruptHandler", "cdecl")
    m1553DeleteInterruptHandler.argtypes = [M1553Handle, POINTER(M1553DeleteInterruptHandlerIn)]
    m1553DeleteInterruptHandler.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2142
if _libs["libait_mil.so"].has("m1553ChannelGetInterrupts", "cdecl"):
    m1553ChannelGetInterrupts = _libs["libait_mil.so"].get("m1553ChannelGetInterrupts", "cdecl")
    m1553ChannelGetInterrupts.argtypes = [M1553Handle, POINTER(M1553ChannelGetInterruptsIn)]
    m1553ChannelGetInterrupts.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2194
if _libs["libait_mil.so"].has("m1553BoardBIT", "cdecl"):
    m1553BoardBIT = _libs["libait_mil.so"].get("m1553BoardBIT", "cdecl")
    m1553BoardBIT.argtypes = [M1553Handle, POINTER(M1553BoardBITIn), POINTER(M1553BoardBITOut)]
    m1553BoardBIT.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2219
if _libs["libait_mil.so"].has("m1553GetBoardInfo", "cdecl"):
    m1553GetBoardInfo = _libs["libait_mil.so"].get("m1553GetBoardInfo", "cdecl")
    m1553GetBoardInfo.argtypes = [M1553Handle, POINTER(M1553GetBoardInfoOut)]
    m1553GetBoardInfo.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2246
if _libs["libait_mil.so"].has("m1553USBGetBatteryInfo", "cdecl"):
    m1553USBGetBatteryInfo = _libs["libait_mil.so"].get("m1553USBGetBatteryInfo", "cdecl")
    m1553USBGetBatteryInfo.argtypes = [M1553Handle, POINTER(M1553USBGetBatteryInfoOut)]
    m1553USBGetBatteryInfo.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2273
if _libs["libait_mil.so"].has("m1553USBSetFrontPanelLED", "cdecl"):
    m1553USBSetFrontPanelLED = _libs["libait_mil.so"].get("m1553USBSetFrontPanelLED", "cdecl")
    m1553USBSetFrontPanelLED.argtypes = [M1553Handle, POINTER(M1553USBSetFrontPanelLEDin)]
    m1553USBSetFrontPanelLED.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2326
if _libs["libait_mil.so"].has("m1553BoardSetIrigTime", "cdecl"):
    m1553BoardSetIrigTime = _libs["libait_mil.so"].get("m1553BoardSetIrigTime", "cdecl")
    m1553BoardSetIrigTime.argtypes = [M1553Handle, POINTER(M1553BoardSetIrigTimeIn)]
    m1553BoardSetIrigTime.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2351
if _libs["libait_mil.so"].has("m1553BoardGetIrigTime", "cdecl"):
    m1553BoardGetIrigTime = _libs["libait_mil.so"].get("m1553BoardGetIrigTime", "cdecl")
    m1553BoardGetIrigTime.argtypes = [M1553Handle, POINTER(M1553BoardGetIrigTimeOut)]
    m1553BoardGetIrigTime.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2375
if _libs["libait_mil.so"].has("m1553BoardLoadElf", "cdecl"):
    m1553BoardLoadElf = _libs["libait_mil.so"].get("m1553BoardLoadElf", "cdecl")
    m1553BoardLoadElf.argtypes = [M1553Handle, c_uint8, String]
    m1553BoardLoadElf.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2418
if _libs["libait_mil.so"].has("m1553BoardGetDiscreteCount", "cdecl"):
    m1553BoardGetDiscreteCount = _libs["libait_mil.so"].get("m1553BoardGetDiscreteCount", "cdecl")
    m1553BoardGetDiscreteCount.argtypes = [M1553Handle, POINTER(M1553BoardGetDiscreteCountOut)]
    m1553BoardGetDiscreteCount.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2446
if _libs["libait_mil.so"].has("m1553BoardGetBackplaneDiscreteCount", "cdecl"):
    m1553BoardGetBackplaneDiscreteCount = _libs["libait_mil.so"].get("m1553BoardGetBackplaneDiscreteCount", "cdecl")
    m1553BoardGetBackplaneDiscreteCount.argtypes = [M1553Handle, POINTER(M1553BoardGetBackplaneDiscreteCountOut)]
    m1553BoardGetBackplaneDiscreteCount.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2468
if _libs["libait_mil.so"].has("m1553BoardSetDiscreteEnable", "cdecl"):
    m1553BoardSetDiscreteEnable = _libs["libait_mil.so"].get("m1553BoardSetDiscreteEnable", "cdecl")
    m1553BoardSetDiscreteEnable.argtypes = [M1553Handle, c_uint32]
    m1553BoardSetDiscreteEnable.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2490
if _libs["libait_mil.so"].has("m1553BoardSetDiscreteInterruptEnable", "cdecl"):
    m1553BoardSetDiscreteInterruptEnable = _libs["libait_mil.so"].get("m1553BoardSetDiscreteInterruptEnable", "cdecl")
    m1553BoardSetDiscreteInterruptEnable.argtypes = [M1553Handle, c_uint32]
    m1553BoardSetDiscreteInterruptEnable.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2515
if _libs["libait_mil.so"].has("m1553BoardGetDiscreteEnable", "cdecl"):
    m1553BoardGetDiscreteEnable = _libs["libait_mil.so"].get("m1553BoardGetDiscreteEnable", "cdecl")
    m1553BoardGetDiscreteEnable.argtypes = [M1553Handle, POINTER(c_uint32)]
    m1553BoardGetDiscreteEnable.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2543
if _libs["libait_mil.so"].has("m1553BoardSetCarrierDiscreteEnable", "cdecl"):
    m1553BoardSetCarrierDiscreteEnable = _libs["libait_mil.so"].get("m1553BoardSetCarrierDiscreteEnable", "cdecl")
    m1553BoardSetCarrierDiscreteEnable.argtypes = [M1553Handle, c_uint32, c_uint32]
    m1553BoardSetCarrierDiscreteEnable.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2576
if _libs["libait_mil.so"].has("m1553BoardGetCarrierDiscreteEnable", "cdecl"):
    m1553BoardGetCarrierDiscreteEnable = _libs["libait_mil.so"].get("m1553BoardGetCarrierDiscreteEnable", "cdecl")
    m1553BoardGetCarrierDiscreteEnable.argtypes = [M1553Handle, POINTER(c_uint32), POINTER(c_uint32)]
    m1553BoardGetCarrierDiscreteEnable.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2596
if _libs["libait_mil.so"].has("m1553BoardDiscreteReset", "cdecl"):
    m1553BoardDiscreteReset = _libs["libait_mil.so"].get("m1553BoardDiscreteReset", "cdecl")
    m1553BoardDiscreteReset.argtypes = [M1553Handle, c_uint32]
    m1553BoardDiscreteReset.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2625
if _libs["libait_mil.so"].has("m1553BoardCarrierDiscreteReset", "cdecl"):
    m1553BoardCarrierDiscreteReset = _libs["libait_mil.so"].get("m1553BoardCarrierDiscreteReset", "cdecl")
    m1553BoardCarrierDiscreteReset.argtypes = [M1553Handle, M1553TriggerModeType, c_uint32]
    m1553BoardCarrierDiscreteReset.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2666
if _libs["libait_mil.so"].has("m1553BoardSetDiscreteConfig", "cdecl"):
    m1553BoardSetDiscreteConfig = _libs["libait_mil.so"].get("m1553BoardSetDiscreteConfig", "cdecl")
    m1553BoardSetDiscreteConfig.argtypes = [M1553Handle, c_uint32, POINTER(M1553BoardSetDiscreteConfigIn)]
    m1553BoardSetDiscreteConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2697
if _libs["libait_mil.so"].has("m1553BoardGetDiscreteConfig", "cdecl"):
    m1553BoardGetDiscreteConfig = _libs["libait_mil.so"].get("m1553BoardGetDiscreteConfig", "cdecl")
    m1553BoardGetDiscreteConfig.argtypes = [M1553Handle, c_uint32, POINTER(M1553BoardGetDiscreteConfigOut)]
    m1553BoardGetDiscreteConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2703
for _lib in _libs.values():
    if not _lib.has("m1553BoardSetPXIeEventRoute", "cdecl"):
        continue
    m1553BoardSetPXIeEventRoute = _lib.get("m1553BoardSetPXIeEventRoute", "cdecl")
    m1553BoardSetPXIeEventRoute.argtypes = [M1553Handle, TY_PXIE_BOARD_ROUTE_SEL, TY_PXIE_BOARD_ROUTE_SEL]
    m1553BoardSetPXIeEventRoute.restype = c_int
    break

# /usr/local/include/ait_mil/m1553_system.h: 2742
if _libs["libait_mil.so"].has("m1553BoardSetCarrierDiscreteConfig", "cdecl"):
    m1553BoardSetCarrierDiscreteConfig = _libs["libait_mil.so"].get("m1553BoardSetCarrierDiscreteConfig", "cdecl")
    m1553BoardSetCarrierDiscreteConfig.argtypes = [M1553Handle, M1553TriggerModeType, c_uint32, POINTER(M1553BoardSetCarrierDiscreteConfigIn)]
    m1553BoardSetCarrierDiscreteConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2777
if _libs["libait_mil.so"].has("m1553BoardGetCarrierDiscreteConfig", "cdecl"):
    m1553BoardGetCarrierDiscreteConfig = _libs["libait_mil.so"].get("m1553BoardGetCarrierDiscreteConfig", "cdecl")
    m1553BoardGetCarrierDiscreteConfig.argtypes = [M1553Handle, M1553TriggerModeType, c_uint32, POINTER(M1553BoardGetCarrierDiscreteConfigOut)]
    m1553BoardGetCarrierDiscreteConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2806
if _libs["libait_mil.so"].has("m1553BoardSetTriggerRoute", "cdecl"):
    m1553BoardSetTriggerRoute = _libs["libait_mil.so"].get("m1553BoardSetTriggerRoute", "cdecl")
    m1553BoardSetTriggerRoute.argtypes = [M1553Handle, POINTER(M1553BoardSetTriggerRouteIn)]
    m1553BoardSetTriggerRoute.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2834
if _libs["libait_mil.so"].has("m1553BoardGetTriggerRoute", "cdecl"):
    m1553BoardGetTriggerRoute = _libs["libait_mil.so"].get("m1553BoardGetTriggerRoute", "cdecl")
    m1553BoardGetTriggerRoute.argtypes = [M1553Handle, POINTER(M1553BoardGetTriggerRouteIn), POINTER(M1553BoardGetTriggerRouteOut)]
    m1553BoardGetTriggerRoute.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2862
if _libs["libait_mil.so"].has("m1553BoardSetDiscreteEvent", "cdecl"):
    m1553BoardSetDiscreteEvent = _libs["libait_mil.so"].get("m1553BoardSetDiscreteEvent", "cdecl")
    m1553BoardSetDiscreteEvent.argtypes = [M1553Handle, c_uint32]
    m1553BoardSetDiscreteEvent.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2895
if _libs["libait_mil.so"].has("m1553BoardSetCarrierDiscreteEvent", "cdecl"):
    m1553BoardSetCarrierDiscreteEvent = _libs["libait_mil.so"].get("m1553BoardSetCarrierDiscreteEvent", "cdecl")
    m1553BoardSetCarrierDiscreteEvent.argtypes = [M1553Handle, M1553TriggerModeType, c_uint32]
    m1553BoardSetCarrierDiscreteEvent.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2930
if _libs["libait_mil.so"].has("m1553BoardGetDiscreteEvent", "cdecl"):
    m1553BoardGetDiscreteEvent = _libs["libait_mil.so"].get("m1553BoardGetDiscreteEvent", "cdecl")
    m1553BoardGetDiscreteEvent.argtypes = [M1553Handle, c_uint32, POINTER(M1553BoardGetDiscreteEventOut)]
    m1553BoardGetDiscreteEvent.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 2970
if _libs["libait_mil.so"].has("m1553BoardGetCarrierDiscreteEvent", "cdecl"):
    m1553BoardGetCarrierDiscreteEvent = _libs["libait_mil.so"].get("m1553BoardGetCarrierDiscreteEvent", "cdecl")
    m1553BoardGetCarrierDiscreteEvent.argtypes = [M1553Handle, M1553TriggerModeType, c_uint32, POINTER(M1553BoardGetDiscreteEventOut)]
    m1553BoardGetCarrierDiscreteEvent.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3003
if _libs["libait_mil.so"].has("m1553BoardSetDiscreteState", "cdecl"):
    m1553BoardSetDiscreteState = _libs["libait_mil.so"].get("m1553BoardSetDiscreteState", "cdecl")
    m1553BoardSetDiscreteState.argtypes = [M1553Handle, c_uint32, POINTER(M1553BoardSetDiscreteStateIn)]
    m1553BoardSetDiscreteState.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3039
if _libs["libait_mil.so"].has("m1553BoardSetCarrierDiscreteState", "cdecl"):
    m1553BoardSetCarrierDiscreteState = _libs["libait_mil.so"].get("m1553BoardSetCarrierDiscreteState", "cdecl")
    m1553BoardSetCarrierDiscreteState.argtypes = [M1553Handle, M1553TriggerModeType, c_uint32, POINTER(M1553BoardSetDiscreteStateIn)]
    m1553BoardSetCarrierDiscreteState.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3071
if _libs["libait_mil.so"].has("m1553BoardGetDiscreteState", "cdecl"):
    m1553BoardGetDiscreteState = _libs["libait_mil.so"].get("m1553BoardGetDiscreteState", "cdecl")
    m1553BoardGetDiscreteState.argtypes = [M1553Handle, c_uint32, POINTER(M1553BoardGetDiscreteStateOut)]
    m1553BoardGetDiscreteState.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3105
if _libs["libait_mil.so"].has("m1553BoardGetCarrierDiscreteState", "cdecl"):
    m1553BoardGetCarrierDiscreteState = _libs["libait_mil.so"].get("m1553BoardGetCarrierDiscreteState", "cdecl")
    m1553BoardGetCarrierDiscreteState.argtypes = [M1553Handle, M1553TriggerModeType, c_uint32, POINTER(M1553BoardGetDiscreteStateOut)]
    m1553BoardGetCarrierDiscreteState.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3132
if _libs["libait_mil.so"].has("m1553BoardSetAllDiscreteStates", "cdecl"):
    m1553BoardSetAllDiscreteStates = _libs["libait_mil.so"].get("m1553BoardSetAllDiscreteStates", "cdecl")
    m1553BoardSetAllDiscreteStates.argtypes = [M1553Handle, POINTER(M1553BoardSetAllDiscreteStatesIn)]
    m1553BoardSetAllDiscreteStates.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3161
if _libs["libait_mil.so"].has("m1553BoardSetAllCarrierDiscreteStates", "cdecl"):
    m1553BoardSetAllCarrierDiscreteStates = _libs["libait_mil.so"].get("m1553BoardSetAllCarrierDiscreteStates", "cdecl")
    m1553BoardSetAllCarrierDiscreteStates.argtypes = [M1553Handle, M1553TriggerModeType, POINTER(M1553BoardSetAllDiscreteStatesIn)]
    m1553BoardSetAllCarrierDiscreteStates.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3187
if _libs["libait_mil.so"].has("m1553BoardGetAllDiscreteStates", "cdecl"):
    m1553BoardGetAllDiscreteStates = _libs["libait_mil.so"].get("m1553BoardGetAllDiscreteStates", "cdecl")
    m1553BoardGetAllDiscreteStates.argtypes = [M1553Handle, POINTER(M1553BoardGetAllDiscreteStatesOut)]
    m1553BoardGetAllDiscreteStates.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3216
if _libs["libait_mil.so"].has("m1553BoardGetAllCarrierDiscreteStates", "cdecl"):
    m1553BoardGetAllCarrierDiscreteStates = _libs["libait_mil.so"].get("m1553BoardGetAllCarrierDiscreteStates", "cdecl")
    m1553BoardGetAllCarrierDiscreteStates.argtypes = [M1553Handle, M1553TriggerModeType, POINTER(M1553BoardGetAllDiscreteStatesOut)]
    m1553BoardGetAllCarrierDiscreteStates.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3254
if _libs["libait_mil.so"].has("m1553BoardSetDiscretePulseLength", "cdecl"):
    m1553BoardSetDiscretePulseLength = _libs["libait_mil.so"].get("m1553BoardSetDiscretePulseLength", "cdecl")
    m1553BoardSetDiscretePulseLength.argtypes = [M1553Handle, POINTER(M1553BoardSetDiscretePulseLengthIn)]
    m1553BoardSetDiscretePulseLength.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3284
if _libs["libait_mil.so"].has("m1553BoardGetDiscretePulseLength", "cdecl"):
    m1553BoardGetDiscretePulseLength = _libs["libait_mil.so"].get("m1553BoardGetDiscretePulseLength", "cdecl")
    m1553BoardGetDiscretePulseLength.argtypes = [M1553Handle, POINTER(M1553BoardGetDiscretePulseLengthOut)]
    m1553BoardGetDiscretePulseLength.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3325
if _libs["libait_mil.so"].has("m1553BoardSetCarrierDiscretePulseLength", "cdecl"):
    m1553BoardSetCarrierDiscretePulseLength = _libs["libait_mil.so"].get("m1553BoardSetCarrierDiscretePulseLength", "cdecl")
    m1553BoardSetCarrierDiscretePulseLength.argtypes = [M1553Handle, POINTER(M1553BoardSetCarrierDiscretePulseLengthIn)]
    m1553BoardSetCarrierDiscretePulseLength.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3358
if _libs["libait_mil.so"].has("m1553BoardGetCarrierDiscretePulseLength", "cdecl"):
    m1553BoardGetCarrierDiscretePulseLength = _libs["libait_mil.so"].get("m1553BoardGetCarrierDiscretePulseLength", "cdecl")
    m1553BoardGetCarrierDiscretePulseLength.argtypes = [M1553Handle, POINTER(M1553BoardGetCarrierDiscretePulseLengthOut)]
    m1553BoardGetCarrierDiscretePulseLength.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3367
if _libs["libait_mil.so"].has("m1553BoardSetPXIStarTriggerConfig", "cdecl"):
    m1553BoardSetPXIStarTriggerConfig = _libs["libait_mil.so"].get("m1553BoardSetPXIStarTriggerConfig", "cdecl")
    m1553BoardSetPXIStarTriggerConfig.argtypes = [M1553Handle, POINTER(M1553BoardSetPXIStarTriggerConfigIn)]
    m1553BoardSetPXIStarTriggerConfig.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3415
if _libs["libait_mil.so"].has("m1553ChannelReset", "cdecl"):
    m1553ChannelReset = _libs["libait_mil.so"].get("m1553ChannelReset", "cdecl")
    m1553ChannelReset.argtypes = [M1553Handle, POINTER(M1553ChannelResetIn)]
    m1553ChannelReset.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3452
if _libs["libait_mil.so"].has("m1553ChannelBIT", "cdecl"):
    m1553ChannelBIT = _libs["libait_mil.so"].get("m1553ChannelBIT", "cdecl")
    m1553ChannelBIT.argtypes = [M1553Handle, POINTER(M1553BoardBITIn), POINTER(M1553BoardBITOut)]
    m1553ChannelBIT.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3490
if _libs["libait_mil.so"].has("m1553ChannelSetResponseTimeout", "cdecl"):
    m1553ChannelSetResponseTimeout = _libs["libait_mil.so"].get("m1553ChannelSetResponseTimeout", "cdecl")
    m1553ChannelSetResponseTimeout.argtypes = [M1553Handle, POINTER(M1553ChannelSetResponseTimeoutIn)]
    m1553ChannelSetResponseTimeout.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3515
if _libs["libait_mil.so"].has("m1553ChannelGetResponseTimeout", "cdecl"):
    m1553ChannelGetResponseTimeout = _libs["libait_mil.so"].get("m1553ChannelGetResponseTimeout", "cdecl")
    m1553ChannelGetResponseTimeout.argtypes = [M1553Handle, POINTER(M1553ChannelGetResponseTimeoutOut)]
    m1553ChannelGetResponseTimeout.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3553
if _libs["libait_mil.so"].has("m1553ChannelSetMilbusProtocol", "cdecl"):
    m1553ChannelSetMilbusProtocol = _libs["libait_mil.so"].get("m1553ChannelSetMilbusProtocol", "cdecl")
    m1553ChannelSetMilbusProtocol.argtypes = [M1553Handle, POINTER(M1553ChannelSetMilbusProtocolIn)]
    m1553ChannelSetMilbusProtocol.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3583
if _libs["libait_mil.so"].has("m1553ChannelGetMilbusProtocol", "cdecl"):
    m1553ChannelGetMilbusProtocol = _libs["libait_mil.so"].get("m1553ChannelGetMilbusProtocol", "cdecl")
    m1553ChannelGetMilbusProtocol.argtypes = [M1553Handle, c_uint8, POINTER(M1553ChannelGetMilbusProtocolOut)]
    m1553ChannelGetMilbusProtocol.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3617
if _libs["libait_mil.so"].has("m1553ChannelSetMemPartition", "cdecl"):
    m1553ChannelSetMemPartition = _libs["libait_mil.so"].get("m1553ChannelSetMemPartition", "cdecl")
    m1553ChannelSetMemPartition.argtypes = [M1553Handle, POINTER(M1553ChannelSetMemPartitionIn)]
    m1553ChannelSetMemPartition.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3643
if _libs["libait_mil.so"].has("m1553ChannelGetMemPartition", "cdecl"):
    m1553ChannelGetMemPartition = _libs["libait_mil.so"].get("m1553ChannelGetMemPartition", "cdecl")
    m1553ChannelGetMemPartition.argtypes = [M1553Handle, POINTER(M1553ChannelGetMemPartitionOut)]
    m1553ChannelGetMemPartition.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3685
if _libs["libait_mil.so"].has("m1553ChannelSetTestSignal", "cdecl"):
    m1553ChannelSetTestSignal = _libs["libait_mil.so"].get("m1553ChannelSetTestSignal", "cdecl")
    m1553ChannelSetTestSignal.argtypes = [M1553Handle, POINTER(M1553ChannelSetTestSignalIn)]
    m1553ChannelSetTestSignal.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3713
if _libs["libait_mil.so"].has("m1553ChannelGetCoupling", "cdecl"):
    m1553ChannelGetCoupling = _libs["libait_mil.so"].get("m1553ChannelGetCoupling", "cdecl")
    m1553ChannelGetCoupling.argtypes = [M1553Handle, POINTER(M1553ChannelGetCouplingOut)]
    m1553ChannelGetCoupling.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3741
if _libs["libait_mil.so"].has("m1553ChannelGetBusCoupling", "cdecl"):
    m1553ChannelGetBusCoupling = _libs["libait_mil.so"].get("m1553ChannelGetBusCoupling", "cdecl")
    m1553ChannelGetBusCoupling.argtypes = [M1553Handle, POINTER(M1553ChannelGetCouplingOut), POINTER(M1553ChannelGetCouplingOut)]
    m1553ChannelGetBusCoupling.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3772
if _libs["libait_mil.so"].has("m1553ChannelSetCoupling", "cdecl"):
    m1553ChannelSetCoupling = _libs["libait_mil.so"].get("m1553ChannelSetCoupling", "cdecl")
    m1553ChannelSetCoupling.argtypes = [M1553Handle, POINTER(M1553ChannelSetCouplingIn)]
    m1553ChannelSetCoupling.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3802
if _libs["libait_mil.so"].has("m1553ChannelSetBusCoupling", "cdecl"):
    m1553ChannelSetBusCoupling = _libs["libait_mil.so"].get("m1553ChannelSetBusCoupling", "cdecl")
    m1553ChannelSetBusCoupling.argtypes = [M1553Handle, POINTER(M1553ChannelSetCouplingIn), POINTER(M1553ChannelSetCouplingIn)]
    m1553ChannelSetBusCoupling.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3830
if _libs["libait_mil.so"].has("m1553ChannelSetAmplitude", "cdecl"):
    m1553ChannelSetAmplitude = _libs["libait_mil.so"].get("m1553ChannelSetAmplitude", "cdecl")
    m1553ChannelSetAmplitude.argtypes = [M1553Handle, POINTER(M1553ChannelSetAmplitudeIn)]
    m1553ChannelSetAmplitude.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3857
if _libs["libait_mil.so"].has("m1553ChannelGetAmplitude", "cdecl"):
    m1553ChannelGetAmplitude = _libs["libait_mil.so"].get("m1553ChannelGetAmplitude", "cdecl")
    m1553ChannelGetAmplitude.argtypes = [M1553Handle, POINTER(M1553ChannelGetAmplitudeOut)]
    m1553ChannelGetAmplitude.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3884
if _libs["libait_mil.so"].has("m1553ChannelSetBitRate", "cdecl"):
    m1553ChannelSetBitRate = _libs["libait_mil.so"].get("m1553ChannelSetBitRate", "cdecl")
    m1553ChannelSetBitRate.argtypes = [M1553Handle, POINTER(M1553ChannelSetBitRateIn)]
    m1553ChannelSetBitRate.restype = c_int

# /usr/local/include/ait_mil/m1553_system.h: 3907
if _libs["libait_mil.so"].has("m1553ChannelGetBitRate", "cdecl"):
    m1553ChannelGetBitRate = _libs["libait_mil.so"].get("m1553ChannelGetBitRate", "cdecl")
    m1553ChannelGetBitRate.argtypes = [M1553Handle, POINTER(M1553ChannelGetBitRateOut)]
    m1553ChannelGetBitRate.restype = c_int

# /usr/local/include/ait_mil/m1553_vme.h: 56
for _lib in _libs.values():
    if not _lib.has("m1553VMEAddDevice", "cdecl"):
        continue
    m1553VMEAddDevice = _lib.get("m1553VMEAddDevice", "cdecl")
    m1553VMEAddDevice.argtypes = [c_uint32, c_uint32, c_uint32]
    m1553VMEAddDevice.restype = c_int
    break

# /usr/local/include/ait_mil/m1553_vme.h: 64
for _lib in _libs.values():
    if not _lib.has("m1553VMERemoveDevice", "cdecl"):
        continue
    m1553VMERemoveDevice = _lib.get("m1553VMERemoveDevice", "cdecl")
    m1553VMERemoveDevice.argtypes = [c_uint32]
    m1553VMERemoveDevice.restype = c_int
    break

M1553_API_FUNC = c_int# /usr/local/include/ait_mil/m1553_cdef.h: 276

# /usr/local/include/ait_mil/m1553_common.h: 79
try:
    M1553_API_IO_VERSION = 1
except:
    pass

# /usr/local/include/ait_mil/m1553_common.h: 85
try:
    MAX_INTERRUPT_LOGLIST_ENTRIES = 128
except:
    pass

# /usr/local/include/ait_mil/m1553_common.h: 90
try:
    MAX_API_BOARDS = 8
except:
    pass

# /usr/local/include/ait_mil/m1553_common.h: 95
try:
    MAX_API_BOARD_CHANNELS = 4
except:
    pass

# /usr/local/include/ait_mil/m1553_bc.h: 32
try:
    MAX_BC_ACYCLIC_TRANSFERS = 64
except:
    pass

# /usr/local/include/ait_mil/m1553_bc.h: 36
try:
    MAX_BC_MINOR_FRAMES = 64
except:
    pass

# /usr/local/include/ait_mil/m1553_bc.h: 40
try:
    MAX_BC_FRAME_TRANSFERS = 128
except:
    pass

# /usr/local/include/ait_mil/m1553_bm.h: 33
try:
    M1553_BUS_WORD_ENTRY_TYPE = 0
except:
    pass

# /usr/local/include/ait_mil/m1553_bm.h: 37
try:
    M1553_ERROR_WORD_ENTRY_TYPE = 1
except:
    pass

# /usr/local/include/ait_mil/m1553_bm.h: 41
try:
    M1553_TIME_TAG_LOW_ENTRY_TYPE = 2
except:
    pass

# /usr/local/include/ait_mil/m1553_bm.h: 45
try:
    M1553_TIME_TAG_HIGH_ENTRY_TYPE = 3
except:
    pass

# /usr/local/include/ait_mil/m1553_bm.h: 824
try:
    M1553_RX_WORD_PARAM_COMMAND_WORD1 = 1
except:
    pass

# /usr/local/include/ait_mil/m1553_bm.h: 830
try:
    M1553_RX_WORD_PARAM_DATA_WORD = 2
except:
    pass

# /usr/local/include/ait_mil/m1553_bm.h: 836
try:
    M1553_RX_WORD_PARAM_STATUS_WORD = 4
except:
    pass

# /usr/local/include/ait_mil/m1553_bm.h: 842
try:
    M1553_RX_WORD_PARAM_COMMAND_WORD2 = 8
except:
    pass

# /usr/local/include/ait_mil/m1553_bm.h: 849
try:
    M1553_RX_WORD_PARAM_PRIMARY_BUS = 32
except:
    pass

# /usr/local/include/ait_mil/m1553_bm.h: 856
try:
    M1553_RX_WORD_PARAM_SECONDARY_BUS = 16
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 53
try:
    API_OK = 0
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 55
try:
    API_ERROR = (-1)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 57
try:
    API_ERROR_NULL_POINTER = (-2)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 59
try:
    API_ERROR_PARAM_INVALID = (-3)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 61
try:
    API_ERROR_VALUE_INVALID = (-4)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 63
try:
    API_ERROR_NOT_IMPLEMENTED = (-5)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 65
try:
    API_NOT_INITIALIZED = (-6)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 67
try:
    API_ERROR_INDEX_OUT_OF_RANGE = (-7)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 69
try:
    API_ERROR_MAX_CLIENTS_EXCEEDED = (-8)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 72
try:
    API_ERROR_KERNELPLUGIN_NOT_FOUND = (-10)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 74
try:
    API_ERROR_INCOMPATIBLE_REVISION = (-11)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 76
try:
    API_ERROR_DRIVER_NOT_FOUND = (-12)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 78
try:
    API_ERROR_NO_DEVICES_FOUND = (-13)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 80
try:
    API_ERROR_HANDLE_INVALID = (-22)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 82
try:
    API_ERROR_RESOURCE_INVALID = (-23)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 84
try:
    API_ERROR_PRIMARY_PROC_START = (-24)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 86
try:
    API_ERROR_EVENT_HDLR_NOT_REGISTERED = (-25)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 88
try:
    API_ERROR_OS = (-27)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 90
try:
    API_ERROR_INVALID_PTR = (-28)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 92
try:
    API_ERROR_CARRIER_NOT_PRESENT = (-29)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 95
try:
    API_ERROR_STRUCT_PARAM1_INVALID = (-50)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 97
try:
    API_ERROR_STRUCT_PARAM2_INVALID = (-51)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 99
try:
    API_ERROR_STRUCT_PARAM3_INVALID = (-52)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 101
try:
    API_ERROR_STRUCT_PARAM4_INVALID = (-53)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 103
try:
    API_ERROR_STRUCT_PARAM5_INVALID = (-54)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 105
try:
    API_ERROR_STRUCT_PARAM6_INVALID = (-55)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 107
try:
    API_ERROR_STRUCT_PARAM7_INVALID = (-56)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 109
try:
    API_ERROR_STRUCT_PARAM8_INVALID = (-57)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 111
try:
    API_ERROR_STRUCT_PARAM9_INVALID = (-58)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 113
try:
    API_ERROR_STRUCT_PARAM10_INVALID = (-59)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 116
try:
    API_ERROR_STRUCT_PARAM1_OUT_OF_RANGE = (-60)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 118
try:
    API_ERROR_STRUCT_PARAM2_OUT_OF_RANGE = (-61)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 120
try:
    API_ERROR_STRUCT_PARAM3_OUT_OF_RANGE = (-62)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 122
try:
    API_ERROR_STRUCT_PARAM4_OUT_OF_RANGE = (-63)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 124
try:
    API_ERROR_STRUCT_PARAM5_OUT_OF_RANGE = (-64)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 126
try:
    API_ERROR_STRUCT_PARAM6_OUT_OF_RANGE = (-65)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 128
try:
    API_ERROR_STRUCT_PARAM7_OUT_OF_RANGE = (-66)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 130
try:
    API_ERROR_STRUCT_PARAM8_OUT_OF_RANGE = (-67)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 132
try:
    API_ERROR_STRUCT_PARAM9_OUT_OF_RANGE = (-68)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 134
try:
    API_ERROR_STRUCT_PARAM10_OUT_OF_RANGE = (-69)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 137
try:
    API_ERROR_STRUCT_PARAM11_INVALID = (-70)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 139
try:
    API_ERROR_STRUCT_PARAM12_INVALID = (-71)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 141
try:
    API_ERROR_STRUCT_PARAM13_INVALID = (-72)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 143
try:
    API_ERROR_STRUCT_PARAM14_INVALID = (-73)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 145
try:
    API_ERROR_STRUCT_PARAM15_INVALID = (-74)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 147
try:
    API_ERROR_STRUCT_PARAM16_INVALID = (-75)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 149
try:
    API_ERROR_STRUCT_PARAM17_INVALID = (-76)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 151
try:
    API_ERROR_STRUCT_PARAM18_INVALID = (-77)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 153
try:
    API_ERROR_STRUCT_PARAM19_INVALID = (-78)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 155
try:
    API_ERROR_STRUCT_PARAM20_INVALID = (-79)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 158
try:
    API_ERROR_STRUCT_PARAM11_OUT_OF_RANGE = (-80)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 160
try:
    API_ERROR_STRUCT_PARAM12_OUT_OF_RANGE = (-81)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 162
try:
    API_ERROR_STRUCT_PARAM13_OUT_OF_RANGE = (-82)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 164
try:
    API_ERROR_STRUCT_PARAM14_OUT_OF_RANGE = (-83)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 166
try:
    API_ERROR_STRUCT_PARAM15_OUT_OF_RANGE = (-84)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 168
try:
    API_ERROR_STRUCT_PARAM16_OUT_OF_RANGE = (-85)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 170
try:
    API_ERROR_STRUCT_PARAM17_OUT_OF_RANGE = (-86)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 172
try:
    API_ERROR_STRUCT_PARAM18_OUT_OF_RANGE = (-87)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 174
try:
    API_ERROR_STRUCT_PARAM19_OUT_OF_RANGE = (-88)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 176
try:
    API_ERROR_STRUCT_PARAM20_OUT_OF_RANGE = (-89)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 186
try:
    DEV_ERROR_GENERIC = (-100)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 188
try:
    DEV_ERROR_DEVICE_NOT_FOUND = (-101)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 190
try:
    DEV_ERROR_INVALID_DEVICE = (-102)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 192
try:
    DEV_ERROR_INVALID_DEVICE_INDEX = (-103)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 194
try:
    DEV_ERROR_NOT_INITIALIZED = (-104)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 196
try:
    DEV_ERROR_BIT_BUSY = (-105)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 198
try:
    DEV_ERROR_BIT_TIMEOUT = (-106)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 200
try:
    DEV_ERROR_BIT_INVALID_TEST = (-107)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 202
try:
    DEV_ERROR_BIT_NOT_RUN = (-108)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 204
try:
    DEV_ERROR_RAM_CELL_BIT_FAIL = (-109)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 206
try:
    DEV_ERROR_RAM_ADDR_LINE_BIT_FAIL = (-110)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 208
try:
    DEV_ERROR_RAM_DATA_LINE_BIT_FAIL = (-111)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 210
try:
    DEV_ERROR_BIT_TEST_FAIL = (-112)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 212
try:
    DEV_ERROR_INVALID_LICENSE_ID = (-113)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 214
try:
    DEV_ERROR_MEMORY_READ = (-114)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 216
try:
    DEV_ERROR_UNSUPPORTED_FUNCTIONALITY = (-115)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 225
try:
    CHANNEL_ERROR_GENERIC = (-200)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 227
try:
    CHANNEL_ERROR_INVALID_INDEX = (-201)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 229
try:
    CHANNEL_INVALID_SYS_CMD = (-202)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 239
try:
    M1553_ERROR_GENERIC = (-300)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 241
try:
    M1553_INVALID_CONFIG_PARAM = (-302)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 243
try:
    M1553_INVALID_STATUS_PARAM = (-303)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 245
try:
    M1553_INVALID_TRANSFER_ENTRY_INDEX = (-304)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 247
try:
    M1553_UNDEFINED_MODE_CODE = (-305)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 249
try:
    M1553_INVALID_MODE_CODE_DIRECTION = (-306)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 251
try:
    M1553_PROHIBITED_MODE_CODE = (-307)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 253
try:
    M1553_INVALID_MODE_CODE_SUBADDRESS = (-308)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 255
try:
    M1553_PROTOCOL_VIOLATION = (-309)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 257
try:
    M1553_INVALID_RT = (-310)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 259
try:
    M1553_INVALID_RT_SUBADDRESS = (-311)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 261
try:
    M1553_INVALID_BYTE_COUNT = (-312)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 263
try:
    M1553_INVALID_SUPPRESS_STATUS = (-313)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 265
try:
    M1553_INVALID_PRIORITY_LEVEL = (-314)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 267
try:
    M1553_ERROR_TRANSFER_ENTRY_IN_USE = (-315)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 269
try:
    M1553_ERROR_TRANSFER_ENTRY_EMPTY = (-316)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 271
try:
    M1553_ERROR_TRANSMIT_QUEUE_FULL = (-317)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 273
try:
    M1553_ERROR_RESULT_QUEUE_EMPTY = (-318)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 283
try:
    BC_ERROR_GENERIC = (-400)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 285
try:
    BC_GAP_ERROR = (-401)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 287
try:
    BC_INVALID_INSTRUCTION_TYPE = (-402)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 289
try:
    BC_INVALID_MINOR_FRAME = (-410)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 291
try:
    BC_INVALID_MAJOR_FRAME = (-411)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 293
try:
    BC_INVALID_MINOR_FRAME_ID = (-412)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 304
try:
    RT_ERROR_GENERIC = (-500)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 315
try:
    BM_ERROR_GENERIC = (-600)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 317
try:
    BM_ERROR_BUFFER_NOT_INITIALIZED = (-601)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 328
try:
    RPLY_ERROR_GENERIC = (-700)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 330
try:
    RPLY_ERROR_BUFFER_NOT_INITIALIZED = (-701)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 332
try:
    RPLY_ERROR_BUFFER_INVALID_SIZE = (-702)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 334
try:
    RPLY_ERROR_NOT_SUPPORTED = (-703)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 343
try:
    BUFF_ERROR_GENERIC = (-800)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 345
try:
    BUFF_ERROR_INVALID_SIZE = (-801)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 347
try:
    BUFF_ERROR_OUT_OF_RAM = (-802)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 349
try:
    BUFF_ERROR_ALLOCATE_FAIL = (-803)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 351
try:
    BUFF_ERROR_DESTROY_FAIL = (-804)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 353
try:
    BUFF_ERROR_INVALID_BUFFER = (-805)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 355
try:
    BUFF_ERROR_INVALID_OFFSET = (-806)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 357
try:
    BUFF_ERROR_INVALID_TYPE = (-807)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 359
try:
    BUFF_ERROR_IN_USE = (-808)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 361
try:
    BUFF_ERROR_ZERO_LENGTH = (-809)
except:
    pass

# /usr/local/include/ait_mil/m1553_error_def.h: 363
try:
    BUFF_ERROR_BUFF_HDR_INVALID = (-810)
except:
    pass

# /usr/local/include/ait_mil/m1553_system.h: 1847
try:
    ADMIN_DEV_TYPE_MIL_STD_1553_GC = 8
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 17
try:
    M1553_GC_VER_MAJOR = 2
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 18
try:
    M1553_GC_VER_MINOR = 0
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 19
try:
    M1553_GC_VER_MAINT = 0
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 20
try:
    M1553_GC_VER_REVISION = 7166
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 21
try:
    AIM_MIL_VER_MAJOR = 2
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 22
try:
    AIM_MIL_VER_MINOR = 0
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 23
try:
    AIM_MIL_VER_MAINT = 0
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 24
try:
    AIM_MIL_VER_REVISION = 7166
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 25
try:
    M1553_GC_VER_REVDATE = "b'2019-10-08 14:53:01 -0500 (Tue, 08 Oct 2019)'"
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 26
try:
    M1553_GC_VER_URL = "b'http://ait-subversion/svn/Owl1553/OWL1553/tags/v3.0.2'"
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 27
try:
    FIRMWARE_VERSION = 4563
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 28
try:
    USB_FIRMWARE_VERSION = 955
except:
    pass

# /usr/local/include/ait_mil/VersionInfo.h: 29
try:
    PXIE_FIRMWARE_VERSION = 4590
except:
    pass

# No inserted files

# No prefix-stripping

