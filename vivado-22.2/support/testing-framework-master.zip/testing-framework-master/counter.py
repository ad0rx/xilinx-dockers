#!/usr/bin/env python3

import time
import argparse
import re
import random
import signal
import common
import sys
import select
import bd_ait
import ait
import ctypes


common.MINOR_FRAME_TIME = 50.0 #.001 #msec
buffer_info = {} #dict of bufferID to counter,length,buffer for buffers that are transmitted (BC for BC_RT and RT for rt transmitters

def updateBuffer(c_chanHandle, bufferID):
  global buffer_info
  
  if not common.WANT_MESSAGE_COUNTER:
    return
  
 
  if bufferID in buffer_info: #bufferID will be in the dict for BC for BC_RT xfers and for RTs that are transmit
    buffer_info[bufferID]["counter"] = (buffer_info[bufferID]["counter"] + 1) % 0XFFFF
    buffer = buffer_info[bufferID]["buffer"]
    buffer[0] = buffer_info[bufferID]["counter"] #Set first word of buffer to new counter
    bd_ait.py_m1553BufSetBuffer(c_chanHandle, bufferID, len(buffer), buffer)

    #print ("\n@@@UPDATED BUFFER COUNTER FOR BUFFERID {} NEW BUFFER {}".format(bufferID,buffer)) 
  #printBufferInfo()
  

'''
{
    M1553InstallInterruptHandlerIn  InterruptConfig; 
    M1553DeleteInterruptHandlerIn  DeleteInterrupt;
    M1553GetBoardInfoOut            boardInfo;
    M1553BMGetStatusOut             bmStatus;
    M1553BCStartIn                  bcStart;
    M1553Handle                     boardHandle;
    M1553Handle                     channelHandle;
    uint32_t                        boardsFound;
    M1553Return                     retVal              = API_OK;
    uint32_t                        board               = 0;      // controls the board index to use
    uint8_t                         channel             = 0;      // controls the channel index to use
    int                             statusIterations    = 10;     // controls the a polling loop
    
    // clear all structures
    memset(&bcStart, 0, sizeof(M1553BCStartIn));
    memset(&boardInfo, 0, sizeof(M1553GetBoardInfoOut));
    memset(&bmStatus, 0, sizeof(M1553BMGetStatusOut));
    
    CHECK(m1553Init(M1553_API_IO_VERSION, &boardsFound));

    // This will retrieve all board and channel handles
    printf("Number of Boards found: %d \n", boardsFound);
    
    if(boardsFound==0)
        return retVal;

    CHECK(m1553BoardOpen(board, &boardHandle));
    CHECK(m1553GetBoardInfo(boardHandle, &boardInfo));
    
    printf("Board: %d Channels:%d Firmware Version:0x%08X\n", board, boardInfo.mChannelCount, boardInfo.mFirmwareVersion);
    for (channel = 0; channel < boardInfo.mChannelCount; channel++){    
    CHECK(m1553ChannelOpen(boardHandle,channel, &channelHandle));   
    CHECK(Setup1553Channel(channelHandle));
    channels[channel].channel = channel;
    channels[channel].channelHandle = channelHandle;

    if (channel == 0){
    
      InterruptConfig.mIntFunc = (M1553_INT_FUNC_PTR)m1553InterruptFunction;
      InterruptConfig.mType = M1553_INTERRUPT_BC;
      CHECK(m1553InstallInterruptHandler(channelHandle, &InterruptConfig));

      printf("Setup the BC and Bus Monitor\n");
      CHECK(Setup1553BusController(channelHandle));
  CHECK(Setup1553BusMonitor(channelHandle));
    } else {
  printf("Setup the RTs\n");
      CHECK(Setup1553RemoteTerminal(channelHandle,channel));
    }
    }
    printf("Start the BC RT and Bus Monitor\n");
    CHECK(m1553BMStart(channels[0].channelHandle));
    for (channel = 1; channel < boardInfo.mChannelCount; channel++){
      CHECK(m1553RTStart(channels[channel].channelHandle));
    }
    bcStart.mFrameTime = 50.0;
    CHECK(m1553BCStart(channels[0].channelHandle,  &bcStart));
    
    while(statusIterations-->0)
    {
        AIT_WAIT(100);
        
        CHECK(m1553BMGetStatus(channels[0].channelHandle, &bmStatus));
        printf("BM Status: Msg Count:%08lx, Err Count:%08lx\r", 
            bmStatus.mMessageCount,
            bmStatus.mErrorCount);
    }

    printf("Stop the BC RT and Bus Monitor\n");
    CHECK(m1553BCStop(channels[0].channelHandle));
    for (channel = 1; channel < boardInfo.mChannelCount; channel++){
      CHECK(m1553RTStop(channels[channel].channelHandle));
    }
    CHECK(m1553BMStop(channels[0].channelHandle));

    DeleteInterrupt.mType = M1553_INTERRUPT_BC;
    CHECK(m1553DeleteInterruptHandler(channels[0].channelHandle, &DeleteInterrupt));

    // Read and print data and status inforamtion from the BC, RT, and Bus Monitor
    CHECK(ReportStatus());

    // Shutdown the board
    for (channel = 0; channel < boardInfo.mChannelCount; channel++){ 
      CHECK(m1553Close(channels[channel].channelHandle));
    }
    CHECK(m1553Close(boardHandle));
    
    return retVal;
} // end main sample function
'''

def py_InterruptFunc(c_chanHandle,interruptType,loglistEntryType,m1553Addr):
  global buffer_info
  print("\n***\nIN AIT INTERRUPT FUNCTION.  INTERRUPT TYPE IS {}".format(interruptType))

  logwordA=loglistEntryType.mLogListWordA
 
  logwordC=loglistEntryType.mLogListWordC

  logwordD=loglistEntryType.mLogListWordD
  
  error = logwordA >> 25 & 0b1
                             
  if interruptType == ait.M1553_INTERRUPT_BC: #1
    inttype = 'AIT BC INT'
    transferID = logwordC
    bufferID = logwordD & 0b1111111111111111
    _,data = bd_ait.py_m1553BufGetBuffer(c_chanHandle, bufferID) #16 bit bufferid
    print("{}: XFER: {} ERROR {} BUFFERID {}:  {}\n".format(inttype,transferID,error,bufferID,data))

    #newBuf = [0x0707]*3
    #bd_ait.py_m1553BufSetBuffer(c_chanHandle, bufferID, len(newBuf), newBuf)   
    updateBuffer(c_chanHandle, bufferID)
    
INT_FUNC_PTR = ait.M1553_INT_FUNC_PTR(py_InterruptFunc)


def py_m1553InstallInterruptHandler(c_chanHandle,interrupttype):
  global INT_FUNC_PTR
    
  print("About to do the interrupt handler install")
  c_mInstallInterruptHandlerIn = ait.M1553InstallInterruptHandlerIn(mType=interrupttype,
                                                                    mIntFunc= INT_FUNC_PTR) 

  
  ait.m1553InstallInterruptHandler(c_chanHandle, ctypes.byref(c_mInstallInterruptHandlerIn))
  print("Done with the interrupt handler install")



def py_addRT(c_chanHandle, rtnum=None, subaddr=None):
  global buffer_info

  bufferID = 10 + rtnum
  headerID = bufferID
      
  length = 32
  buffer = [0] * length
       
  bd_ait.py_m1553RTSASetBufferHeader(c_chanHandle, headerID, bufferID)     
  bd_ait.py_m1553BufSetBuffer(c_chanHandle, bufferID, length, buffer)
  bd_ait.py_m1553BufGetBuffer(c_chanHandle, bufferID, length)
  res=bd_ait.py_m1553RTSetConfig(c_chanHandle,rtnum=rtnum)
 
  if res:
    bd_ait.py_m1553RTSASetConfig(c_chanHandle, headerID=headerID, rtnum=rtnum, subaddr=subaddr, direction=common.Direction.RECEIVE, mode=None)

def py_createTransfer(c_chanHandle, transferID, dataBuffer, dataLength):
  global buffer_info
  bufferID = transferID
  headerID = bufferID
  transfertype = ait.M1553_BC_TO_RT
  xmitrtnum=0
  xmitsubaddr=0
  rcvrtnum=transferID
  rcvsubaddr=transferID
    
  length = 32
  buffer = [0] * length
  

  if dataBuffer:
    bufferLen = len(dataBuffer)
    buffer[:bufferLen]=dataBuffer
    
  print("About to set buffer {} for transferID {}".format(buffer,transferID))
  
  if transfertype == ait.M1553_BC_TO_RT:
    buffer_info[bufferID] = {"counter":0, "length":length, "buffer":buffer}
    
  bd_ait.py_m1553BCSetBufferHeader(c_chanHandle, headerID, bufferID)     
  bd_ait.py_m1553BufSetBuffer(c_chanHandle, bufferID, length, buffer)
 
  return bd_ait.py_m1553BCSetTransfer(c_chanHandle, headerID, transferID, transfertype, dataLength, xmitrtnum, xmitsubaddr, rcvrtnum, rcvsubaddr)  #Return the transferID if sucessful; else -1


def run():
  statusIterations    = 10
  boardHandles = []
  channelHandles = []
  numBoards = bd_ait.py_m1553Init()
  print("numBoards is {}".format(numBoards))

    
  for i in range(0, numBoards):
    print("Opening board {}".format(i))    
    c_boardHandle = bd_ait.py_m1553BoardOpen(i)
    boardHandles.append(c_boardHandle)
    print("board handle = {}".format(c_boardHandle.value))
    c_boardInfo = bd_ait.py_m1553GetBoardInfo(c_boardHandle)
      
    boardname = str(c_boardInfo.mSerialNumber)  # Use the serial number as the board name
    print("Device board name is {}".format(boardname))


    for c in range(0, c_boardInfo.mChannelCount):

      print("Finding handle for channel {}".format(c))
      c_chanHandle = bd_ait.py_m1553ChannelOpen(c_boardHandle, c)
      print("{}: chan handle = {}".format(c, c_chanHandle.value))
      print("Adding AIT channel for ({},{}) to channelHandles".format(boardname, c))
      channelHandles.append(c_chanHandle)
      
      bd_ait.py_m1553ChannelReset(c_chanHandle)
      bd_ait.py_m1553ChannelSetCoupling(c_chanHandle)
      bd_ait.py_m1553ChannelSetResponseTimeout(c_chanHandle, 14)
      
      if (c == 0): #This is the BC channel
        py_m1553InstallInterruptHandler(c_chanHandle,ait.M1553_INTERRUPT_BC)        
        bd_ait.py_m1553BCInit(c_chanHandle)
        ait.m1553BMInit(c_chanHandle)
        c_config = ait.M1553BMConfig(mTraceAfterTrigger=ctypes.c_uint32(0x10000))
        c_configin = ait.M1553BMSetConfigIn(c_config)
        ait.m1553BMSetConfig(c_chanHandle, ctypes.byref(c_configin))
        
        dataBuffer = []
        dataLength = 3
        for i in range(dataLength):
          dataBuffer.append(0xaced)
        py_createTransfer(c_chanHandle, 1, dataBuffer, dataLength)
        dataBuffer = []
        for i in range(dataLength):
          dataBuffer.append(0xdead)        
        py_createTransfer(c_chanHandle, 2, dataBuffer, dataLength)
        dataBuffer = []
        for i in range(dataLength):
          dataBuffer.append(0xface)             
        py_createTransfer(c_chanHandle, 3, dataBuffer, dataLength)                               

        bd_ait.setUpFraming(c_chanHandle, 3, transferStart = 1)
      else: #Everything else is an RT channel
        py_addRT(c_chanHandle, rtnum=c, subaddr=c)

  bd_ait.py_m1553BMStart(channelHandles[0])


  for c in range(1, 4):
    bd_ait.py_m1553RTStart(channelHandles[c])

  bd_ait.py_m1553BCStart(channelHandles[0], numFrames=0, minorFrameTime=common.MINOR_FRAME_TIME)
  
  for i in range(statusIterations):
    time.sleep(.1)
    MESSAGES,ERRORS = bd_ait.py_m1553BMGetStatus(channelHandles[0])
    print("BM MESSAGES {} ERRORS {}".format(MESSAGES,ERRORS))  
 
    
  print("HEADING TO THE EXIT")
  bd_ait.py_m1553BCStop(channelHandles[0])  

  for c in range(1, 4):
    bd_ait.py_m1553RTStop(channelHandles[c])
    
  bd_ait.py_m1553BMStop(channelHandles[0])    
    
  bd_ait.py_m1553DeleteInterruptHandler(channelHandles[0],ait.M1553_INTERRUPT_BC,0)
  
  MESSAGES,ERRORS = bd_ait.py_m1553BCGetStatus(channelHandles[0])
  print("BC MESSAGES {} ERRORS {}".format(MESSAGES,ERRORS))
  MESSAGES,ERRORS = bd_ait.py_m1553BMGetStatus(channelHandles[0])
  print("BM MESSAGES {} ERRORS {}".format(MESSAGES,ERRORS))  
  for c in range(1, 4):
    (MESSAGES,ERRORS)=bd_ait.py_get_global_rt_status(channelHandles[c])
    print("RT {} MESSAGES {} ERRORS {}".format(c,MESSAGES,ERRORS))       

  bd_ait.update_bm_dump(filedata=None,c_chanHandle=channelHandles[0])
        
  for c in range(0, 4):
    bd_ait.py_m1553Close(channelHandles[c])

  for boardHandle in boardHandles:   #This was hanging
    print("\nShutting down AIT board")
    bd_ait.py_m1553Close(boardHandle)
 

if __name__ == '__main__':

  run()
  
