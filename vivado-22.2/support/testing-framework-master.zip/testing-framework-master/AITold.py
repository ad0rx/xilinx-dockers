#!/usr/bin/env python3

import ctypes
import faulthandler
from enum import Enum, IntEnum



M1553_API_IO_VERSION = 1
MAX_API_BOARD_CHANNELS = 4
aitlib = None

class py_M1553BCTransferStartModeType(IntEnum):
	M1553_BC_START_IMMEDIATELY = 0
	M1553_BC_START_ON_STROBE = 1	
	M1553_BC_START_ON_MODECODE = 2	
	M1553_BC_START_MINOR_FRAME_ON_STROBE = 3	
	M1553_BC_START_SETUP = 4	
	M1553_BC_START_FAST = 5	
	M1553_BC_START_INSTRUCTION = 6

class py_M1553ResetMode(IntEnum):
	M1553_RESET_ALL = 0
	M1553_RESET_INITIALIZE_MEMORY = 1
	M1553_RESET_MEMORY_PARTITIONS = 2
	M1553_RESET_INTERRUPT_REGISTERS = 3


class py_M1553BitControl(IntEnum):
	M1553_BIT_NO_TEST = 0 	
	M1553_BIT_ALL_TEST = 1	
	M1553_BIT_RAM_TEST = 2 	
	M1553_BIT_FULL_RAM_TEST = 3	
	M1553_BIT_IO_TEST = 4 	
	M1553_BIT_PLX_TEST = 5	
	M1553_BIT_TRANSFER_TEST = 6 	
	M1553_BIT_INTERRUPT_TEST = 7	
	M1553_BIT_IRIG_TEST = 8	

class c_M1553BCStartIn(ctypes.Structure):
	_fields_ = [('mStartMode',ctypes.c_uint32),
			('mCount',ctypes.c_uint32),
			('mFrameTime',ctypes.c_float),
			('mStartAddress',ctypes.c_uint32)
			]
	
class c_M1553Handle(ctypes.Structure):
	_fields_ = [('value',ctypes.c_voidp)]
	
class c_M1553ChannelResetIn(ctypes.Structure):
	_fields_ = [('mMode', ctypes.c_uint32)]
	
class c_M1553BoardBITIn(ctypes.Structure):
	_fields_ = [('mControl', ctypes.c_uint32),
			('mParam', ctypes.c_uint32) #unused
			]
	
class c_M1553BoardBITOut(ctypes.Structure):
	_fields_ = [('mBITStatus', 2 * ctypes.c_uint8)]			

class c_M1553CouplingCapabilities(ctypes.Structure):
	_fields_ = [('mNetworkCoupling', ctypes.c_ubyte),
						('mTransformerCoupling', ctypes.c_ubyte),
						('mDirectCoupling', ctypes.c_ubyte),
						('mIsolatedCoupling', ctypes.c_ubyte),
						('mDigitalWrapCoupling', ctypes.c_ubyte),
						('mFixedCoupling', ctypes.c_ubyte)
						]					

class c_M1553IrigCapabilities(ctypes.Structure):
	_fields_ = [('mSinusoidalCarrier', ctypes.c_ubyte),
						('mFreeWheeling', ctypes.c_ubyte),
						('mSwitchable', ctypes.c_ubyte)
						]					
	
	
class c_M1553GetBoardInfoOut(ctypes.Structure):
	_fields_ = [('mDeviceBackplane', ctypes.c_uint32),
						('mBoardType', ctypes.c_uint32),
						('mFirmwareVersion', ctypes.c_uint32),
						('mSoftwareCompatibility', ctypes.c_uint32),
						('mChannelCount', ctypes.c_uint8),
						('mSerialNumber', ctypes.c_uint32),
						('mPartNumber', ctypes.c_uint32),
						('mVariableAmplitude', ctypes.c_ubyte),
						('mCouplingCapabilities', c_M1553CouplingCapabilities),
						('mIrigCapabilities', c_M1553IrigCapabilities),
						('mGlobalRamSize', ctypes.c_uint32),
						('mChannelMemorySize', MAX_API_BOARD_CHANNELS * ctypes.c_uint32),
						('mChannelMemoryOffset', MAX_API_BOARD_CHANNELS * ctypes.c_uint32),
						('mPciConfigRegisters', 16 * ctypes.c_uint32)						
							]

def getAitlib(path="/usr/local/lib64/libait_mil.so"):
	global aitlib
	aitlib = ctypes.CDLL(path)
	print("aitlib = {}".format(aitlib))

def py_m1553Init(structIOversion = M1553_API_IO_VERSION):

	c_structIOversion = ctypes.c_uint32(structIOversion)
	c_boardsFound = ctypes.c_uint32(0)
	aitlib.m1553Init.argtypes = [ctypes.c_uint32,ctypes.POINTER(ctypes.c_uint32) ]
	aitlib.m1553Init(c_structIOversion, ctypes.byref(c_boardsFound))
	
	return c_boardsFound.value	

def py_m1553BoardOpen(boardNum):
	
	c_boardNum = ctypes.c_uint32(boardNum)

	c_boardHandle = c_M1553Handle()
	print("boardNum = {} boardHandle = {}".format(c_boardHandle.value,c_boardNum.value))
	aitlib.m1553BoardOpen.argtypes = [ctypes.c_uint32,ctypes.POINTER(c_M1553Handle)]
	aitlib.m1553BoardOpen(c_boardNum,ctypes.byref(c_boardHandle))
		
	return c_boardHandle

def py_m1553GetBoardInfo(c_boardHandle):
	
	c_boardInfo = c_M1553GetBoardInfoOut()
	
	aitlib.m1553GetBoardInfo.argtypes = [ c_M1553Handle, ctypes.POINTER(c_M1553GetBoardInfoOut) ]
	aitlib.m1553GetBoardInfo(c_boardHandle, ctypes.byref(c_boardInfo))
	print("board channel count = {}".format(c_boardInfo.mChannelCount))
	print("board firmware version = 0x{:08x}".format(c_boardInfo.mFirmwareVersion))
	print("board serial number = 0x{:x}".format(c_boardInfo.mSerialNumber))	

	return c_boardInfo

def py_m1553ChannelOpen(c_boardHandle, chanNum):
	c_chanNum = ctypes.c_uint32(chanNum)
	c_chanHandle = c_M1553Handle()
	print("boardHandle = {} chanNum = {} chanHandle = {}".format(c_boardHandle.value,c_chanNum.value, c_chanHandle.value))
	aitlib.m1553ChannelOpen.argtypes = [c_M1553Handle,ctypes.c_uint32,ctypes.POINTER(c_M1553Handle)]
	aitlib.m1553ChannelOpen(c_boardHandle,c_chanNum,ctypes.byref(c_chanHandle))
	
	return c_chanHandle

def py_m1553BCStart (c_chanHandle,mStartMode=0,mCount=0,mFrameTime=20.0,mStartAddress=0):
	c_start = c_M1553BCStartIn(mStartMode,mCount,mFrameTime,mStartAddress)
	aitlib.m1553BCStart.argtypes = [c_M1553Handle,ctypes.POINTER(c_M1553BCStartIn)]
	aitlib.m1553BCStart(c_chanHandle, ctypes.byref(c_start))

def py_m1553ChannelReset(c_chanHandle, reset = py_M1553ResetMode.M1553_RESET_ALL):
	c_reset = c_M1553ChannelResetIn(int(reset))
	aitlib.m1553ChannelReset.argtypes = [c_M1553Handle,ctypes.POINTER(c_M1553ChannelResetIn)]
	aitlib.m1553ChannelReset(c_chanHandle, ctypes.byref(c_reset))

def py_m1553ChannelBIT(c_chanHandle,control = py_M1553BitControl.M1553_BIT_ALL_TEST):
	aitlib.m1553ChannelBIT.argtypes = [c_M1553Handle,
									ctypes.POINTER(c_M1553BoardBITIn),
									ctypes.POINTER(c_M1553BoardBITOut)]
	c_boardBITin = c_M1553BoardBITIn(int(control),0)	
	c_boardBITout = c_M1553BoardBITOut((0,0))		
	aitlib.m1553ChannelBIT(c_chanHandle, ctypes.byref(c_boardBITin), ctypes.byref(c_boardBITout))
	
	print("Built In Test Results Result: {:2d}.{:2d}".format(c_boardBITout.mBITStatus[0], c_boardBITout.mBITStatus[1]))
	if (c_boardBITout.mBITStatus[0] != 0):
		print("Self test failed")
	else:
		print("Self test passed")
		
	return

def py_m1553Close(c_chanOrBoardHandle):
	aitlib.m1553Close.argtypes = [c_M1553Handle]
	aitlib.m1553Close(c_chanOrBoardHandle)
	return 

def py_m1553BMInit(c_chanHandle):	
	aitlib.m1553BMInit.argtypes = [c_M1553Handle]
	aitlib.m1553BMInit(c_chanHandle)
	return

def py_m1553BMStart(c_chanHandle):	
	aitlib.m1553BMStart.argtypes = [c_M1553Handle]
	aitlib.m1553BMStart(c_chanHandle)
	return

def py_m1553BMStop(c_chanHandle):	
	aitlib.m1553BMStop.argtypes = [c_M1553Handle]
	aitlib.m1553BMStop(c_chanHandle)
	return
		
def py_m1553BCInit(c_chanHandle):	
	aitlib.m1553BCInit.argtypes = [c_M1553Handle]
	aitlib.m1553BCInit(c_chanHandle)
	return

def py_m1553BCStop(c_chanHandle):	
	aitlib.m1553BCStop.argtypes = [c_M1553Handle]
	aitlib.m1553BCStop(c_chanHandle)
	return
		
def py_m1553RTInit(c_chanHandle):	
	aitlib.m1553RTInit.argtypes = [c_M1553Handle]
	aitlib.m1553RTInit(c_chanHandle)
	return
		
def py_m1553RTStart(c_chanHandle):	
	aitlib.m1553RTStart.argtypes = [c_M1553Handle]
	aitlib.m1553RTStart(c_chanHandle)
	return
		
def py_m1553RTStop(c_chanHandle):	
	aitlib.m1553RTStop.argtypes = [c_M1553Handle]
	aitlib.m1553RTStop(c_chanHandle)
	return
		
		
if __name__ == '__main__':
	faulthandler.disable()
	faulthandler.enable(all_threads=True)
	
	getAitlib()
	numBoards = py_m1553Init()
	print("numBoards is {}".format(numBoards))
	
	for i in range(0,numBoards):
		print("Opening board {}".format(i))
		
		c_boardHandle = py_m1553BoardOpen(i)
		print("board handle = {}".format(c_boardHandle.value))
		c_boardInfo = py_m1553GetBoardInfo(c_boardHandle)

		for c in range(0,c_boardInfo.mChannelCount):
			print("Finding handle for channel {}".format(c))
			c_chanHandle = py_m1553ChannelOpen(c_boardHandle, c)
			print("{}: chan handle = {}".format(c,c_chanHandle.value))
			print("About to do a channel reset")
			py_m1553ChannelReset(c_chanHandle)
			print("About to do channel self-test")
			py_m1553ChannelBIT(c_chanHandle)
			
