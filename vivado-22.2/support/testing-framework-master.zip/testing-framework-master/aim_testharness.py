#!/usr/bin/env python3

import aim_mil.device
import aim_mil.event
from aim_mil.mil_bindings import *
import time
import common
import os

RT_BUFFID_RT_OBJ_DICT = {}
XFER_BUFFID_XFER_OBJ_DICT = {}
XFER_OBJ_ID_DICT = {}
buffer_info = {} #dict of bufferID to counter,length,buffer for buffers that are transmitted (BC for BC_RT and RT for rt transmitters


def updateBuffer(rt_or_bc_obj, bufferID):
  global buffer_info
  
  if not common.WANT_MESSAGE_COUNTER:
    return
  
  if not rt_or_bc_obj:
    return  
  
  if bufferID in buffer_info: #bufferID will be in the dict for BC for BC_RT xfers and for RTs that are transmit
    buffer_info[bufferID]["counter"] = (buffer_info[bufferID]["counter"] + 1) % 0XFFFF
    buffer_info[bufferID]["buffer"][0] = buffer_info[bufferID]["counter"] #Set first word of buffer to new counter
    #print("About to set the buffer to {}".format(buffer_info[bufferID]["buffer"]))
    rt_or_bc_obj.data = buffer_info[bufferID]["buffer"]
    

class AIMStream:
  def __init__(self,stream,isRTchan=False,isBCchan=False, chanNum=0):
    self.stream = stream
    self.chanNum = chanNum
    self.isRTchan = isRTchan
    self.isBCchan = isBCchan
    self.transfers = []
    self.bc_status = {'status': API_BC_STATUS_BUSY}
    self.monitor = None
    self.event_count = 0
    self.event_list = []
    print("Setting the callback handler")
    self.interrupt = aim_mil.event.AimDeviceEventHandler(self.stream)
    self.interrupt.set_callback_handler(self.callback_handler)
    
    
    if isRTchan == True:
      stream.init_rts()
      self.interrupt.install(API_INT_RT)
      
    if isBCchan == True:
      print("WANT_BBUS is {}".format(common.WANT_BBUS))
      print("REDUNDANT_BUS is {}".format(common.REDUNDANT_BUS))       
      stream.init_bc(wantbbus=common.WANT_BBUS,redundant_bus=common.REDUNDANT_BUS)
      self.interrupt.install(API_INT_BC)
      self.interrupt.install(API_INT_BM)
    elif common.WANT_EXTRA_BMS:
      self.interrupt.install(API_INT_BM)
      
    #print("Creating new aimstream {} isRTchan = {} isBCchan = {}".
          #format(self.stream.id,self.isRTchan,self.isBCchan))

  def callback_handler(self, handle, biu, int_type, loglist_addr):
    global RT_BUFFID_RT_OBJ_DICT
    global XFER_BUFFID_XFER_OBJ_DICT
    
    #print("RT_BUFFID_RT_OBJ_DICT= {}".format(RT_BUFFID_RT_OBJ_DICT))
    #print("XFER_BUFFID_XFER_OBJ_DICT= {}".format(XFER_BUFFID_XFER_OBJ_DICT))      
       
    #print("\n***\n")
    self.event_count += 1

    event =  TY_API_INTR_LOGLIST_ENTRY.from_buffer_copy(loglist_addr.contents)   

    logwordA=event.ul_Lla
    #print("AIMlogwordA is {}".format(bin(logwordA))) 
    logwordC=event.x_Llc.ul_All
    #print("AIMlogwordC is {}".format(bin(logwordC)))
    logwordD=event.x_Lld.ul_All
    #print("AIMlogwordD is {}".format(bin(logwordD)))
      
    error = logwordA >> 25 & 0b1
    bufferID = logwordD & 0b1111111111111111 #16 bits
    if int_type == API_INT_RT:
      inttype = 'AIM RT INT'
      mode_length = logwordC & 0b11111
      print("mode_length = {}".format(mode_length))
      sa = logwordC >> 5 & 0b11111
      print("sa = {}".format(sa))
      direction = logwordC >> 10 & 0b1
      print("direction = {}".format(direction))
      rt = logwordC >> 11 & 0b11111
      print("rt = {}".format(rt))
      rtobj = RT_BUFFID_RT_OBJ_DICT.get(bufferID)
      print("rtobj = {}".format(rtobj))
      if rtobj:
        data = rtobj.data
      else:
        data = None
      print("RT {} SA {} T/R {} MODE_LENGTH {}".format(rt,sa,direction,mode_length))
      print("{}: DIR: {} ERROR {} BUFFERID {}: {}\n".format(inttype,direction,error,bufferID,data))
      
      updateBuffer(rtobj,bufferID)
    elif int_type == API_INT_BC:
      inttype = 'AIM BC INT'
      transferID = logwordC & 0b111111111111111111111111 #(2**24 - 1)
      xferobj = XFER_BUFFID_XFER_OBJ_DICT.get(bufferID)
      if xferobj:
        data = xferobj.data
      else:
        data = None      
      print("{}: XFER: {} ERROR {} BUFFERID {}: {}\n".format(inttype,transferID,error,bufferID,data))
      updateBuffer(xferobj,bufferID)
    elif int_type == API_INT_BM:
      inttype = 'AIM BM INT'
      #print("AIM BM INTERRUPT!")
      bytes_read = self.monitor.read()
      #print("BM bytes_read = {}".format(bytes_read))       
    

  def startRTs(self):
    if self.isRTchan:
      self.stream.start_rts()
    
  def startBC(self):
    if self.isBCchan:
      if len(self.transfers):
        self.stream.add_cyclic_transfers(self.transfers)
        self.stream.setup_default_framing()
        #self.stream.setup_instruction_framing()
      
      self.stream.start_bc(cycles=common.NUM_FRAMES,frame_time=common.MINOR_FRAME_TIME)       
    
  
  def stopRTs(self):
    if self.isRTchan:
      self.stream.stop_rts()
    
  def stopBC(self):
    if self.isBCchan: 
      print("Stopping BC stream {}".format(self.stream.id))
    
      try:
        self.stream.stop_bc()
      except:
        pass
      
  def stopBMs(self):
    print("In AIM stopBMs, chanNum = {} isBCchan = {} isRTchan = {} WANT_EXTRA_BMS = {} ".format(self.chanNum, self.isBCchan, self.isRTchan, common.WANT_EXTRA_BMS))
    if self.isBCchan or (self.isRTchan and common.WANT_EXTRA_BMS):
      print("In AIM stopBMs, chanNum = {} STOPPING BM".format(self.chanNum))
      try:
        if (self.monitor):
          self.monitor.read()
          self.monitor.stop()
      except:
        pass
  
  def startBMs(self):
    print("In AIM startBMs, chanNum = {} isBCchan = {} isRTchan = {} WANT_EXTRA_BMS = {} ".format(self.chanNum, self.isBCchan, self.isRTchan, common.WANT_EXTRA_BMS))
    if self.isBCchan or (self.isRTchan and common.WANT_EXTRA_BMS):
      print("In AIM startBMs, chanNum = {} STARTING BM".format(self.chanNum))
      self.monitor = self.stream.start_recording(os.path.join(common.BM_OUTPUT_DIR,common.BM_OUTPUT_FILE.replace("C",str(self.chanNum)).replace("D","AIM")))
      
  def deleteInterruptHandlers(self):
    return
    if self.isRTchan == True:
      self.interrupt.remove(API_INT_RT)
      
    if self.isBCchan == True:
      self.interrupt.remove(API_INT_BC)
      self.interrupt.remove(API_INT_BM)
    elif common.WANT_EXTRA_BMS:
      self.interrupt.remove(API_INT_BM)
        
  def shutdown(self):
    print("Shutting down AIM channel {}".format(self.chanNum))
    return    
    self.stream.close()        

  def dumpBCStatus(self):
    MESSAGES=0
    ERRORS=0
    if self.isBCchan:
      MESSAGES=self.stream.bc_status['messages']
      ERRORS=self.stream.bc_status['errors']
      common.STATUSES['BC'].append({'devtype':'AIM','chan':self.chanNum,'messages':MESSAGES,'errors':ERRORS})
      #print("AIM CHANNEL BC TOTALS: MESSAGES={}\tERRORS={}".format(MESSAGES,ERRORS))
    return (MESSAGES,ERRORS)

  def dumpBMStatus(self):
    MESSAGES=0
    ERRORS=0
    if self.isBCchan or common.WANT_EXTRA_BMS:
      MESSAGES=self.monitor.bm_status['messages']
      ERRORS=self.monitor.bm_status['errors']
      common.STATUSES['BM'].append({'devtype':'AIM','chan':self.chanNum,'messages':MESSAGES,'errors':ERRORS})
      #print("AIM CHANNEL BM TOTALS: MESSAGES={}\tERRORS={}".format(MESSAGES,ERRORS))
    return (MESSAGES,ERRORS)

  def dumpRTStatus(self):
    MESSAGES=0
    ERRORS=0
    if self.isRTchan:
      #Get the RT statuses
      #self.stream.get_individual_rt_statuses()
      MESSAGES=self.stream.rt_status['messages']
      ERRORS=self.stream.rt_status['errors']
      common.STATUSES['RT'].append({'devtype':'AIM','chan':self.chanNum,'messages':MESSAGES,'errors':ERRORS})
      #print("AIM CHANNEL RT TOTALS: MESSAGES={}\tERRORS={}".format(MESSAGES,ERRORS))
    return (MESSAGES,ERRORS)

class AIM:
  def __init__(self):

    self.streamHandles = {}  #Maps (devname,channum) tuples to AIM stream objects
    self.monitor = None
    self.BC = None
    self.nextTransferID = 0
    self.transfer_ID_map = {}

    host = aim_mil.device.Host('local')
    print("host = {} host.devices = {}".format(host,host.devices))

    devicesInUse = [*common.DEVICES.keys()] #This gives the device names of interest
    #print ('devicesInUse = {}'.format(devicesInUse))
    for device in host.devices:
        device.init(common.XMIT_AMPLITUDE)

        #print("Executing sample program for module %d..." % device.id)
        boardname = device.boardname.decode("utf-8")
        print("Device board name is {}".format(boardname))
        print("Device versions are {}".format(device.versions))

        if boardname not in devicesInUse:
          continue

        rtchans = common.DEVICES[boardname].rtchans
        bcchan = common.DEVICES[boardname].bcchan
        #print("rtchans for {} are {}".format(boardname,rtchans))
        #print("bcchan for {} is {}".format(boardname,bcchan))
        '''  
        if not common.FAST_MODE:
          for stream in device.streams:
            if not (stream.id in rtchans) and not (bcchan == stream.id):
              continue
            
            stream.open()
            stream.set_coupling(API_CAL_CPL_TRANSFORM)              
          
            print("Selftest on stream %d: " % stream.id + repr(stream.selftest()))
            stream.close()
        '''
        for stream in device.streams:

          print ("stream.id is {}".format(stream.id))

          stream.open()
          #print("Getting per-stream info")
          #device.init_board(stream._handle)
          #device.init_driver_info(stream._handle)
          #device.init_name(stream._handle)
          #device.init_boardinfo(stream._handle)
          #device.init_versions(stream._handle)
          #boardname = device.boardname.decode("utf-8")
          #print("Device board name is {}".format(boardname))
          #print("Device versions are {}".format(device.versions))
          
          #device.set_response_timeout(stream._handle, responsetimeout=common.RESPONSE_TIMEOUT)

          if not (stream.id in rtchans) and not (bcchan == stream.id):
            stream.close()
            continue
          
          stream.reset()
          
                    
          #print("Selftest on stream %d: " % stream.id + repr(stream.selftest()))    
          stream.set_coupling(API_CAL_CPL_TRANSFORM)          
          
          isRTchan = False
          isBCchan = False
          if (stream.id in rtchans):
            print("rtchans contains stream.id {}".format(stream.id))
            isRTchan = True
          if (bcchan == stream.id):
            #stream.set_response_timeout(responsetimeout=common.RESPONSE_TIMEOUT)  This does not work.
            print("bcchan is stream.id {}".format(stream.id))
            isBCchan = True
            
          #print("Adding stream for ({},{}) to streamHandles".format(boardname,stream.id))
          aimstream = AIMStream(stream=stream,isRTchan=isRTchan,isBCchan=isBCchan,chanNum=stream.id)
          if isBCchan:
            self.BC = aimstream  #Hold on to the handle to the stream
            
          self.streamHandles[(boardname,stream.id)] = aimstream
          #print ("self.streamHandles is now {}".format(self.streamHandles))

            
  def print_aim_device(self,device=None):
    if not device:
      return

    #print("AIM device: id = {} boardname = {} serial = {} host = {} streams = {} versions = {}".format(device.id, device.boardname, device.serial, device.host, device.streams, device.versions))

  def map_transfer_to_id(self, transfer):
    global XFER_OBJ_ID_DICT
    
    XFER_OBJ_ID_DICT[transfer] = self.nextTransferID
    self.nextTransferID += 1

  #There are 4 flavors of BCRT transfer -- BCRT, BCBCAST, MODE (not transmit), and MODE_BCAST  
  def addBCRTTransfer(self, devname=None, channum=None, xferType=None, rtnum=None, subaddr=None,dataLength=None, dataBuffer=None):
    global XFER_BUFFID_XFER_OBJ_DICT, buffer_info
    print("In AIM BCRTTransfer")
    if not devname or not channum or not xferType or dataLength==None  or not rtnum or subaddr == None :
      print("Not adding transfer because devname {} channum {} xferType {} dataLength {} rtnums {} subaddr {} not specified".format(devname,channum,xferType,dataLength,rtnum,subaddr))
      return None

    aimstream = self.streamHandles.get((devname,channum))
    if not aimstream:
      return None
    stream = aimstream.stream
    
    if xferType == common.Transfer.BCRT or xferType == common.Transfer.BCBCAST:
      if dataBuffer == None:
        print ("Data buffer not provided for BCRT tranfer.")
        return None

      transfer = aim_mil.bc.BcRtTransfer(stream, dataLength, (rtnum, subaddr), tic=API_BC_TIC_INT_ON_XFER_END,
                                         gaptime=common.TRANSFER_GAP_TIME,gapmode=common.TRANSFER_GAP_MODE)
      transfer.data = dataBuffer
      print("Data transfered is {}".format(transfer.data))
      print("AIM XFER BUFFERID = {}".format(transfer.hid))
      #print("addBCRTTransfer: dataLength = {} rtnum = {} subaddr = {} buffer_id = {}".format(dataLength, rtnum, subaddr,transfer.hid))
      buffer_info[transfer.hid] = {"counter":0, "length":len(transfer.data), "buffer":transfer.data}      

    elif xferType == common.Transfer.MODE_BCAST or xferType == common.Transfer.MODE:

      transfer = aim_mil.bc.BcRtTransfer(stream, dataLength, (rtnum, subaddr), tic=API_BC_TIC_INT_ON_XFER_END,
                                         gaptime=common.TRANSFER_GAP_TIME,gapmode=common.TRANSFER_GAP_MODE)
      if dataBuffer and len(dataBuffer) == 1:
        transfer.data = dataBuffer
      #print("addBCRTTransfer: dataLength = {} rtnum = {} subaddr = {} dataBuffer = {} buffer_id = {}".format(dataLength, rtnum, subaddr, dataBuffer,transfer.hid)) 
      print("AIM XFER BUFFERID = {}".format(transfer.hid))
      
    aimstream.transfers.append(transfer)
    XFER_BUFFID_XFER_OBJ_DICT[transfer.hid] = transfer
    self.map_transfer_to_id(transfer)
    return transfer

  #There are two flavors of RTBC Transfer -- RTBC and MODE (transmit) 
  def addRTBCTransfer(self, devname=None, channum=None, xferType=None, rtnum=None, dataLength=None, subaddr = None, dataBuffer=None):
    global XFER_BUFFID_XFER_OBJ_DICT
    print("In AIM RTBCTransfer")
    if not devname or not channum or not xferType or dataLength==None or not rtnum or subaddr == None:
      print("Not adding transfer because devname {} channum {} xferType {} dataLength {} rtnum {} subaddr {} not specified".format(devname,channum,xferType,dataLength,rtnum,subaddr))
      return None

    aimstream = self.streamHandles.get((devname,channum))
    if not aimstream:
      return None
    stream = aimstream.stream

    if xferType == common.Transfer.RTBC or xferType == common.Transfer.MODE:
      transfer = aim_mil.bc.RtBcTransfer(stream, dataLength, (rtnum, subaddr), tic=API_BC_TIC_INT_ON_XFER_END, 
                                         gaptime=common.TRANSFER_GAP_TIME,gapmode=common.TRANSFER_GAP_MODE)
      #print("addRTBCTransfer: dataLength = {} rtnum = {} subaddr = {} dataBuffer = {} buffer_id = {}".format(dataLength, rtnum, subaddr, dataBuffer,transfer.hid))  
      print("AIM XFER BUFFERID = {}".format(transfer.hid))             
    aimstream.transfers.append(transfer)
    XFER_BUFFID_XFER_OBJ_DICT[transfer.hid] = transfer
    self.map_transfer_to_id(transfer)
    return transfer

  #There are two flavors of RTRT Transfer -- RTRT and RTBCAST
  def addRTRTTransfer(self, devname=None, channum=None, xferType=None, rt_xmit=None, rt_rcv=None, dataLength=None, dataBuffer=None):
    global XFER_BUFFID_XFER_OBJ_DICT
    if not devname or not channum or not xferType or not dataLength or not rt_xmit or not rt_rcv:
      print("Not adding transfer because devname {} channum {} xferType {} dataLength {} rt_xmit {} or rt_rcv {}not specified".format(devname,channum,xferType,dataLength,rt_xmit,rt_rcv))
      return None

    aimstream = self.streamHandles.get((devname,channum))
    if not aimstream:
      return None
    stream = aimstream.stream

    if xferType == common.Transfer.RTRT or xferType == common.Transfer.RTBCAST:

      transfer = aim_mil.bc.RtRtTransfer(stream, dataLength, rt_xmit, rt_rcv, tic=API_BC_TIC_INT_ON_XFER_END, 
                                         gaptime=common.TRANSFER_GAP_TIME,gapmode=common.TRANSFER_GAP_MODE)
      print("AIM XFER BUFFERID = {}".format(transfer.hid))
      
    aimstream.transfers.append(transfer)
    XFER_BUFFID_XFER_OBJ_DICT[transfer.hid] = transfer
    self.map_transfer_to_id(transfer)
    return transfer

      
  def addRT(self,  devname=None, channum=None, direction=None, rtnum=None,  subaddr=None, dataLength=0, dataBuffer=None,mode=None):
    #global RT_INTERRUPT_HANDLES
    global RT_BUFFID_RT_OBJ_DICT,buffer_info
    print("In add RT, direction = {} dataBuffer = {} dataLength= {} mode= {}".format(direction,dataBuffer,dataLength,mode))
    if not devname or not channum or not direction or not rtnum or subaddr == None: #Note that subaddr may be 0, so need to check explicitly for None
      print("Not adding rt because devname {} channum {}  direction {} rtnum {} subaddr {} not specified".format(devname,channum,direction,rtnum,subaddr))
      return

    aimstream = self.streamHandles.get((devname,channum))
    if not aimstream:
      return
    stream = aimstream.stream

    if mode :
      mode = int(common.MODES[mode][1])
      
    if (common.STATUS_BITS_RT == -1 or common.STATUS_BITS_RT == rtnum) and (common.STATUS_BITS != 0) :
      statusbits = common.STATUS_BITS
    else:
      statusbits = 0
      

    if direction == common.Direction.RECEIVE:
      #print("Setting up stream receive for rt {} subaddr {}".format(rtnum,subaddr))
      r = stream.setup_receive_rt((rtnum,subaddr),mode=mode,response_time=common.RESPONSE_TIME, statusbits=statusbits)
      
    elif direction == common.Direction.TRANSMIT:
      #print("Setting up stream transmit for rt {} subaddr {}".format(rtnum,subaddr))
      r = stream.setup_transmit_rt((rtnum,subaddr),mode=mode, response_time=common.RESPONSE_TIME, statusbits=statusbits)
      if dataBuffer == None or len(dataBuffer) == 0:
        pass
        #print ("Data buffer not provided for transmitter rt. Not setting a transmit buffer. (Mode transmit will not set a buffer.)")
      else:
        r.data = dataBuffer
        buffer_info[r.bufferID] = {"counter":0, "length":len(r.data), "buffer":r.data}    
    print("AIM RT BUFFERID = {}".format(r.bufferID))
    RT_BUFFID_RT_OBJ_DICT[r.bufferID] = r
    common.RT_INTERRUPT_HANDLES[(rtnum,subaddr,mode)] = r

  def startRTs(self):
    for aimstream in [*self.streamHandles.values()]:
      aimstream.startRTs()

  def startBMs(self):
    for aimstream in [*self.streamHandles.values()]:
      aimstream.startBMs()
      
  #Start the stream associated with the BC if it exists
  def startBC(self):
    if self.BC:
      self.BC.startBC()    

  def stopBC(self):
    print("In AIM.stopBC")
    if self.BC:
      self.BC.stopBC()
      
  def stopRTs(self):
    for aimstream in [*self.streamHandles.values()]:
      aimstream.stopRTs()
      
  def stopBMs(self):
    for aimstream in [*self.streamHandles.values()]:
      aimstream.stopBMs()
      
  def dumpRTStatus(self):
    #print("Dumping status for all the streams")
    #print("\n==== AIM RT Status Summary ====")
    #Loop over all the streams to dump their status
    MESSAGES=0
    ERRORS=0
    for aimstream in [*self.streamHandles.values()]:
      #print("AIM CHANNEL: {}".format(aimstream.stream.id))
      (messages,errors)=aimstream.dumpRTStatus()
      MESSAGES += messages
      ERRORS += errors
    
    #print("\nOVERALL AIM RT TOTALS: MESSAGES={}\tERRORS={}\n\n".format(MESSAGES,ERRORS))
    
  def dumpBCStatus(self):
    #print("Dumping status for all the streams")
    #print("\n==== AIM BC Status Summary ====")
    #Loop over all the streams to dump their status
    MESSAGES=0
    ERRORS=0
    for aimstream in [*self.streamHandles.values()]:
      #print("AIM CHANNEL: {}".format(aimstream.stream.id))
      (messages,errors)=aimstream.dumpBCStatus()
      MESSAGES += messages
      ERRORS += errors
    
    #print("\nOVERALL AIM BC TOTALS: MESSAGES={}\tERRORS={}".format(MESSAGES,ERRORS))
    
  def dumpBMStatus(self):
    #print("Dumping status for all the streams")
    #print("\n==== AIM BM Status Summary ====")
    #Loop over all the streams to dump their status
    MESSAGES=0
    ERRORS=0
    for aimstream in [*self.streamHandles.values()]:
      #print("AIM CHANNEL: {}".format(aimstream.stream.id))
      (messages,errors)=aimstream.dumpBMStatus()
      MESSAGES += messages
      ERRORS += errors
    
    #print("\nOVERALL AIM BM TOTALS: MESSAGES={}\tERRORS={}".format(MESSAGES,ERRORS))
    
  def deleteInterruptHandlers(self):
    for aimstream in [*self.streamHandles.values()]:
      aimstream.deleteInterruptHandlers()
      
    print("THE AIM INTERRUPT HANDLERS ARE DELETED\n\n")
  
  def shutdown(self):
    for aimstream in [*self.streamHandles.values()]:
      aimstream.shutdown() 
    

  def dumpMonitor(self):
    #monitor_msgs = monitor.read_empty()
    bytes_read = self.monitor.read()
    print("bytes_read = {}".format(bytes_read))
    #print("Monitor queue received %d messages" % len(monitor_msgs))
    #print("\tFirst one is: " + repr(monitor_msgs[0]))
    
  def dumpTransferStatus(self, transferHandle=None):
    global XFER_OBJ_ID_DICT
    transferStats = transferHandle.read()
    #print("For AIM xfer ID {}, messages {} errors {} mStatusWord1 {:04X} mStatusWord2 {:04X} ".format(transferID,transferStats['msg_cnt'],transferStats['err_cnt'],transferStats['st1'],transferStats['st2']))
    

    if common.STATUS_BITS: #Check to see if status words contain the status bits
      if common.checkStatus(transferStats['st1']) or common.checkStatus(transferStats['st2']):
        print("\tFor AIM xfer handle {}, expected status bits received".format(transferHandle))
      else:
        print("\tFor AIM xfer handle {}, expected status bits NOT received!".format(transferHandle))
    return XFER_OBJ_ID_DICT[transferHandle], transferStats['msg_cnt'],transferStats['err_cnt'],transferStats['st1'],transferStats['st2']
    


  
  
