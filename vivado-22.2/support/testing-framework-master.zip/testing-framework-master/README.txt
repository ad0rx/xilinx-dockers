The testing framework assumes that this AIM archive has been
placed somewhere:
mil-std-1553-linux-bsp-13.5.2

Let <AIM> refer to the full path to this archive.


To run busping.py, the exported PYTHONPATH will need to include:
<AIM>/src/library/add-ons/python/
