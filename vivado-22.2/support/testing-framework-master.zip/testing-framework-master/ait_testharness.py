#!/usr/bin/env python3

# import time
import common
import bd_ait
import ait


    
      # self.interrupt.install(API_INT_RT)
class AITChannel:

  def __init__(self, c_chanHandle, isRTchan=False, isBCchan=False, chanNum=0):
    self.c_chanHandle = c_chanHandle
    self.chanNum = chanNum
    self.isRTchan = isRTchan
    self.isBCchan = isBCchan
    self.RTs = set()
    
    print("About to do a channel reset")
    bd_ait.py_m1553ChannelReset(c_chanHandle)
    bd_ait.py_m1553ChannelSetCoupling(c_chanHandle)
    
    if (common.XMIT_AMPLITUDE_CHAN == self.chanNum or common.XMIT_AMPLITUDE_CHAN == -1):
      bd_ait.py_m1553ChannelSetAmplitude(c_chanHandle, self.chanNum, common.XMIT_AMPLITUDE)
 
    if isRTchan == True:
      bd_ait.py_m1553RTInit(c_chanHandle)
      bd_ait.py_m1553InstallInterruptHandler(c_chanHandle,ait.M1553_INTERRUPT_RT,self.chanNum)
      
    if isBCchan == True:
      self.nextTransferID = 0
      self.transfers = []
      bd_ait.py_m1553BCInit(c_chanHandle)
      bd_ait.py_m1553BMInit(c_chanHandle)
      bd_ait.py_m1553ChannelSetResponseTimeout(c_chanHandle, common.RESPONSE_TIMEOUT)
      bd_ait.py_m1553InstallInterruptHandler(c_chanHandle,ait.M1553_INTERRUPT_BC,self.chanNum)
      bd_ait.py_m1553InstallInterruptHandler(c_chanHandle,ait.M1553_INTERRUPT_BM,self.chanNum)
    elif common.WANT_EXTRA_BMS:
      bd_ait.py_m1553BMInit(c_chanHandle)
      bd_ait.py_m1553InstallInterruptHandler(c_chanHandle,ait.M1553_INTERRUPT_BM,self.chanNum)            
            

    print("Errors found so far: {}".format(bd_ait.ERRORS))


  def addRT(self,direction=None, rtnum=None,  subaddr=None, dataLength=0, dataBuffer=None,mode=None):
    print("In addRT for chanNum = {} : rt {} subaddr {} mode={} databuffer={}".format(self.chanNum,rtnum, subaddr,mode,dataBuffer))
    if not rtnum:
      return 
    else:
      self.RTs.add(rtnum)
    bd_ait.py_addRT(self.c_chanHandle, direction=direction, rtnum=rtnum, subaddr=subaddr, dataLength=dataLength, dataBuffer=dataBuffer, mode=mode)

    #common.Direction.RECEIVE
    
  def addBCRTTransfer(self, rtnum, subaddr, dataLength, dataBuffer):
    print("\n======\nIn AIT addBCRTTransfer for rt {} subaddr {}".format(rtnum, subaddr))
    c_transfer_result = bd_ait.py_createTransfer(self.c_chanHandle, self.nextTransferID, ait.M1553_BC_TO_RT, dataBuffer, dataLength, rcvrtnum=rtnum, rcvsubaddr=subaddr)
    if c_transfer_result > -1 :
      self.transfers.append(c_transfer_result)
      self.nextTransferID += 1

    return c_transfer_result
  
  def addRTBCTransfer(self, rtnum, subaddr, dataLength, dataBuffer=None):
    print("\n======\nIn AIT addRTBCTransfer for rt {} subaddr {}".format(rtnum, subaddr))
    c_transfer_result = bd_ait.py_createTransfer(self.c_chanHandle, self.nextTransferID, ait.M1553_RT_TO_BC, dataBuffer, dataLength, xmitrtnum=rtnum, xmitsubaddr=subaddr)
    if c_transfer_result > -1:
      self.transfers.append(c_transfer_result)
      print("In In AIT addRTBCTransfer, incrementing the transfer ID, {} before increment".format(self.nextTransferID))
      self.nextTransferID += 1

    return c_transfer_result    
  
  def addRtRtTransfer(self, rt_xmit, rt_rcv, dataLength, dataBuffer=None):
    print("\n======\nIn addRtRtTransfer for rt_xmit {}/{} rt_rcv {}/{}".format(rt_xmit[0],
                                    rt_xmit[1],
                                    rt_rcv[0],
                                    rt_rcv[1]))

    c_transfer_result = bd_ait.py_createTransfer(self.c_chanHandle, self.nextTransferID, ait.M1553_RT_TO_RT, dataBuffer, dataLength, xmitrtnum=rt_xmit[0], xmitsubaddr=rt_xmit[1],
                                                 rcvrtnum=rt_rcv[0], rcvsubaddr=rt_rcv[1])
    if c_transfer_result > -1:
      self.transfers.append(c_transfer_result)
      self.nextTransferID += 1

    return c_transfer_result    

  def setup_framing(self):
    bd_ait.setUpFraming(self.c_chanHandle, self.nextTransferID)    


  def startRTs(self):
    #print("starting ait chan with RTs")
    if self.isRTchan:
      bd_ait.py_m1553RTStart(self.c_chanHandle)

    
  def startBC(self):
    #print("starting ait chan with BC")
    #print("Setting up framing")
    if self.isBCchan:   
      self.setup_framing()
      #print("@#$%@#$% In startBC, common.MINOR_FRAME_TIME = {}".format(common.MINOR_FRAME_TIME))
      bd_ait.py_m1553BCStart(self.c_chanHandle)
    
  def startBMs(self):
    print("In AIT startBMs, chanNum = {} isBCchan = {} isRTchan = {} WANT_EXTRA_BMS = {} ".format(self.chanNum, self.isBCchan, self.isRTchan, common.WANT_EXTRA_BMS))
    if self.isBCchan or (self.isRTchan and common.WANT_EXTRA_BMS):
      print("In AIT startBMs, chanNum = {} STARTING BM".format(self.chanNum))
      bd_ait.py_m1553BMStart(self.c_chanHandle)

  def stopBC(self):
    if self.isBCchan: 
      bd_ait.py_m1553BCStop(self.c_chanHandle)

  def stopRTs(self):
    if self.isRTchan:
      bd_ait.py_m1553RTStop(self.c_chanHandle)
      
  def stopBMs(self):
    print("In AIT stopBMs, chanNum = {} isBCchan = {} isRTchan = {} WANT_EXTRA_BMS = {} ".format(self.chanNum, self.isBCchan, self.isRTchan, common.WANT_EXTRA_BMS))
    if self.isBCchan or (self.isRTchan and common.WANT_EXTRA_BMS):
      print("In AIT stopBMs, chanNum = {} STOPPING BM".format(self.chanNum))
      bd_ait.update_bm_dump_by_chan(self.chanNum)
      bd_ait.py_m1553BMStop(self.c_chanHandle)    
  
  def dumpBCStatus(self):
    MESSAGES=0
    ERRORS=0
    if self.isBCchan:
      MESSAGES,ERRORS = bd_ait.py_m1553BCGetStatus(self.c_chanHandle)
      common.STATUSES['BC'].append({'devtype':'AIT','chan':self.chanNum,'messages':MESSAGES,'errors':ERRORS})
      #print("AIT CHANNEL BC TOTALS: MESSAGES={}\tERRORS={}".format(MESSAGES,ERRORS))
    return MESSAGES,ERRORS

  def dumpBMStatus(self):
    MESSAGES=0
    ERRORS=0
    if self.isBCchan or common.WANT_EXTRA_BMS:
      MESSAGES,ERRORS = bd_ait.py_m1553BMGetStatus(self.c_chanHandle)
      common.STATUSES['BM'].append({'devtype':'AIT','chan':self.chanNum,'messages':MESSAGES,'errors':ERRORS})
      #print("AIT CHANNEL BM TOTALS: MESSAGES={}\tERRORS={}".format(MESSAGES,ERRORS))
    return MESSAGES,ERRORS

  def dumpRTStatus(self):
    MESSAGES=0
    ERRORS=0
    if self.isRTchan:
      #Get the RT statuses
      #bd_ait.py_get_individual_rt_statuses(self.c_chanHandle,list(self.RTs))
      (MESSAGES,ERRORS)=bd_ait.py_get_global_rt_status(self.c_chanHandle)
      common.STATUSES['RT'].append({'devtype':'AIT','chan':self.chanNum,'messages':MESSAGES,'errors':ERRORS})
      #print("AIT CHANNEL RT TOTALS: MESSAGES={}\tERRORS={}".format(MESSAGES,ERRORS))
    return (MESSAGES,ERRORS)

  def deleteInterruptHandlers(self):
    if self.isRTchan == True:
      bd_ait.py_m1553DeleteInterruptHandler(self.c_chanHandle,ait.M1553_INTERRUPT_RT,self.chanNum)
      
    if self.isBCchan == True:
      bd_ait.py_m1553DeleteInterruptHandler(self.c_chanHandle,ait.M1553_INTERRUPT_BC,self.chanNum)
      bd_ait.py_m1553DeleteInterruptHandler(self.c_chanHandle,ait.M1553_INTERRUPT_BM,self.chanNum)
    elif common.WANT_EXTRA_BMS:
      bd_ait.py_m1553DeleteInterruptHandler(self.c_chanHandle,ait.M1553_INTERRUPT_BM,self.chanNum)
  
  def shutdown(self):
    print("Shutting down AIT channel {}".format(self.chanNum))
    
    bd_ait.py_m1553Close(self.c_chanHandle)          

class AIT:

  def __init__(self):

    self.channelHandles = {}  # Maps (devname,channum) tuples to AIT channel objects
    self.monitor = None
    self.BC = None
    self.boardHandles = []
    
    self.shutdown()
    numBoards = bd_ait.py_m1553Init()
    print("numBoards is {}".format(numBoards))
    
    devicesInUse = [*common.DEVICES.keys()]  # This gives the device names of interest
    
    for i in range(0, numBoards):
      print("Opening board {}".format(i))
      # device.init(common.RESPONSE_TIMEOUT)
    
      c_boardHandle = bd_ait.py_m1553BoardOpen(i)
      self.boardHandles.append(c_boardHandle)
      print("board handle = {}".format(c_boardHandle.value))
      c_boardInfo = bd_ait.py_m1553GetBoardInfo(c_boardHandle)
      
      boardname = str(c_boardInfo.mSerialNumber)  # Use the serial number as the board name
      print("Device board name is {}".format(boardname))
      
      if boardname not in devicesInUse:
          continue

      rtchans = common.DEVICES[boardname].rtchans
      bcchan = common.DEVICES[boardname].bcchan
      print("rtchans for {} are {}".format(boardname, rtchans))
      print("bcchan for {} is {}".format(boardname, bcchan))

      for c in range(0, c_boardInfo.mChannelCount):
        normalizedChanNumber = c + 1
        if not (normalizedChanNumber in rtchans) and not (bcchan == normalizedChanNumber):
            continue
        print("Finding handle for channel {}".format(normalizedChanNumber))
        c_chanHandle = bd_ait.py_m1553ChannelOpen(c_boardHandle, c)
        print("{}: chan handle = {}".format(normalizedChanNumber, c_chanHandle.value))
          
        isRTchan = False
        isBCchan = False
        if (normalizedChanNumber in rtchans):
          # print("rtchans contains stream.id {}".format(stream.id))
          isRTchan = True
        if (bcchan == normalizedChanNumber):
          # print("bcchan is stream.id {}".format(stream.id))
          isBCchan = True
            
        print("Adding AIT channel for ({},{}) to channelHandles".format(boardname, normalizedChanNumber))
        aitchan = AITChannel(c_chanHandle=c_chanHandle, isRTchan=isRTchan, isBCchan=isBCchan, chanNum=normalizedChanNumber)
        if isBCchan:
          self.BC = aitchan  # Hold on to the handle to the stream
            
        self.channelHandles[(boardname, normalizedChanNumber)] = aitchan
        # print ("self.channelHandles is now {}".format(self.channelHandles))
            
  def print_ait_device(self, device=None):
    if not device:
      return

    # print("AIM device: id = {} boardname = {} serial = {} host = {} streams = {} versions = {}".format(device.id, device.boardname, device.serial, device.host, device.streams, device.versions))

  # There are 4 flavors of BCRT transfer -- BCRT, BCBCAST, MODE (not transmit), and MODE_BCAST  
  def addBCRTTransfer(self, devname=None, channum=None, xferType=None, rtnum=None, subaddr=None, dataLength=None, dataBuffer=None):
    print("In AIT BCRTTransfer")
    if not devname or not channum or not xferType or dataLength == None  or not rtnum or subaddr == None:
      print("Not adding transfer because devname {} channum {} xferType {} dataLength {} rtnums {} subaddr {} not specified".format(devname, channum, xferType, dataLength, rtnum, subaddr))
      return None
    
    if xferType == common.Transfer.BCRT or xferType == common.Transfer.BCBCAST:
      if dataBuffer == None:
        print ("Not adding transfer because: Data buffer not provided for BCRT tranfer.")
        return None
    elif xferType == common.Transfer.MODE_BCAST or xferType == common.Transfer.MODE:
      if dataBuffer and len(dataBuffer) != 1:
        print("Not adding transfer because: Data buffer provided for MODE or MODE_BCAST, but length != 1")
        return None
    else:
      return None             
    
    #print("devname = {}  channum = {}".format(devname, channum))
    aitchan = self.channelHandles.get((devname, channum))
    if not aitchan:
      return None
    c_transfer = aitchan.addBCRTTransfer(rtnum, subaddr, dataLength, dataBuffer)
    return c_transfer

  # There are two flavors of RTBC Transfer -- RTBC and MODE (transmit) 
  def addRTBCTransfer(self, devname=None, channum=None, xferType=None, rtnum=None, dataLength=None, subaddr=None, dataBuffer=None):
    print("In AIT RTBCTransfer")
    if not devname or not channum or not xferType or dataLength==None or not rtnum or subaddr == None:
      print("Not adding transfer because devname {} channum {} xferType {} dataLength {} rtnum {} subaddr {} not specified".format(devname, channum, xferType, dataLength, rtnum, subaddr))
      return None

    if xferType == common.Transfer.RTBC or xferType == common.Transfer.MODE:
      aitchan = self.channelHandles.get((devname, channum))
      if not aitchan:
        return None
      c_transfer = aitchan.addRTBCTransfer(rtnum, subaddr, dataLength)
      return c_transfer
    else:
      return None

  # There are two flavors of RTRT Transfer -- RTRT and RTBCAST
  # rt_xmit and rt_rcv are (rtnum,subaddr) tuples.
  def addRTRTTransfer(self, devname=None, channum=None, xferType=None, rt_xmit=None, rt_rcv=None, dataLength=None, dataBuffer=None):

    if not devname or not channum or not xferType or not dataLength or not rt_xmit or not rt_rcv:
      print("Not adding transfer because devname {} channum {} xferType {} dataLength {} rt_xmit {} or rt_rcv {}not specified".format(devname, channum, xferType, dataLength, rt_xmit, rt_rcv))
      return None

    if xferType == common.Transfer.RTRT or xferType == common.Transfer.RTBCAST:
      aitchan = self.channelHandles.get((devname, channum))
      if not aitchan:
        return None
      c_transfer = aitchan.addRtRtTransfer(rt_xmit, rt_rcv, dataLength)
      return c_transfer
    else:
      return None

      
  def addRT(self,  devname=None, channum=None, direction=None, rtnum=None,  subaddr=None, dataLength=0, dataBuffer=None,mode=None):
    #global RT_INTERRUPT_HANDLES
    
    #print("In add RT, direction = {} dataBuffer = {}".format(direction,dataBuffer))
    if not devname or not channum or not direction or not rtnum or subaddr == None: #Note that subaddr may be 0, so need to check explicitly for None
      print("Not adding rt because devname {} channum {}  direction {} rtnum {} subaddr {} not specified".format(devname,channum,direction,rtnum,subaddr))
      return
    
    aitchan = self.channelHandles.get((devname, channum))
    if not aitchan:
      return
    aitchan.addRT(direction, rtnum,  subaddr, dataLength, dataBuffer, mode)
    return

 

    #if mode :
      #mode = int(common.MODES[mode][1])
    '''
    if direction == common.Direction.RECEIVE:
      #print("Setting up stream receive for rt {} subaddr {}".format(rtnum,subaddr))
      r = stream.setup_receive_rt((rtnum,subaddr),mode=mode, response_time=common.RESPONSE_TIME)
      
    elif direction == common.Direction.TRANSMIT:
      #print("Setting up stream transmit for rt {} subaddr {}".format(rtnum,subaddr))
      r = stream.setup_transmit_rt((rtnum,subaddr),mode=mode, response_time=common.RESPONSE_TIME)
      if dataBuffer == None or len(dataBuffer) == 0:
        pass
        #print ("Data buffer not provided for transmitter rt. Not setting a transmit buffer. (Mode transmit will not set a buffer.)")
      else:
        r.data = dataBuffer
    '''
    #common.RT_INTERRUPT_HANDLES[(rtnum,subaddr,mode)] = r
  

  def startRTs(self):
    # Start the chans that have RTs
    for aitchan in [*self.channelHandles.values()]:
      aitchan.startRTs()

  def startBMs(self):
    # Start the chans that have RTs
    for aitchan in [*self.channelHandles.values()]:
      aitchan.startBMs()

  # Then start the chan associated with the BC if it exists
  def startBC(self):
    if self.BC:
      self.BC.startBC()
      
  def alterBC(self, loopnum):
    if self.BC:
      newBuf = [loopnum]*3
      bd_ait.py_m1553BufSetBuffer(self.BC.c_chanHandle, 1, len(newBuf), newBuf)

  def stopBC(self):
    # First stop the chan associated with the BC if it exists
    if self.BC:
      self.BC.stopBC()
      
  def stopRTs(self):
    # Then stop the RTs on chans that have RTs
    for aitchan in [*self.channelHandles.values()]:
      aitchan.stopRTs()

  def stopBMs(self):
    # Then stop the BMs on chans 
    for aitchan in [*self.channelHandles.values()]:
      aitchan.stopBMs()
        
  def dumpRTStatus(self):
    #print("Dumping status for all the streams")
    #print("\n==== AIT RT Status Summary ====")
    #Loop over all the streams to dump their status
    MESSAGES=0
    ERRORS=0
    for aitchan in [*self.channelHandles.values()]:
      #print("AIT CHANNEL: {}".format(aitchan.chanNum))
      (messages,errors)=aitchan.dumpRTStatus()
      MESSAGES += messages
      ERRORS += errors
    
    #print("\nOVERALL AIT RT TOTALS: MESSAGES={}\tERRORS={}\n\n".format(MESSAGES,ERRORS))

  def dumpBCStatus(self):
    #print("Dumping status for all the streams")
    #print("\n==== AIT BC Status Summary ====")
    #Loop over all the streams to dump their status
    MESSAGES=0
    ERRORS=0
    for aitchan in [*self.channelHandles.values()]:
      #print("AIT CHANNEL: {}".format(aitchan.chanNum))
      (messages,errors)=aitchan.dumpBCStatus()
      MESSAGES += messages
      ERRORS += errors
    
    #print("\nOVERALL AIT BC TOTALS: MESSAGES={}\tERRORS={}".format(MESSAGES,ERRORS))
    
  def dumpBMStatus(self):
    #print("Dumping status for all the streams")
    #print("\n==== AIT BM Status Summary ====")
    #Loop over all the streams to dump their status
    MESSAGES=0
    ERRORS=0
    for aitchan in [*self.channelHandles.values()]:
      #print("AIT CHANNEL: {}".format(aitchan.chanNum))
      (messages,errors)=aitchan.dumpBMStatus()
      MESSAGES += messages
      ERRORS += errors
    
    #print("\nOVERALL AIT BM TOTALS: MESSAGES={}\tERRORS={}".format(MESSAGES,ERRORS))
    

  def deleteInterruptHandlers(self):
    for aitchan in [*self.channelHandles.values()]:
      aitchan.deleteInterruptHandlers()
      
    print("THE AIT INTERRUPT HANDLERS ARE DELETED\n\n")
  
  def shutdown(self):
    '''
    for aitchan in [*self.channelHandles.values()]:
      aitchan.shutdown()    

    for boardHandle in self.boardHandles:   #This was hanging
      print("Shutting down AIT board")
      bd_ait.py_m1553Close(boardHandle)
    '''      
    bd_ait.py_m1553Uninitialize()
      
  '''    

  def dumpMonitor(self):
    #monitor_msgs = monitor.read_empty()
    bytes_read = self.monitor.read()
    print("bytes_read = {}".format(bytes_read))
    #print("Monitor queue received %d messages" % len(monitor_msgs))
    #print("\tFirst one is: " + repr(monitor_msgs[0]))
  '''  
  def dumpTransferStatus(self, transferHandle=None):
    return bd_ait.py_dumpTransferStatus(self.BC.c_chanHandle, transferHandle)
    
    
    
    
    
    
    
