#!/usr/bin/env python3


__author__ = 'markus'


import aim_mil.device
from aim_mil.mil_bindings import *
import time


if __name__ == '__main__':

    host = aim_mil.device.Host('local')
    print("host = {} host.devices = {}".format(host,host.devices))

    for device in host.devices:
        device.init()

        print("Executing sample program for module %d..." % device.id)
        print("Device board name is {}".format(device.boardname))
        print("Device versions are {}".format(device.versions))

        stream1 = None
        stream2 = None

        for stream in device.streams:
            stream.open()
            #print("Selftest on stream %d: " % stream.id + repr(stream.selftest()))
            stream.set_coupling(API_CAL_CPL_TRANSFORM)
            
            
            if stream.id == 1:
                stream1 = stream
                stream.init_bc()
                monitor = stream.start_monitoring()
                transfer1 = aim_mil.bc.BcRtTransfer(stream, 32, (1, 1))
                transfer2 = aim_mil.bc.RtBcTransfer(stream, 4, (29, 28))
            

                transfer1.data = [1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2,3,4,5,1,2]


                stream.add_cyclic_transfers([transfer1, transfer2])
                #stream.add_cyclic_transfers([transfer2])
                stream.setup_default_framing()

            if stream.id == 2:
                stream2 = stream
                stream.init_rts()
                rt1 = stream.setup_receive_rt((1, 1))
                rt2 = stream.setup_transmit_rt((29, 28))
                rt2.data = [5,6,7,8,9,5,6,7,8,9,5,6,7,8,9,5,6,7,8,9,5,6,7,8,9,5,6,7,8,9,5,6]



        print("Starting run")
        stream2.start_rts()
        stream1.start_bc(10)

        bc_status = {'status': API_BC_STATUS_BUSY}
        while bc_status['status'] != API_BC_STATUS_HALTED:
            bc_status = stream1.bc_status
            time.sleep(1)

        print("Stopping run")

        stream1.stop_bc()
        stream2.stop_rts()
        monitor.stop()

        print("BC Status: Messages: %d Errors: %d" % (bc_status['messages'], bc_status['errors']))

        print("\tBC-RT transfer data: " + repr(transfer1.data))
        print("\tRT-BC transfer data: " + repr(transfer2.data))

        monitor_msgs = monitor.read_empty()

        print("Monitor queue received %d messages" % len(monitor_msgs))
        count = 3 if len(monitor_msgs) >= 3 else len(monitor_msgs)
        for i in range(count):
            print("\tMsg {} is: ".format(i) + repr(monitor_msgs[i]))
