#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -

"""
Assemble wavegen instructions into a laid out program
"""

import shlex
import subprocess
import sys

if __name__=='__main__':
    from ms1553 import (milstd_1553, milstd_1553_mode)
    from wavegen_code import wavegen_code
else:
    from .ms1553 import (milstd_1553, milstd_1553_mode)
    from .wavegen_code import wavegen_code



class wavegen_link:
    """Lay out wavegen code into memory, target gotos, etc"""
    def __init__(self, defaultlines=0xff, stdprefix=True, stdsuffix=True):
        """stdprefix will (typically) reset the wavegen, enable output
        on the defaultlines.  stdsuffix will start the program running."""
        self.groups = dict()
        self.before = dict()
        self.after = dict()
        self.start = None
        self.base = 0
        self.addresses = dict()
        self.cmdlist = []
        self.defaultlines = defaultlines
        self.stdprefix = stdprefix
        self.stdsuffix = stdsuffix
        self.linked = None


    def addgroup(self, name, start=False, follows=None, **kwargs):
        """Add a named group of microcode (typically train with preconditions and "next" step)
        may specify that this group immediate follows (fallthrough) another group, plus
        whether this is the first group in the address page.

        Note kwargs are passed through to wg_group()"""

        self.groups[name] = wg_group(name, **kwargs)

        if start:
            self.start = name

        if follows:
            self.after[follows] = name
            self.before[name] = follows

        self.linked = None

        return self.groups[name]


    def rmgroup(self, name):
        """Remove a named group"""
        self.linked = None
        self.groups.pop(name)
        if name in self.before:
            self.before.pop(name)
        for i in self.after:
            if self.after[i] == name:
                self.after.pop(i)


    def relink(self, *args, **kwargs):
        """Force a link"""
        self.linked = None
        return self.link(*args, **kwargs)

    def retrain(self):
        """Support modified trains"""
        for grp in self.groups.values():
            grp.retrain()
        return(self)

    def link(self, addr=0, stdprefix=None, stdsuffix=None, defaultlines=None, resetonly=None):
        """Output an array of integers representing the values to place in
        memory, starting at specified address (0 if not specified)

        defaultlines/stdprefix/suffix may (persistently) override the __init__
        options of the same name.  stdprefix will reset the program map (if addr==0)
        and enable the "defaultlines" for output.  stdsuffix will start the program running.
        """

        if self.linked:
            return self.linked

        if stdprefix is not None:
            self.stdprefix = stdprefix

        if stdsuffix is not None:
            self.stdsuffix = stdsuffix

        if defaultlines is not None:
            self.defaultlines = defaultlines

        self.cmdlist = None
        self.base = addr

        if self.stdprefix:
            cur = "__stdprefix"
            if self.base == 0:
                self.addgroup(cur, outputlines=self.defaultlines, preidle=14)
            else:
                self.addgroup(cur, preidle=14)

        work = dict(self.groups)

        def findnext(cur):
            """Find the next group to output"""
            if cur and cur in self.after:
                return self.after[cur]
            for k in work:
                if k not in self.before:
                    return k
            return None

        sizes = {}

        def dowork(cur):
            """Figure how large group commands are, assign addresses"""
            nonlocal sizes, work, self, addr
            g = work.pop(cur)
            self.addresses[cur] = addr
            addr += g.size
            sizes[cur] = g.size

        if self.stdprefix:
            dowork("__stdprefix")

        if self.start:
            cur = self.start
        else:
            cur = findnext(None)

        while cur:
            dowork(cur)
            cur = findnext(cur)

        if self.stdsuffix:
            cur="__stdsuffix"
            work[cur] = self.addgroup(cur, cmds=[wavegen_code.halt()])
            dowork(cur)

        if work:
            raise Exception("Could not link all keys: %s"%str(work.keys()))
        if addr == 0:
            raise Exception("Could not link any keys")
        if addr > 65535:
            raise Exception("Program too big for storage")

        halt = wavegen_code.halt()
        output = [ halt for i in range(addr-self.base) ]

        for k in self.addresses:
            caddr = self.addresses[k] - self.base
            output[caddr:caddr+sizes[k]] = self.groups[k].generate(caddr, self.addresses)

        if self.stdprefix:
            self.rmgroup("__stdprefix")

        if self.stdsuffix:
            self.rmgroup("__stdsuffix")

        self.linked = output

        return output


    def gotomap(self, **kwargs):
        """Print the linktable as goto statements, for manual code execution"""

        if ("resetonly" in kwargs and kwargs['resetonly']):
            return

        if not self.linked:
            self.link(addr=addr)
        for n in sorted(self.addresses):
            print(""": %s; poke 0x83c00010 0x%x"""%(shlex.quote(n), self.addresses[n]))


    def gencmdlist(self, **kwargs):
        """Return a list of a list of shell commands that will configure and (typically) start a program running
        See link() for possible kwargs, plus 'resetonly' which means only generate a reset command."""

        resetonly = kwargs['resetonly'] if ("resetonly" in kwargs) else False

        cmdlist = [ ]

        wordmap = self.link(**kwargs)

        if (self.stdprefix and self.base == 0) or resetonly:
            cmdlist.append([ "poke", "0x83c0000c", "0xff" ])			# Reset
            if resetonly:
                return(cmdlist)

        cmdlist.append([ "poke", "0x%x"%(0x83c10000 + self.base), "-M" ] + list(map(hex, wordmap)))

        if self.stdsuffix:
            cmdlist.append([ "poke", "0x83c00008", "1" ])			# Start
        self.cmdlist = cmdlist
        return(cmdlist)


    def shellcmd(self, **kwargs):
        """Return a shell string that will configure and (typically) start a program running.
        See link() for possible kwargs"""

        if not self.linked or not self.cmdlist:
            cmdlist = self.gencmdlist(**kwargs)
        else:
            cmdlist = self.cmdlist
        return("; ".join([" ".join(cl) for cl in cmdlist]))


    def debugpoke(self, fileout=sys.stdout, **kwargs):
        """Print out a shell string that will configure and (typically) start a program running.
        See link() for possible kwargs"""

        print(self.shellcmd(**kwargs), file=fileout)


    def execute(self, host, **kwargs):
        """Execute the necessary shellcmd on defined host ("" means direct execution on local system, otherwise ssh)"""

        if host == "":
            for cmd in self.gencmdlist(**kwargs):
                subprocess.check_call(cmd)
        else:
            sp = subprocess.Popen(["ssh", "-oStrictHostKeyChecking=no", "-oConnectTimeout=2", host, "/bin/sh", "-e"], stdin=subprocess.PIPE)
            sp.communicate(input=self.shellcmd(**kwargs).encode('utf-8'))
            if sp.returncode != 0:
                raise subprocess.CalledProcessError(sp.returncode, "ssh %s poke"%host)



class wg_group:
    """Define a named unit of microcode"""

    def __init__(self, name, train=[], cmds=[], preidle=None, predelay=None, postgoto=None, postdelay=None,
                 nonStandardIdleTimeout=None, nonStandardIdleTimeoutGotoTarget=None,
                 nonStandardIdleTimeoutLines=0xfff, standardBCResponseLines=0xfff, outputlines=None,
                 standardBCResponseHandling=False, BCResponseTimeout=12.0, BCPreResponseIdle=2.0, BCPostResponseIdle=2.0,
                 BCRTRT_mode=False, BC_BcastVariant=False):
        """Group name plus train of 1553 messages, other microcode, time for
        bus to be idle prior to xmission, other delay before xmission,
        optional target to goto after this group is done under normal circumstances.

        if outputlines is non-null, change the output port set to the
        listed lines.

        There is a group of arguments to assist in standard BC
        processing.  Specifically, standard BCs commands something and
        then the RT (after a minimum wait interval) responds within a
        specific timeout and the BC has to wait at least a minimum
        wait interval before it can start transmitting against.
        Except, if the RT should happen to not respond, after the
        timeout has passed the BC should continue on to the next
        transmission.  Thus, the we need two different timing pattern
        behaviors based on whether or not the RT responds.  Enable
        standardBCResponseHandling if you want this behavior.  The
        defaults of BCResponseTimeout indicate the maximum delay prior
        to the timeout, the BCPostResponseIdle indicates the delay
        after the RT response if it does arrive.  Penultimately, RTRT mode
        indicates that the BC should expect an RTRT pattern with two
        statuses and two groups of timeouts.  Finally, BC_BcastVariant tells
        the system that this is a bcast transfer of some sort, so no
        final status code will be expected. Postgoto OR the group
        that "follows" this one will be executed next whether or not
        the timeout hits.

        For people wanting more fine-grained control, you may specify
        "nonStandardIdleTimeout" and if that hits, execution is
        transferred to "nonStandardIdleTimeoutGotoTarget".

        """

        self.name = name
        self.train = train
        self.traincmds = []
        self.precmds = []
        self.postcmds = []
        self.postsymbols = []
        self.cmds = cmds
        self.addr = None

        if self.train:
            self.traincmds = [item for x in self.train.train for item in x.cmd_mcode]

        if preidle:
            self.precmds.append(wavegen_code.wait_idlecnt(preidle))

        if predelay:
            self.precmds.append(wavegen_code.wait_us(predelay))

        if postdelay:
            self.postcmds.append(wavegen_code.wait_us(postdelay))

        if outputlines:
            self.precmds.append(wavegen_code.outmask(outputlines))

        if standardBCResponseHandling:
            if BCRTRT_mode:
                if BCPreResponseIdle:
                    self.postcmds.append(wavegen_code.wait_us(BCPreResponseIdle))
                if (BCResponseTimeout-BCPreResponseIdle) > 0:
                    self.postcmds.append(wavegen_code.wait_timed_activity(BCResponseTimeout-BCPreResponseIdle, standardBCResponseLines))
                self.postcmds.append(wavegen_code.goto(2, relative=True))		  # Condition: Activity seen
                self.postcmds.append(None)						  # Condition: Timeout occurred
                gotodoneloc = len(self.postcmds)
                if BCPreResponseIdle:
                    self.postcmds.append(wavegen_code.wait_idlecnt(BCPreResponseIdle))  # State: At end of RT1's xmission + 2ųs
                if not BC_BcastVariant:
                    if BCResponseTimeout > BCPreResponseIdle:
                        d = BCResponseTimeout - BCPreResponseIdle
                    else:
                        d = BCResponseTimeout
                    self.postcmds.append(wavegen_code.wait_timed_activity(d, standardBCResponseLines))
                    self.postcmds.append(wavegen_code.wait_us(0)) # Eat the detected-signal case
                    if BCPostResponseIdle:
                        self.postcmds.append(wavegen_code.wait_idlecnt(BCPostResponseIdle))  # State: At end of RT2's xmission + 2ųs
                    # Command after this will be "state: second RT timeout occurred OR fallthough", in any case the next normal xmission
                next_loc = len(self.postcmds) - gotodoneloc + 1
                self.postcmds[gotodoneloc] = wavegen_code.goto(next_loc, relative=True)  # Fill in actual goto command now we know the target
            else:
                if not BC_BcastVariant:
                    if BCPreResponseIdle:
                        self.postcmds.append(wavegen_code.wait_us(BCPreResponseIdle))
                    self.postcmds.append(wavegen_code.wait_timed_activity(BCResponseTimeout-BCPreResponseIdle, standardBCResponseLines))
                    self.postcmds.append(wavegen_code.wait_us(0)) # Eat the detected-signal case
                    if BCResponseTimeout > BCPreResponseIdle:
                        self.postcmds.append(wavegen_code.wait_idlecnt(BCPostResponseIdle))  # State: At end of RT1's xmission + "2ųs"
                # Command after this will be "state: first RT timeout occurred OR fallthough", in any case the next normal xmission

        if (nonStandardIdleTimeout and nonStandardIdleTimeoutGotoTarget):
            self.postcmds.append(wavegen_code.wait_timed_activity(nonStandardIdleTimeout, nonStandardIdleTimeoutLines))
            self.postcmds.append(wavegen_code.goto(2, relative=True))
            self.postcmds.append(None)
            self.postsymbols.append(nonStandardIdleTimeoutGotoTarget)

        if postgoto:
            self.postcmds.append(None)
            self.postsymbols.append(postgoto)

        count = 0
        count += len(self.precmds)
        count += len(self.traincmds)
        count += len(self.cmds)
        count += len(self.postcmds)
        self.size = count

    def retrain(self):
        if self.train:
            self.traincmds = [item for x in self.train.train for item in x.cmd_mcode]

    def generate(self, base, symbols):

        """Transform group into microcode with goto resolved"""

        output = []
        output += self.precmds
        output += self.traincmds
        output += self.cmds
        if self.postcmds:
            j = 0
            for i in range(len(self.postcmds)):
                cmd = self.postcmds[i]
                if cmd is None:
                    cmd = wavegen_code.goto(symbols[self.postsymbols[j]])
                    j += 1
                output.append(cmd)
        return output



if __name__=='__main__':

    from ms1553_train import *
    p = wavegen_link()
    p.addgroup("initial", train=train_1553_BCRT_1(1, 1, [ 0, 1, 2 ]), predelay=3)
    p.addgroup("first", train=train_1553_BCRT_2(1), predelay=6, follows="initial", postgoto="initial")

    p = wavegen_link()
    p.addgroup("initial", predelay=160)
    p.addgroup("sync1", train=train_1553().add(milstd_1553_mode(1, codetxt="Transmit Status")), preidle=10, follows="initial")
    p.addgroup("sync2", train=train_1553().add(milstd_1553_mode(2, codetxt="Transmit Status")), preidle=20, follows="sync1")
    p.addgroup("sync3", train=train_1553().add(milstd_1553_mode(3, codetxt="Transmit Status")), preidle=30, follows="sync2", postgoto="initial")
    p.addgroup("1R1/32", train=train_1553_BCRT_1(1, 1, [ 0 for j in range(32) ]), preidle=3, postgoto="initial")
    p.addgroup("StatOK1", train=train_1553_BCRT_2(1), preidle=3, postgoto="initial")
    p.addgroup("2R2/31", train=train_1553_BCRT_1(2, 2, [ 0xaaaa for j in range(31) ]), preidle=3, postgoto="initial")
    p.addgroup("StatOK2", train=train_1553_BCRT_2(1), preidle=3, postgoto="initial")
    p.addgroup("3R3/30", train=train_1553_BCRT_1(3, 3, [ 0x5555 for j in range(30) ]), preidle=3, postgoto="initial")
    p.addgroup("StatOK3", train=train_1553_BCRT_2(1), preidle=3, postgoto="initial")
    p.addgroup("1R1/32+Stat", train=train_1553_BCRT_1(1, 1, [ 0xffff for j in range(32) ]), preidle=3, postgoto="StatOK1")
    memory = p.link()
    p.debugpoke()
    p.gotomap()

