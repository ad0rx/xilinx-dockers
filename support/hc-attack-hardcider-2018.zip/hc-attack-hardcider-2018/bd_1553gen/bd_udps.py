#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -

import socket
import struct

class busDefenderUdpServer:
    """Class to receive Bus Defender data over a UDP socket, and perform basic parsing and aggregation of such data."""

    # xfer_type aka dtype aka element[0]
    XT_LOG = 2
    XT_BUS_DATA = 3
    XT_CMD = 4
    XT_TEST = 5
    XT_ERR = 6
    # datatypes_1553_e aka wd_worddtype
    HT_UNKNOWN = 0
    HT_CMD = 1
    HT_STATUS = 2
    HT_DATA = 3
    # messagetypes_1553_e aka wd_messagetype
    MT_UNKNOWABLE = 0
    MT_MESSAGEGAP = 1
    MT_BCRT = 2
    MT_RTBC = 3
    MT_RTRT = 4
    MT_MODE = 5
    MT_MODE_TRANS = 6
    MT_MODE_RECV = 7
    MT_BC_BCAST = 8
    MT_RT_BCAST = 9
    MT_MODE_BCAST = 10
    MT_MODE_RECV_BCAST = 11
    MT_ANY = 12
    MT_C2A = { MT_UNKNOWABLE: "unknowable",MT_MESSAGEGAP: "messagegap",MT_BCRT: "bcrt",MT_RTBC: "rtbc",MT_RTRT: "rtrt",MT_MODE: "mode", MT_MODE_TRANS: "mode_trans", MT_MODE_RECV: "mode_recv", MT_BC_BCAST: "bc_bcast", MT_RT_BCAST: "rt_bcast", MT_MODE_BCAST: "mode_bcast", MT_MODE_RECV_BCAST: "mode_recv_bcast", MT_ANY: "any", }
    # hc_gap_class aka wd_gc
    GC_INITIAL = 0
    GC_BACKINBACK = 1
    GC_BACK2BACK = 2
    GC_SUBRESPONSE = 3
    GC_RESPONSE = 4
    GC_LARGE = 5
    GC_ANY = 6



    def __init__(self, host="0.0.0.0", port=5002, want_except=False):
        """Create the UDP server socket to receive Bus Defender events, bound
        to host and port.  If you don't want a UDP server, set port to
        None/-1.  want_except allows you to set the default behavior
        when processing (DataParser) network data--whether you want
        exception or not.  Default not."""

        if int(port) > 0 and port < 65536:
            self.fd = socket.socket(family=socket.AF_INET, type=socket.SOCK_DGRAM)
            self.fd.bind((host, port))
        else:
            self.fd = None
        self.want_except = want_except
        self.agginfo = {}
        self.exptime = 0
        self.Running = True


    def __iter__(self):
        """Provide parsed data events as an iterator"""
        return self


    def __next__(self):
        """Provide parsed data events as an iterator"""

        while self.Running:
            x = self.DataParser(self.getdata())
            if x:
                return(x)


    def getdata(self, recvflags=0):
        """Read data from the class input socket"""
        data = self.fd.recv(65536, recvflags)
        if len(data) < 1:
            if self.Running:
                raise Exception("Socket closed")
            else:
                return None
        return data


    def DataParser(self, data, want_except=None):
        """Parse the raw data coming from BD, (e.g. from getdata).  If
	want_except is True, raise an exception on bad input data.
	Otherwise fail silently (returning None) assuming that the
	internet is a scary place.  Returned value is an array, with
	the elements typed by the first element of the array.  Current
        types are XT_LOG, XT_BUS_DATA, XT_ERR.

        # 0               1         2         3           4            5            6        7
        (XT_LOG,      when_sec, when_nsec, priority,  xo_logmsg)
        (XT_BUS_DATA, when_sec, when_nsec, bdm_valid, bdm_doverload, bdm_line_in,  bdm_out, bitfields)
        (XT_ERR,      when_sec, when_nsec, xer_port,  xer_counter,   xer_errorbits

        See the code for the bitfield definition
        """


        if want_except is None:
            want_except = self.want_except
        if len(data) < 4:
            if want_except:
                raise ValueError("Trivial data: %d"%(len(data)))
            else:
                return None
        dtype, dlen = struct.unpack_from("@xBH", data)
        if len(data) != dlen + 4:
            if want_except:
                raise ValueError("Data/declared length mismatch: %d/%d"%(len(data), dlen))
            else:
                return None
        if dtype == self.XT_LOG:          # Log
            if dlen < 10:
                if want_except:
                    raise ValueError("Log with insufficient data: %d"%(dlen))
                else:
                    return None
            # (type) when_sec, when_nsec, priority, xo_logmsg
            data = struct.unpack_from("@IIB%ds"%(dlen-9), data, 4)
        elif dtype == self.XT_BUS_DATA:        # BDM Bus Data
            if dlen != 28:
                if want_except:
                    raise ValueError("BDM with insufficient data: %d"%(dlen))
                else:
                    return None
            # when_sec, when_nsec, bdm_doverload, bdm_valid, bdm_worddesc, bdm_numout, bdm_line_in, bdm_out
            (when_sec, when_nsec, bdm_doverload, bdm_valid, bdm_worddesc, bdm_numout, bdm_line_in, bdm_out) = struct.unpack_from("@IIIIIBBxxI", data, 4)
            bitfields = {}
            bitfields['wd_unused'] = ((bdm_worddesc >> 25) & 0x7f)
            bitfields['wd_last'] = ((bdm_worddesc >> 24) & 1)
            bitfields['wd_errors'] = ((bdm_worddesc >> 16) & 0xff)
            bitfields['wd_first'] = ((bdm_worddesc >> 15) & 1)
            bitfields['wd_gc'] = ((bdm_worddesc >> 12) & 0x7)
            bitfields['wd_msgtype_cnt'] = ((bdm_worddesc >> 6) & 0x3f)
            bitfields['wd_messagetype'] = ((bdm_worddesc >> 2) & 0xf)
            bitfields['wd_worddtype'] = ((bdm_worddesc >> 0) & 3)
            bitfields['hs_parity'] = bdm_doverload & 1
            bitfields['pf_sync_unused'] = (bdm_doverload >> 17) & 3
            bitfields['pf_sync'] = (bdm_doverload >> 18) & 1
            bitfields['pf_prefix_unused'] = (bdm_doverload >> 19)
            if bitfields['wd_worddtype'] == self.HT_CMD:
                bitfields['hc_dword_cnt'] = (bdm_doverload >> 1) & 0x1f
                bitfields['hc_dword_cnt32'] = bitfields['hc_dword_cnt'] if bitfields['hc_dword_cnt'] > 0 else 32
                bitfields['hc_subaddr'] = (bdm_doverload >> 6) & 0x1f
                bitfields['hc_tr'] = (bdm_doverload >> 11) & 1
                bitfields['hc_rtaddr'] = (bdm_doverload >> 12) & 0x1f
                if bitfields['wd_messagetype'] == self.MT_MODE:
                    bitfields['hc_len'] = 0
                elif bitfields['wd_messagetype'] == self.MT_MODE_TRANS or bitfields['wd_messagetype'] == self.MT_MODE_RECV:
                    bitfields['hc_len'] = 1
                else:
                    bitfields['hc_len'] = bitfields['hc_dword_cnt32']
            elif bitfields['wd_worddtype'] == self.HT_STATUS:
                bitfields['hs_terminal'] = (bdm_doverload >> 1) & 1
                bitfields['hs_dynbusctrlaccpt'] = (bdm_doverload >> 2) & 1
                bitfields['hs_subsysflg'] = (bdm_doverload >> 3) & 1
                bitfields['hs_busy'] = (bdm_doverload >> 4) & 1
                bitfields['hs_bcastrcv'] = (bdm_doverload >> 5) & 1
                bitfields['hs_reserved'] = (bdm_doverload >> 6) & 7
                bitfields['hs_srvreq'] = (bdm_doverload >> 9) & 1
                bitfields['hs_instrument'] = (bdm_doverload >> 10) & 1
                bitfields['hs_msgerr'] = (bdm_doverload >> 11) & 1
                bitfields['hs_rtaddr'] = (bdm_doverload >> 12) & 0x1f
            elif bitfields['wd_worddtype'] == self.HT_DATA:
                bitfields['hd_msg'] = (bdm_doverload >> 1) & 0xffff
            # 0(type)   1         2         3             4              5         6       7
            data = (when_sec, when_nsec, bdm_valid, bdm_doverload, bdm_line_in, bdm_out, bitfields)
        elif dtype == self.XT_ERR:	# Error message
            if dlen != 12:  # padding byte at end
                if want_except:
                    raise ValueError("Error with insufficient data: %d"%(dlen))
                else:
                    return None
            # (type) when_sec, when_nsec, xer_port, xer_counter, xer_errorbits
            data = struct.unpack_from("@IIBBB", data, 4)
        elif dtype == self.XT_CMD or dtype == self.XT_TEST:
            return(None)
        else:
            if want_except:
                raise ValueError("Bad network data, type %d"%dtype)
            return(None)
        return (dtype, *data)


    def aggregate_flush(self):
        """Flush the aggregate information (typically done automatically when
        a new message comes in or old was finished, but could be done
        manually on timeout
        """

        retval = self.agginfo
        self.agginfo = {}
        return retval if retval else None


    def aggregate_bdm(self, event):
        """Take the output of DataParser and form the BDM records into a dict
        containing a single message.  Dict will be keyed by "cmd1"
        "cmd2" "status1" "status2" and "data", values will be the
        input event.  (note data will be an array of events, length of
        the data word).  There may be an additional key 'good' which
        indicates that the system believes this record is complete (or
        at least not egregiously bad).  cmd2/status1/status may be not
        present the array depending on message type and/or whether UDP
        dropped the packet.  Note also data will be an empty array if no data
        is present, or may contain None elements if we data was lost somewhere
        (e.g. udp). Also contains the last mtype and mbdm_out keys.

        """
        retval = None
        if event[0] != self.XT_BUS_DATA:
            return None
        bf = event[7]
        etime = event[1] + event[2]/1000000000.0

        if bf['wd_worddtype'] == self.HT_CMD and bf['wd_first']:
            if self.agginfo:
                retval = self.aggregate_flush()
        else:
            if 'cmd1' not in self.agginfo:
                return None
            if self.exptime < etime:
                retval = self.aggregate_flush()
                return retval

        # Approximating current message time + BC timeout
        self.exptime = etime + .000035

        if bf['wd_worddtype'] == self.HT_CMD:
            if bf['wd_first']:
                self.agginfo['cmd1'] = event
                self.agginfo['data'] = [None] * bf['hc_len']
                self.agginfo['mtype'] = bf['wd_messagetype']
                self.agginfo['firsttime'] = etime
                self.agginfo['lasttime'] = etime
                self.agginfo['bdm_out'] = event[6]
            else:
                self.agginfo['cmd2'] = event
                self.agginfo['mtype'] = bf['wd_messagetype']
                self.agginfo['lasttime'] = etime
                self.agginfo['bdm_out'] = event[6]
        elif bf['wd_worddtype'] == self.HT_STATUS:
            if 'status1' not in self.agginfo:
                self.agginfo['status1'] = event
                self.agginfo['mtype'] = bf['wd_messagetype']
                self.agginfo['lasttime'] = etime
                self.agginfo['bdm_out'] = event[6]
            else:
                self.agginfo['status2'] = event
                self.agginfo['mtype'] = bf['wd_messagetype']
                self.agginfo['lasttime'] = etime
                self.agginfo['bdm_out'] = event[6]
        elif bf['wd_worddtype'] == self.HT_DATA:
            if bf['wd_msgtype_cnt'] > self.agginfo['cmd1'][7]['hc_len']:
                retval = self.aggregate_flush()
            else:
                self.agginfo['data'][bf['wd_msgtype_cnt']-1] = event
                self.agginfo['mtype'] = bf['wd_messagetype']
                self.agginfo['lasttime'] = etime
                self.agginfo['bdm_out'] = event[6]

        if bf['wd_last'] and self.agginfo:
            if (None not in self.agginfo['data'] and
                (self.agginfo['mtype'] != self.MT_RTRT or ('cmd2' in self.agginfo and 'status1' in self.agginfo)) and
                (self.agginfo['mtype'] not in [self.MT_RTBC, self.MT_MODE_TRANS, self.MT_RT_BCAST] or 'status1' in self.agginfo)):
                # In theory should also check that cmd2/status1 is good
                self.agginfo['good'] = True
            retval = self.aggregate_flush()

        return(retval)


    def aggregate_supplement(self, message):
        """Generate supplemental meta-information about a message, including which port is the data port and the sub defender hashmap key"""
        if not message or not 'good' in message:
            return None
        if message['mtype'] in [self.MT_BCRT, self.MT_MODE, self.MT_MODE_RECV, self.MT_BC_BCAST, self.MT_MODE_BCAST, self.MT_MODE_RECV_BCAST]:
            message['data_port'] = message['cmd1'][5]
            message['bdkey'] = (self.MT_C2A[message['mtype']], message['cmd1'][7]['hc_dword_cnt'], message['data_port'], "BC", 0, message['cmd1'][7]['hc_rtaddr'], message['cmd1'][7]['hc_subaddr'])
            pass
        elif message['mtype'] in [self.MT_RTBC, self.MT_MODE_TRANS, self.MT_RT_BCAST]:
            message['data_port'] = message['status1'][5]
            message['bdkey'] = (self.MT_C2A[message['mtype']], message['cmd1'][7]['hc_dword_cnt'], message['data_port'], message['cmd1'][7]['hc_rtaddr'], message['cmd1'][7]['hc_subaddr'], "BC", 0)
            pass
        elif message['mtype'] in [self.MT_RTRT]:
            message['data_port'] = message['status1'][5]
            message['bdkey'] = (self.MT_C2A[message['mtype']], message['cmd1'][7]['hc_dword_cnt'], message['data_port'], message['cmd2'][7]['hc_rtaddr'], message['cmd2'][7]['hc_subaddr'], message['cmd1'][7]['hc_rtaddr'], message['cmd1'][7]['hc_subaddr'])
            pass
        else:
            raise ValueError("Unknown/unhandled type %s"%str(message['mtype']))


        message['bdportmaps'] = [(message['cmd1'][5], "BC")]
        if 'status1' in message:
            message['bdportmaps'] += [(message['status1'][5], message['status1'][7]['hs_rtaddr'])]
        if 'status2' in message:
            message['bdportmaps'] += [(message['status2'][5], message['status2'][7]['hs_rtaddr'])]

        return(message)



if __name__=='__main__':
    x = busDefenderUdpServer(port=5002, want_except=True)
    for d in x:
        if d[0] == x.XT_LOG:
            print("LOG: %s"%d[4])
        elif d[0] == x.XT_BUS_DATA:
            bf = d[7]
            print("BDM: %d/%d %08x/%08x -> %08x"%(bf['wd_worddtype'], bf['wd_messagetype'], d[4], d[3], d[6]))
        elif d[0] == x.XT_ERR:
            print("ERR: %d/%d/%d"%(d[3],d[4],d[5]))
        else:
            print("Unknown message")
