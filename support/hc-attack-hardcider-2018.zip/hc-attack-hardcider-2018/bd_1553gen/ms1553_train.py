#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -

"""
Provide basic 1553 structure definition and classes
"""
import re
import random

if __name__=='__main__':
    from ms1553 import (milstd_1553, milstd_1553_staticinfo, milstd_1553_cmd, milstd_1553_data, milstd_1553_status, milstd_1553_mode, milstd_1553_messagetypes)
else:
    from .ms1553 import (milstd_1553, milstd_1553_staticinfo, milstd_1553_cmd, milstd_1553_data, milstd_1553_status, milstd_1553_mode, milstd_1553_messagetypes)



# TRICKY!  Class methods are automatically created
class train_1553:
    """Create a train of 1553 words"""

    def __init__(self, **kwargs):
        self.train = []

    # def add(self, word, head=False):
    #     if type(word) is not list:
    #         word.train = [word]
    #     if head:
    #         self.train[:0] = word.train
    #     else:
    #         self.train.extend(word.train)
    #     return self

    def add(self, word, head=False):
        wordList = word.train if type(word) is list else [word]
        if head:
            self.train[:0] = wordList
        else:
            self.train.extend(wordList)
        return self


    def _strfoo(self, foo):
        thelist = self.train
        wordcount = getattr(self, "wordcount", None)
        if wordcount:
            thelist = thelist[:wordcount+1]
        return ", ".join([getattr(x, foo) for x in thelist])

    def _intfoo(self, foo):
        thelist = self.train
        wordcount = getattr(self, "wordcount", None)
        if wordcount:
            thelist = thelist[:wordcount+1]
        return [getattr(x, foo) for x in thelist]

    def _listfoo(self, foo):
        thelist = self.train
        wordcount = getattr(self, "wordcount", None)
        if wordcount:
            thelist = thelist[:wordcount+1]
        return[item for x in thelist for item in getattr(x, foo)]

    # return a list of (b, l, r)
    def wirebits(self, rateDivider=50):
        thelist = self.train
        wordcount = getattr(self, "wordcount", None)
        if wordcount:
            thelist = thelist[:wordcount+1]
        return [x.wirebits(rateDivider) for x in self.train]

    def list40s(self):
        thelist = self.train
        wordcount = getattr(self, "wordcount", None)
        if wordcount:
            thelist = thelist[:wordcount+1]
        return [item for x in thelist for item in x.list40]

    def bigwordM(self, multiplier):
        thelist = self.train
        wordcount = getattr(self, "wordcount", None)
        if wordcount:
            thelist = thelist[:wordcount+1]
        return [x.bigwordM(multiplier) for x in self.train]

    def bigwordMHz(self, rate):
        thelist = self.train
        wordcount = getattr(self, "wordcount", None)
        if wordcount:
            thelist = thelist[:wordcount+1]
        return [x.bigwordMHz(rate) for x in self.train]

    def __str__(self):
        return self.strhuman

    def generic_datawordset(self, wordname, pos, worddef, **kwargs):
        """Set the data word at pos (absolute from the train start, not data start) based on the passed in word definition"""
        newcnt = (pos+1)-len(self.train)
        if newcnt > 0:
            self.train += [None] * newcnt
        newclass =  type("milstd_1553_data_%s"%wordname, (milstd_1553_data,), {})
        setattr(newclass, "strhuman", property(lambda self, name=wordname, wdef=worddef: milstd_1553_staticinfo.word_via_worddef(self, name, wdef), None, None, "name string property"))

        self.train[pos] = newclass(milstd_1553_staticinfo.worddef_to_word(worddef, kwargs))
        return self



## TRICKY!
## AUTOMATICALLY CREATED PROPERTIES IN train_1553
for _propname in ("strhuman", "strhuman_mode", "strhuman_cmd", "strhuman_status", "strhuman_data", "strhex18", "strbin18", "strhex20", "strbin20", "strhex40", "strbin40", "str_txwrd", "strwavegen40", "mode_codetxt", "str_mcode"):
    setattr(train_1553, _propname, property(lambda self, foo=_propname: self._strfoo(foo), None, None, "name string property"))
for _propname in ("cmd_txwrd",):
    setattr(train_1553, _propname, property(lambda self, foo=_propname: self._intfoo(foo), None, None, "name int property"))
for _propname in ("listwavegen40","cmd_mcode"):
    setattr(train_1553, _propname, property(lambda self, foo=_propname: self._listfoo(foo), None, None, "name list property"))



class train_1553_BCRT_1(train_1553):
    """BCRT part one (or BCCAST)--BC side"""
    _wantsubaddr = True
    def __init__(self, rt, subaddr, contentlist, wordcount=None, bigEndianOutput=True, **kwargs):
        """Define the first part of a BCRT transmission.  Define rt
        destination address, rt subaddress, and the list of 16 bit
        payload messages """
        super().__init__()
        if not wordcount:
            wordcount = len(contentlist)
        self.add(milstd_1553_cmd(rt, 0, subaddr, wordcount))
        if contentlist:
            for data in contentlist:
                self.add(milstd_1553_data(data, bigEndianOutput=bigEndianOutput))
    @property
    def strhuman(self):
        return "BCRT: "+super().strhuman
    def generic_datawordset(self, wordname, pos, worddef, **kwargs):
        return super().generic_datawordset(wordname, pos+1, worddef, **kwargs)

class train_1553_BCRT_2(train_1553):
    """BCRT part two--RT side"""
    def __init__(self, rt, bigEndianOutput=None, **kwargs):
        """Define the second part of a BCRT transmission (status) (ignore bigEndianOutput--not used)"""
        super().__init__()
        self.add(milstd_1553_status(rt, **kwargs))
    @property
    def strhuman(self):
        return "BCRT: "+super().strhuman

class train_1553_BCBCAST_1(train_1553_BCRT_1):
    _wantsubaddr = True
    def __init__(self, subaddress, contentlist, bigEndianOutput=None, **kwargs):
        super().__init__(31, subaddress, contentlist, **kwargs)
    @property
    def strhuman(self):
        return "BCBCAST: "+super().strhuman



class train_1553_RTBC_1(train_1553):
    """RTBC part one--BC side"""
    _wantsubaddr = True
    def __init__(self, rt, subaddr, leng, bigEndianOutput=None):
        """Define the first part of a BCRT transmission.  Define rt
        destination address, rt subaddress, and the amount of data we want (ignore bigEndianOutput--not used)"""
        super().__init__()
        self.add(milstd_1553_cmd(rt, 1, subaddr, leng))
    @property
    def strhuman(self):
        return "RTBC: "+super().strhuman
class train_1553_RTBC_2(train_1553):
    """RTBC part two--RT side"""
    def __init__(self, rt, contentlist, bigEndianOutput=True, **kwargs):
        """Define the second part of a BCRT transmission (status)"""
        super().__init__()
        self.add(milstd_1553_status(rt, **kwargs))
        if contentlist:
            for data in contentlist:
                self.add(milstd_1553_data(data, bigEndianOutput=bigEndianOutput))
    @property
    def strhuman(self):
        return "RTBC: "+super().strhuman
    def generic_datawordset(self, wordname, pos, worddef, **kwargs):
        return super().generic_datawordset(wordname, pos+1, worddef, **kwargs)


class train_1553_RTRT_1(train_1553):
    """RTRT part one--BC side"""
    def __init__(self, rrt, rsubaddr, trt, tsubaddr, leng, bigEndianOutput=None):
        """Define the first part of a RTRT transmission.  Define rt
        destination address, rt subaddress, and the amount of data we want (ignore bigEndianOutput--not used)"""
        super().__init__()
        self.add(milstd_1553_cmd(rrt, 0, rsubaddr, leng))
        self.add(milstd_1553_cmd(trt, 1, tsubaddr, leng))
    @property
    def strhuman(self):
        return "RTRT: "+super().strhuman
class train_1553_RTRT_2(train_1553):
    """RTRT (or RTBCAST) part two--RT side"""
    def __init__(self, trt, contentlist, bigEndianOutput=True, **kwargs):
        """Define the second part of a RTRT transmission (status)"""
        super().__init__()
        self.add(milstd_1553_status(trt, **kwargs))
        if contentlist:
            for data in contentlist:
                self.add(milstd_1553_data(data, bigEndianOutput=bigEndianOutput))
    @property
    def strhuman(self):
        return "RTRT: "+super().strhuman
    def generic_datawordset(self, wordname, pos, worddef, **kwargs):
        return super().generic_datawordset(wordname, pos+1, worddef, **kwargs)
class train_1553_RTRT_3(train_1553):
    """RTRT part three--RT side"""
    def __init__(self, rrt, bigEndianOutput=None, **kwargs):
        """Define the second part of a BCRT transmission (status) (ignore bigEndianOutput--not used)"""
        super().__init__()
        self.add(milstd_1553_status(rrt, **kwargs))
    @property
    def strhuman(self):
        return "RTRT: "+super().strhuman

class train_1553_RTBCAST_1(train_1553_RTRT_1):
    def __init__(self, rsubaddr, trt, tsubaddr, leng, bigEndianOutput=None):
        super().__init__(31, rsubaddr, trt, tsubaddr, leng)
    @property
    def strhuman(self):
        return "RTBCAST: "+super().strhuman
class train_1553_RTBCAST_2(train_1553_RTRT_2):
    @property
    def strhuman(self):
        return "RTBCAST: "+super().strhuman
    def generic_datawordset(self, wordname, pos, worddef, **kwargs):
        return super().generic_datawordset(wordname, pos+1, worddef, **kwargs)


class train_1553_MODE_1(train_1553):
    """Mode code command word"""
    def __init__(self, rt, subaddr=0, codetext=None, contentlist=None, code=None, tr=None, bigEndianOutput=True):
        """Define the first part of a mode code.  Define RT destination
        address.  Subaddress (must be 31 or 0) will be 0 by default.
        You may specify either codetext or code+transmit/receive(tr) bit.
        If there is transmit data (len>=16+tr=0), you may specify it in contentlist."""
        super().__init__()
        self.add(milstd_1553_mode(rt, modehi=subaddr, tr=tr, code=code, codetxt=codetext))
        if contentlist:
            for data in contentlist:
                self.add(milstd_1553_data(data, bigEndianOutput=bigEndianOutput))
    @property
    def strhuman(self):
        return "MODE: "+super().strhuman
    def generic_datawordset(self, wordname, pos, worddef, **kwargs):
        return super().generic_datawordset(wordname, pos+1, worddef, **kwargs)
class train_1553_MODE_2(train_1553):
    """MODE part two--RT side.  Only applicable for non-broadcast mode codes"""
    def __init__(self, rt, contentlist=None, bigEndianOutput=True, **kwargs):
        """Define the second part of a MODE transmission (status).
        Optional contentlist if content is relevant"""
        super().__init__()
        self.add(milstd_1553_status(rt, **kwargs))
        if contentlist:
            for data in contentlist:
                self.add(milstd_1553_data(data, bigEndianOutput=bigEndianOutput))
    @property
    def strhuman(self):
        return "MODE: "+super().strhuman
    def generic_datawordset(self, wordname, pos, worddef, **kwargs):
        return super().generic_datawordset(wordname, pos+1, worddef, **kwargs)




class Generic_1553MsgDef_Definition:
    """Class to hold the definition of a generic 1553 data message
    For example, a which data bits mean what for a specific message an LRU generates or receives"""
    def __init__(self, name, trainclass, subaddress=None, expectedwords=None, maxwords=None, word_defs=None):
        if not word_defs or expectedwords is None or subaddress is None:
            raise ValueError("Missing parameter")
        if not maxwords:
            maxwords = expectedwords
        self.name = name
        self.trainclass = trainclass
        self.subaddress = subaddress
        self.expectedwords = expectedwords
        self.maxwords = maxwords
        self.word_defs = word_defs
        wordlist = {}
        for word in word_defs:
            bitcount = 0
            if word[0] in wordlist:
                raise ValueError("Name clash with %s in %s"% (word[0], name))
            wordlist[word[0]] = True
            for field in word[1]:
                bitcount += field[2]
            if bitcount != 16:
                raise ValueError("Incorrect word %s.%s definition (bitcount)"%(name,word[0]))



class Generic_1553MsgDef_Impl:
    """Generic method to instantiate specificed 1553 messages definitions classes"""

    # Overridden during actual Class Instantiation
    _word_defs = None
    _expected_wordcount = None
    _total_wordcount = None
    _classname = None
    _subaddress = None

    def __init__(self, wc=None, **kwargs):
        if wc is None:
            wc = self._expected_wordcount
        self.wordcount = wc
        if getattr(self, "_wantsubaddr", False):
            super().__init__(self._rtaddr, self._subaddress, None, wordcount=wc, **kwargs)
        else:
            super().__init__(self._rtaddr, None, **kwargs)
        if self._total_wordcount < self._expected_wordcount:
            self._total_wordcount = self._expected_wordcount
        if self._total_wordcount < wc:
            self._total_wordcount = wc
        self.train += [None] * self._total_wordcount
        for worddefinfo in self._word_defs:
            mfun = getattr(self, worddefinfo[0])
            mfun(**kwargs)
#        if (len(self._word_defs) != self._total_wordcount):
#            print("WARNING: mismatch %d %d\n"%(len(self._word_defs), self._total_wordcount))
        for i in range(len(self._word_defs)+1,self._total_wordcount+1):
            self.train[i] = milstd_1553_data(0)
        for i in range(self._total_wordcount):
            if not self.train[i]:
                raise Exception("Train index %d missing value for %s: word_defs %d, total %d"%(i,self._classname,len(self._word_defs),self._total_wordcount))

    def Generic_get(self, name):
        wordnum = 0
        for worddef in self._word_defs:
            wordnum += 1
            offset = 1
            for fname, defval, wlen in reversed(worddef[1]):
                if name == fname:
                    return(self.train[wordnum]._generic_getter(offset, wlen))
                offset += wlen
        raise Exception("Could not find generic field %s"%name)

    def Generic_set(self, name, nval):
        wordnum = 0
        for worddef in self._word_defs:
            wordnum += 1
            offset = 1
            for fname, defval, wlen in reversed(worddef[1]):
                if name == fname:
                    self.train[wordnum]._generic_setter(offset, wlen, nval)
                    return
                offset += wlen
        raise Exception("Could not find generic field %s"%name)

    def Generic_getlen(self, name):
        for worddef in self._word_defs:
            for fname, defval, wlen in reversed(worddef[1]):
                if name == fname:
                    return wlen
        raise Exception("Could not find generic field %s"%name)

    def overridedatawords18(self, wordlist):
        for i in range(1, self._total_wordcount+1):
            self.train[i].word18 = wordlist[i-1]

    def overridedatawords16(self, wordlist):
        for i in range(1, self._total_wordcount+1):
            self.train[i].word18 = ((wordlist[i-1] & 0xffff) << 1)
            self.train[i].make_parity_good()

    def randomize_with_exceptions(self, exceptionlist):
        i = 0
        for worddef in self._word_defs:
            i += 1
            offset = 1
            self.train[i].word18 = (random.randint(0,65535) << 1)
            for name, defval, wlen in reversed(worddef[1]):
                for word in exceptionlist:
                    if word in name:
                        self.train[i]._generic_setter(offset, wlen, 0)
                        break
                offset += wlen
        for i in range(1, self._total_wordcount+1):
            self.train[i].make_parity_good()


    @property
    def strhuman(self):
        return self._classname+" "+super().strhuman



def Specific_WordDef_Factory(lru_class, msg_def):
    """Way to generate a specific class from the generic method"""
    newclass = type(msg_def.name, (Generic_1553MsgDef_Impl, lru_class, msg_def.trainclass), {})
    newclass._word_defs = msg_def.word_defs
    newclass._expected_wordcount = msg_def.expectedwords
    newclass._total_wordcount = msg_def.maxwords
    newclass._subaddress = msg_def.subaddress
    newclass._classname = msg_def.name
    worddefinfocnt=0
    for worddefinfo in msg_def.word_defs:
        setattr(newclass, worddefinfo[0], lambda self, _n=worddefinfo[0], _i=worddefinfocnt, _wd=worddefinfo[1], **kwargs: self.generic_datawordset(_n, _i, _wd, **kwargs))
        worddefinfocnt += 1
    return newclass




class ms1553_messageinfo():
    """Administrative data to to defined the generic message metadata from a brief description.
    Examples: BCRT(1.2/32) -> BCRT message to address 1, subaddress 2, with 32 data words
    Examples: BCBCAST(.2/32) -> BC Broadcast message to address 31, subaddress 2, with 32 data words
    Examples: RTBC(1.2/3) -> RTBC message to address 1, subaddress 2, with 3 data words
    Examples: RTRT(1.2/3,4.5) -> RTRT message destined to rt 1, subaddress 2, sourced by RT 4.5, of length 3
    Examples: RTBCAST(.2/3,4.5) -> RTRT message destined to all RTs (31), subaddress 2, sourced by RT 4.5, of length 3
    Examples: MODE(31, Synchronize) -> Broadcast mode code telling everyone to synchronize
    Examples: MODE(11,Transmit Vector Word) -> Mode code to RT 11 (using subaddress 0) telling it to transmit a vector data word
    Examples: MODE(11.0,Transmit Vector Word) -> Mode code to RT 11 (using subaddress 0) telling it to transmit a vector data word
    Examples: MODE(11.31,Transmit Vector Word) -> Mode code to RT 11 (using subaddress 31) telling it to transmit a vector data word

    There is an optional "stage" where you can append the number 1, 2,
    or 3 to the message types (e.g. BCRT2(1,2,32)) which indicates
    that this is the status reply to the specifed BCRT message)
    Examples: BCRT1(1.2/32) -> BCRT message from BC to address 1, subaddress 2, with 32 data words
    Examples: BCRT2(1.2/32) -> BCRT status reply to above message
    Examples: MODE1(31,"Synchronize") -> Broadcast mode code telling everyone to synchronize
    Examples: MODE2(11,"Transmit Vector Word") -> Status reply to mode code

    Finally if you have the optional stage, you may also have and
    optional "data" where you can append [0xfeed,64206] or whatever
    the appropriate number of data words are.  Data words are assumed
    to be 0 if not specified (including with []).
    Examples: BCRT1(1.2/2)[0xfeed,64206] -> Two data words for BCRT message to address 1, subaddress 2, of length 2 are 0xfeed and 0xface.
    """
    def __init__(self, messagetext,
                 bdports=None, bigEndianOutput=True):
        """Create an instance, either through textual description or through explicitly defined message components"""

        self.train = None
        self.matchsub = None
        self.bigEndianOutput = bigEndianOutput
        self.textDecode(messagetext)


    def textDecode(self, text):
        """Decode a textual description of a 1553 message"""

        m = re.match(r"(BCRT|BCBCAST|RTBC|RTRT|RTBCAST|MODE|MODE_TRANS|MODE_RECV|MODE_BCAST|MODE_RECV_BCAST)([123]?)\(([^;)]*)(;[^)]+)?\)(?:\[(.*)\])?\s*$", text)

        if not m:
            raise ValueError("Not a defined message text descriptive string: %s"%text)

        cmd, cstage, cargs, text_kwargs, data = m.groups()

        if not data:
            data=""

        self.stage = cstage
        self.stageargs = None
        self.stagetype = None
        self.modename = None
        self.tr = None
        self.datalist = None
        self.datalen = None
        self.bcxmitd = False
        self.bdargs = None
        self.stage_kwargs = {}

        if not cstage:
            self.reactive = None
        elif cstage=="1":
            self.reactive = False
        else:
            self.reactive = True

        if cmd == "BCRT":
            self.messagetype = milstd_1553_messagetypes.BCRT

            #               RTADDR           SA             LEN
            m = re.match(r"^(\d+)(?:,\s*|\.)(\d+)(?:,\s*|/)(\d+)\s*$", cargs)
            if not m:
                raise ValueError("Invalid transfer command")
            self.rtaddr1, self.subaddr1, self.length = map(int, m.groups())
            self.rtaddr2 = self.subaddr2 = None
            self.tr = False
            self.bdargs = ("BC", 0, self.rtaddr1, self.subaddr1)
            self.datalist = self.dataconv(data, self.length)
            self.datalen = 32 if self.length is None or self.length==0 else self.length
            self.bcxmitd = True

            if cstage:
                if cstage == "1":
                    self.stagetype = train_1553_BCRT_1
                    self.stageargs = (self.rtaddr1, self.subaddr1, self.datalist, self.length)
                elif cstage == "2":
                    self.stagetype = train_1553_BCRT_2
                    self.stageargs = (self.rtaddr1,)
                else:
                    raise ValueError("Invalid stage for BCRT")

        elif cmd == "BCBCAST":
            self.messagetype = milstd_1553_messagetypes.BCBCAST

            #               RTADDR(!cap)             SA             LEN
            m = re.match(r"^(?:(?:31)?(?:,\s*|\.))?(\d+)(?:,\s*|/)(\d+)\s*$", cargs)
            if not m:
                raise ValueError("Invalid transfer command")
            self.rtaddr1 = 31
            self.subaddr1, self.length = map(int, m.groups())
            self.rtaddr2 = self.subaddr2 = None
            self.tr = False
            self.bdargs = ("BC", 0, self.rtaddr1, self.subaddr1)
            self.datalist = self.dataconv(data, self.length)
            self.datalen = 32 if self.length is None or self.length==0 else self.length
            self.bcxmitd = True

            if cstage:
                if cstage == "1":
                    self.stagetype = train_1553_BCRT_1
                    self.stageargs = (self.rtaddr1, self.subaddr1, self.datalist, self.length)
                elif cstage == "2":
                    self.stagetype = train_1553_BCRT_2
                    self.stageargs = (self.rtaddr1,)
                else:
                    raise ValueError("Invalid stage for BCRT")

        elif cmd == "RTBC":
            self.messagetype = milstd_1553_messagetypes.RTBC

            #               RTADDR           SA             LEN
            m = re.match(r"^(\d+)(?:,\s*|\.)(\d+)(?:,\s*|/)(\d+)\s*$", cargs)
            if not m:
                raise ValueError("Invalid transfer command")
            self.rtaddr1, self.subaddr1, self.length = map(int, m.groups())
            self.rtaddr2 = self.subaddr2 = None
            self.bdargs = (self.rtaddr1, self.subaddr1, "BC", 0)
            self.datalist = self.dataconv(data, self.length)
            self.datalen = 32 if self.length is None or self.length==0 else self.length
            self.tr = True

            if cstage:
                if cstage == "1":
                    self.stagetype = train_1553_RTBC_1
                    self.stageargs = (self.rtaddr1, self.subaddr1, self.length)
                elif cstage == "2":
                    self.stagetype = train_1553_RTBC_2
                    self.stageargs = (self.rtaddr1, self.datalist)
                else:
                    raise ValueError("Invalid stage for RTBC")

        elif cmd == "RTRT":
            self.messagetype = milstd_1553_messagetypes.RTRT

            #               RTADDR           SA             LEN     RT2              SA2
            m = re.match(r"^(\d+)(?:,\s*|\.)(\d+)(?:,\s*|/)(\d+),\s*(\d+)(?:,\s*|\.)(\d+)\s*$", cargs)
            if not m:
                raise ValueError(f"Invalid transfer command: {cargs}")
            self.rtaddr1, self.subaddr1, self.length, self.rtaddr2, self.subaddr2 = map(int, m.groups())
            self.bdargs = (self.rtaddr2, self.subaddr2, self.rtaddr1, self.subaddr1)
            self.datalist = self.dataconv(data, self.length)
            self.datalen = 32 if self.length is None or self.length==0 else self.length
            self.tr = 2

            if cstage:
                if cstage == "1":
                    self.stagetype = train_1553_RTRT_1
                    self.stageargs = (self.rtaddr1, self.subaddr1, self.rtaddr2, self.subaddr2, self.length)
                elif cstage == "2":
                    self.stagetype = train_1553_RTRT_2
                    self.stageargs = (self.rtaddr2, self.datalist)
                elif cstage == "3":
                    self.stagetype = train_1553_RTRT_3
                    self.stageargs = (self.rtaddr1,)
                else:
                    raise ValueError("Invalid stage for RTRT")

        elif cmd == "RTBCAST":
            self.messagetype = milstd_1553_messagetypes.RTBCAST

            #                     RTADDR(!capt)     SA             LEN     RT2              SA2
            m = re.match(r"^(?:(?:31)?(?:,\s*|\.))?(\d+)(?:,\s*|/)(\d+),\s*(\d+)(?:,\s*|\.)(\d+)\s*$", cargs)
            if not m:
                raise ValueError("Invalid transfer command")
            self.rtaddr1 = 31
            self.subaddr1, self.length, self.rtaddr2, self.subaddr2 = map(int, m.groups())
            self.bdargs = (self.rtaddr1, self.subaddr1, self.rtaddr2, self.subaddr2)
            self.datalist = self.dataconv(data, self.length)
            self.datalen = 32 if self.length is None or self.length==0 else self.length
            self.tr = 2

            if cstage:
                if cstage == "1":
                    self.stagetype = train_1553_RTBCAST_1
                    self.stageargs = (self.subaddr1, self.rtaddr2, self.subaddr2, self.length)
                elif cstage == "2":
                    self.stagetype = train_1553_RTBCAST_2
                    self.stageargs = (self.rtaddr2, self.datalist)
                else:
                    raise ValueError("Invalid stage for RTRT")

        elif cmd in ("MODE", "MODE_TRANS", "MODE_RECV", "MODE_BCAST", "MODE_RECV_BCAST"):
            #               RTADDR    SA           MODENAME
            m = re.match(r"^(\d+)?(?:\.(0|31))?,\s*(\S.*\S)\s*$", cargs)
            if not m:
                raise ValueError(f"Invalid transfer command")

            self.rtaddr1, self.subaddr1, self.modename = m.groups()
            self.rtaddr2 = self.subaddr2 = None

            if (self.rtaddr1 == "" or self.rtaddr1 is None) and (cmd == "MODE_BCAST" or cmd == "MODE_RECV_BCAST"):
                self.rtaddr1 = "31"

            self.rtaddr1 = int(self.rtaddr1, 0)

            if self.subaddr1 is None:
                self.subaddr1 = 0
            else:
                self.subaddr1 = int(self.subaddr1, 0)

            isresp=False
            if cstage:
                if cstage == "1":
                    self.stagetype = train_1553_MODE_1
                    self.stageargs = (self.rtaddr1, self.subaddr1, self.modename)
                elif cstage == "2":
                    self.stagetype = train_1553_MODE_2
                    self.stageargs = (self.rtaddr1,)
                    isresp=True
                else:
                    raise ValueError("Invalid stage for MODE")

            dataP = milstd_1553_staticinfo.mode_txt2datap(self.modename)
            recvP = milstd_1553_staticinfo.mode_txt2rcvp(self.modename)
            broadP = self.rtaddr1 == 31
            if dataP or cmd in ("MODE_TRANS", "MODE_RECV", "MODE_RECV_BCAST"):
                expectedData = 1
                dataP = True
            if dataP and data == "N/A":
                dataP = False
                expectedData = 0
            elif not dataP and data:
                dataP = True
                expectedData = len(data.split(','))
            if not broadP and not dataP:
                self.messagetype = milstd_1553_messagetypes.MODE
                self.datalist = []
                self.datalen = 0
                self.bdargs = ("BC", 0, self.rtaddr1, self.subaddr1, )
            elif broadP and not dataP:
                self.messagetype = milstd_1553_messagetypes.MODE_BCAST
                self.datalist = []
                self.datalen = 0
                self.bdargs = ("BC", 0, self.rtaddr1, self.subaddr1)
            elif dataP and recvP and not broadP:
                self.messagetype = milstd_1553_messagetypes.MODE_RECV
                self.datalist = self.dataconv(data, expectedData)
                self.datalen = expectedData
                self.bcxmitd = True
                self.bdargs = ("BC", 0, self.rtaddr1, self.subaddr1)
                if self.stageargs and not isresp:
                    self.stageargs += (self.datalist,)
            elif dataP and recvP and broadP:
                self.messagetype = milstd_1553_messagetypes.MODE_RECV_BCAST
                self.datalist = self.dataconv(data, expectedData)
                self.datalen = expectedData
                self.bcxmitd = True
                self.bdargs = ("BC", 0, self.rtaddr1, self.subaddr1)
                if self.stageargs and not isresp:
                    self.stageargs += (self.datalist,)
            elif dataP and not recvP:
                self.messagetype = milstd_1553_messagetypes.MODE_TRANS
                self.datalist = self.dataconv(data, expectedData)
                self.datalen = expectedData
                self.bdargs = (self.rtaddr1, self.subaddr1, "BC", 0)
                if self.stageargs and isresp:
                    self.stageargs += (self.datalist,)
            else:
                raise Exception("Unknown/impossible state")

            self.tr, self.length = milstd_1553_staticinfo.mode_txt2code(self.modename)
        else:
            raise ValueError("Unknown 1553 message type...somehow")

        if text_kwargs is not None:
            for text_kwarg in text_kwargs.split(";")[1:]:
                try:
                    key, value = text_kwarg.split("=", 1)
                except:
                    continue

                if re.match("[\d.]*",value):
                    self.stage_kwargs[key] = int(value)
                else:
                    self.stage_kwargs[key] = value


    def dataconv(self, text, length, fixuser=True):
        """Convert a string describing data to an array of ints representing that data"""
        # Let it fail by itself
        # wpat = '(0x[0-9a-fA-F]{1,8}|0o[0-7]{1,1}|0b[0-1]{1,32}|[0-9]{10})'
        # re.fullmatch('(%s,)*%s'%(wpat,wpat), test)
        m = re.search(r'\*MATCHSUB=\(([^\)]+)\),?',text)
        if m:
            self.matchsub = m.group(1)
            text = re.sub(r'\*MATCHSUB=\([^\)]+\),?','',text)
        if length is not None and length == 0:
            length = 32
        if text and "*RANDOM" in text:
            return [ random.randint(0,65535) for x in range(length) ]
        elif text and "*ZEROS" in text:
            return [ 0 ] * length
        elif text and "*ONES" in text:
            return [ 0xffff ] * length
        elif text:
            dlist = list(map(lambda x: int(x, 0), text.split(',')))
            if length and fixuser:
                if len(dlist) < length:
                    dlist += [ 0 ] * length
                if len(dlist) > length:
                    dlist = dlist[:length]
            return dlist
        elif length is not None:
            return [ 0 ] * length
        else:
            return []


    def instantiate(self, **kwargs):
        """Convert this textual description to a 1553 train"""

        if not self.stagetype:
            raise ValueError("Cannot instantiate without a transfer stage (e.g. BCRT1(...)")
        self.train = self.stagetype(*self.stageargs, bigEndianOutput=self.bigEndianOutput, **self.stage_kwargs, **kwargs)
        return(self)


    def bdrule(self, aux=0, ports=[-1]):
        type = milstd_1553_messagetypes.enum_to_bd[self.messagetype]

        len = self.length

        if self.matchsub:
            m = re.search(r'(\d+)\.(\d+)/(\d+)=(\d+)\.(\d+)/(\d+)', self.matchsub)
            len = int(m.group(6))
            if str(self.bdargs[0]) == str(m.group(1)):
                self.bdargs = list(self.bdargs)
                self.bdargs[0] = str(m.group(4))
            if str(self.bdargs[2]) == str(m.group(1)):
                self.bdargs = list(self.bdargs)
                self.bdargs[2] = str(m.group(4))

        # x aux type len port s s d d
        msg = "*HASH_MATCH, 0x%x, %s, %d, %%d, %s, %d, %s, %d"%(aux, type, len%32, *self.bdargs)

        out = []
        for p in ports:
            out.append(msg%p)
        return out


    @property
    def strhuman(self):
        if self.train:
            return "%s: "%(self.hdrinfo())+self.train.strhuman
        else:
            return self.hdrinfo

    def hdrinfo(self):
        mt=milstd_1553_messagetypes.enum_to_txt[self.messagetype]
        if self.messagetype in (milstd_1553_messagetypes.MODE, milstd_1553_messagetypes.MODE_BCAST, milstd_1553_messagetypes.MODE_RECV, milstd_1553_messagetypes.MODE_RECV_BCAST, milstd_1553_messagetypes.MODE_TRANS):
            mt += "(%s.%s, %s)"%(self.rtaddr1, self.subaddr1, self.modename)
        else:
            mt += "(%s.%s/%s"%(self.rtaddr1, self.subaddr1, self.length)
            if self.rtaddr2 is not None:
                mt += "%s.%s"%(self.rtaddr2, self.subaddr2)
            mt += ")"

        return mt

    def __str__(self):
        if self.train:
            return self.strhuman
        return self.hdrinfo()



if __name__=='__main__':
    import ms1553

    x = train_1553().add(ms1553.milstd_1553_cmd(8, 1, 2, 3))   \
        .add(ms1553.milstd_1553_status(8))                     \
        .add(ms1553.milstd_1553_data(0xface))                  \
        .add(ms1553.milstd_1553_mode(26, codetxt="Transmit Status"))

    print(x)
    print(str(x.str_txwrd))
    print(str(x.cmd_txwrd))
    print(x.listwavegen40)
    print(list(map(hex, x.listwavegen40)))

    for rate in [50,37,25,10,5,2,1]:
        obits = int(20*rate)
        print('bigwordM {}: bits={} {}'.format(rate, obits, x.bigwordM(rate)))

    # print(x.bigwordM(50))
    # print(x.bigwordMHz(2))

    x = train_1553_BCRT_1(1, 2, [ 0xffff, 0x5555, 0xaaaa, 0 ])
    print(x)
    x = train_1553_BCRT_2(1)
    print(x)

    x = train_1553_BCBCAST_1(2, [ 0xfff0, 0x5550, 0xaaa0, 0xf ])
    print(x)

    x = train_1553_RTBC_1(1, 2, 4)
    print(x)
    x = train_1553_RTBC_2(1, [ 0xf0ff, 0x5055, 0xa0aa, 0xf00 ])
    print(x)

    x = train_1553_RTRT_1(1, 2, 3, 4, 4)
    print(x)
    x = train_1553_RTRT_2(3, [ 0xff0f, 0x5505, 0xaa0a, 0x0f0 ])
    print(x)
    x = train_1553_RTRT_3(1)
    print(x)

    x = train_1553_RTBCAST_1(2, 3, 4, 4)
    print(x)
    x = train_1553_RTBCAST_2(3, [ 0x0fff, 0x0555, 0x0aaa, 0xf000 ])
    print(x)
    print(x.listwavegen40)


    from word_transform import transform_1553
    print("Train BCRT: CMD(1R2/2) converted to 8MHz output")
    x = train_1553_BCRT_1(1, 2, [ 0xffff, 0x5555 ])
    x.train = list(map(lambda car: transform_1553(car, rateMHz=8), x.train))
    print(x.str_mcode)

    print("Train with bias applied to all elements")
    x = train_1553_BCRT_1(1, 2, [ 0xffff, 0x5555 ])
    x.train = list(map(lambda car: transform_1553(car, rateMHz=8).xform_bias("rise",magnitude=1/160), x.train))
    print(x.str_mcode)
    print(x.cmd_mcode)


    foo = [
        Generic_1553MsgDef_Definition("addr_cmd", train_1553_BCRT_1, 13, 1, 0,
                                      [("prog_addr_loc",
                                        [
                                            ("prgm_addr_location", 0, 16),
                                        ])]),
        Generic_1553MsgDef_Definition("verify_load", train_1553_RTBC_2, 15, 1, 0,
                                      [("verify_data",
                                        [
                                            ("spare", 0, 8),
                                            ("verify_data", 0x8, 8),
                                        ])]),
    ]

    class foort:
        _rtaddr = 1

    for msg_def in foo:
        globals()[msg_def.name] = Specific_WordDef_Factory(foort, msg_def)

    x = addr_cmd(prgm_addr_location=0xfeed)
    print(x)
    x = verify_load()
    print(x)
