#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -

"""
Provide methods to transform a 1553 word
"""

if __name__=='__main__':
    from bd_1553gen import *
    import copy
    # from ms1553 import milstd_1553, milstd_1553_staticinfo, milstd_1553_cmd, milstd_1553_mode, milstd_1553_status, milstd_1553_data
    # from wavegen_code import wavegen_code
else:
    from .ms1553 import milstd_1553, milstd_1553_staticinfo, milstd_1553_cmd, milstd_1553_mode, milstd_1553_status, milstd_1553_data
    from .wavegen_code import wavegen_code
    import copy

import random

# bit manipulation utility functions
def bitnum(rawword, x):
    return (rawword >> x) & 1


def delBit(rawword, pos):
    rxmask = (1 << pos + 1) - 1
    rxBits = rawword & rxmask
    return (rawword & (rxmask >> 1)) | (rawword - rxBits) >> 1


def addBit(rawword, bit, pos):
    rxBits = rawword & (1 << pos) - 1
    return rxBits | bit << pos | (rawword - rxBits) << 1


def setBit(rawword, bit, pos):
    return rawword | (1 << pos) if bit == 1 else rawword & ~(1 << pos)


def toggleBit(rawword, pos):
    return rawword ^ (1 << pos)
# -------------------------------------------

class transform_1553(milstd_1553):
    def __init__(self, word18, rateMHz=2):
        """Set a 1553 word based on the 18 bit represetation plus the desired representation output rate"""
        if type(word18) is int:
            self.word18 = word18
        else:
            self.word18 = word18.word18
        self.outputrateMHz = self.rateMHz = rateMHz
        self.rawword,self.obits,_ = self.bigwordMHz(self.rate)
        self.rawmask = (2 ** (self.obits)) - 1

    @property
    def rate(self):
        return self.rateMHz

    @rate.setter
    def rate(self, value):
        """Set the new native representation rate """
        # """Set the new native representation rate, plus zeroize all previous transformations"""
        self.outputrateMHz = self.rateMHz = value
        # self.rawword,self.obits,_ = self.bigwordMHz(self.rate)
        self.rawmask = (2 ** (self.obits)) - 1

    @property
    def cmd_mcode(self):
        """Output microcode to represent this transform"""
        multiplier = int((100.0/self.outputrateMHz)+.5)
        return wavegen_code.generate_tx(self.rawword, self.obits, multiplier, activity=self.rawmask)

    @property
    def str_mcode(self):
        """Output microcode to represent this transform"""
        multiplier = int((100.0/self.outputrateMHz)+.5)
        return ",".join(wavegen_code.generate_tx(self.rawword, self.obits, multiplier, activity=self.rawmask, format="string"))





    def xform_multiplier_skew(self,  magnitude=0):

        """ Changes the TX multiplier speed by a magnitude integer

        multiplier += magnitude

        Example, for a 10MHz
          mag  1 will set multiplier to 11 with a freqMhz 9.090909
          mag -1 will set multiplier to  9 with a freqMhz 11.111111
         """
        multiplier = int((100.0 / self.outputrateMHz) + .5)
        new_multiplier = multiplier + magnitude

        if (new_multiplier < 1 or new_multiplier > 127):
            raise ValueError("Data rate must be between 1 and 127")

        if new_multiplier == 0:
            print('ERROR: invalid magnitude, no transformation was made')
            raise ValueError("ERROR: invalid magnitude out of range")

        new_rateMHz = 100.0 / new_multiplier
        print('rate %s->%s freqMhz %s->%s'%(multiplier, new_multiplier, self.outputrateMHz, new_rateMHz))
        self.outputrateMHz = new_rateMHz
        return (self)

    def xform_addNoise(self, magnitude=0, startpct=0, endpct=1):
        """ flips bits in a word by the magnitude percent
            startpct, endpct are fractions of the wors selecting the bits

              Example, for a 10MHz representation of a word with 200 bits,
              mag .5 startpct=0.25, endpct=0.75 will flip 100 bits randomly
              in the middle 50-150 bits of the word.
        """

        if startpct < 0 or startpct >= 1:
            raise ValueError("Startpct must be fraction from 0 to 1")
        if endpct <= 0 or endpct > 1:
            raise ValueError("Endpct must be fraction from 0 to 1")
        if startpct >= endpct:
            raise ValueError("Startpct must be smaller than endpct")
        if magnitude <= -1 or magnitude > 1:
            raise ValueError("Magnitude must be nonzero fraction from -1 to 1")

        if magnitude == 0:
            return (self)

        startbit = int(startpct * self.obits + .5)
        endbit = int(endpct * self.obits + .5)
        togledBits = int(magnitude * self.obits + .5)

        # print(milstd_1553_staticinfo.binX(self.rawword, self.obits))

        for i in range(0,togledBits):
            pos = int(random.uniform(startbit, endbit))
            #pos = int(random.gauss(mu, sigma)) #@todo in case we want gaussian later on
            self.rawword = toggleBit(self.rawword , pos)
            # print('toggle bit %s'%pos)
            # print(milstd_1553_staticinfo.binX( self.rawword, self.obits))

        return (self)


    def xform_power(self, magnitude=0, modulationBits=10, startpct=0, endpct=1):
        """ sets the power level by magnitude modulating the output with modulationBits.
            and using a dutycycle.
            e.g. xform_power(magnitude=0.5, modulationBits=10) with a 100Mhz freq will use 10 bits (10 Mhz)
        """

        if startpct < 0 or startpct >= 1:
            raise ValueError("Startpct must be fraction from 0 to 1")
        if endpct <= 0 or endpct > 1:
            raise ValueError("Endpct must be fraction from 0 to 1")
        if startpct >= endpct:
            raise ValueError("Startpct must be smaller than endpct")
        if magnitude <= -1 or magnitude > 1:
            raise ValueError("Magnitude must be nonzero fraction from -1 to 1")

        if magnitude == 1:
            return (self)

        startbit = int(startpct * self.obits + .5)
        endbit = int(endpct * self.obits + .5)

        modMask = (1 << int(modulationBits / 2 + modulationBits / 2 * magnitude)) - 1
        newraw = self.rawword

        # print('modMask=%s'%((milstd_1553_staticinfo.binX(modMask, modulationBits))*200))
        # print('raw=    %s'%milstd_1553_staticinfo.binX(newraw, self.obits))
        for pos in range(0, self.obits):
            if startbit <= pos < endbit:  # if in range
                maskBitPos = (pos+2) % modulationBits #offset 2 to avoid fronts
                maskbit = modMask & 1 << maskBitPos
                if maskbit == 0:
                    newraw = toggleBit(newraw,pos)
                    # print('newraw=%s' % milstd_1553_staticinfo.binX(newraw, self.obits))

        # print('newraw =%s' % milstd_1553_staticinfo.binX(newraw, self.obits))

        self.rawword = newraw
        return (self)

    def xform_cut(self, startpct=0, endpct=1):
        """ sets activity to zero from startpct to endpct
        """

        if startpct < 0 or startpct >= 1:
            raise ValueError("Startpct must be fraction from 0 to 1")
        if endpct <= 0 or endpct > 1:
            raise ValueError("Endpct must be fraction from 0 to 1")
        if startpct >= endpct:
            raise ValueError("Startpct must be smaller than endpct")

        startbit = int(startpct * self.obits + .5)
        endbit = int(endpct * self.obits + .5)

        mask = ~((1 << (endbit - startbit))-1 << startbit | 1 << (self.obits))
        # print('mask=%s'%milstd_1553_staticinfo.binX(mask, self.obits))
        # print('rawmask=%s'%milstd_1553_staticinfo.binX(self.rawmask, self.obits))
        self.rawmask &= mask
        # print('rawmask=%s' % milstd_1553_staticinfo.binX(self.rawmask, self.obits))
        return (self)

    def xform_bitLength(self, magnitude=0, startpct=0, endpct=1):
        """ extends or shrinks the bits in a word by the magnitude percent
            startpct, endpct are fractions of the wors selecting the bits

              Example, for a 10MHz representation of a word with 200 bits,
              mag .5 will create a 300 bit word by duplicating a bit each 2.

              Example2, for a 10MHz representation of a word with 200 bits,
              mag .5 startpct=0.25, endpct=0.75 will create a 250 bit word by
              duplicating a bit each 2 in the middle 50-150 bits of the word
        """

        if startpct <= -1 or startpct >= 1:
            raise ValueError("Startpct must be fraction from -1 to 1")
        if endpct <= 0 or endpct > 1:
            raise ValueError("Endpct must be fraction from 0 to 1")
        if startpct >= endpct:
            raise ValueError("Startpct must be smaller than endpct")
        if magnitude <= -1 or magnitude > 1 or magnitude == 0:
            raise ValueError("Magnitude must be a non-zero fraction from -1 to 1")

        startbit = int(startpct * self.obits + .5)
        endbit = int(endpct * self.obits + .5)

        selBit = int(1 / abs(magnitude))
        newobits = int(self.obits * (1+(magnitude*(endpct-startpct))))

        newword = self.rawword
        newmask = self.rawmask
        newb = 0

        # print(milstd_1553_staticinfo.binX(newword, newobits))

        for b in range(0, self.obits):
            if startbit <= b < endbit: # if in range
                if b % selBit == 0: #bit selector
                    if magnitude > 0: # Add bits
                        bitval = bitnum(self.rawword,b)
                        newword = addBit(newword, bitnum(self.rawword, b), newb)
                        newmask = addBit(newmask, bitnum(self.rawmask, b), newb)
                        newb+=1;
                    else: # remove bits
                        newword = delBit(newword, newb)
                        newmask = delBit(newmask, newb)
                        newb -= 1
                    # print(milstd_1553_staticinfo.binX(newword, max(newobits,self.obits)))
            newb += 1;

        self.obits = newobits
        self.rawword = newword
        self.rawmask = newmask
        return (self)

    def xform_bias(self, direction, magnitude=0, startpct=0, endpct=1):

        """For all "rise"/"fall" edge transitions, move the transition by the
        mag fraction of the word, starting at the listed percentage
        through the word.

        Example, for a 10MHz representation of a word, direction rise,
        mag .01, startpct .5 means starting half way through the digitized signal,
        any transition from 0 to 1 will have 2 of the 1s changed to 0s, delaying
        the transition by 1%"""

        if direction not in ("rise","fall"):
            raise ValueError("Direction must be 'rise' or 'fall'")
        if startpct < 0 or startpct >= 1:
            raise ValueError("Startpct must be fraction from 0 to 1")
        if endpct <= 0 or endpct > 1:
            raise ValueError("Endpct must be fraction from 0 to 1")
        if startpct >= endpct:
            raise ValueError("Startpct must be smaller than endpct")
        #if magnitude <= -1 or magnitude > 1 or magnitude == 0:
        if magnitude <= -1 or magnitude > 1:
            raise ValueError("Magnitude must be nonzero fraction from -1 to 1")

        startbit = int(startpct * self.obits + .5)
        endbit = int(endpct * self.obits + .5)
        delay = self.obits * abs(magnitude)

        def bitnum(x):
            return (self.rawword >> x) & 1
        def setbits(pos,value,count,newword):
            if pos < 0:
                count += pos
                pos = 0
            if pos-count < 0:
                return newword
            if pos > self.obits:
                return newword
            if pos+count > self.obits:
                count = self.obits - pos
            if count < 1:
                return newword

            countmask = (1 << (count)) - 1

            if value:
                newword |= (countmask << (pos-count))
            else:
                newword &= ~(countmask << (pos-count))
            return newword

        count = int(delay+.5)

        if direction == "rise" and magnitude >= 0:
            value = 0
            relstart = 1
        if direction == "rise" and magnitude < 0:
            value = 1
            relstart = delay+1
        if direction == "fall" and magnitude > 0:
            value = 1
            relstart = 1
        if direction == "fall" and magnitude < 0:
            value = 0
            relstart = +delay+1

        newword = self.rawword
        lastbit = bitnum(endbit)
        for b in range(endbit, startbit, -1):
            curbit = bitnum(b)
            # Time to transform?
            if ((direction == "rise" and curbit > lastbit) or
                (direction == "fall" and curbit < lastbit)):
                newword = setbits(int(b+relstart),value,count, newword)
            lastbit = curbit
        self.rawword = newword
        return(self)

def fuzzTrain(train, fuzzPlan):
    fuzzedTrain = copy.deepcopy(train)
    # print('tc=%s' % fuzzPlan)
    n = fuzzPlan['testID']
    # print('************************  preparing testcase %s' % n)
    for w in fuzzPlan['wlist']:
        idx = w['word']
        fuzzedTrain.train[idx] = transform_1553(fuzzedTrain.train[idx], rateMHz=100)  # expand 100Mhz
        for transforms in w['tList']:
            tname = transforms[0]
            # i = fuzzedTrain.train[idx]
            if tname == 'NOISE':
                mag = transforms[1]
                startpct = transforms[2]
                endpct = transforms[3]
                # print('NOISE(mag=%s,startpct=%s, endpct=%s)' % (mag, startpct, endpct))
                fuzzedTrain.train[idx].xform_addNoise(mag, startpct=startpct, endpct=endpct)
            if tname == 'BITCUT':
                startpct = transforms[1]
                endpct = transforms[2]
                # print('BITCUT(startpct=%s, endpct=%s)' % (startpct, endpct))
                fuzzedTrain.train[idx].xform_cut(startpct=startpct, endpct=endpct)
            if tname == 'BITLENGH':
                mag = transforms[1]
                startpct = transforms[2]
                endpct = transforms[3]
                # print('BITLENGH(mag=%s,startpct=%s, endpct=%s)' % (mag, startpct, endpct))
                fuzzedTrain.train[idx].xform_bitLength(mag, startpct=startpct, endpct=endpct)
            if tname == 'POWER':
                mag = transforms[1]
                startpct = transforms[2]
                endpct = transforms[3]
                # print('POWER(mag=%s,startpct=%s, endpct=%s)' % (mag, startpct, endpct))
                fuzzedTrain.train[idx].xform_power(mag, startpct=startpct, endpct=endpct)
    return fuzzedTrain


if __name__=='__main__':


    x = milstd_1553_data(0xffff)
    # word,obits,_ = x.bigwordMHz(8)
    # print(milstd_1553_staticinfo.binX(word,obits))

    # y = transform_1553(x, rateMHz=100)
    y = transform_1553(x, rateMHz=4)
    print()
    # print(milstd_1553_staticinfo.binX(y.rawmask,y.obits))

    y.xform_cut(startpct=25/80, endpct=80/80)

    #y.xform_bitLength(magnitude=.5)
    # y.xform_power(magnitude=.5, startpct = 0, endpct = 1)

    # print(milstd_1553_staticinfo.binX(y.rawmask,y.obits))

    import sys
    sys.exit()

    y = transform_1553(x, rateMHz=10)
    print()
    print(milstd_1553_staticinfo.binX(y.rawword,y.obits))

    #y.xform_bitLength(magnitude=.5)
    y.xform_addNoise(magnitude=.5, startpct = 0.25, endpct = 0.75)

    print(milstd_1553_staticinfo.binX(y.rawword,y.obits))

    import sys
    sys.exit()

    y = transform_1553(x, rateMHz=10)
    print()
    print(milstd_1553_staticinfo.binX(y.rawword,y.obits))

    #y.xform_bitLength(magnitude=.5)
    y.xform_bitLength(magnitude=.5, startpct = 0.25, endpct = 0.75)

    print(milstd_1553_staticinfo.binX(y.rawword,y.obits))

    import sys
    sys.exit()

    y = transform_1553(x, rateMHz=4)
    print()
    print(milstd_1553_staticinfo.binX(y.rawword,y.obits))

    #y.xform_bitLength(magnitude=.5)
    y.xform_bitLength(magnitude=-.5, startpct = 0.25, endpct = 0.75)

    # startpct = 0, endpct = 1
    print(milstd_1553_staticinfo.binX(y.rawword,y.obits))

    import sys
    sys.exit()

    y = transform_1553(x.word18, rateMHz=8)
    print(milstd_1553_staticinfo.binX(y.rawword,y.obits))

    y = transform_1553(x, rateMHz=8)
    y.xform_bias("fall", magnitude=-1/160)
    print(milstd_1553_staticinfo.binX(y.rawword,y.obits))

    y = transform_1553(x, rateMHz=8)
    y.xform_bias("fall", magnitude=1/160)
    print(milstd_1553_staticinfo.binX(y.rawword,y.obits))

    y = transform_1553(x, rateMHz=8)
    y.xform_bias("rise", magnitude=1/160)
    print(milstd_1553_staticinfo.binX(y.rawword,y.obits))

    y = transform_1553(x, rateMHz=8)
    y.xform_bias("rise", magnitude=-1/160)
    print(milstd_1553_staticinfo.binX(y.rawword,y.obits))

    y = transform_1553(x, rateMHz=8).xform_bias("rise", magnitude=-1/160).xform_bias("fall", magnitude=1/160)
    print(milstd_1553_staticinfo.binX(y.rawword,y.obits))
    print(y.str_mcode)
    print(str(y.cmd_mcode))
