#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -
#


if __name__=='__main__':
    from ms1553 import (milstd_1553, milstd_1553_mode)
    from wavegen_code import wavegen_code
else:
    from .ms1553 import (milstd_1553, milstd_1553_mode)
    # from .wavegen_code import wavegen_code



class wavegen_code_fromword:
    """Translate word into microcode"""
    @staticmethod
    def decompile(word, cont):
        """Hacky decompile from int into microcode--decidely not complete"""

        if type(word) is not int:
            word = int(word, 0)
        op = word >> 28
        operand24 = word & ((1 << 24)-1)
        operand16 = word & ((1 << 16)-1)
        if cont:
            cont = (word >> 31) & 1
            return ("TXCONT()", cont)
        if op == 0:
            return ("NOOP()", cont)
        if op == 1:
            cont = (word >> 27) & 1
            return ("TXFRG()", cont)
        if op == 3:
            cont = (word >> 27) & 1
            return ("TXVAR()", cont)
        if op == 4:
            sync = (operand24 >> 16) & 1
            forcep = (word >> 24) & 1
            parity = (operand24 >> 20) & 1
            if not forcep:
                parity = "X"
            milWd = milstd_1553(sync << 17 | operand16 << 1 | parity if isinstance(parity, int) else 0)
            return ("TXWRD(%d, %s, %04x)"%(sync, parity, operand16)+'['+milWd.strhuman+']', cont)
        if op == 5:
            return ("OUTMASK(0x%x)"%operand24, cont)
        if op == 6:
            if (operand24 >> 16) & 1:
                if operand16 >> 15:
                    relative = -1
                else:
                    relative = 1
                operand16 &= (1<<15) - 1
                return ("GOTO(%d)"%(operand16*relative), cont)
            else:
                return ("GOTO(0x%04x)"%(operand16), cont)
        if op == 0xf:
            return ("HALT()", cont)
        if op == 0x2:
            subtype = (word >> 24) & 0xf
            if subtype == 0:
                return ("WAIT_ActHi(%x)"%operand24, cont)
            if subtype == 1:
                return ("WAIT_ActLo(%x)"%operand24, cont)
            if subtype == 2:
                return ("WAIT_4bit(%d)"%operand24, cont)
            if subtype == 3:
                return ("WAIT(%.1f)"%(operand24/10), cont)
            if subtype == 4:
                return ("WAIT_Poke()", cont)
            if subtype == 5:
                return ("WAIT_TimedActLoWait(%.1f)"%(operand24/10), cont)
            if subtype == 8:
                return ("WAIT_TimedHiWaitCond(mask=%x, time=%.1f)"%((operand24 & 0b111111111111), (operand24 >> 12)/10), cont)
            return ("UNKNOWNWAIT()", cont)
#        if op & 0xc == 0xc:
#            return "CONT()"
        return ("UNKNOWN OPCODE", cont)
