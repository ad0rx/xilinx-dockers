#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -

"""
Provide basic 1553 structure definition and classes
"""
import re
from enum import Enum

if __name__=='__main__':
    from wavegen_code import wavegen_code
else:
    from .wavegen_code import wavegen_code


# TRICKY!  Class methods are automatically created
class milstd_1553:
    """Basic 1553 structure definitions -- IN BIG ENDIAN VIEW OF MEMORY!!!!"""

    def __init__(self, word18, word20=None):
        """Set a 1553 word based on the 18 bit represetation (SYNCb+16bDATA+Parity)"""
        if word20:
            self.word20 = word20
        else:
            self.word18 = word18

    def _generic_getter(self, offset, len):
        return (self.word18 >> offset) & (2**len-1)
    def _generic_setter(self, offset, len, value):
        if len == 1:
            value = int(not not value)
        mask = (2**len-1)
        self.word18 = (self.word18 & ~(mask << offset)) | ((value & mask) << offset)
        if (offset != 0):
            self.make_parity_good()

    @property
    def word20(self):
        """Return 20 bit (ųs view) of 1553 word (SYNCb + 0b + 0b +16bDATA+Parity)"""
        word20 = self.word18 & 0x1ffff
        word20 |= (self.word18 & 0x20000) << 2
        return word20

    @word20.setter
    def word20(self, word20):
        """Set word based on 20 bit (ųs) view"""
        self.word18 = word20 & 0x1ffff
        self.word18 |= (word20 & 0x80000) >> 2

    @property
    def word40(self):
        """Return word based on 40 bit (manchester) view"""
        word40 = 0
        if self.word18 & 0x20000:
            word40 |= 0x7 << 37
        else:
            word40 |= 0x7 << 34
        for bit in range(0,17):
            bshift = bit * 2
            if self.word18 & (1<<bit):
                word40 |= 2 << bshift
            else:
                word40 |= 1 << bshift
        return word40

    @property
    def list40(self):
        """Return list based on 40 bit (manchester) view"""
        list40 = []
        if self.word18 & 0x20000:
            list40 += [1,1,1,0,0,0]
        else:
            list40 += [0,0,0,1,1,1]
        for bit in range(16,-1,-1):
            if self.word18 & (1<<bit):
                list40 += [1,0]
            else:
                list40 += [0,1]
        return list40

    def bigwordMHz(self, rate):
        """Return a (potenially very large--up to 2000 bits long) word variant based on
        the requested signalling rate in MHz, use values between 2 and 100"""
        return(self.bigwordM(100.0/rate))

    def bigwordM(self, multiplier):
        """Return a (potenially very large--up to 2000 bits long) word variant based on
        multiplier--a value from [1-50] or from 100MHz to 2MHz."""
        if (multiplier < 1 or multiplier > 50):
            raise ValueError("Multiplier must be between 1 and 50")
        rate = 100/multiplier
        obits = int(round(20*rate))
        bigword = 0
        word40 = self.word40

        for obit in range(0,obits):
            ibit = int(obit * 2.0 / rate)
            bigword |= (word40 & (1 << ibit)) << (obit - ibit)
        return(bigword,obits,multiplier)

    def wirebits(self, rateDivider=50):
        return self.bigwordM(rateDivider)

    def __str__(self):
        """Default class representation, 20 bit view as hex"""
        return self.strhex20

    def make_parity_good(self):
        """Set the parity bit to the correct value for this word"""
        self.paritybit = self.calcparity

    def make_parity_bad(self):
        """Set the parity bit to the incorrect value for this word"""
        self.paritybit = 1 ^ self.calcparity

    def reverse_sync(self):
        """Set the parity bit to the correct value for this word"""
        self.word18 = self.word18 ^ 0x20000

    @property
    def calcparity(self):
        """Calculate odd parity based on current data contents"""
        return parity16.calcodd(self.data)

    @property
    def goodparity(self):
        """Truthy: is the parity valid?"""
        return parity16.calcodd(self.data) == self.paritybit

    @property
    def cmd_wraplen(self):
        """Return the command word len with the 0->32 mapping applied"""
        kx = self.cmd_len
        return kx if kx else 32
    @cmd_wraplen.setter
    def cmd_wraplen(self, value):
        if value == 32:
            value = 0
        self.cmd_len = value

    @property
    def cmd_ismode(self):
        """Return if this is really/could be a mode code (assuming CMD etc)"""
        return self.cmd_subaddr in [0, 31]

    @property
    def stat_dynamicBusControlAcceptance(self):
        """Is the status dynamic bus control acceptance bit set?"""
        return (self.word18 >> 2) & 1

    @property
    def stat_terminalFlag(self):
        """Is the status terminal bit set?"""
        return (self.word18 >> 1) & 1

    @property
    def strhuman(self):
        """Return the human representation"""
        if self.syncbit:
            if self.cmd_ismode:
                word = self.strhuman_mode()
            else:
                word = self.strhuman_cmd()
            word += "|"+self.strhuman_status()
        else:
            word = self.strhuman_data()
        return word

    def strhuman_mode(self):
        """Return the human representation if this were a mode code"""
        word = "MODE(%d%s%d/%d=%s)"%(self.cmd_addr, "T" if self.cmd_tr else "R", self.cmd_subaddr, self.mode_code, self.mode_codetxt)
        if not self.goodparity:
            word += "!"
        return word

    def strhuman_cmd(self):
        """Return the human representation if this were a command word"""
        word = "CMD(%d%s%d/%d)"%(self.cmd_addr, "T" if self.cmd_tr else "R", self.cmd_subaddr, self.cmd_len)
        if not self.goodparity:
            word += "!"
        return word

    def strhuman_status(self):
        """Return the human representation if this were a status word"""
        if self.stat_bits:
            statbits = ", "
            statbits += "M" if self.stat_messageError & 1 else "."
            statbits += "I" if self.stat_instrumentation else "."
            statbits += "R" if self.stat_serviceRequest else "."
            x = self.stat_reserved
            statbits += "." if not x else str(x)
            statbits += "*" if self.stat_broadcastCommandReceived else "."
            statbits += "B" if self.stat_busy else "."
            statbits += "S" if self.stat_subsystemFlag else "."
            statbits += "D" if self.stat_dynamicBusControlAcceptance else "."
            statbits += "T" if self.stat_terminalFlag else "."
        else:
            statbits = ""

        word = "STATUS(%d%s)"%(self.cmd_addr, statbits)
        if not self.goodparity:
            word += "!"
        return word

    def strhuman_data(self):
        """Return the human representation if this were a data word"""
        word = "DATA(%04x)"%(self.data)
        if not self.goodparity:
            word += "!"
        return word

    @property
    def strhex18(self):
        """Return the 18 bit hex string word"""
        return "%05x"%self.word18

    def __str__(self):
        return self.strhex18

    @property
    def strbin18(self):
        """Return the 18 bit binary string word"""
        return milstd_1553_staticinfo.binX(self.word18, 18)

    @property
    def strhex20(self):
        """Return the 20 bit hex string word"""
        return "%05x"%self.word20

    @property
    def strbin20(self):
        """Return the 20 bit binary string word"""
        return milstd_1553_staticinfo.binX(self.word20, 20)

    @property
    def strhex40(self):
        """Return the 40 bit hex string word"""
        return "%010x"%self.word40

    @property
    def strbin40(self):
        """Return the 40 bit binary string word"""
        return milstd_1553_staticinfo.binX(self.word40, 40)

    @property
    def cmd_mcode(self):
        """Return preferred microcode format to output this word"""
        return [self.cmd_txwrd]

    @property
    def str_mcode(self):
        """Return preferred microcode format to output this word"""
        return self.str_txwrd

    @property
    def cmd_txwrd(self):
        """Return txwrd formatted 1553 word
        (0100 + XXXF (Force parity 1, autocompute 0) + XXXP (Parity 1, 0 if forced) + XXXS (sync bit CMDSTAT(1)/DATA(0) + 16X DATA content
        """
        # return wavegen_code.txword(self.word18 & 0x20000, ((self.word18 >> 1) & 0xffff), parity=1 ^ (self.word18 & 1)) # <<<<< 1 ^ temp fix invert set parity
        return wavegen_code.txword(self.word18 & 0x20000, ((self.word18 >> 1) & 0xffff), parity=self.word18 & 1)

    @property
    def str_txwrd(self):
        """Return txwrd formatted 1553 word
        (0100 + XXXF (Force parity 1, autocompute 0) + XXXP (Parity 1, 0 if forced) + XXXS (sync bit CMDSTAT(1)/DATA(0) + 16X DATA content
        """
        return wavegen_code.txword(self.word18 & 0x20000, ((self.word18 >> 1) & 0xffff), parity=(self.word18 & 1), format="string")

    @property
    def strwavegen40(self):
        """Return the 40 bit binary string encoded in wavegen pseudo-microcode"""
        return ", ".join(wavegen_code.generate_tx(self.word40, format="string"))

    @property
    def listwavegen40(self):
        """Return the 40 bit binary string encoded in wavegen values for poking"""
        return wavegen_code.generate_tx(self.word40)

    def printall(self):
        """Print all normal representations for this object"""
        print("    base: ",end="")
        print(self)
        print("     str: "+str(self))
        print("strhex18: "+self.strhex18)
        print("strbin18: "+self.strbin18)
        print("strhex20: "+self.strhex20)
        print("strbin20: "+self.strbin20)
        print("strhex40: "+self.strhex40)
        print("strbin40: "+self.strbin40)
        print("strhuman: "+self.strhuman)
        print("str_txwrd: "+self.str_txwrd)
        print("cmd_txwrd: "+hex(self.cmd_txwrd))
        print("strwaveg: "+self.strwavegen40)
        print("strlistg: "+str(self.listwavegen40))
        print("strlistg: "+str(list(map(lambda x: milstd_1553_staticinfo.binX(x,32), self.listwavegen40))))

    @property
    def mode_codetxt(self):
        """Return textual representation of the mode code"""
        return milstd_1553_staticinfo.mode_code2txt(self.cmd_tr, self.mode_code)


## TRICKY!
## AUTOMATICALLY CREATED PROPERTIES IN milstd_1553
for _propname,_offset,_len in (("syncbit", 17, 1), ("data", 1, 16), ("paritybit", 0, 1),
                               ("cmd_addr", 12, 5), ("cmd_tr", 11, 1), ("cmd_subaddr", 6, 5), ("cmd_len", 1, 5),
                               ("mode_code", 1, 5),
                               ("stat_bits", 1, 11), ("stat_messageError", 11, 1), ("stat_instrumentation", 10, 1),
                               ("stat_serviceRequest", 9, 1), ("stat_reserved", 6, 3), ("stat_broadcastCommandReceived", 5, 1),
                               ("stat_busy", 4, 1), ("stat_subsystemFlag", 3, 1), ("stat_dynamicBusControlAcceptance", 2, 1),
                               ("stat_terminalFlag", 1, 1)):
    setattr(milstd_1553, _propname, property(lambda self, o=_offset, l=_len: milstd_1553._generic_getter(self, o,l),
                                             lambda self, v, o=_offset, l=_len: milstd_1553._generic_setter(self, o, l, v),
                                             None, "name property"))





class milstd_1553_messagetypes(Enum):
    """Define legal/distinct 1553 message types"""

    BCRT = 1
    BCBCAST = 2
    RTBC = 3
    RTRT = 4
    RTBCAST = 5
    MODE = 6
    MODE_BCAST = 7
    MODE_RECV = 8
    MODE_RECV_BCAST = 9
    MODE_TRANS = 10

setattr(milstd_1553_messagetypes, "enum_to_txt", {v: k for k, v in milstd_1553_messagetypes.__members__.items()})

# Create map from enums to Bus Defender type strings
setattr(milstd_1553_messagetypes, "enum_to_bd", {
    milstd_1553_messagetypes.BCRT: "bcrt",
    milstd_1553_messagetypes.BCBCAST: "bc_bcast",
    milstd_1553_messagetypes.RTBC: "rtbc",
    milstd_1553_messagetypes.RTRT: "rtrt",
    milstd_1553_messagetypes.RTBCAST: "rt_bcast",
    milstd_1553_messagetypes.MODE: "mode",
    milstd_1553_messagetypes.MODE_TRANS: "mode_trans",
    milstd_1553_messagetypes.MODE_BCAST: "mode_bcast",
    milstd_1553_messagetypes.MODE_RECV: "mode_recv",
    milstd_1553_messagetypes.MODE_RECV_BCAST: "mode_recv_bcast"
    } )




class milstd_1553_staticinfo:
    """Storage for some 1553 static/one-time-generation information for storage/execution efficiency"""

    # T/R, length, name.  user defined ones use the syntax ``MODECODE{TR,length}''
    known_modecodes = { "1,0": "Dynamic Bus Control",
                        "1,1": "Synchronize",
                        "1,2": "Transmit Status",
                        "1,3": "Initiate Self Test",
                        "1,4": "Transmitter Shutdown",
                        "1,5": "Override Transmitter Shutdown",
                        "1,6": "Inhibit Terminal Flag Bit",
                        "1,7": "Override Inhibit Terminal Flag Bit",
                        "1,8": "Reset Remote Terminal",
                        "1,16": "Transmit Vector Word",
                        "0,17": "Synchronize Data",
                        "1,18": "Transmit Last Command",
                        "1,19": "Transmit Built In Test Word",
                        "0,20": "Selected Transmitter Shutdown",
                        "0,21": "Override Selected Transmitter Shutdown" }
    codes_2_modes = {v: k for k, v in known_modecodes.items()}
    modecode_datawords = {v: 1 if (int(k.split(',')[1]) >= 16) else 0 for k, v in known_modecodes.items()}


    @staticmethod
    def mode_code2txt(tr,code):
        """Look up the textual name by tr bit and code.  Return reserved if no known mapping"""
        x = milstd_1553_staticinfo.known_modecodes.get("%d,%d"%(tr,code), None)
        if x is None:
            x = "MODECODE{%d,%d}"%(tr,code)
        return(x)

    @staticmethod
    def mode_txt2code(txt):
        """Look up the tr bit and codes by the textual mode name.  Raise exception if no known mapping"""
        return list(map(lambda x: int(x), milstd_1553_staticinfo.mode_txt2data(txt).split(',')))

    @staticmethod
    def mode_txt2rcvp(txt):
        """Check to see if mode string is requesting the RT receive"""
        return int(milstd_1553_staticinfo.mode_txt2data(txt).split(',')[0], 0) == 0

    @staticmethod
    def mode_txt2datap(txt):
        """Check to see if mode string will have a data word associated"""
        return int(milstd_1553_staticinfo.mode_txt2data(txt).split(',')[1], 0) >= 16

    @staticmethod
    def mode_txt2data(txt):
        """Check to see what the TR and length is for this mode code"""
        if txt in milstd_1553_staticinfo.codes_2_modes:
            return milstd_1553_staticinfo.codes_2_modes[txt]
        m = re.match(r"^\s*MODECODE{\s*([01]),\s*(\d+)\s*}\s*$", txt)
        if not m:
            raise ValueError("Unknown mode code %s"%txt)
        return ",".join(m.groups())

    @staticmethod
    def mode_code2datap(code):
        """Check to see if mode code will have a data word associated
        Returning # of data words 1/0"""
        return (code & 0x1f) >= 16

    @staticmethod
    def binX(v,size):
        """Return the binary representation of an integer padded to size bits"""
        return ("0"*size+(bin(v)[2:]))[-size:]

    @staticmethod
    def bitX(v, offset):
        """Return the integer representation of a bit at the designated offset"""
        # Convert to boolean
        return int(bool(v)) << offset

    @staticmethod
    def fun2map(__default=None, **kwargs):
        if __default:
            k = dict(__default)
            k.update(kwargs)
        else:
            k = kwargs
        return k

    @staticmethod
    def word_via_worddef(dself, wordname, worddef):
        fields=[]
        working = dself.word18 >> 1
        for field in reversed(worddef):
            name, _, len = field
            mask = (1<<len)-1
            fields.append("%s=%d"%(name, working & mask))
            working >>= len
        return "%s("%wordname + ",".join(fields) + ")"

    @staticmethod
    def worddef_to_word(worddef, overrides):
        word = 0
        for bit in worddef:
            v = overrides.get(bit[0], bit[1])
            bitlen = bit[2]
            if bitlen == 1:
                v = int(bool(v))
            else:
                v = v & (2 ** bitlen - 1)

            word = (word << bitlen) | v
#            print("%s->%d word:%x"%(bit[0], v,word))
        return word


class milstd_1553_cmd(milstd_1553):
    """Subclass of 1553 for each command definition and specific printing"""

    def __init__(self, *args, _deferredlen=False, **kwargs):
        """Create a 1553 command word from basic components, either literal arguments
        (addr, tr, subaddr, leng) aka (1,0,5,6) or string abbreviation ("1R5/6")."""

        USAGE='__init__(<<addr, tr, subaddr, len> | <"addr[TR]subaddr[/len]?">'
        if len(args) == 4:
            addr, tr, subaddr, leng = args
        elif len(args) == 3:
            addr, tr, subaddr = args
            leng = 0
        elif len(args) == 1:
            m = re.match(r'(\d+)([TR])(\d+)(?:/(\d+))?$', args[0])
            if not m or (m.lastindex < 4 and not _deferredlen):
                raise ValueError('USAGE: '+USAGE)
            addr = int(m.group(1))
            tr = 1 if m.group(2) == "T" else 0
            subaddr = int(m.group(3))
            if m.lastindex == 4:
                leng = int(m.group(4))
        else:
            raise ValueError('USAGE: '+USAGE)

        self.word18 = ((1 << 17) |
                       ((addr & 0x1f) << 12) |
                       ((tr & 1) << 11) |
                       ((subaddr & 0x1f) << 6) |
                       ((leng & 0x1f) << 1))
        self.make_parity_good()

    @property
    def strhuman(self):
        return self.strhuman_cmd()



class milstd_1553_mode(milstd_1553):
    """Subclass of 1553 for each mode definition and specific printing"""

    def __init__(self, addr, modehi=0, tr=None, code=None, codetxt=None):
        """Create a 1553 mode code from basic components"""
        if (not (code is None or tr is None) ^ (codetxt is None)):
            raise ValueError("Exactly one of (tr and code) or codetxt must be non-None")

        if codetxt:
            (tr, code) = milstd_1553_staticinfo.mode_txt2code(codetxt)

        self.word18 = ((1 << 17) |
                       ((addr & 0x1ff) << 12) |
                       ((tr & 1) << 11) |
                       ((31 if modehi else 0) << 6) |
                       ((code & 0x1ff) << 1))
        self.make_parity_good()

    @property
    def strhuman(self):
        return self.strhuman_mode()



class milstd_1553_status(milstd_1553):
    """Subclass of 1553 for each status definition and specific printing"""

    def __init__(self, addr, messageError=0, instrumentation=0, serviceRequest=0, reserved=0, broadcastCommandReceived=0, busy=0, subsystemFlag=0, dynamicBusControlAcceptance=0, terminalFlag=0, **kwargs):
        """Create a 1553 status word from basic components (default response: good status)"""
        self.word18 = ((1 << 17) |
                       ((addr & 0x1f) << 12) |
                       ((messageError&1) << 11) |
                       ((instrumentation&1) << 10) |
                       ((serviceRequest&1) << 9) |
                       ((reserved&7) << 6) |
                       ((broadcastCommandReceived&1) << 5) |
                       ((busy&1) << 4) |
                       ((subsystemFlag&1) << 3) |
                       ((dynamicBusControlAcceptance&1) << 2) |
                       ((terminalFlag&1) << 1))
        self.make_parity_good()

    @property
    def strhuman(self):
        return self.strhuman_status()



class milstd_1553_data(milstd_1553):
    """Subclass of 1553 for each data definition and specific printing"""

    def __init__(self, data, bigEndianOutput=True):
        """Create a 1553 data word from basic components"""
        if bigEndianOutput:
            # We are taking this input data and storing it so that the most significant bit is output first
            self.word18 = (data & 0xffff) << 1;
        else:
            # We are taking this input data and storing it so that the least significant bit is output first
            self.word18 = ((data & 0xff) << 8 | (data & 0xff00) >> 8) << 1;
        self.make_parity_good()

    @property
    def strhuman(self):
        return self.strhuman_data()



class parity16():
    """Fairly efficient parity calculations for 16 bit data, using  8 bit lookup table (calculated once)"""

    @staticmethod
    def calculate(v):
        v ^= v >> 8;
        return (parity16.lookup[v & 0xff])

    @staticmethod
    def calcodd(v):
        p = parity16.calculate(v)
        return 0 if p else 1

    lookup = list([(0x6996 >> (((i >> 4) ^ i)&0xf) & 1) for i in range(256)])



if __name__=='__main__':
    x = milstd_1553(0)
    print("testing milstd_1553(0)")
    x.printall()
    x = milstd_1553(0x3ffff)
    print("\ntesting milstd_1553(0x3ffff)")
    x.printall()

    for v in [0x8a001, 0x88843, 0x88000, 0x00001, 0x9afc5, 0x9a000, 0x84a90, 0x84011]:
        x = milstd_1553(0)
        x.word20 = v
        print("\nTesting milstd_1553(0).word20 = 0x%05x"%v)
        x.printall()

    x = milstd_1553_cmd(8, 1, 2, 3)
    print("\nTesting milstd_1553_cmd(8, 1, 2, 3)")
    x.printall()

    x = milstd_1553_cmd("8T2/3")
    print("\nTesting milstd_1553_cmd(8T2/3)")
    x.printall()

    x = milstd_1553_status(8)
    print("\nTesting milstd_1553_status(8)")
    x.printall()

    x = milstd_1553_data(0xffff)
    print("\nTesting milstd_1553_data(0xffff)")
    x.printall()

    x = milstd_1553_data(0xface)
    print("\nTesting milstd_1553_data(0xface)")
    x.printall()

    x = milstd_1553_mode(26, modehi=1, codetxt="Transmit Status")
    print("\nTesting milstd_1553_mode(26, modehigh=1, codetxt='Transmit Status')")
    x.printall()

    x = milstd_1553_mode(26, tr=1, code=2)
    print("\nTesting milstd_1553_mode(26, tr=1, code=2)")
    x.printall()

    for rate in [50,37.5,25,10,5,2,1]:
        b, l, r = x.bigwordM(rate)
        print('{}: bits={} {}'.format(r, l, milstd_1553_staticinfo.binX(b, l)))
