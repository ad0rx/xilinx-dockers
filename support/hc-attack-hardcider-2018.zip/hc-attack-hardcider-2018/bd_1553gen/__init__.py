"""Bus Defender Attack and Traffic Generation Tools

Methods to describe 1553 words (milstd_1553*), groups of words
(train_1553*), ways to transform/permute 1553 words or groups in
various ways ways (transform_1553), ways to convert 1553 words (and
related concepts) into microcode for Bus Defender to execute
(wavegen_code), ways to link code into programs and subroutines for
execution, and finally ways to load Bus Defender with linked code.
"""
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -

from .ms1553 import milstd_1553, milstd_1553_staticinfo, milstd_1553_cmd, milstd_1553_mode, milstd_1553_status, milstd_1553_data, milstd_1553_messagetypes
from .ms1553_train import train_1553, train_1553_BCRT_1, train_1553_BCRT_2, train_1553_BCBCAST_1, train_1553_RTBC_1, train_1553_RTBC_2, train_1553_RTRT_1, train_1553_RTRT_2, train_1553_RTRT_3, train_1553_RTBCAST_1, train_1553_RTBCAST_2, train_1553_MODE_1, train_1553_MODE_2, Generic_1553MsgDef_Definition, Specific_WordDef_Factory, ms1553_messageinfo
from .wavegen_code import mcode_word, wavegen_code
from .wavegen_linker import wavegen_link
from .wavegen import wavegen
from .word_transform import transform_1553, fuzzTrain
from .wavegen_decompile import wavegen_code_fromword
from .bd_udps import busDefenderUdpServer
from .bd_intr import busDefenderEffector

__version_info__=(0,0,9)
__version__=".".join(map(str,__version_info__))
