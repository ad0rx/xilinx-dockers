#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -

import shlex
import subprocess
import concurrent.futures

class busDefenderEffector:
    """Class to effect hc-attack like functionality via a Bus Defender"""

    def __init__(self, host=None, secure=False, logtest=[], verbose=False, sshargs=["-oStrictHostKeyChecking=no", "-oConnectTimeout=2"]):
        """Create a channel to one or more Bus Defenders (or local if host "",
        or print if host None), using control connections.  Note host
        may be a string (hostname or user@hostname) or a list of
        strings."""

        self.verbose = verbose
        self.sshargs = sshargs

        if logtest:
            if isinstance(logtest, str):
                logtest = shlex.split(logtest)
            if len(logtest) == 1:
                logtest = shlex.split(logtest[0])
            else:
                logtest = logtest
        elif secure:
            logtest = ["/secure/bin/logtest ", "--secure"]
        else:
            logtest = ["logtest"]
        self.logtest = logtest

        if host is None:
            self.hostlist=[]
            self.verbose = True
        elif isinstance(host, str):
            self.hostlist=[host]
        else:
            self.hostlist=host

    def runcmd(self, cmd, logtest=False, stdin=None):
        """Run a command on all hosts"""

        if isinstance(cmd, str):
            cmd = ["bash", "-c", cmd]

        if logtest:
            cmd = self.logtest + cmd

        if self.verbose:
            if self.hostlist:
                print("Running: %s"%str(cmd))
            else:
                print("Should run: %s"%str(cmd))


        def subrun(cmd, stdin):
            if self.verbose:
                sp = subprocess.Popen(cmd, stdin=subprocess.PIPE)
            else:
                import os
                FNULL = open(os.devnull, 'w')
                sp = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=FNULL, stderr=subprocess.STDOUT)
            if stdin:
                sp.communicate(input=stdin.encode('utf-8'))
            else:
                sp.communicate(input=None)
            if sp.returncode != 0:
                raise subprocess.CalledProcessError(sp.returncode, "cmd=%s"%(str(cmd)))

        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
                subs={}
                for h in self.hostlist:
                    if h != "":
                        cmda = ["ssh", *self.sshargs, h, *list(map(shlex.quote, cmd))]
                    else:
                        cmda = list(cmd)
                    subs[executor.submit(subrun, cmda, stdin)] = 1
                for future in concurrent.futures.as_completed(subs):
                    data = future.result()

        except Exception as e:
            print(str(e))
            raise e


    @staticmethod
    def genbdconfig(inports=[0,2,3,4,5,6,7], outports=[30], action="WAVEGEN_GOTO", wavegen_addressmap={}, hashxfers=[], acl=[]):
        """Generate a BD configuration for wavegen.
        wavegen_addressmap is only relevant if action is WAVEGEN_GOTO.
        hashxfers is list of (name, class-with-bdrule or string with subs)
        acl is a list of lists, where the inner list is an (name, aclelements) and aclelements is an array of elements (minus zero and three) for a BD ACL
        """

        if isinstance(inports, int):
            newports = []
            for port in range(32):
                if ((1 << port) & inports):
                    newports.append(port)
            inports = newports

        config = "*INIT,\n*NOPRIVACY\n*NOSPEAKER_CONTROL\n"
        for p in inports:
            config += "*INPORT, %d\n"%p
        for p in outports:
            config += "*OUTPORT, %d\n"%p

        rtlist = {"BC":1}
        for name, xfer in hashxfers:
            if xfer.rtaddr1 is not None:
                rtlist[xfer.rtaddr1] = 1
            if xfer.rtaddr2 is not None:
                rtlist[xfer.rtaddr2] = 1
        for rt in rtlist:
            for p in inports:
                config += "*PORTMAP, %d, %s\n"%(p, rt)

        cnt = 0
        if hashxfers:
            config += "*HASH_ACTION, %s\n"%action
            for name, xfer in hashxfers:
                cnt += 1
                config += "# %s\n"%name
                address = wavegen_addressmap.get(name,cnt)
                if isinstance(xfer, str):
                    for p in inports:
                        config += xfer%(address, p)
                else:
                    config += "\n".join(xfer.bdrule(aux=address, ports=inports)) + "\n"


        for ac in acl:
            cnt += 1
            name, fields = ac
            address = wavegen_addressmap.get(name,cnt)
            newlist=map(str, [action, address] + list(fields[:2]) + [str(-1)] + list(fields[2:]))
            config += ("# %s\n"%name) + (",".join(newlist)) + "\n"
        return config


if __name__=='__main__':
#    x = busDefenderEffector(host=["localhost","hc13.l215"])
#    x.runcmd(["touch","/tmp/foo bar"])
#    x.runcmd(["touch","/tmp/bar foo"])
    x = busDefenderEffector(host=["localhost"])
    x.runcmd(["tee","/tmp/foo bar"],stdin="foo basr baz\n")
