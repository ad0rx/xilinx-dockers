#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020-2021 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -
#


# if __name__=='__main__':
#     from bd_1553gen import *
# else:
#     from ./ms1553 import (milstd_1553, milstd_1553_mode)


"""
Microcode generators for wavegen
"""

class mcode_word():
    """Take/evaluate a method and allow the resulting microcode to be displayed in a few different ways"""

    def __init__(self, method_name, *args, **keyw):
        """Provide a method name for execution, then parameterize it based on supplied arguments"""

        method = eval(method_name)
        # method(*args, format="word")
        self.cmd_txwrd = method(*args, **keyw, format="word")
        self.str_cmd = method(*args, **keyw, format="string")

    def __str__(self):
        return self.str_cmd

    @property
    def strhuman(self):
        """Return preferred microcode format to output this word"""
        return self.str_cmd

    @property
    def cmd_mcode(self):
        """Return preferred microcode format to output this word"""
        return [self.cmd_txwrd]

    @property
    def str_mcode(self):
        """Return preferred microcode format to output this word"""
        return self.str_cmd



class wavegen_code:
    """Microcode generator functions"""

    @staticmethod
    def halt(format="word"):
        """Generate a halt instruction"""
        if format not in ("word","string"):
            raise ValueError("Format must be word or string")
        if (format=="word"):
            word = 0xf << 28
        else:
            word = "HALT()"
        return word

    @staticmethod
    def outmask(mask,format="word"):
        """Generate a outmask instruction"""
        if format not in ("word","string"):
            raise ValueError("Format must be word or string")
        if (format=="word"):
            word = (0x5 << 28) | (mask & 0xFFFFFF)
        else:
            word = "OUTMASK(%x)"%mask
        return word

    @staticmethod
    def wait_us(usec, format="word"):
        """Generate wait for the specified number of ųsec -- may be fractional w/precision 10MHz
           Or a user writes to the interrupt goto register"""

        if format not in ("word","string"):
            raise ValueError("Format must be word or string")
        ticks = int(usec * 10)

        if (format=="word"):
            word = 0x23 << 24 | (ticks & 0xffffff)
        else:
            word = "SYNC_WAIT(%d)"%(ticks & 0xffffff)
        return word

    @staticmethod
    def wait_activity(lines, format="word"):
        """Wait for any of the specified lines to generate activity, even be it for the shortest amount of time
           Or a user writes to the interrupt goto register"""

        if format not in ("word","string"):
            raise ValueError("Format must be word or string")

        olines = 0
        if lines & 0xff800000:
            olines = (1<<23)
        olines |= lines & 0x7fffff

        if (format=="word"):
            word = 0x20 << 24 | olines
        else:
            word = "ActHI_WAIT(%x)"%olines
        return word

    @staticmethod
    def wait_idle(lines, format="word"):
        """Wait for any of the specified lines to go inactive, even be it for the shortest amount of time
           Or a user writes to the interrupt goto register"""

        if format not in ("word","string"):
            raise ValueError("Format must be word or string")

        olines = 0
        if lines & 0xff800000:
            olines = (1<<23)
        olines = lines & 0x7fffff

        if (format=="word"):
            word = 0x21 << 24 | olines
        else:
            word = "ActLOW_WAIT(%x)"%olines
        return word

    @staticmethod
    def wait_timed_activity(usec, lines, format="word"):
        """Wait for any of the specified lines to generate activity, or
           timeout in 1/10 of USec (max 409ųs) if activity is detected
           wavegen goes to the next instruction if a timeout is
           detected wavegen goes to the next + 1 instruction.  lines
           are lower 11 ports, no way to trigger on higher ports.
           Or a user writes to the interrupt goto register
        """

        if format not in ("word", "string"):
            raise ValueError("Format must be word or string")

        ticks = int(usec * 10) & 0xfff

        olines = lines & 0xfff

        if (format=="word"):
            word = 0x28 << 24 | ticks << 12 | olines
        else:
            word = "TimedActHI_WAIT(%x,%x)"%(ticks, olines)
        return word

    @staticmethod
    def wait_idlecnt(usec, format="word"):
        """Wait for any allowed input line to go inactive, for
        the continuous specified amount of time in usec
        (fractional possible w/10MHz precision) -- or a user to
        write to the interrupt goto register"""
        if format not in ("word","string"):
            raise ValueError("Format must be word or string")

        ticks = int(usec * 10)

        if (format=="word"):
            word = 0x25 << 24 | ticks
        else:
            word = "ActLowTick_WAIT(%x)"%ticks
        return word

    @staticmethod
    def wait_bitcnt(bitnum, format="word"):
        """Wait for the requested number of bits to go by (or a user
        to write to interrupt goto register)"""
        if format not in ("word","string"):
            raise ValueError("Format must be word or string")

        bitnum &= 0x1f

        if (format=="word"):
            word = 0x22 << 24 | bitnum
        else:
            word = "bitcnt_WAIT(%x)"%bitnum
        return word

    @staticmethod
    def wait_user(format="word"):
        """Wait for the user to place an address to GOTO in 0x83c00010"""
        if format not in ("word","string"):
            raise ValueError("Format must be word or string")

        if (format=="word"):
            word = 0x24 << 24
        else:
            word = "gotoPoke_WAIT()"
        return word

    @staticmethod
    def goto(address, relative=False, format="word"):
        """Generate a goto another microcode location"""
        if format not in ("word","string"):
            raise ValueError("Format must be word or string")
        if (format=="word"):
            word = (6 << 28)
            if relative:
                word |= 1 << 16
                if address < 0:
                    word |= 1 << 15
                word |= abs(address) & 0x7fff
            else:
                word |= address & 0xffff
        else:
            word = "GOTO("
            if relative:
                word += "R, %d)"%address
            else:
                word += "A, %d)"%address

        return word

    @staticmethod
    def txword(sync, data, parity=None, format="word"):
        """Generate a 1553 transmit word command"""
        if format not in ("word","string"):
            raise ValueError("Format must be word or string")
        if (format=="word"):
            word = (4 << 28) | ((1 << 24) if parity is not None else 0) | ((1 << 20) if parity else 0) | (int(not not sync) << 16) | (data & 0xffff)
        else:
            if parity is not None:
                parity = "1" if parity else "0"
            else:
                parity = "A"
            word = "TXWRD(%d, %d, %04x)"%(1 if parity else 0,int(not not sync),(data & 0xffff))
        return word

    @staticmethod
    def txvar(continuation, datarate, data, activity=None, format="word"):
        """Generate a single txvar word of 10 bits, with continuation set,
        expect txcont() words following this item.
        Data represents transmitting "high" (1) or "low" (0) if activity=1 for that bit.
        Transmit idle if activty=0.
        Datarate controls the length of a bit (datarate / 100MHz is bitlength, so 10 ns to ~2.5 ųs per bit.
        """
        if format not in ("word","string"):
            raise ValueError("Format must be word or string")
        if (datarate < 1 or datarate > 127):
            raise ValueError("Data rate must be between 1 and 127")
        if activity is None:
            activity |= 0x3ff
        else:
            activity &= 0x3ff

        if (format=="word"):
            contw = (1<<27) if continuation else 0
            word = (3 << 28) | contw | (datarate << 20) | (data & 0x3ff) << 10 | activity
        else:
            contw = "C" if continuation else "F"
            word = "TXVAR(%s,%d,%03x,%03x)"%(contw, datarate, data, activity)
        return word

    @staticmethod
    def txcont(continuation, data, activity=None, format="word"):
        """Generate a single tx continuation word of 15 bits, at whatever.
        with continuation set, expect more txcont() words following this item.
        Data represents transmitting "high" (1) or "low" (0) if activity=1 for that bit.
        Transmit idle if activty=0.
        """

        if format not in ("word","string"):
            raise ValueError("Format must be word or string")
        if activity is None:
            activity = 0x7fff
        else:
            activity &= 0x7fff

        if (format=="word"):
            contw = (1<<31) if continuation else 0
            word =  contw | (data << 15) | activity
        else:
            contw = "C" if continuation else "F"
            word = "CONT(%s,%04x,%04x)"%(contw, data, activity)
        return word

    @staticmethod
    def txfrag(continuation, datarate, data, activity=None, bits=8, format="word"):
        """Generate a single txfrag word of up to 8 bits of output at the specified output rate.
        with continuation set, expect txcont() words following this item.
        Data represents transmitting "high" (1) or "low" (0) if activity=1 for that bit.
        Transmit idle if activty=0.
        Datarate controls the length of a bit (datarate / 100MHz is bitlength, so 10 ns to ~2.5 ųs per bit.
        """
        if format not in ("word","string"):
            raise ValueError("Format must be word or string")
        if (datarate < 1 or datarate > 127):
            raise ValueError("Data rate must be between 1 and 127")
        if (bits < 1 or bits > 8):
            raise ValueError("Bits must be between 1 and 8")

        mask = (1 << bits) - 1

        if activity is None:
            activity = mask
        else:
            activity &= mask

        bits = 0 if bits == 8 else bits #TXFRG 8->0

        if (format=="word"):
            contw = (1<<27) if continuation else 0
            word = (1 << 28) | contw | (datarate << 20) | bits << 17 | (data & mask) << 8 | activity
        else:
            contw = "C" if continuation else "F"
            word = "TXFRG(%s,%d,%d,%02x,%02x)"%(contw, datarate, bits, data & mask, activity)
        return word

    @staticmethod
    def generate_tx(word, bits=40, datarate=50, format="word", activity=None):
        """Generate the necessary commands to output the $bits bits of data stored in word, at the rate defined by the multiplier.
        Datarate controls the length of a bit (datarate / 100MHz is bitlength, so 10 ns to ~2.5 ųs per bit, with the default 50 meaning .5 ųs per bit.
        """

        if format not in ("word","string"):
            raise ValueError("Format must be word or string")
        if (datarate < 1 or datarate > 127):
            raise ValueError("Data rate must be between 1 and 127")

        if activity is None:
            activity = (2**(bits+1))-1

        cwords = int(bits / 15)
        crem = bits % 15
        # print('bits=%bitscrem=%s', (bits, crem))
        if crem == 10:
            wantvar = 1
            wantfrg = 0
        if crem > 10:
            wantvar = 1
            wantfrg = 1
        if crem <= 8:
            wantfrg = 1
            wantvar = 0
        if crem == 9:
            wantfrg = 2
            wantvar = 0
        if crem == 0: # we need a train head
            wantfrg = 1
            wantvar = 1
            cwords -=1
            crem = 15

        Rbit = bits
        words = list()
        if wantvar == 1:
            Rbit -= 10
            crem -= 10
            mask = 0x3ff
            words.append( wavegen_code.txvar(cwords, datarate, (word >> Rbit) & mask, activity=(activity >> Rbit) & mask, format=format) )
        if wantfrg == 2:
            Rbit -= 8
            wantfrg -= 1
            crem -= 8
            words.append( wavegen_code.txfrag(cwords, datarate, word >> Rbit, activity=(activity >> Rbit), bits=8, format=format) )
        if wantfrg == 1:
            Rbit -= crem
            mask = (1 << crem) - 1
            #def txfrag(continuation, datarate, data, activity=None, bits=8, format="word"):
            words.append( wavegen_code.txfrag(cwords, datarate, (word >> Rbit) & mask, activity=(activity >> Rbit) & mask, bits=crem, format=format))

        while cwords > 0:
            Rbit -= 15
            cwords -= 1
            mask = 0x7fff
            words.append( wavegen_code.txcont(cwords, (word >> Rbit) & mask, activity=((activity >> Rbit) & mask), format=format) )

        return words



if __name__=='__main__':

     code = mcode_word('wavegen_code.halt')
     print('code str_mcode=%s' % code.str_mcode)
     print('code cmd_mcode=%s' % list(map(hex, code.cmd_mcode)))
