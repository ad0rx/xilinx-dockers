#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020-2021 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -
#

import argparse
import shlex
import subprocess
from bd_1553gen import *

normalcmd = milstd_1553_cmd(1, 0, 1, 1)
normaldata = milstd_1553_data(0xffff)
normalstatus = milstd_1553_status(1)
debugspike = wavegen_code.txfrag(0,30,2, bits=2)

testinfo={
    # Normal test -- real RT collides
    "normal": lambda x: normalcmd.cmd_mcode + normaldata.cmd_mcode + [ wavegen_code.wait_us(4) ] + normalstatus.cmd_mcode,
    # AIM cannot decode the cmdword/data gap and ignores it--then interprets status word as command
    "t1a": lambda x: normalcmd.cmd_mcode + [ wavegen_code.wait_us(.75) ] + normaldata.cmd_mcode + [ wavegen_code.wait_us(4) ] + normalstatus.cmd_mcode,
    # AIM can decode the cmdword/data gap and responds--causing collision
    "t1b": lambda x: normalcmd.cmd_mcode + [ wavegen_code.wait_us(.5) ] + normaldata.cmd_mcode + [ wavegen_code.wait_us(4) ] + normalstatus.cmd_mcode,
}

parser = argparse.ArgumentParser()
parser.add_argument('--verbose', action='count', help='Increasing levels of verbosity')
parser.add_argument('--onceonly', action='store_true', help='Send only one frame')
parser.add_argument('--host', default=None, help='Host to auto-execute program on (empty-string performs direct execution)', metavar="hostname or empty string for localhost")
parser.add_argument('--test', help='Specify status test',metavar="|".join(testinfo.keys()))
parser.add_argument('--outlines', default=0xff, type=lambda x: int(x, 0), help='Lines to transmit on', metavar='bitfield')
parser.add_argument('--inlines', default=0xff, type=lambda x: int(x, 0), help='Lines to listen on', metavar='bitfield')
parser.add_argument('--interframegap', default=10, type=float, help='Amount of ųs between frames (additive to intermsggap)', metavar='fractional microseconds')
parser.add_argument('--postrespidle', default=20, type=float, help='Amount of ųs after a response and before a next command', metavar='fractional microseconds')
parser.add_argument('--responsetimeout', default=12, type=float, help='Amount of ųs before a query times out and the system moves on', metavar='fractional microseconds')
parser.add_argument('--logtest', default=None, help='Specify (repeated arguments) logtest arguments', metavar='arguments')
parser.add_argument('--secure', action='store_true', help='Run wavegen on a BD that uses /secure')
parser.add_argument('--reset', action='store_true', help='Stop wavegen execution')
args = parser.parse_args()

if args.test not in testinfo:
    raise ValueError("Must specify --test from allowed list: %s"%("|".join(testinfo.keys())))

groupargs = {"standardBCResponseHandling":True, "BCResponseTimeout":args.responsetimeout, "BCPostResponseIdle":args.postrespidle, "standardBCResponseLines":args.inlines}

testvec = train_1553_BCRT_1(1, 2, [ 0xffff ])


p = wavegen_link(defaultlines=args.outlines)

p.addgroup("initial", preidle=args.interframegap)

p.addgroup("testvec1", train=testvec, follows="initial", **groupargs)

p.addgroup("test:"+args.test, cmds=testinfo[args.test](args.test), follows="testvec1", postgoto="testvec2", postdelay=args.postrespidle)

p.addgroup("testvec2", train=testvec, preidle=2, **groupargs)

bde = busDefenderEffector(args.host, secure=args.secure, logtest=args.logtest, verbose=args.verbose)
# Generate/execute programs
bde.runcmd(cmd=p.shellcmd(resetonly=args.reset), logtest=False)

if args.host is None or args.verbose:
    p.debugpoke(resetonly=args.reset)
    p.gotomap(resetonly=args.reset)

