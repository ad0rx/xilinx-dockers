#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020-2021 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -
#

import argparse
import shlex
import subprocess
from bd_1553gen import *


parser = argparse.ArgumentParser()
parser.add_argument('--verbose', action='count', help='Increasing levels of verbosity')
parser.add_argument('--onceonly', action='store_true', help='Send only one frame')
parser.add_argument('--host', default=None, help='Host to auto-execute program on (empty-string performs direct execution)')
parser.add_argument('-a','--logtest_arg', action='append', help='Specify (repeated arguments) logtest arguments')
parser.add_argument('--test', default='normal', help='Specify status test [normal,instrumentation,reserved1/2/3, dynamicbuscontrolacceptance,messageerror,busy,terminalflag]')
args = parser.parse_args()

if args.logtest_arg is None:
    args.logtest_arg = []


p = wavegen_link()
p.addgroup("init", predelay=-1, postgoto="init")

x = tn = train_1553().add(ms1553.milstd_1553_status(1))
for i in range(31):
    x.add(milstd_1553_data(i))

x = ti = train_1553().add(ms1553.milstd_1553_status(1,instrumentation=1))
for i in range(31):
    x.add(milstd_1553_data(i))

x = tr1 = train_1553().add(ms1553.milstd_1553_status(1,reserved=1))
for i in range(31):
    x.add(milstd_1553_data(i))

x = tr2 = train_1553().add(ms1553.milstd_1553_status(1,reserved=2))
for i in range(31):
    x.add(milstd_1553_data(i))

x = tr3 = train_1553().add(ms1553.milstd_1553_status(1,reserved=4))
for i in range(31):
    x.add(milstd_1553_data(i))

x = tdbca = train_1553().add(ms1553.milstd_1553_status(1,dynamicBusControlAcceptance=1))
for i in range(31):
    x.add(milstd_1553_data(i))

me = train_1553().add(ms1553.milstd_1553_status(1,messageError=1))
busy = train_1553().add(ms1553.milstd_1553_status(1,busy=1))
term = train_1553().add(ms1553.milstd_1553_status(1,terminalFlag=1))

cmdmap = {"normal": tn, "instrumentation": ti, "reserved1": tr1, "reserved2": tr2, "reserved3": tr3, "dynamicbuscontrolacceptance": tdbca, "messageerror": me, "busy": busy, "terminalflag": term}
if args.test not in cmdmap:
    raise ValueError("Invalid test type")


p.addgroup("1R3/31", predelay=4.5, train=cmdmap[args.test], standardBCResponseHandling=True, postgoto="init")
p.link()

addr = p.addresses["1R3/31"]
bdconfig="""*INIT,
*INPORT, 0
*INPORT, 2
*OUTPORT, 30
*NOSPEAKER_CONTROL
*PORTMAP, 30, BM
*PORTMAP, 0, BC
*PORTMAP, 2, BC
*PORTMAP, 0, 1
*PORTMAP, 2, 1
*PORTMAP, 0, 2
*PORTMAP, 2, 2
*PORTMAP, 0, 3
*PORTMAP, 2, 3
*HASH_ACTION, WAVEGEN_GOTO
*HASH_MATCH, 0x%x, rtbc, 31, 0, 1, 3, BC, 0
*HASH_MATCH, 0x%x, rtbc, 31, 2, 1, 3, BC, 0
"""%(addr, addr)

if args.host is not None:
    cmda = ["logtest"]+args.logtest_arg+["--config", "-"]
    cmda = map(shlex.quote, ["logtest"]+args.logtest_arg+["--config", "-"])
    if args.host == "":
        sp = subprocess.Popen(cmda, stdin=subprocess.PIPE)
    else:
        sp = subprocess.Popen(["ssh", "-oStrictHostKeyChecking=no", "-oConnectTimeout=2", args.host, *list(map(shlex.quote, cmda))], stdin=subprocess.PIPE)
    sp.communicate(input=bdconfig.encode('utf-8'))
    if sp.returncode != 0:
        raise subprocess.CalledProcessError(sp.returncode, "logtest %s"%args.host)
else:
    print(bdconfig)

if args.host is not None:
    p.execute(args.host)
else:
    p.debugpoke()
    p.gotomap()
