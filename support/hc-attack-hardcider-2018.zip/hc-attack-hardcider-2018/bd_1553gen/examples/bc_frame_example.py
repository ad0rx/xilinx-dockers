#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020-2021 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -
#

"""
example of bus controller frame
BC2RT requests for RTs
"""

if __name__=='__main__':
    from bd_1553gen import *
    # from ms1553 import (milstd_1553, milstd_1553_mode)
    # from wavegen_code import wavegen_code
else:
    from .ms1553 import (milstd_1553, milstd_1553_mode)
    from .wavegen_code import wavegen_code


if __name__=='__main__':
    waveGenIP = 'dixon1-a.l215.perspectalabs.com'
    waveGenKey = '~/.ssh/id_rsa'
    outMask = 0x1
    inMask = 0x1

    wg = wavegen('root@'+waveGenIP, key=waveGenKey, ports=outMask, inPorts=inMask)

    microcode = train_1553()
    microcode.add(mcode_word('wavegen_code.outmask', outMask))

    for rt in range(0,11):
        microcode.add(train_1553_RTBC_1(rt,1,2))
        microcode.add(mcode_word('wavegen_code.wait_us',1))
        microcode.add(mcode_word('wavegen_code.wait_timed_activity', 13, 0XFF))    # wavegen_code.wait_timed_activity(usec=13,lines=0XFF)
        microcode.add(mcode_word('wavegen_code.goto',2,relative=True))    # goto  wait for end of transmission if activity detected
        microcode.add(mcode_word('wavegen_code.goto',2,relative=True))    # goto - next CMD if no activity detected
        microcode.add(mcode_word('wavegen_code.wait_idlecnt',7)) # from activity detected

    microcode.add(mcode_word('wavegen_code.wait_us', 100))
    microcode.add(mcode_word('wavegen_code.goto',1,relative=False))

    wg.load(microcode.cmd_mcode, init=True)

    # print('microcode str_mcode=%s' % BCRT_1)
    # print('microcode str_mcode=%s' % BCRT_1.str_mcode)
    # print('microcode cmd_mcode=%s' % list(map(hex, BCRT_1.cmd_mcode)))

    wg.start()


    # p = wavegen_link()
    # p.addgroup("initial", train=train_1553_BCRT_1(1, 1, [ 0, 1, 2 ]), predelay=3)
    # p.addgroup("first", train=train_1553_BCRT_2(1), predelay=6, follows="initial", postgoto="initial")
    #
    # p = wavegen_link()
    # p.addgroup("initial", predelay=160)
    # p.addgroup("sync1", train=train_1553().add(milstd_1553_mode(1, codetxt="Transmit Status")), preidle=10, follows="initial")
    # p.addgroup("sync2", train=train_1553().add(milstd_1553_mode(2, codetxt="Transmit Status")), preidle=20, follows="sync1")
    # p.addgroup("sync3", train=train_1553().add(milstd_1553_mode(3, codetxt="Transmit Status")), preidle=30, follows="sync2", postgoto="initial")
    # p.addgroup("1R1/32", train=train_1553_BCRT_1(1, 1, [ 0 for j in range(32) ]), preidle=3, postgoto="initial")
    # p.addgroup("StatOK1", train=train_1553_BCRT_2(1), preidle=3, postgoto="initial")
    # p.addgroup("2R2/31", train=train_1553_BCRT_1(2, 2, [ 0xaaaa for j in range(31) ]), preidle=3, postgoto="initial")
    # p.addgroup("StatOK2", train=train_1553_BCRT_2(1), preidle=3, postgoto="initial")
    # p.addgroup("3R3/30", train=train_1553_BCRT_1(3, 3, [ 0x5555 for j in range(30) ]), preidle=3, postgoto="initial")
    # p.addgroup("StatOK3", train=train_1553_BCRT_2(1), preidle=3, postgoto="initial")
    # p.addgroup("1R1/32+Stat", train=train_1553_BCRT_1(1, 1, [ 0xffff for j in range(32) ]), preidle=3, postgoto="StatOK1")
    # memory = p.link()
    # p.debugpoke()
    # p.gotomap()