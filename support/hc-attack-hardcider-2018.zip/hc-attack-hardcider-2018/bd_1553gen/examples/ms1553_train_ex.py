#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020-2021 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -
#

from bd_1553gen import *

x = train_1553().add(ms1553.milstd_1553_cmd(8, 1, 2, 3))   \
    .add(ms1553.milstd_1553_status(8))                     \
    .add(ms1553.milstd_1553_data(0xface))                  \
    .add(ms1553.milstd_1553_mode(26, codetxt="Transmit Status"))

print(x)
print(str(x.str_txwrd))
print(str(x.cmd_txwrd))
print(x.listwavegen40)
print(list(map(hex, x.listwavegen40)))

for rate in [50,37,25,10,5,2,1]:
    obits = int(20*rate)
    print('bigwordM {}: bits={} {}'.format(rate, obits, x.bigwordM(rate)))

# print(x.bigwordM(50))
# print(x.bigwordMHz(2))

x = train_1553_BCRT_1(1, 2, [ 0xffff, 0x5555, 0xaaaa, 0 ])
print(x)
x = train_1553_BCRT_2(1)
print(x)

x = train_1553_BCBCAST_1(2, [ 0xfff0, 0x5550, 0xaaa0, 0xf ])
print(x)

x = train_1553_RTBC_1(1, 2, 4)
print(x)
x = train_1553_RTBC_2(1, [ 0xf0ff, 0x5055, 0xa0aa, 0xf00 ])
print(x)

x = train_1553_RTRT_1(1, 2, 3, 4, 4)
print(x)
x = train_1553_RTRT_2(3, [ 0xff0f, 0x5505, 0xaa0a, 0x0f0 ])
print(x)
x = train_1553_RTRT_3(1)
print(x)

x = train_1553_RTBCAST_1(2, 3, 4, 4)
print(x)
x = train_1553_RTBCAST_2(3, [ 0x0fff, 0x0555, 0x0aaa, 0xf000 ])
print(x)
print(x.listwavegen40)

x = train_1553_MODE_1(2, codetext="Transmit Vector Word")
print(x)
x = train_1553_MODE_1(2, subaddr=5, codetext="Transmit Vector Word")
print(x)
x = train_1553_MODE_2(2, contentlist=[0])
print(x)

print("Train BCRT: CMD(1R2/2) converted to 8MHz output")
x = train_1553_BCRT_1(1, 2, [ 0xffff, 0x5555 ])
x.train = list(map(lambda car: transform_1553(car, rateMHz=8), x.train))
print(x.str_mcode)

print("Train with bias applied to all elements")
x = train_1553_BCRT_1(1, 2, [ 0xffff, 0x5555 ])
x.train = list(map(lambda car: transform_1553(car, rateMHz=8).xform_bias("rise",magnitude=1/160), x.train))
print(x.str_mcode)
print(x.cmd_mcode)


foo = [
    Generic_1553MsgDef_Definition("addr_cmd", train_1553_BCRT_1, 13, 1, 0,
                                  [("prog_addr_loc",
                                    [
                                        ("prgm_addr_location", 0, 16),
                                    ])]),
    Generic_1553MsgDef_Definition("verify_load", train_1553_RTBC_2, 15, 1, 0,
                                  [("verify_data",
                                    [
                                        ("spare", 0, 8),
                                        ("verify_data", 0x8, 8),
                                    ])]),
]

class foort:
    _rtaddr = 1

for msg_def in foo:
    globals()[msg_def.name] = Specific_WordDef_Factory(foort, msg_def)

x = addr_cmd(prgm_addr_location=0xfeed)
print(x)
x = verify_load()
print(x)

print(str(ms1553_messageinfo("BCRT(1.2/32)")))
print(str(ms1553_messageinfo("BCRT(1.2/32)").bdrule()))
print(str(ms1553_messageinfo("BCRT(1.2/32)").bdrule(1,[2,3])))
print(str(ms1553_messageinfo("BCRT1(1.2/32)")))
print(str(ms1553_messageinfo("BCRT1(1.2/32)").instantiate()))
print(str(ms1553_messageinfo("BCRT1(1.2/32)[0xffff,52,0o342,0b110]").instantiate()))
print(str(ms1553_messageinfo("BCRT2(1.2/32)")))

print(str(ms1553_messageinfo("BCBCAST(.2/32)")))
print(str(ms1553_messageinfo("RTBC(1.2/3)")))
print(str(ms1553_messageinfo("RTRT(1.2/3,4.5)")))
print(str(ms1553_messageinfo("RTBCAST(.2/3,4.5)")))
print(str(ms1553_messageinfo("MODE(31, Synchronize)")))
print(str(ms1553_messageinfo("MODE(11.0,Transmit Vector Word)")))
print(str(ms1553_messageinfo("MODE(11.31, Transmit Vector Word)")))
print(str(ms1553_messageinfo("MODE(11, MODECODE{1,25})")))
