#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020-2021 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -
#

import fileinput
import re
from bd_1553gen import *

for line in fileinput.input():
    if 'poke' in line:
        m = re.search(r'poke 0x83c10000 -M ([^;]+)', line)
        line = m.group(1)
        print(line)
    args = line.rstrip().split()
    count=0
    cont = 0
    for word in args:
        msg, cont = wavegen_code_fromword.decompile(word, cont)
        print("%04x "%count+word+':'+msg)
        count += 1