#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020-2021 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -
#

from bd_1553gen import *


p = wavegen_link()
p.addgroup("init")
#p.addgroup("sync", train=train_1553().add(milstd_1553_mode(31, codetxt="Synchronize")), preidle=10, follows="init")
#follows="sync"
#for i in range(31):
#    this = "sync%d"%i
#    p.addgroup(this, train=train_1553().add(milstd_1553_mode(i, codetxt="Synchronize")), preidle=i+1, follows=follows)
#    follows = this
#p.addgroup("gotosync", follows=follows, postgoto="sync")

p.addgroup("maininit", preidle=14)
p.addgroup("main", follows="maininit")
p.addgroup("1R1/32", train=train_1553_BCRT_1(1, 1, [ 0x00 for j in range(4) ]), standardBCResponseHandling=True, follows="main")
p.addgroup("2R1/31", train=train_1553_BCRT_1(2, 1, [ 0xff for j in range(3) ]), standardBCResponseHandling=True, follows="1R1/32")
p.addgroup("3R1/30", train=train_1553_BCRT_1(3, 1, [ 0x55 for j in range(2) ]), standardBCResponseHandling=True, follows="2R1/31")
p.addgroup("4R1/29", train=train_1553_BCRT_1(4, 1, [ 0xaa for j in range(1) ]), standardBCResponseHandling=True, follows="3R1/30", postgoto="main")
# Bad code, revert
#p.addgroup("1R1/32", train=train_1553_BCRT_1(1, 1, [ 0x00 for j in range(32) ]), standardBCResponseHandling=True, follows="main")
#p.addgroup("2R1/31", train=train_1553_BCRT_1(2, 1, [ 0xff for j in range(31) ]), standardBCResponseHandling=True, follows="1R1/32")
#p.addgroup("3R1/30", train=train_1553_BCRT_1(3, 1, [ 0x55 for j in range(30) ]), standardBCResponseHandling=True, follows="2R1/31")
#p.addgroup("4R1/29", train=train_1553_BCRT_1(4, 1, [ 0xaa for j in range(29) ]), standardBCResponseHandling=True, follows="3R1/30", postgoto="main")
p.debugpoke()
print("Link map with gotos:");
p.gotomap()
