#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -

if __name__=='__main__':
    from bd_1553gen import *
    # from word_transform import transform_1553
    # from system_memory import SystemMemory
    # from wavegen_code import *
    # from ms1553_train import *
    # from ms1553 import *
else:
    from .word_transform import transform_1553
    from .system_memory import SystemMemory
    from .wavegen_code import *
    from .ms1553_train import *
    from .ms1553 import *
import subprocess

REMOTE = False
DEBUG = False

"""
Interface with wavegen local via memory pokes or remote via SSH
"""
class wavegen:
    """Interface for Bus Defender Wave Generation"""

    MC_RESET      = 0xff
    MC_NOOP       = 0
    MC_WAIT_SYNC  = 0b00100011 << 24

    # WavegenV4 VERSION >= 'h00000138 :memory registers

    MC_ADDR        = 0x83c00004
    MC_START_ADDR  = 0x83c00008
    MC_RESET_ADDR  = 0x83c0000C
    MC_CODEZERO    = 0x43c00024
    MC_PROGCOUNTER = 0x83c00014
    MC_GOTOPOKE    = 0x83c00010
    MC_INPORTS     = 0x43c00028


    OUTPUT_ADDR   = 0x43c000d4

    def __init__(self, ports=0xff ):
        if DEBUG: print('using local wavegen')
        self.outPorts = ports
        self.REMOTE = False
        self.getPokes = getPokes

    def __init__(self, wgTarget, key='~/.ssh/id_rsa', ports=0xff, inPorts=None, getPokes=False):
        if DEBUG: print('using remote wavegen ssh {} -i {} '.format(wgTarget,key))
        self.outPorts = ports
        self.wgTarget = wgTarget
        self.key = key
        self.REMOTE = True
        self.inPorts = inPorts
        self.getPokes = getPokes

    def init(self):
        if self.REMOTE:
            self.wgPokeList = []
            # MC_OUTLINES is replaced by CMD OUTMASK
            self.wgPokeList.append("poke 0x%x 0x%x" % (self.MC_RESET_ADDR, self.MC_RESET))
            if self.inPorts: self.wgPokeList.append("poke 0x%x 0x%x" % (self.MC_INPORTS, self.inPorts))
            # self.wgPokeList.append("poke 0x%x 0x%x" % (self.MC_OUTLINES, self.outPorts))
        else:
            self.microcode_len = 16
            self.microcode_mem = SystemMemory(self.MC_ADDR, self.microcode_len)
            self.microcode_mem.pokeword(self.MC_RESET_ADDR, self.MC_RESET) # reset
            if self.inPorts: self.microcode_mem.pokeword(self.MC_INPORTS, self.inPorts)
        # self.microcode_mem.pokeword(self.MC_OUTLINES, self.outPorts) # set out ports

    def loadTrain(self, train, init=True):
        if DEBUG: print('1553seq=%s'%train)
        return self.load(train.cmd_mcode, init=init)

    def load(self, words, init=True):

        if init: self.init() #reset the program and sets out mask
        self.to_wgCMD(words)
        if self.REMOTE:
            return self.SSH_load(self.wgPokeList)
        return 'local shared memory mode'


    def SSH_load(self, program):

        cmdSTR = ' && '.join(program)
        if self.getPokes: print('Pokes cmdSTR={}'.format(cmdSTR))
        p = subprocess.Popen('ssh -i "{}" {} "{} && echo -ne OK"'.format( self.key, self.wgTarget, cmdSTR), shell=True,
                             stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT)
        res = p.stdout.readlines()
        if DEBUG: print('remote stdout %s \n'%res)

        return cmdSTR

    def start(self, codeZero=False):
        if self.REMOTE:
            if codeZero:
                self.SSH_load(["poke 0x%x 0x%x" % (self.MC_CODEZERO, 1)])
                self.SSH_load(["poke 0x%x 0x%x" % (self.MC_START_ADDR, 1)])
            else:
                self.SSH_load(["poke 0x%x 0x%x" % (self.MC_START_ADDR, 1)])
        else:
            self.microcode_mem.pokeword(self.MC_CODEZERO, 1)
            self.microcode_mem.pokeword(self.MC_START_ADDR, 1)

    def reset(self):
        if self.REMOTE:
            self.SSH_load(["poke 0x%x 0x%x" % (self.MC_RESET_ADDR, self.MC_RESET)])
        else:
            self.microcode_mem.pokeword(self.MC_RESET_ADDR, self.MC_RESET) # reset



    def waveout(self, word):
        """Transfer a single microcode word to wavegen"""
        # import ms1553
        # print("Writing "+ms1553.milstd_1553.binX(word,32))
        if not self.REMOTE:
            self.microcode_mem.pokeword(self.MC_ADDR, word)
        else:
            self.wgPokeList.append("poke 0x%x 0x%x" % (self.MC_ADDR, word))

    def to_wgCMD(self, words):
        """Transfer a list of microcode words to wavegen"""
        if not isinstance(words, list):
            return self.waveout(words)
        #  self.outport_mem.repeated_pokeword(self.OUTPUT_ADDR, words)
        if self.REMOTE:
             self.wgPokeList.append('poke 0x%X '%(self.MC_ADDR)+''.join([' 0x%X'%word for word in words]))
        else:
            self.microcode_mem.repeated_pokeword(self.MC_ADDR, words)




if __name__=='__main__':


    # test power
    if True:
        microcode = train_1553()
        microcode.add(mcode_word('wavegen_code.outmask', 0x5))
        modulationBits = 10
    # for modulationBits in range(8,15):

        # for magnitudePerc in [0,101]:
        magnitudePerc = 10
        magnitude = magnitudePerc /100
        BCRT_1 = train_1553_BCRT_1(1, 1, [0xffff]*10)
        rateMhz = 100

        print ('>>>>>>>>>>>>>>>>>>>>>>>>>>>>> power magnitude %s'%magnitude)
        BCRT_1_EXP = train_1553()
        BCRT_1_EXP.train = list(map(lambda car: transform_1553(car, rateMHz=rateMhz), BCRT_1.train))
        [print('0x%s %s' % (i, milstd_1553_staticinfo.binX(i.rawword, i.obits))) for i in BCRT_1_EXP.train]
        # APPLY FILTER
        # trainPower = [100]+range(0,101,10)
        for idx, i in enumerate(BCRT_1_EXP.train):
            magnitude = 1 if idx == 0 else idx / 10
            print('word #%s setting power to %s'%(idx, magnitude))
            i.xform_power(magnitude,modulationBits=modulationBits)

        microcode.add(BCRT_1_EXP)
        microcode.add(mcode_word('wavegen_code.wait_us', 50))

    microcode.add(mcode_word('wavegen_code.halt'))


    # send 1usec spike
    if False:
        microcode = train_1553()

        for modulationMhz in range(5,21): #sweet 10 11
        # if True:
            #[100, 50, 20, 20, 10, 4, 2]
            rateMHz = 100
            spikeBits = rateMHz # 1uSec
            # modulationMhz = 5
            modulationBits = int(rateMHz/modulationMhz)


            # spike1 =  transform_1553(0)
            # spike1.outputrateMHz = spike1.rateMHz = 1
            # spike1.rawword = 0
            # spike1.obits = 1
            # spike1.rawmask = 1

            for dutyCyclePerc in range(0,101,10):

                # microcode.add(spike1)

                spike = transform_1553(0)
                spike.outputrateMHz = spike.rateMHz = rateMHz
                spike.rawword = spike.rawmask = (1 <<  int(spikeBits/2)) -1
                spike.obits = spikeBits
                spike.rawmask = (1 <<  spikeBits) -1
                modFullMask = 0

                # spike.rawmask = (1 << int(spikeBits / 2)) - 1

                # dutyCycle = 0.9
                dutyCycle = dutyCyclePerc/100
                modMask = (1 << int(modulationBits/2+modulationBits/2*dutyCycle)) -1
                # modMask = (1 << int( modulationBits / 2 * (1-dutyCycle))) - 1
                # modMask = 0
                # howManyOnes = int( modulationBits / 2 * (1-dutyCycle))
                # for pos in range (0,howManyOnes):
                #     modMask |= 1 << int(pos * modulationBits/howManyOnes)


                print(milstd_1553_staticinfo.binX(modMask, modulationBits))
                for pos in range(0, spike.obits, modulationBits):
                    modFullMask |= (modMask << pos)

                #spike.rawmask |= 1 << 99
                #spike.rawmask |= 1 << 9


                print('spike.rawmask=%s' % spike.rawword)
                print(milstd_1553_staticinfo.binX(modFullMask, spikeBits))
                print(milstd_1553_staticinfo.binX(spike.rawword, spikeBits))
                spike.rawword ^= modFullMask #flip bits in mask

                print(milstd_1553_staticinfo.binX(spike.rawword, spikeBits))



                # spike.rawmask = (1 <<  int(spikeBits/2)) -1

                microcode.add(spike)
                microcode.add(mcode_word('wavegen_code.wait_us', 1))
        microcode.add(mcode_word('wavegen_code.halt'))


    if False:
        #test all valid frequencies
        microcode = train_1553()
        for rateMhz in [100,50,20,20,10,4,2]:
            BCRT_1 = train_1553_BCRT_1(1, 1, [0xffff])
            BCRT_1.train = list(map(lambda car: transform_1553(car, rateMHz=rateMhz), BCRT_1.train))
            [print('0x%s %s' % (i, milstd_1553_staticinfo.binX(i.rawword, i.obits))) for i in BCRT_1.train]
            microcode.add(BCRT_1)
            microcode.add(mcode_word('wavegen_code.wait_us', 50))
        microcode.add(mcode_word('wavegen_code.halt'))



    if False:
    # test rate skew
        microcode = train_1553()
        for rateMhz in [100, 50, 20, 20, 10, 4, 2]:
            BCRT_1 = train_1553_BCRT_1(1, 1, [0xffff])
            for rateSkew in range(-3 , 4):
                print ('>>>>>>>>>>>>>>>>>>>>>>>>>>>>> rateSkew %s'%rateSkew)
                BCRT_1_EXP = train_1553()
                BCRT_1_EXP.train = list(map(lambda car: transform_1553(car, rateMHz=rateMhz), BCRT_1.train))
                [print('0x%s %s' % (i, milstd_1553_staticinfo.binX(i.rawword, i.obits))) for i in BCRT_1_EXP.train]
                # APPLY FILTER
                #[i.xform_multiplier_skew(magnitude=rateSkew) for i in BCRT_1_EXP.train]  # apply filter to train

                for i in BCRT_1_EXP.train:
                    try:
                        i.xform_multiplier_skew(magnitude=rateSkew)
                        # [i.xform_bias("rise", magnitude=magnitude) for i in BCRT_1_Trans.train]  # apply filter to train
                        [print('0x%s rate=%s bits=%s' % (i, i.outputrateMHz, i.obits)) for i in BCRT_1_EXP.train]

                        [print('0x%s %s' % (i, milstd_1553_staticinfo.binX(i.rawword, i.obits))) for i in
                         BCRT_1_EXP.train]
                        microcode.add(BCRT_1_EXP)
                    except ValueError as e:
                        microcode.add(mcode_word('wavegen_code.wait_us', 40))
                        print('transformation error=%s'%e)

                    microcode.add(mcode_word('wavegen_code.wait_us', 50))
            microcode.add(mcode_word('wavegen_code.wait_us', 50))
        microcode.add(mcode_word('wavegen_code.halt'))

    # #BCRT_1 = train_1553_BCRT_1(1, 0, [ 0xffff, 0xaaaa ])
    # BCRT_1 = train_1553_BCRT_1(1, 0, range(4))
    # BCRT_2 = train_1553_BCRT_2(1)
    #
    # BCRT_1_EXP = train_1553()
    # BCRT_1_EXP.train = list(map(lambda car: transform_1553(car, rateMHz=20), BCRT_1.train))
    # BCRT_2_EXP = train_1553()
    # BCRT_2_EXP.train = list(map(lambda car: transform_1553(car, rateMHz=20), BCRT_2.train))
    #
    # [print('0x%s %s'%(i,milstd_1553_staticinfo.binX(i.rawword,i.obits))) for i in BCRT_1_EXP.train]
    # [i.xform_bias("rise", magnitude=1/400) for i in BCRT_1_EXP.train] # apply filter to train
    # [print('0x%s %s' % (i, milstd_1553_staticinfo.binX(i.rawword, i.obits))) for i in BCRT_1_EXP.train]
    #
    # microcode = train_1553()
    #
    # microcode.add(BCRT_1)
    # microcode.add(mcode_word('wavegen_code.wait_us',6.5))
    # microcode.add(BCRT_2)
    # microcode.add(mcode_word('wavegen_code.wait_us', 15))
    # microcode.add(BCRT_1_EXP)
    # microcode.add(mcode_word('wavegen_code.wait_us',6.5))
    # microcode.add(BCRT_2_EXP)
    # microcode.add(mcode_word('wavegen_code.halt'))

    print('microcode str_mcode=%s' %microcode)
    print('microcode str_mcode=%s'%microcode.str_mcode)
    print('microcode cmd_mcode=%s'%list(map(hex, microcode.cmd_mcode)))

    wgTarget = 'root@dixon1-a.l215.perspectalabs.com'
    wg = wavegen(wgTarget, ports=0x05) #01=port 0  04=port2
    wg.load(microcode.cmd_mcode, init=True)
    wg.start(codeZero=True)



