#!/usr/bin/python3
#
# ++Copyright Peraton LABS GPR++
#
# Copyright (c) 2020 Peraton Labs
# All rights reserved.
#
# This Software contains proprietary information of Peraton Labs that
# shall be distributed, routed or made available solely to authorized
# persons having a need to know within Peraton Labs and the US
# Government, except with the written permission of Peraton Labs.
#
# - -Copyright Peraton LABS GPR- -

"""
Interface with system memory via memory peeks and pokes
"""

import mmap
import struct

class SystemMemory:
    """Handle memory maps of /dev/mem"""

    def __init__(self, base, len):
        self.pagemask = ~ (mmap.PAGESIZE - 1)
        self.base = base
        self.len = len
        self.end = base + len

        self.pagebase = base & self.pagemask
        self.pageend = ((self.end + mmap.PAGESIZE) & self.pagemask) - 1
        self.pagelen = self.pageend - self.pagebase

        self.devmem = open("/dev/mem", "r+b")
        self.mmap = mmap.mmap(self.devmem.fileno(), self.pagelen, offset=self.pagebase)

    def peekslice(self, addr, len):
        start = addr-self.pagebase
        return self.mmap[addr:addr+len]

    def pokeslice(self, addr, values, valsize=4):
        """Copy array of packed values of size valsize into memory"""
        start = addr-self.pagebase
        vlen = len(values)
        self.mmap[start:start+len]

    def peekword(self, addr):
        start = addr-self.pagebase
        preg = self.mmap[start:start+4]
        return struct.unpack("<L", preg)[0]

    def pokeword(self, addr, value):
        start = addr - self.pagebase
        preg = struct.pack("<L", value)
        self.mmap[start:start+4] = preg

    def repeated_pokeword(self, addr, values):
        start = addr-self.pagebase
        for value in values:
            preg = struct.pack("<L", value)
            self.mmap[start:start+4] = preg
