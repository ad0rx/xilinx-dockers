# Bus Defender Attack/Traffic Generation Tool

This is a project that helps form 1553 word, messages, and generation
programs using Bus Defender to send traffic.  This is designed to both
test Bus Defender and test the effectiveness of Bus Defender.

To Install:
cd to cloned dir
edit setup.py, remove 'os.' from all strings near line 15
make
